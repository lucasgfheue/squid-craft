# Juegos del Patio — mod para NeoForge 1.21.1

Minijuegos de supervivencia en una dimensión propia.
**Versión 0.1:** el complejo (dimensión nueva) y el dormitorio gigante: 306 camas en literas junto a las
paredes (la zona del portón queda libre), una plaza abierta en el centro con una rayuela gigante, y a los lados
del portón dos salas con puerta: **baños** (8 cubículos, 8 duchas y lavamanos con espejo) y **comedor**
(4 mesas largas con bancos, mostrador y cocina). Lo habitan 150 jugadores bot y dos vigilantes cuidan el portón.
Detrás del portón hay un pasillo por donde entra el comandante en la ceremonia de bienvenida y, al fondo,
la **Torre de los Juegos**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **una** de estas dos cosas a la raíz del repositorio:
   - el archivo `.zip` tal cual, **o**
   - todos los archivos de adentro del zip.
3. Si subiste el `.zip`, crea también el archivo `.github/workflows/compilar.yml`
   (botón *Add file → Create new file*, escribe esa ruta con las barras y pega el contenido del workflow).
   Si subiste los archivos sueltos, el workflow ya viene incluido.
4. Entra a la pestaña **Actions**: la compilación arranca sola (tarda unos minutos la primera vez).
5. Descarga el `.jar` desde **Releases → Última compilación** o desde la ejecución en **Actions → Artifacts**.

> Si la pestaña Actions pide permiso para ejecutar workflows, acéptalo.

### Los otros jugadores (bots)

En el dormitorio viven **150 jugadores controlados por el juego**, cada uno con su nombre y una de
48 skins distintas, todos con el uniforme negro del complejo. Pasean por la plaza, el comedor y los
baños, saludan cuando te acercas, se juntan a charlar con emoticones (`:D`, `jaja`, `♥`, `gg`, `xD`...),
se agachan y saltan como jugadores, a veces salen corriendo (y saltan mientras corren), dan saltitos
de alegría cuando charlan, y a veces se acuestan un rato en las literas de abajo.

Al entrar al complejo te ponen el **uniforme** (camisa, pantalón y zapatillas) si todavía no lo tienes.

### Los guardias

Los guardias llevan máscara de gas, uniforme azul marino y un casco del color de su rango. Cada rango tiene su
**símbolo de ajedrez** en el pecho y la espalda (y en el nombre, al mirarlos) y su arma:

| Rango | Símbolo | Color | Arma | Vida |
|---|---|---|---|---|
| Vigilante | ♟ peón | blanco | Porra (cuerpo a cuerpo) | 12 ❤ |
| Guardia | ♞ caballo | azul | Pistola (rápida) | 14 ❤ |
| Sargento | ♜ torre | rojo | Rifle (preciso, largo alcance) | 17 ❤ |
| Comandante | ♚ rey | dorado | Escopeta (5 perdigones) | 25 ❤ |

En la sala solo hay **dos vigilantes (blancos)**, uno a cada lado del portón. No patrullan ni pasean: se quedan
quietos mirando hacia la sala y solo giran la cabeza si alguien se les acerca. Si tienen que pelear, después
vuelven a su lugar. El **comandante** y los **sargentos** aparecen en la ceremonia de bienvenida; cualquier
rango se puede poner a mano con el huevo de guardia o con `/juegosdelpatio invocar`.

Son **neutrales**: solo atacan a quien los ataque (y avisan a los guardias cercanos), a quien lastime a un
jugador o a un bot cerca de ellos, y a los monstruos que se acerquen. No reaccionan a jugadores en creativo
ni en dificultad Pacífica. A veces sueltan su arma al morir.

**Las armas** también las puedes usar tú (están en la pestaña *Juegos del Patio* del modo creativo):
clic derecho para disparar. Gastan una **bala** por disparo (en creativo no). Balas: pepita de hierro +
pólvora → 8 balas.

### Calendario y ceremonia de bienvenida

Los días se cuentan como en el mundo normal (el mismo número de día que muestra F3).

- **Solo se puede entrar el día 0** (y después cada 6 días: 6, 12, 18...). Los demás días la invitación
  avisa que las puertas están cerradas y qué día vuelven a abrir. Salir se puede siempre.
- **Al atardecer del día de entrada** (hora 12500, como `/time set 12500`), si hay jugadores adentro,
  suena una campana y **se abre el portón grande**: la puerta sube y por el pasillo de atrás entra el
  **comandante** (dorado), escoltado por **cuatro sargentos** (rojos), dos de cada lado.
- Los bots dejan lo que están haciendo y se juntan frente al portón; los guardias de la sala se quedan
  quietos en sus puestos.
- El comandante da la bienvenida, se presenta y explica las reglas: **5 juegos** (uno por día), el
  **premio de 1.000 diamantes**, que se puede **votar para salir** y que el premio **se reparte entre todos
  los jugadores**. Después el desfile vuelve al pasillo y el portón se cierra.

Para probarla sin esperar: `/time set 12500` (pone el mundo en el día 0 al atardecer) o
`/juegosdelpatio ceremonia`. La cantidad de días, la hora, los juegos y el premio se cambian al principio
de `Complejo.java` (`CICLO_DIAS`, `HORA_CEREMONIA`, `JUEGOS`, `PREMIO_DIAMANTES`).

> Por ahora el comandante **anuncia** la votación y los juegos, pero todavía no están programados.

### Las noches

- **Un minuto después de la ceremonia** (y los otros días, al anochecer: hora 13000) **se apagan todas las
  luces** del dormitorio (salón, baños y comedor): lámparas, luces del techo y del piso, y **se sacan los
  faroles de las literas** (vuelven a la mañana). **Las únicas que quedan prendidas son los faroles que cuelgan
  del techo**, con una luz azul tenue (soul lanterns). Los baños, que no tienen faroles, quedan a oscuras.
- Los bots dejan lo que estén haciendo y **se acuestan en las literas de abajo** (cada uno busca una cama libre).
- **La noche dura 2 minutos.** Después se prenden las luces, los bots se levantan y **empieza el día
  siguiente** (el reloj del mundo normal también salta a la mañana). Después de un día de juego, el día
  siguiente es siempre el del juego que sigue: juego 1 → día 1, juego 2 → día 2 (aunque alguien haya atrasado el
  reloj, por ejemplo con `/time set day`, que en Minecraft vuelve al día 0).
- Dormir **no adelanta nada**. En el complejo solo te puedes acostar con las luces apagadas, y el juego te
  despierta a los pocos segundos.
- **Cada día nuevo aparece en la pantalla**: "Día 1", con lo que toca (día de entrada, o "Hoy: juego 1 de 5").

### La Torre de los Juegos

Al fondo del pasillo de los guardias hay una torre de 56 bloques de alto con una escalera que sube en espiral
pegada a las paredes. Cada 8 bloques hay un descanso con una **puerta numerada (1 a 5)**, una por juego,
con el número hecho de lámparas. En el medio queda el hueco abierto, con faroles colgando y el barrilete
del complejo dibujado en el piso.

Los juegos **no están detrás de las puertas**: cuando una puerta se abre, en su lugar aparece un **portal**
de luz que te lleva al juego de ese número, que está lejos, en otra parte del complejo (el juego N queda
alrededor de x = 1000·N, a 100 de altura). Así cada juego puede ser tan grande como haga falta. Los juegos 1,
2 y 3 ya tienen su arena; mientras un juego no está hecho (el 4 y el 5), ahí hay una plataforma provisoria con su
número y un **portal de vuelta** a la sala.

Para probarlo: `/juegosdelpatio porton abrir`, `/juegosdelpatio puerta 1 abrir`, sube hasta la puerta 1 y
entra al portal. `/juegosdelpatio puerta 1 cerrar` vuelve a poner la puerta. `/juegosdelpatio porton cerrar`
cierra el portón (quien esté en el pasillo o en la torre vuelve a la sala).

### El día de juego: Luz verde, luz roja

El día siguiente a la entrada (día 1, 7, 13...) es el primer juego:

1. **Un minuto después de que se prenden las luces**, si hay jugadores en el complejo, se abre el portón y
   entra el **comandante con sus cuatro sargentos**. Avisa que **el primer juego está por comenzar** y que hay
   que ir a la **puerta 1 de la torre**.
2. El desfile vuelve al pasillo, se abre la puerta 1 de la torre como portal y **el comandante sube hasta
   ella y entra**. **Los bots lo siguen**: cruzan el portón, suben la escalera y entran al portal (salen de a
   poco, no todos juntos); los sargentos marcan el camino. **Los jugadores no pueden cruzar el portal todavía**:
   la cuenta regresiva se ve arriba de la pantalla, y **cuando se termina el minuto, pasan todos juntos al
   juego** (con los bots que no llegaron). Después el portón y la puerta se cierran.
3. En la arena, el comandante habla desde su podio y **explica las reglas** (en el chat). Mientras tanto una
   barrera invisible no deja pasar la línea de salida.
4. **El juego dura 3 minutos**, con el tiempo en una barra arriba de la pantalla (verde o roja, según la luz)
   y cuántos faltan llegar. Al fondo está **el Vigía**, un gigante mecánico de 32 bloques, parado de espaldas:
   **luz verde, se avanza**. Cuando **se da vuelta y mira con su visor rojo, es luz roja: hay que quedarse
   quieto, y ni la cabeza se puede mover** (girar la cámara más de 3 grados también cuenta). Cada cambio aparece en grande en la pantalla, con un sonido, y en las luces de las paredes (una
   cada 50 bloques, para que siempre haya una a la vista aunque el gigante quede lejos). Al ponerse en rojo
   hay un instante para frenar; después, **a quien se mueva, el Vigía lo ve** (le tira un rayo rojo) **y queda
   eliminado**. Un mensaje te dice por qué: si te moviste, si moviste la cabeza o si te empujaron. Los bots
   también quedan con la cabeza quieta.
5. **Quien no cruza la meta antes de que se acabe el tiempo también queda eliminado.** Los eliminados
   **mueren y reaparecen en el mundo normal** (en su cama de allá, si tenían una; si no, en el spawn). Lo que
   llevaban queda tirado en la arena.
6. Los que pasaron vuelven a la sala. En la barra de arriba se ve todo el tiempo **cuántos llegaron a la
   meta** y cuántos faltan; al cruzar, te dice qué número llegaste.
7. **A los 10 segundos vuelve el comandante con sus escoltas** y dice cuántos cruzaron la meta, **cuántos
   quedaron eliminados** y **cuántos quedan en total**. **El premio sube 10 diamantes por cada eliminado**
   (jugador o bot), y el comandante dice a cuánto llegó.
8. **Votación: seguir jugando o irse.** En el chat aparecen dos botones, **[ SEGUIR ]** y **[ IRSE ]** (o
   escribe `/votar seguir` o `/votar irse`). Votan los jugadores que siguen en el complejo y también los bots
   (cuantos más eliminados hubo, más quieren irse). Hay un minuto, con el conteo en una barra. Gana la
   mayoría; si empatan, se sigue. **Mientras haya muchos bots (10 o más que jugadores), siempre gana seguir, pero
   por muy poco**: casi todo el minuto va ganando irse por uno o dos votos y, en los últimos 10 segundos ("¡Faltan
   los últimos votos!"), votan los indecisos y la dan vuelta por 1 a 4 votos (o empatan, y con empate se sigue). Con
   pocos bots, cada uno vota lo que quiere y puede ganar cualquiera. **Si gana irse, el premio se reparte entre todos los que quedan**
   (jugadores y bots): a los 10 segundos cada jugador recibe su parte en diamantes y vuelve a su mundo, y el
   premio vuelve a empezar en 1000. Si gana seguir, los juegos siguen (al día siguiente, el juego 2).
9. **La cena.** Si ganó seguir, cuando el comandante se va y se cierra el portón, **aparecen tres vigilantes
   (los de blanco) detrás del mostrador del comedor** con la comida. Suena una campana y una barra arriba
   cuenta cuántos ya tienen la suya. **A cada uno le dan un filete** (después del segundo juego, **una zanahoria y
   una papa cruda**): acércate al mostrador y te lo dan solo.
   **Los bots también van al comedor**, hacen fila y se comen el filete ahí mismo. Si en un minuto y medio
   alguien no vino, se lo llevan igual.
10. **Cuando todos tienen su comida, los vigilantes se van y al minuto se apagan las luces**: todos a dormir.
    La noche dura 2 minutos y amanece el día siguiente.

La arena es un patio gigante al aire libre, de noche: **100 bloques de ancho y 280 de largo** entre la
salida y la meta a cuadros, con carriles, una franja amarilla cada 50 bloques y paredes de 12 de alto con
reflectores. Se construye sola la primera vez (alrededor de x = 1000) y se mantiene cargada mientras se juega.

Los bots también juegan: unos caminan, otros corren, y de vez en cuando alguno no frena a tiempo. Los que
cruzan la meta pasean y festejan del otro lado. **Los bots eliminados no vuelven**; para reponerlos:
`/juegosdelpatio bots <cantidad>`. El día de juego no se puede salir con la invitación.

#### Correr cansa

En el primer juego, **correr cansa a los jugadores** (a los bots no; y en el segundo juego, Las sillas
musicales, no cansa a nadie): con el aire lleno puedes correr 3 segundos seguidos, y sin correr se recupera de a
poco. Si se vacía, **te cansas y no puedes correr por 5 segundos**.
Mientras se juega, **la barra verde de experiencia muestra tu aire**; cuando te cansas, la barra de comida
baja a 3 muslos (es lo que hace que Minecraft no te deje correr) y al descansar vuelve a como estaba. Al
terminar el juego, la barra de experiencia vuelve a ser la tuya. En la sala se corre normal.

**Y en el primer juego, correr da mucha más hambre** (unas 2,5 veces más que afuera: cada carrera de 3 segundos gasta
cerca de medio muslo). Si corres todo el juego llegas con hambre... y la cena es recién a la noche.

#### Nadie juega limpio

- **En este juego no se puede pegar** (ni a jugadores ni a bots): los golpes no hacen nada. Lo único que vale
  es **empujar: clic derecho con la mano vacía** sobre un bot o sobre otro jugador, **una vez cada 5 segundos**
  (la pantalla te avisa cuánto falta y cuándo puedes de nuevo; los bots esperan lo mismo). No saca vida, pero lo
  tira para atrás: **con la luz roja, se movió y queda eliminado** (tú no cuentas como que te moviste).
- El bot que empujas se enoja: en el juego te devuelve los empujones (con la luz roja no te persigue, solo te
  empuja si estás al lado). En la sala también se puede empujar, y ahí el bot enojado te pega.
- **Empujones de los bots.** Desde la segunda luz verde, algunos bots eligen a quién empujar: a cada jugador le toca uno
  (se le nota en la cara: `>:(`), y otros pocos le tienen ganas a otro bot. Con la luz verde se te pegan;
  con la roja, si quedaron al lado, **te empujan** y te mueves... y quedas eliminado (te avisa quién fue).
  Para salvarte, no dejes que se te acerquen. **Si corres, ellos también corren** (y un poco más rápido que tú)
  para no quedarse atrás; caminando también te alcanzan.
- **En la sala, si le pegas a un bot, te devuelve los golpes** un rato.
- **Rencor.** Si muere un bot al que le pegaste o empujaste (por ejemplo, porque lo empujaste con la luz
  roja), los demás lo vieron: por cada uno, dos bots más te van a querer empujar (hasta 7). Dura hasta que se
  cierra el mundo.
- **Pasando la meta estás a salvo**: ahí el Vigía no elimina a nadie, aunque te muevas con la luz roja. Si
  vuelves a la cancha (antes de la línea), te elimina como a cualquiera. Y cuando se acaba el tiempo, queda
  eliminado todo el que esté antes de la línea.
- **La meta.** Algunos de los bots que cruzan se quedan en la línea y **empujan fuerte para atrás al que quiere
  cruzar** (con la luz roja, eso lo elimina). Con la luz roja no pisan la cancha: empujan desde la meta al que
  tienen al lado.
- En la arena los guardias no se meten.

Para probarlo sin esperar: `/juegosdelpatio juego llamar` (todo, desde que entra el comandante) o
`/juegosdelpatio juego empezar` (directo a la arena, a las reglas). `/juegosdelpatio juego parar` lo corta y
todos vuelven a la sala sin que nadie quede eliminado.

### El segundo día de juego: Las sillas musicales

El día 2 del ciclo (2, 8, 14...) es el segundo juego. Empieza igual que el primero: **un minuto después de que
se prenden las luces vuelve el comandante con sus sargentos**, avisa que **el segundo juego está por comenzar** y
que el portal está en la **puerta 2 de la torre** (un tramo de escalera más arriba que la 1). Los bots lo siguen
y, cuando termina el minuto, todos pasan juntos al juego.

El juego es en un **salón de fiestas techado**: piso de parqué, paredes blancas con franjas de colores y notas
musicales dibujadas y arañas de faroles. Se juega **todos juntos en una ronda enorme**: en el centro hay un disco
negro como un vinilo gigante, con **un gramófono gigante** en el medio (de su bocina dorada salen las notas
mientras suena la música), y **lejos, cerca de las paredes, la pista blanca** por donde camina la gente.

1. El comandante explica las reglas desde su podio, en la entrada.
2. **Las sillas están en el centro**, en anillos alrededor del gramófono, mirando para afuera: **3 menos que la
   gente**. Siempre queda lugar para pasar entre las sillas y llegar a las de adentro. A todos se los pone en la
   pista, repartidos parejo alrededor, y en la pantalla dice qué ronda es, cuántos son y cuántas sillas hay.
3. **Suena la música** (una melodía hecha para el juego, con sonidos de bloque musical) durante 7 a 15
   segundos, y nadie sabe cuándo va a parar. **Mientras suena, todos caminan por la pista, alrededor del salón,
   como las agujas del reloj.** Si un jugador deja de caminar (o se va de la pista, por ejemplo para acercarse a
   las sillas), a los 2 segundos se le avisa y a los 5 **queda eliminado**. Los bots caminan solos.
4. **Cuando la música para** aparece en grande **¡A SENTARSE!** y **las luces del salón parpadean** unos 4
   segundos (se apagan y se prenden, con el clic de las luces) mientras todos corren: hay que **correr al centro
   y sentarse en una silla libre, con clic derecho en la silla** (estando cerca). **Hay 12 segundos para conseguir
   silla.** Mientras suena la música no se puede sentar nadie. Sentado, no te puedes levantar hasta que termine la
   ronda... pero te pueden sacar.
5. **Sacar a otro de la silla.** El que quedó parado puede sacar a uno que está sentado: **clic derecho sobre
   él varias veces** (con la mano vacía). Cada clic es un tirón; se ve una barrita en la pantalla (■■■□□□□□). Con
   8 tirones lo saca, y el que tiró se sienta en su lugar. **El que está sentado, para que no lo saquen, tiene que
   apretar la Z rápido**: cada Z aguanta un tirón (la tecla se puede cambiar en Opciones → Controles, "Aguantar").
   Si nadie tira por un rato, los tirones se aflojan solos. Los bots también lo hacen: los que se quedan sin silla
   van primero a sacar a los jugadores (de 5 a 7 tirones por segundo), y los que están sentados aguantan solos,
   unos más fuerte que otros.
6. **No hay segundos de pelea aparte:** todo pasa dentro de los mismos 12 segundos. Cuando ya no quedan sillas
   libres se avisa en la pantalla (y la barra de arriba se pone amarilla), pero el tiempo sigue corriendo igual:
   **a los 12 segundos quedan eliminados los que siguen parados**. Todos se levantan y vuelven a la pista.
7. **Son 3 rondas:** en la primera hay **3 sillas menos** que gente, en la segunda **5 menos** y en la tercera
   **7 menos** (se sacan las que sobran entre ronda y ronda). Son **15 eliminados en total**; **los que quedan
   después de la tercera ronda pasan**. (Si fueran muy pocos, siempre queda por lo menos una silla.)
8. Después, como en el primer juego: todos vuelven a la sala, **el comandante vuelve con los resultados**
   (cuántos pasaron, cuántos quedaron eliminados, cuánto subió el premio), **se vota**, y si gana seguir **viene
   la cena: esta vez, una zanahoria y una papa cruda para cada uno** (los bots también se las comen) y a dormir.
   Al día siguiente, el tercer juego.

**Empujones:** en este juego tampoco se puede pegar, pero **se vale empujar** (clic derecho con la mano vacía,
una vez cada 5 segundos), jugadores y bots: sirve para sacar del medio al que va a la misma silla que tú. **El
empujado sale para atrás**, y por un momento (algo más de medio segundo) no se puede frenar ni sentarse: igual
cuando un bot te empuja a ti que cuando tú empujas a un bot (antes el bot se frenaba enseguida, o se sentaba en
la primera silla libre que le quedaba a mano). Los bots también empujan: al que va a la silla que quieren, al que
les hizo algo, y de vez en cuando, por molestar, al que tienen al lado mientras caminan. **Al que está sentado no
se lo puede empujar** (sí sacar de la silla, ver arriba). Si te empujan mientras suena la música, ese momento no
cuenta como que dejaste de caminar.

El parpadeo nunca pasa de 3 destellos por segundo. Si en **Opciones → Accesibilidad** tienes activado **"Ocultar
destellos de rayos"**, las luces no parpadean: el salón solo se oscurece un poco mientras dura.

**Los bots son difíciles.** Se dan cuenta al instante de que paró la música y corren a las sillas un poco más
rápido que un jugador corriendo, sin cansarse (en este juego a ti tampoco te cansa correr: puedes correr todo lo
que quieras, y la barra de experiencia es la tuya).
**Para cada jugador, los 2 bots más cercanos a la silla adonde va él van por esa misma silla** (se fijan para
dónde corres, y si cambias de silla, cambian ellos también) y, si te tienen al lado, te empujan. Los demás corren a
la silla libre más cercana, esquivando las otras. **Apenas tienen una silla libre al lado, se sientan.** Mientras
suena la música, al jugador que tienen al lado lo empujan bastante seguido. Si ya no quedan sillas libres, van a
sacar a alguien de su silla, primero a los jugadores, y sentados aguantan solos.

Para probarlo sin esperar: `/juegosdelpatio segundojuego` (desde que entra el comandante) o
`/juegosdelpatio juego empezar 2` (directo al salón, a las reglas).

### El tercer día de juego: Las escondidas

El día 3 del ciclo (3, 9, 15...) es el tercer juego. Empieza igual que los otros: **un minuto después de que se
prenden las luces vuelve el comandante**, avisa que **el tercer juego está por comenzar** y que el portal está en
la **puerta 3 de la torre** (un tramo de escalera más arriba que la 2). Los bots lo siguen y, cuando termina el
minuto, todos pasan juntos.

El juego es en una **escuela gigante, de noche** (150 × 120 bloques, paredes oscuras; en los pasillos, techo negro y
piso de baldosas blancas y naranjas): un pasillo con
casilleros que da toda la vuelta, **30 aulas** (bancos, pizarrón y un ropero), **baños** con cubículos,
**depósitos** llenos de barriles, el **gimnasio** (con gradas y su depósito), la **biblioteca** (estanterías
altas), el **comedor** con la cocina, el **salón de actos** (escenario con telón), la dirección, la enfermería y la
**sala de profesores**. En el medio está el **hall**, con el podio del comandante. Hay poca luz, y en los
escondites, menos.

1. El comandante explica las reglas desde el podio del hall.
2. **Se arman dos equipos al azar, mitad y mitad**: la mitad busca y la otra mitad se esconde (si son impares, se
   esconde uno más). En la pantalla te dice qué te tocó, y a cada uno le ponen su chaleco.
   **Después hay 1 minuto para cambiarse de equipo, en el hall** (nadie puede salir del hall todavía): hazle **clic
   derecho a uno del otro equipo** para pedirle cambiar; si él también te hace clic derecho, **se cambian** (de
   equipo y de chaleco) y todos se enteran por el chat. Si un bot te lo pide, viene hasta donde estás: hazle clic
   derecho para aceptar. Los bots contestan solos (a la mitad les gusta buscar y a la otra mitad esconderse: el que
   está en el equipo que no le gusta casi siempre acepta) y también se cambian entre ellos. En la barra de arriba se
   ve el tiempo que queda y cuántos cambios hubo. Los equipos siguen siendo mitad y mitad.
3. **Los buscadores esperan en la sala de profesores**, que tiene rejas en las puertas, **con los ojos cerrados**
   (ceguera), durante **1 minuto**. Mientras tanto, **los demás se esconden** por toda la escuela: hay más de 150
   escondites (roperos, cubículos de los baños, huecos entre las estanterías, debajo de las gradas, detrás del
   telón, casilleros vacíos, depósitos...).
4. **Se abren las rejas y los buscadores salen con una espada de netherite con filo V** (irrompible). Tienen
   **5 minutos** para encontrar a los que se esconden y **matarlos**. **Cada buscador tiene que matar al menos a
   uno: el que no mata a nadie queda eliminado al final.** Al que todavía no atrapó a nadie se le avisa cuando
   quedan 2 minutos y con un cartel en el último minuto (los bots que buscan, en el último minuto, van corriendo).
   **Está prohibido que los buscadores se maten entre ellos**: el golpe no hace nada y te avisa. Los que se esconden no pueden pelear: solo correr y empujar
   (clic derecho con la mano vacía).
5. En ese momento **se abre una de las 6 salidas al patio**, al azar; las otras siguen con rejas. Están en las
   puntas del pasillo y al norte y al sur, con una luz verde arriba. **El que se esconde y cruza la salida
   abierta, pasa**: aparece en el patio y espera ahí. Los buscadores no pueden salir.
6. **Cuando se termina el tiempo, todos los que siguen vivos pasan**: los escondidos que nadie encontró, los que
   salieron y **los buscadores que atraparon al menos a uno** (los que no atraparon a nadie quedan eliminados en ese
   momento). Si ya no queda nadie escondido, termina antes.
7. Después: resultados, votación y la cena... que esta vez es especial (ver «La noche del pastel», más abajo).

**Para esconderte mejor:** agáchate (Shift) y quédate donde está oscuro. Así no se ve tu nombre a través de las
paredes y a los bots les cuesta mucho más verte. **Los bots que buscan ven desde muy lejos**: donde hay mucha luz,
hasta 56 bloques (44 con luz media, 32 con poca, 14 a oscuras); agachado, un poco menos, y corriendo, más. Ven casi
todo lo que tienen adelante y a los costados (también a través de vidrios y rejas), y si estás cerca te oyen aunque
no te miren (si corres, desde más lejos; agachado, casi nada). Cuando uno te ve, le aparece **«¡!»** arriba del
nombre y a ti te sale en la pantalla **«¡… te vio! ¡Corre!»**.

**Los bots que buscan, más inteligentes:** caminan mirando para los costados y, cuando se paran, para todos lados
(también para atrás). Si ven a alguien, **avisan a los otros buscadores** que estén cerca, que van corriendo para
ahí. Lo persiguen casi tan rápido como un jugador corriendo (5,3 bloques por segundo contra 5,6: el que corre bien
se les escapa, y saltando mientras corres, más); si se les pierde, lo siguen oyendo correr un ratito, van adonde lo
vieron por última vez y **revisan los escondites de alrededor**. A veces "oyen algo" y van a revisar escondites de
la zona donde hay un jugador escondido (no van derecho a él). Y le pegan con la espada (nunca a través de un vidrio
o una reja).

**Los bots que se esconden** corren a un escondite libre en el minuto para esconderse y se agachan ahí (y no se
les ve el nombre). Algunos, uno de cada tres, después se animan a buscar la salida: van de salida en salida hasta
encontrar la abierta. **Si un buscador los vio, está cerca o les pega** (o si tú buscas y los miras de frente),
**salen disparados, muy rápido** (unos 9 bloques y medio por segundo, de 2 y medio a 3 y medio segundos) a otro
escondite lejos y para el otro lado, o a la salida si ya la vieron. Después quedan **cansados** de 7 a 9 segundos: si
tienen que escaparse otra vez, corren más lento que tú, así que si los sigues, los alcanzas.

**Chalecos:** al repartir los equipos, a cada uno le ponen un chaleco: **amarillo el que busca** (con un ojo en la
espalda) y **violeta el que se esconde** (con una luna). No se lo puede sacar; al final le devuelven su camisa.

**Cuerpos:** al que encuentran **queda tirado en el piso**, boca arriba, con su skin y su chaleco, hasta que termina
el juego.

**Los dos trucos de los que se esconden:**

- **Hacerse el muerto (la G):** te tiras al piso **10 segundos** y te ves igual que un cuerpo de verdad (sin nombre
  ni nada). No te puedes mover; con la G otra vez te levantas antes. Después tienes que esperar **30 segundos** para
  volver a hacerlo. Los bots que buscan **no se dan cuenta, salvo los que te vieron tirarte**; y si uno pasa justo
  al lado, a veces (3 de cada 10) nota que respiras. Si te pegan, te levantas (y te encontraron). Los jugadores que
  buscan pueden pegarle a un cuerpo para salir de dudas. Los bots que se esconden también lo hacen: cuando viene un
  buscador que todavía no los vio, a veces se tiran al piso.
- **Quitarle la espada a un buscador:** acércate **por la espalda** (agachado, para que no te oiga), **a un bloque**
  y sin que te vea, y **mantén el clic derecho** sobre él (con la mano vacía). Empieza un **forcejeo**, como en las
  sillas: cada tirón llena la barrita (■■■□□□□□□□) y **el buscador tiene que apretar la Z rápido** para aflojarla.
  Si la llenas, **le quitas la espada**: sin espada no puede atrapar a nadie, y **a los 30 segundos le traen otra**.
  Si se suelta (o pasan 8 segundos), te descubrió: ¡corre! (y tienes que esperar 4 segundos para volver a agarrar a
  alguien). Mientras lo tienes agarrado casi no se puede mover ni pegarte, pero los otros buscadores sí. Los bots que
  se esconden (uno de cada tres) también lo intentan, y los bots que buscan se resisten solos, unos más fuerte que
  otros. Las teclas se pueden cambiar en Opciones → Controles ("Hacerse el muerto" y "Aguantar").

La primera vez, la escuela tarda un momento en construirse. Para probarlo sin esperar:
`/juegosdelpatio tercerjuego` (desde que entra el comandante) o `/juegosdelpatio juego empezar 3` (directo al
hall, a las reglas).

### La noche del pastel (después del tercer juego)

Después de los resultados y la votación del tercer juego, **en la cena les dan a todos un pastel y una espada para
cortarlo** (el pastel se come así como viene, con clic derecho al aire; los bots se lo comen ahí mismo). Cuando
todos terminaron de comer:

1. **La pelea.** Dos bots se empiezan a pelear a las piñas frente al escenario y **todos los demás se juntan
   alrededor a mirar**. Uno de los dos muere (queda tirado en el piso).
2. **El apagón.** De repente **se apagan las luces**: todos a dormir (tú también te puedes acostar).
3. **El que ganó la pelea se levanta**, va **agachado, con la espada**, hasta uno que está durmiendo y **lo mata
   de un golpe**.
4. **La masacre: no tiene tiempo.** Las luces se prenden y **parpadean todo el rato** (nunca más de 3 destellos
   por segundo; con "Ocultar destellos de rayos" no parpadean). Todos se despiertan: **unos huyen y otros atacan con
   la espada a cualquiera que vean, a ti también** (y si no ven a nadie, salen a buscar); al que huye y le pegan, a
   veces se defiende. Tú puedes pelear o esconderte. Los guardias de la sala no se meten. El que muere queda tirado
   en el piso y **eliminado** (el premio sube, como siempre). **No para hasta que murió la mitad de los que estaban
   en la cena** (bots y jugadores, contando al de la pelea y al que mataron dormido): al empezar se avisa en el chat
   cuántos tienen que morir, y cada muerte dice cuántos van (por ejemplo, 12/41). Si pasa un rato sin que muera
   nadie, se suman más bots a atacar; y si pasa un minuto y medio sin ninguna muerte (por ejemplo, porque quedan
   solo jugadores que no pelean), entran los guardias igual, para que nunca se trabe.
5. **Los guardias.** **Apenas murió la mitad** se deja de pelear, **las luces quedan prendidas**, el portón se abre
   y **entran corriendo el comandante, cuatro sargentos y cuatro guardias, apuntando con sus armas**. **Les quitan
   las espadas a todos** y desde ahí **está prohibido pelear** en la sala (hasta la mañana). El comandante dice
   cuántos murieron esa noche, **cuánto es el premio** y que **el cuarto juego está a punto de comenzar**, y se van.
   Al minuto se apagan las luces y es una noche como cualquier otra.

Si en la sala hay menos de 3 bots, no hay pelea: después de la cena la noche es como siempre.

El mod está en español aunque tengas Minecraft en inglés (o en otro idioma).

## Instalar

Copia `juegosdelpatio-0.1.0.jar` en la carpeta `mods` de tu instalación de NeoForge 1.21.1.

## Cómo se juega

- Fabrica la **Invitación**: papel + pepita de oro (sin forma, en la mesa de crafteo).
- **Clic derecho** con la invitación (el día 0, 6, 12...): despiertas en el dormitorio del complejo.
- **Clic derecho otra vez** dentro del complejo: vuelves al lugar exacto desde donde entraste (menos el día de juego).
- Puedes dormir en las literas: tu punto de aparición queda en el dormitorio.

La primera vez que alguien entra, el dormitorio se construye solo (puede tardar un segundo).

### Comandos (operadores / trucos activados)

| Comando | Qué hace |
|---|---|
| `/juegosdelpatio entrar` | Entra sin invitación (cualquier día) |
| `/juegosdelpatio salir` | Sale del complejo |
| `/juegosdelpatio reconstruir` | Vuelve a colocar el dormitorio y la torre, y crea 150 bots y los 2 vigilantes |
| `/juegosdelpatio bots <0-150>` | Reemplaza a los bots por la cantidad que digas |
| `/juegosdelpatio guardias <0-2>` | Vuelve a poner los vigilantes del portón (0 los saca) |
| `/juegosdelpatio invocar <rango>` | Pone un guardia fijo donde estás (`vigilante`, `guardia`, `sargento`, `comandante`) |
| `/juegosdelpatio ceremonia` | Empieza ahora la ceremonia de bienvenida |
| `/juegosdelpatio porton abrir` / `cerrar` | Abre o cierra el portón (camino al pasillo y a la torre) |
| `/juegosdelpatio puerta <1-5> abrir` / `cerrar` | Abre una puerta de la torre (aparece el portal a ese juego) o la cierra |
| `/juegosdelpatio primerjuego` | Aparece el comandante con sus sargentos y empieza el primer juego (igual que `juego llamar`) |
| `/juegosdelpatio segundojuego` | Lo mismo con el segundo juego, Las sillas musicales (igual que `juego llamar 2`) |
| `/juegosdelpatio tercerjuego` | Lo mismo con el tercer juego, Las escondidas (igual que `juego llamar 3`) |
| `/juegosdelpatio juego llamar [1-3]` | Empieza ahora el día del juego 1, 2 o 3, desde que entra el comandante |
| `/juegosdelpatio juego empezar [1-3]` | Lleva a todos a la arena del juego 1, 2 o 3 y empieza con las reglas |
| `/juegosdelpatio juego parar` | Corta el juego: todos vuelven a la sala (nadie queda eliminado) |
| `/juegosdelpatio resultados` | Vuelve el comandante con los resultados del último juego, y se vota |
| `/juegosdelpatio comida` | Aparecen ya los tres vigilantes en el comedor y reparten la comida (después, a dormir) |
| `/votar seguir` / `/votar irse` | Votar (para cualquier jugador, cuando hay una votación) |
| `/give @s juegosdelpatio:invitacion` | Te da una invitación |
| `/give @s juegosdelpatio:huevo_jugador` | Huevo para poner un bot donde quieras |
| `/give @s juegosdelpatio:huevo_guardia` | Huevo de guardia (rango al azar) |

Si llamas a un juego con un comando otro día que no es el suyo (por ejemplo, el juego 1 el día de entrada), **el
calendario salta hacia adelante hasta el día de ese juego**, a la misma hora. Así, después de dormir, toca el
juego que sigue y el cartel dice el día que corresponde: juego 1 → día 1, y al día siguiente juego 2 → día 2.
El calendario nunca vuelve para atrás: repetir el juego 1 el día 2 lo lleva al día 1 del ciclo siguiente (7).

## Estructura del proyecto

| Ruta | Contenido |
|---|---|
| `src/main/java/com/juegosdelpatio/` | Código: registro, invitación, viaje entre dimensiones, comandos |
| `src/main/resources/data/juegosdelpatio/dimension*/` | La dimensión `juegosdelpatio:complejo` (vacía, noche fija) |
| `src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt` | Dormitorio, baños, comedor y pasillo de los guardias (65 × 21 × 102 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/torre.nbt` | La Torre de los Juegos (21 × 56 × 21 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/luz_verde.nbt` | La arena del juego 1, Luz verde, luz roja, con el Vigía (102 × 38 × 308 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/sillas.nbt` | El salón del juego 2, Las sillas musicales: la ronda enorme con el gramófono en el centro (81 × 18 × 97 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/escuela.nbt` | La escuela del juego 3, Las escondidas, con su patio (150 × 9 × 132 bloques) |
| `herramientas/gen_sala.py` | Script que genera `dormitorio.nbt` (cambia medidas, camas, luces...) |
| `herramientas/gen_torre.py` | Script que genera `torre.nbt` |
| `herramientas/gen_luz_verde.py` | Script que genera `luz_verde.nbt` |
| `herramientas/gen_sillas.py` | Script que genera `sillas.nbt` |
| `herramientas/gen_escondidas.py` | Script que genera `escuela.nbt` (y un plano visto desde arriba) |
| `herramientas/render.py` | Genera imágenes de vista previa de la sala |
| `herramientas/ceremonia_render.py` | Imagen de la ceremonia (portón abierto, desfile y público) |
| `herramientas/torre_render.py` | Imágenes de la torre |
| `herramientas/noche_render.py` | Imágenes de la sala de día y de noche, y de un portal abierto |
| `herramientas/luz_verde_render.py` | Imágenes de la arena de Luz verde, luz roja |
| `herramientas/sillas_render.py` | Imágenes del salón de Las sillas musicales |
| `herramientas/escondidas_render.py` | Plano de la escuela e imágenes de Las escondidas |
| `herramientas/chalecos.py` | Texturas e íconos de los chalecos de Las escondidas (amarillo y violeta) |
| `herramientas/masacre_render.py` | Imágenes de la noche del pastel (la pelea, el acecho, la masacre y los guardias) |
| `herramientas/portal_textura.py` | Dibuja la textura animada del portal |
| `herramientas/skins.py` | Dibuja las 48 skins de los bots y las texturas del uniforme |
| `herramientas/guardias.py` | Dibuja las skins de los 4 rangos de guardia, las armas y la bala |

Para regenerar la sala después de editar el script:

```
python3 herramientas/gen_sala.py src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt bloques.pkl
```

## Compilar en tu PC (opcional)

Con Java 21 instalado: `./gradlew build` (Windows: `gradlew.bat build`). El `.jar` queda en `build/libs/`.
