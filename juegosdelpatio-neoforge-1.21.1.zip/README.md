# Juegos del Patio — mod para NeoForge 1.21.1

Minijuegos de supervivencia en una dimensión propia.
**Versión 0.1:** el complejo (dimensión nueva) y el dormitorio gigante: 306 camas en literas junto a las
paredes (la zona del portón queda libre), una plaza abierta en el centro con una rayuela gigante, y a los lados
del portón dos salas con puerta: **baños** (8 cubículos, 8 duchas y lavamanos con espejo) y **comedor**
(4 mesas largas con bancos, mostrador y cocina). Lo habitan 150 jugadores bot y dos vigilantes cuidan el portón.
Detrás del portón hay un pasillo por donde entra el comandante en la ceremonia de bienvenida y, al fondo,
la **Torre de los Juegos**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **una** de estas dos cosas a la raíz del repositorio:
   - el archivo `.zip` tal cual, **o**
   - todos los archivos de adentro del zip.
3. Si subiste el `.zip`, crea también el archivo `.github/workflows/compilar.yml`
   (botón *Add file → Create new file*, escribe esa ruta con las barras y pega el contenido del workflow).
   Si subiste los archivos sueltos, el workflow ya viene incluido.
4. Entra a la pestaña **Actions**: la compilación arranca sola (tarda unos minutos la primera vez).
5. Descarga el `.jar` desde **Releases → Última compilación** o desde la ejecución en **Actions → Artifacts**.

> Si la pestaña Actions pide permiso para ejecutar workflows, acéptalo.

### Los otros jugadores (bots)

En el dormitorio viven **150 jugadores controlados por el juego**, cada uno con su nombre y una de
48 skins distintas, todos con el uniforme negro del complejo. Pasean por la plaza, el comedor y los
baños, saludan cuando te acercas, se juntan a charlar con emoticones (`:D`, `jaja`, `♥`, `gg`, `xD`...),
se agachan y saltan como jugadores, a veces salen corriendo (y saltan mientras corren), dan saltitos
de alegría cuando charlan, y a veces se acuestan un rato en las literas de abajo.

Al entrar al complejo te ponen el **uniforme** (camisa, pantalón y zapatillas) si todavía no lo tienes.

### Los guardias

Los guardias llevan máscara de gas, uniforme azul marino y un casco del color de su rango. Cada rango tiene su
**símbolo de ajedrez** en el pecho y la espalda (y en el nombre, al mirarlos) y su arma:

| Rango | Símbolo | Color | Arma | Vida |
|---|---|---|---|---|
| Vigilante | ♟ peón | blanco | Porra (cuerpo a cuerpo) | 12 ❤ |
| Guardia | ♞ caballo | azul | Pistola (rápida) | 14 ❤ |
| Sargento | ♜ torre | rojo | Rifle (preciso, largo alcance) | 17 ❤ |
| Comandante | ♚ rey | dorado | Escopeta (5 perdigones) | 25 ❤ |

En la sala solo hay **dos vigilantes (blancos)**, uno a cada lado del portón. No patrullan ni pasean: se quedan
quietos mirando hacia la sala y solo giran la cabeza si alguien se les acerca. Si tienen que pelear, después
vuelven a su lugar. El **comandante** y los **sargentos** aparecen en la ceremonia de bienvenida; cualquier
rango se puede poner a mano con el huevo de guardia o con `/juegosdelpatio invocar`.

Son **neutrales**: solo atacan a quien los ataque (y avisan a los guardias cercanos), a quien lastime a un
jugador o a un bot cerca de ellos, y a los monstruos que se acerquen. No reaccionan a jugadores en creativo
ni en dificultad Pacífica. A veces sueltan su arma al morir.

**Las armas** también las puedes usar tú (están en la pestaña *Juegos del Patio* del modo creativo):
clic derecho para disparar. Gastan una **bala** por disparo (en creativo no). Balas: pepita de hierro +
pólvora → 8 balas.

### Calendario y ceremonia de bienvenida

Los días se cuentan como en el mundo normal (el mismo número de día que muestra F3).

- **Solo se puede entrar el día 0** (y después cada 6 días: 6, 12, 18...). Los demás días la invitación
  avisa que las puertas están cerradas y qué día vuelven a abrir. Salir se puede siempre.
- **Al atardecer del día de entrada** (hora 12500, como `/time set 12500`), si hay jugadores adentro,
  suena una campana y **se abre el portón grande**: la puerta sube y por el pasillo de atrás entra el
  **comandante** (dorado), escoltado por **cuatro sargentos** (rojos), dos de cada lado.
- Los bots dejan lo que están haciendo y se juntan frente al portón; los guardias de la sala se quedan
  quietos en sus puestos.
- El comandante da la bienvenida, se presenta y explica las reglas: **5 juegos** (uno por día), el
  **premio de 1.000 diamantes**, que se puede **votar para salir** y que el premio **se reparte entre todos
  los jugadores**. Después el desfile vuelve al pasillo y el portón se cierra.

Para probarla sin esperar: `/time set 12500` (pone el mundo en el día 0 al atardecer) o
`/juegosdelpatio ceremonia`. La cantidad de días, la hora, los juegos y el premio se cambian al principio
de `Complejo.java` (`CICLO_DIAS`, `HORA_CEREMONIA`, `JUEGOS`, `PREMIO_DIAMANTES`).

> Por ahora el comandante **anuncia** la votación y los juegos, pero todavía no están programados.

### Las noches

- **Un minuto después de la ceremonia** (y los otros días, al anochecer: hora 13000) **se apagan todas las
  luces** del dormitorio (salón, baños y comedor): lámparas, luces del techo y del piso, y **se sacan los
  faroles de las literas** (vuelven a la mañana). **Las únicas que quedan prendidas son los faroles que cuelgan
  del techo**, con una luz azul tenue (soul lanterns). Los baños, que no tienen faroles, quedan a oscuras.
- Los bots dejan lo que estén haciendo y **se acuestan en las literas de abajo** (cada uno busca una cama libre).
- **La noche dura 2 minutos.** Después se prenden las luces, los bots se levantan y **empieza el día
  siguiente** (el reloj del mundo normal también salta a la mañana). Después de un día de juego, el día
  siguiente es siempre el del juego que sigue: juego 1 → día 1, juego 2 → día 2 (aunque alguien haya atrasado el
  reloj, por ejemplo con `/time set day`, que en Minecraft vuelve al día 0).
- Dormir **no adelanta nada**. En el complejo solo te puedes acostar con las luces apagadas, y el juego te
  despierta a los pocos segundos.
- **Cada día nuevo aparece en la pantalla**: "Día 1", con lo que toca (día de entrada, o "Hoy: juego 1 de 5").

### La Torre de los Juegos

Al fondo del pasillo de los guardias hay una torre de 56 bloques de alto con una escalera que sube en espiral
pegada a las paredes. Cada 8 bloques hay un descanso con una **puerta numerada (1 a 5)**, una por juego,
con el número hecho de lámparas. En el medio queda el hueco abierto, con faroles colgando y el barrilete
del complejo dibujado en el piso.

Los juegos **no están detrás de las puertas**: cuando una puerta se abre, en su lugar aparece un **portal**
de luz que te lleva al juego de ese número, que está lejos, en otra parte del complejo (el juego N queda
alrededor de x = 1000·N, a 100 de altura). Así cada juego puede ser tan grande como haga falta. Los juegos 1 y
2 ya tienen su arena; mientras un juego no está hecho (del 3 al 5), ahí hay una plataforma provisoria con su
número y un **portal de vuelta** a la sala.

Para probarlo: `/juegosdelpatio porton abrir`, `/juegosdelpatio puerta 1 abrir`, sube hasta la puerta 1 y
entra al portal. `/juegosdelpatio puerta 1 cerrar` vuelve a poner la puerta. `/juegosdelpatio porton cerrar`
cierra el portón (quien esté en el pasillo o en la torre vuelve a la sala).

### El día de juego: Luz verde, luz roja

El día siguiente a la entrada (día 1, 7, 13...) es el primer juego:

1. **Un minuto después de que se prenden las luces**, si hay jugadores en el complejo, se abre el portón y
   entra el **comandante con sus cuatro sargentos**. Avisa que **el primer juego está por comenzar** y que hay
   que ir a la **puerta 1 de la torre**.
2. El desfile vuelve al pasillo, se abre la puerta 1 de la torre como portal y **el comandante sube hasta
   ella y entra**. **Los bots lo siguen**: cruzan el portón, suben la escalera y entran al portal (salen de a
   poco, no todos juntos); los sargentos marcan el camino. **Los jugadores no pueden cruzar el portal todavía**:
   la cuenta regresiva se ve arriba de la pantalla, y **cuando se termina el minuto, pasan todos juntos al
   juego** (con los bots que no llegaron). Después el portón y la puerta se cierran.
3. En la arena, el comandante habla desde su podio y **explica las reglas** (en el chat). Mientras tanto una
   barrera invisible no deja pasar la línea de salida.
4. **El juego dura 3 minutos**, con el tiempo en una barra arriba de la pantalla (verde o roja, según la luz)
   y cuántos faltan llegar. Al fondo está **el Vigía**, un gigante mecánico de 32 bloques, parado de espaldas:
   **luz verde, se avanza**. Cuando **se da vuelta y mira con su visor rojo, es luz roja: hay que quedarse
   quieto, y ni la cabeza se puede mover** (girar la cámara más de 3 grados también cuenta). Cada cambio aparece en grande en la pantalla, con un sonido, y en las luces de las paredes (una
   cada 50 bloques, para que siempre haya una a la vista aunque el gigante quede lejos). Al ponerse en rojo
   hay un instante para frenar; después, **a quien se mueva, el Vigía lo ve** (le tira un rayo rojo) **y queda
   eliminado**. Un mensaje te dice por qué: si te moviste, si moviste la cabeza o si te empujaron. Los bots
   también quedan con la cabeza quieta.
5. **Quien no cruza la meta antes de que se acabe el tiempo también queda eliminado.** Los eliminados
   **mueren y reaparecen en el mundo normal** (en su cama de allá, si tenían una; si no, en el spawn). Lo que
   llevaban queda tirado en la arena.
6. Los que pasaron vuelven a la sala. En la barra de arriba se ve todo el tiempo **cuántos llegaron a la
   meta** y cuántos faltan; al cruzar, te dice qué número llegaste.
7. **A los 10 segundos vuelve el comandante con sus escoltas** y dice cuántos cruzaron la meta, **cuántos
   quedaron eliminados** y **cuántos quedan en total**. **El premio sube 10 diamantes por cada eliminado**
   (jugador o bot), y el comandante dice a cuánto llegó.
8. **Votación: seguir jugando o irse.** En el chat aparecen dos botones, **[ SEGUIR ]** y **[ IRSE ]** (o
   escribe `/votar seguir` o `/votar irse`). Votan los jugadores que siguen en el complejo y también los bots
   (cuantos más eliminados hubo, más quieren irse). Hay un minuto, con el conteo en una barra. Gana la
   mayoría; si empatan, se sigue. **Si gana irse, el premio se reparte entre todos los que quedan**
   (jugadores y bots): a los 10 segundos cada jugador recibe su parte en diamantes y vuelve a su mundo, y el
   premio vuelve a empezar en 1000. Si gana seguir, los juegos siguen (al día siguiente, el juego 2).
9. **La cena.** Si ganó seguir, cuando el comandante se va y se cierra el portón, **aparecen tres vigilantes
   (los de blanco) detrás del mostrador del comedor** con la comida. Suena una campana y una barra arriba
   cuenta cuántos ya tienen la suya. **A cada uno le dan un filete**: acércate al mostrador y te lo dan solo.
   **Los bots también van al comedor**, hacen fila y se comen el filete ahí mismo. Si en un minuto y medio
   alguien no vino, se lo llevan igual.
10. **Cuando todos tienen su comida, los vigilantes se van y al minuto se apagan las luces**: todos a dormir.
    La noche dura 2 minutos y amanece el día siguiente.

La arena es un patio gigante al aire libre, de noche: **100 bloques de ancho y 280 de largo** entre la
salida y la meta a cuadros, con carriles, una franja amarilla cada 50 bloques y paredes de 12 de alto con
reflectores. Se construye sola la primera vez (alrededor de x = 1000) y se mantiene cargada mientras se juega.

Los bots también juegan: unos caminan, otros corren, y de vez en cuando alguno no frena a tiempo. Los que
cruzan la meta pasean y festejan del otro lado. **Los bots eliminados no vuelven**; para reponerlos:
`/juegosdelpatio bots <cantidad>`. El día de juego no se puede salir con la invitación.

#### Correr cansa

En el juego, **correr cansa a los jugadores** (a los bots no): con el aire lleno puedes correr 3 segundos
seguidos, y sin correr se recupera de a poco. Si se vacía, **te cansas y no puedes correr por 5 segundos**.
Mientras se juega, **la barra verde de experiencia muestra tu aire**; cuando te cansas, la barra de comida
baja a 3 muslos (es lo que hace que Minecraft no te deje correr) y al descansar vuelve a como estaba. Al
terminar el juego, la barra de experiencia vuelve a ser la tuya. En la sala se corre normal.

**Y en el juego, correr da mucha más hambre** (unas 2,5 veces más que afuera: cada carrera de 3 segundos gasta
cerca de medio muslo). Si corres todo el juego llegas con hambre... y la cena es recién a la noche.

#### Nadie juega limpio

- **En este juego no se puede pegar** (ni a jugadores ni a bots): los golpes no hacen nada. Lo único que vale
  es **empujar: clic derecho con la mano vacía** sobre un bot o sobre otro jugador, **una vez cada 5 segundos**
  (la pantalla te avisa cuánto falta y cuándo puedes de nuevo; los bots esperan lo mismo). No saca vida, pero lo
  tira para atrás: **con la luz roja, se movió y queda eliminado** (tú no cuentas como que te moviste).
- El bot que empujas se enoja: en el juego te devuelve los empujones (con la luz roja no te persigue, solo te
  empuja si estás al lado). En la sala también se puede empujar, y ahí el bot enojado te pega.
- **Empujones de los bots.** Desde la segunda luz verde, algunos bots eligen a quién empujar: a cada jugador le toca uno
  (se le nota en la cara: `>:(`), y otros pocos le tienen ganas a otro bot. Con la luz verde se te pegan;
  con la roja, si quedaron al lado, **te empujan** y te mueves... y quedas eliminado (te avisa quién fue).
  Para salvarte, no dejes que se te acerquen. **Si corres, ellos también corren** (y un poco más rápido que tú)
  para no quedarse atrás; caminando también te alcanzan.
- **En la sala, si le pegas a un bot, te devuelve los golpes** un rato.
- **Rencor.** Si muere un bot al que le pegaste o empujaste (por ejemplo, porque lo empujaste con la luz
  roja), los demás lo vieron: por cada uno, dos bots más te van a querer empujar (hasta 7). Dura hasta que se
  cierra el mundo.
- **Pasando la meta estás a salvo**: ahí el Vigía no elimina a nadie, aunque te muevas con la luz roja. Si
  vuelves a la cancha (antes de la línea), te elimina como a cualquiera. Y cuando se acaba el tiempo, queda
  eliminado todo el que esté antes de la línea.
- **La meta.** Algunos de los bots que cruzan se quedan en la línea y **empujan fuerte para atrás al que quiere
  cruzar** (con la luz roja, eso lo elimina). Con la luz roja no pisan la cancha: empujan desde la meta al que
  tienen al lado.
- En la arena los guardias no se meten.

Para probarlo sin esperar: `/juegosdelpatio juego llamar` (todo, desde que entra el comandante) o
`/juegosdelpatio juego empezar` (directo a la arena, a las reglas). `/juegosdelpatio juego parar` lo corta y
todos vuelven a la sala sin que nadie quede eliminado.

### El segundo día de juego: Las sillas musicales

El día 2 del ciclo (2, 8, 14...) es el segundo juego. Empieza igual que el primero: **un minuto después de que
se prenden las luces vuelve el comandante con sus sargentos**, avisa que **el segundo juego está por comenzar** y
que el portal está en la **puerta 2 de la torre** (un tramo de escalera más arriba que la 1). Los bots lo siguen
y, cuando termina el minuto, todos pasan juntos al juego.

El juego es en un **salón de fiestas techado**: piso de parqué, paredes blancas con franjas de colores y notas
musicales dibujadas y arañas de faroles. Se juega **todos juntos en una ronda enorme**: en el centro hay un disco
negro como un vinilo gigante, con **un gramófono gigante** en el medio (de su bocina dorada salen las notas
mientras suena la música), y **lejos, cerca de las paredes, la pista blanca** por donde camina la gente.

1. El comandante explica las reglas desde su podio, en la entrada.
2. **Las sillas están en el centro**, en anillos alrededor del gramófono, mirando para afuera: **3 menos que la
   gente**. Siempre queda lugar para pasar entre las sillas y llegar a las de adentro. A todos se los pone en la
   pista, repartidos parejo alrededor, y en la pantalla dice qué ronda es, cuántos son y cuántas sillas hay.
3. **Suena la música** (una melodía hecha para el juego, con sonidos de bloque musical) durante 7 a 15
   segundos, y nadie sabe cuándo va a parar. **Mientras suena, todos caminan por la pista, alrededor del salón,
   como las agujas del reloj.** Si un jugador deja de caminar (o se va de la pista, por ejemplo para acercarse a
   las sillas), a los 2 segundos se le avisa y a los 5 **queda eliminado**. Los bots caminan solos.
4. **Cuando la música para** aparece en grande **¡A SENTARSE!** y **las luces del salón parpadean** unos 4
   segundos (se apagan y se prenden, con el clic de las luces) mientras todos corren: hay que **correr al centro
   y sentarse en una silla libre, con clic derecho en la silla** (estando cerca). Hay 12 segundos. Sentado no te pueden empujar y
   no te puedes levantar hasta que termine la ronda... pero te pueden sacar (ver abajo). Mientras suena la música
   no se puede sentar nadie.
5. **Sacar a otro de la silla.** El que quedó parado puede sacar a uno que está sentado: **clic derecho sobre
   él varias veces** (con la mano vacía). Cada clic es un tirón; se ve una barrita en la pantalla (■■■□□□□□). Con
   8 tirones lo saca, y el que tiró se sienta en su lugar. **El que está sentado, para que no lo saquen, tiene que
   apretar la Z rápido**: cada Z aguanta un tirón (la tecla se puede cambiar en Opciones → Controles, "Aguantar en
   la silla"). Si nadie tira por un rato, los tirones se aflojan solos. Los bots también lo hacen: los que se
   quedan sin silla tratan de sacar al que tienen más cerca (un poco más a los jugadores), y los que están
   sentados aguantan solos, unos más fuerte que otros.
6. **Cuando ya no quedan sillas libres hay 5 segundos para pelearlas**; después, **los que siguen parados
   quedan eliminados**. Todos se levantan y vuelven a la pista.
7. **Son 3 rondas:** en la primera hay **3 sillas menos** que gente, en la segunda **5 menos** y en la tercera
   **7 menos** (se sacan las que sobran entre ronda y ronda). Son **15 eliminados en total**; **los que quedan
   después de la tercera ronda pasan**. (Si fueran muy pocos, siempre queda por lo menos una silla.)
8. Después, como en el primer juego: todos vuelven a la sala, **el comandante vuelve con los resultados**
   (cuántos pasaron, cuántos quedaron eliminados, cuánto subió el premio), **se vota**, y si gana seguir **viene
   la cena** y a dormir.

**Empujones:** en este juego tampoco se puede pegar, pero **se vale empujar** (clic derecho con la mano vacía,
una vez cada 5 segundos), jugadores y bots: sirve para sacar del medio al que va a la misma silla que tú. Los
bots también empujan: al que va a la silla que quieren, al que les hizo algo, y de vez en cuando, por molestar,
al que tienen al lado mientras caminan. **Al que está sentado no se lo puede empujar.** Si te empujan mientras
suena la música, ese momento no cuenta como que dejaste de caminar.

El parpadeo nunca pasa de 3 destellos por segundo. Si en **Opciones → Accesibilidad** tienes activado **"Ocultar
destellos de rayos"**, las luces no parpadean: el salón solo se oscurece un poco mientras dura.

Los bots tardan un instante en darse cuenta de que paró la música (como mucho un cuarto de segundo) y corren a
la silla libre más cercana, esquivando las otras (si otro bot está más cerca de esa, buscan otra). **Apenas
tienen una silla libre al lado, se sientan** (cualquiera, no solo a la que iban). Correr cansa igual que en el primer juego
(3 segundos corriendo), así que la carrera desde la pista hasta las sillas se hace medio corriendo y medio
caminando.

Para probarlo sin esperar: `/juegosdelpatio segundojuego` (desde que entra el comandante) o
`/juegosdelpatio juego empezar 2` (directo al salón, a las reglas).

El mod está en español aunque tengas Minecraft en inglés (o en otro idioma).

## Instalar

Copia `juegosdelpatio-0.1.0.jar` en la carpeta `mods` de tu instalación de NeoForge 1.21.1.

## Cómo se juega

- Fabrica la **Invitación**: papel + pepita de oro (sin forma, en la mesa de crafteo).
- **Clic derecho** con la invitación (el día 0, 6, 12...): despiertas en el dormitorio del complejo.
- **Clic derecho otra vez** dentro del complejo: vuelves al lugar exacto desde donde entraste (menos el día de juego).
- Puedes dormir en las literas: tu punto de aparición queda en el dormitorio.

La primera vez que alguien entra, el dormitorio se construye solo (puede tardar un segundo).

### Comandos (operadores / trucos activados)

| Comando | Qué hace |
|---|---|
| `/juegosdelpatio entrar` | Entra sin invitación (cualquier día) |
| `/juegosdelpatio salir` | Sale del complejo |
| `/juegosdelpatio reconstruir` | Vuelve a colocar el dormitorio y la torre, y crea 150 bots y los 2 vigilantes |
| `/juegosdelpatio bots <0-150>` | Reemplaza a los bots por la cantidad que digas |
| `/juegosdelpatio guardias <0-2>` | Vuelve a poner los vigilantes del portón (0 los saca) |
| `/juegosdelpatio invocar <rango>` | Pone un guardia fijo donde estás (`vigilante`, `guardia`, `sargento`, `comandante`) |
| `/juegosdelpatio ceremonia` | Empieza ahora la ceremonia de bienvenida |
| `/juegosdelpatio porton abrir` / `cerrar` | Abre o cierra el portón (camino al pasillo y a la torre) |
| `/juegosdelpatio puerta <1-5> abrir` / `cerrar` | Abre una puerta de la torre (aparece el portal a ese juego) o la cierra |
| `/juegosdelpatio primerjuego` | Aparece el comandante con sus sargentos y empieza el primer juego (igual que `juego llamar`) |
| `/juegosdelpatio segundojuego` | Lo mismo con el segundo juego, Las sillas musicales (igual que `juego llamar 2`) |
| `/juegosdelpatio juego llamar [1-2]` | Empieza ahora el día del juego 1 (o 2), desde que entra el comandante |
| `/juegosdelpatio juego empezar [1-2]` | Lleva a todos a la arena del juego 1 (o 2) y empieza con las reglas |
| `/juegosdelpatio juego parar` | Corta el juego: todos vuelven a la sala (nadie queda eliminado) |
| `/juegosdelpatio resultados` | Vuelve el comandante con los resultados del último juego, y se vota |
| `/juegosdelpatio comida` | Aparecen ya los tres vigilantes en el comedor y reparten la comida (después, a dormir) |
| `/votar seguir` / `/votar irse` | Votar (para cualquier jugador, cuando hay una votación) |

Si llamas a un juego con un comando otro día que no es el suyo (por ejemplo, el juego 1 el día de entrada), **el
calendario salta hacia adelante hasta el día de ese juego**, a la misma hora. Así, después de dormir, toca el
juego que sigue y el cartel dice el día que corresponde: juego 1 → día 1, y al día siguiente juego 2 → día 2.
El calendario nunca vuelve para atrás: repetir el juego 1 el día 2 lo lleva al día 1 del ciclo siguiente (7).
| `/give @s juegosdelpatio:invitacion` | Te da una invitación |
| `/give @s juegosdelpatio:huevo_jugador` | Huevo para poner un bot donde quieras |
| `/give @s juegosdelpatio:huevo_guardia` | Huevo de guardia (rango al azar) |

## Estructura del proyecto

| Ruta | Contenido |
|---|---|
| `src/main/java/com/juegosdelpatio/` | Código: registro, invitación, viaje entre dimensiones, comandos |
| `src/main/resources/data/juegosdelpatio/dimension*/` | La dimensión `juegosdelpatio:complejo` (vacía, noche fija) |
| `src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt` | Dormitorio, baños, comedor y pasillo de los guardias (65 × 21 × 102 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/torre.nbt` | La Torre de los Juegos (21 × 56 × 21 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/luz_verde.nbt` | La arena del juego 1, Luz verde, luz roja, con el Vigía (102 × 38 × 308 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/sillas.nbt` | El salón del juego 2, Las sillas musicales: la ronda enorme con el gramófono en el centro (81 × 18 × 97 bloques) |
| `herramientas/gen_sala.py` | Script que genera `dormitorio.nbt` (cambia medidas, camas, luces...) |
| `herramientas/gen_torre.py` | Script que genera `torre.nbt` |
| `herramientas/gen_luz_verde.py` | Script que genera `luz_verde.nbt` |
| `herramientas/gen_sillas.py` | Script que genera `sillas.nbt` |
| `herramientas/render.py` | Genera imágenes de vista previa de la sala |
| `herramientas/ceremonia_render.py` | Imagen de la ceremonia (portón abierto, desfile y público) |
| `herramientas/torre_render.py` | Imágenes de la torre |
| `herramientas/noche_render.py` | Imágenes de la sala de día y de noche, y de un portal abierto |
| `herramientas/luz_verde_render.py` | Imágenes de la arena de Luz verde, luz roja |
| `herramientas/sillas_render.py` | Imágenes del salón de Las sillas musicales |
| `herramientas/portal_textura.py` | Dibuja la textura animada del portal |
| `herramientas/skins.py` | Dibuja las 48 skins de los bots y las texturas del uniforme |
| `herramientas/guardias.py` | Dibuja las skins de los 4 rangos de guardia, las armas y la bala |

Para regenerar la sala después de editar el script:

```
python3 herramientas/gen_sala.py src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt bloques.pkl
```

## Compilar en tu PC (opcional)

Con Java 21 instalado: `./gradlew build` (Windows: `gradlew.bat build`). El `.jar` queda en `build/libs/`.
