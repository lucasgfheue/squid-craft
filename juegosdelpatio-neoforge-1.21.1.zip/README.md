# Juegos del Patio — mod para NeoForge 1.21.1

Minijuegos de supervivencia en una dimensión propia.
**Versión 0.1:** el complejo (dimensión nueva) y el dormitorio gigante: 306 camas en literas junto a las
paredes (la zona del portón queda libre), una plaza abierta en el centro con una rayuela gigante, y a los lados
del portón dos salas con puerta: **baños** (8 cubículos, 8 duchas y lavamanos con espejo) y **comedor**
(4 mesas largas con bancos, mostrador y cocina). Lo habitan 150 jugadores bot y dos vigilantes cuidan el portón.
Detrás del portón hay un pasillo por donde entra el comandante en la ceremonia de bienvenida y, al fondo,
la **Torre de los Juegos**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **una** de estas dos cosas a la raíz del repositorio:
   - el archivo `.zip` tal cual, **o**
   - todos los archivos de adentro del zip.
3. Si subiste el `.zip`, crea también el archivo `.github/workflows/compilar.yml`
   (botón *Add file → Create new file*, escribe esa ruta con las barras y pega el contenido del workflow).
   Si subiste los archivos sueltos, el workflow ya viene incluido.
4. Entra a la pestaña **Actions**: la compilación arranca sola (tarda unos minutos la primera vez).
5. Descarga el `.jar` desde **Releases → Última compilación** o desde la ejecución en **Actions → Artifacts**.

> Si la pestaña Actions pide permiso para ejecutar workflows, acéptalo.

### Los otros jugadores (bots)

En el dormitorio viven **150 jugadores controlados por el juego**, cada uno con su nombre y una de
48 skins distintas, todos con el uniforme negro del complejo. Pasean por la plaza, el comedor y los
baños, saludan cuando te acercas, se juntan a charlar con emoticones (`:D`, `jaja`, `♥`, `gg`, `xD`...),
se agachan y saltan como jugadores, a veces salen corriendo (y saltan mientras corren), dan saltitos
de alegría cuando charlan, y a veces se acuestan un rato en las literas de abajo.

Al entrar al complejo te ponen el **uniforme** (camisa, pantalón y zapatillas) si todavía no lo tienes.

### Los guardias

Los guardias llevan máscara de gas, uniforme azul marino y un casco del color de su rango. Cada rango tiene su
**símbolo de ajedrez** en el pecho y la espalda (y en el nombre, al mirarlos) y su arma:

| Rango | Símbolo | Color | Arma | Vida |
|---|---|---|---|---|
| Vigilante | ♟ peón | blanco | Porra (cuerpo a cuerpo) | 12 ❤ |
| Guardia | ♞ caballo | azul | Pistola (rápida) | 14 ❤ |
| Sargento | ♜ torre | rojo | Rifle (preciso, largo alcance) | 17 ❤ |
| Comandante | ♚ rey | dorado | Escopeta (5 perdigones) | 25 ❤ |

En la sala solo hay **dos vigilantes (blancos)**, uno a cada lado del portón. No patrullan ni pasean: se quedan
quietos mirando hacia la sala y solo giran la cabeza si alguien se les acerca. Si tienen que pelear, después
vuelven a su lugar. El **comandante** y los **sargentos** aparecen en la ceremonia de bienvenida; cualquier
rango se puede poner a mano con el huevo de guardia o con `/juegosdelpatio invocar`.

Son **neutrales**: solo atacan a quien los ataque (y avisan a los guardias cercanos), a quien lastime a un
jugador o a un bot cerca de ellos, y a los monstruos que se acerquen. No reaccionan a jugadores en creativo
ni en dificultad Pacífica. A veces sueltan su arma al morir.

**Las armas** también las puedes usar tú (están en la pestaña *Juegos del Patio* del modo creativo):
clic derecho para disparar. Gastan una **bala** por disparo (en creativo no). Balas: pepita de hierro +
pólvora → 8 balas.

### Calendario y ceremonia de bienvenida

Los días se cuentan como en el mundo normal (el mismo número de día que muestra F3).

- **Solo se puede entrar el día 0** (y después cada 6 días: 6, 12, 18...). Los demás días la invitación
  avisa que las puertas están cerradas y qué día vuelven a abrir. Salir se puede siempre.
- **Al atardecer del día de entrada** (hora 12500, como `/time set 12500`), si hay jugadores adentro,
  suena una campana y **se abre el portón grande**: la puerta sube y por el pasillo de atrás entra el
  **comandante** (dorado), escoltado por **cuatro sargentos** (rojos), dos de cada lado.
- Los bots dejan lo que están haciendo y se juntan frente al portón; los guardias de la sala se quedan
  quietos en sus puestos.
- El comandante da la bienvenida, se presenta y explica las reglas: **5 juegos** (uno por día), el
  **premio de 1.000 diamantes**, que se puede **votar para salir** y que el premio **se reparte entre todos
  los jugadores**. Después el desfile vuelve al pasillo y el portón se cierra.

Para probarla sin esperar: `/time set 12500` (pone el mundo en el día 0 al atardecer) o
`/juegosdelpatio ceremonia`. La cantidad de días, la hora, los juegos y el premio se cambian al principio
de `Complejo.java` (`CICLO_DIAS`, `HORA_CEREMONIA`, `JUEGOS`, `PREMIO_DIAMANTES`).

> Por ahora el comandante **anuncia** la votación y los juegos, pero todavía no están programados.

### Las noches

- **Un minuto después de la ceremonia** (y los otros días, al anochecer: hora 13000) **se apagan todas las
  luces** del dormitorio (salón, baños y comedor): lámparas, luces del techo y del piso, y **se sacan los
  faroles de las literas** (vuelven a la mañana). **Las únicas que quedan prendidas son los faroles que cuelgan
  del techo**, con una luz azul tenue (soul lanterns). Los baños, que no tienen faroles, quedan a oscuras.
- Los bots dejan lo que estén haciendo y **se acuestan en las literas de abajo** (cada uno busca una cama libre).
- **La noche dura 5 minutos.** Después se prenden las luces, los bots se levantan y **empieza el día
  siguiente** (el reloj del mundo normal también salta a la mañana).
- Dormir **no adelanta nada**. En el complejo solo te puedes acostar con las luces apagadas, y el juego te
  despierta a los pocos segundos.
- **Cada día nuevo aparece en la pantalla**: "Día 1", con lo que toca (día de entrada, o "Hoy: juego 1 de 5").

### La Torre de los Juegos

Al fondo del pasillo de los guardias hay una torre de 56 bloques de alto con una escalera que sube en espiral
pegada a las paredes. Cada 8 bloques hay un descanso con una **puerta numerada (1 a 5)**, una por juego,
con el número hecho de lámparas. En el medio queda el hueco abierto, con faroles colgando y el barrilete
del complejo dibujado en el piso.

Los juegos **no están detrás de las puertas**: cuando una puerta se abre, en su lugar aparece un **portal**
de luz que te lleva al juego de ese número, que está lejos, en otra parte del complejo (el juego N queda
alrededor de x = 1000·N, a 100 de altura). Así cada juego puede ser tan grande como haga falta. Mientras un
juego no está hecho, ahí hay una plataforma provisoria con su número y un **portal de vuelta** a la sala.

Para probarlo: `/juegosdelpatio porton abrir`, `/juegosdelpatio puerta 1 abrir`, sube hasta la puerta 1 y
entra al portal. `/juegosdelpatio puerta 1 cerrar` vuelve a poner la puerta. `/juegosdelpatio porton cerrar`
cierra el portón (quien esté en el pasillo o en la torre vuelve a la sala).

### El día de juego: Luz verde, luz roja

El día siguiente a la entrada (día 1, 7, 13...) es el primer juego:

1. **Un minuto después de que se prenden las luces**, si hay jugadores en el complejo, se abre el portón y
   entra el **comandante con sus cuatro sargentos**. Avisa que **el primer juego está por comenzar** y que hay
   que ir a la **puerta 1 de la torre**.
2. El desfile vuelve al pasillo, se abre la puerta 1 de la torre como portal y **el comandante sube hasta
   ella y entra**. **Los bots lo siguen**: cruzan el portón, suben la escalera y entran al portal (salen de a
   poco, no todos juntos); los sargentos marcan el camino. **Hay un minuto para entrar** (la cuenta regresiva
   se ve arriba de la pantalla). **Cuando se termina el minuto, todos los que siguen en el complejo pasan solos
   al juego**, y el portón y la puerta se cierran.
3. En la arena, el comandante habla desde su podio y **explica las reglas** (en el chat). Mientras tanto una
   barrera invisible no deja pasar la línea de salida.
4. **El juego dura 3 minutos**, con el tiempo en una barra arriba de la pantalla (verde o roja, según la luz)
   y cuántos faltan llegar. Al fondo está **el Vigía**, un gigante mecánico de 32 bloques, parado de espaldas:
   **luz verde, se avanza**. Cuando **se da vuelta y mira con su visor rojo, es luz roja: hay que quedarse
   quieto**. Cada cambio aparece en grande en la pantalla, con un sonido, y en las luces de las paredes (una
   cada 50 bloques, para que siempre haya una a la vista aunque el gigante quede lejos). Al ponerse en rojo
   hay un instante para frenar; después, **a quien se mueva, el Vigía lo ve** (le tira un rayo rojo) **y queda
   eliminado**.
5. **Quien no cruza la meta antes de que se acabe el tiempo también queda eliminado.** Los eliminados
   **mueren y reaparecen en el mundo normal** (en su cama de allá, si tenían una; si no, en el spawn). Lo que
   llevaban queda tirado en la arena.
6. Los que pasaron vuelven a la sala.

La arena es un patio gigante al aire libre, de noche: **100 bloques de ancho y 280 de largo** entre la
salida y la meta a cuadros, con carriles, una franja amarilla cada 50 bloques y paredes de 12 de alto con
reflectores. Se construye sola la primera vez (alrededor de x = 1000) y se mantiene cargada mientras se juega.

Los bots también juegan: unos caminan, otros corren, y de vez en cuando alguno no frena a tiempo. Los que
cruzan la meta pasean y festejan del otro lado. **Los bots eliminados no vuelven**; para reponerlos:
`/juegosdelpatio bots <cantidad>`. El día de juego no se puede salir con la invitación.

#### Nadie juega limpio

- **En este juego no se puede pegar** (ni a jugadores ni a bots): los golpes no hacen nada. Lo único que vale
  es **empujar: clic derecho con la mano vacía** sobre un bot o sobre otro jugador, **una vez cada 5 segundos**
  (la pantalla te avisa cuánto falta y cuándo puedes de nuevo; los bots esperan lo mismo). No saca vida, pero lo
  tira para atrás: **con la luz roja, se movió y queda eliminado** (tú no cuentas como que te moviste).
- El bot que empujas se enoja: en el juego te devuelve los empujones (con la luz roja no te persigue, solo te
  empuja si estás al lado). En la sala también se puede empujar, y ahí el bot enojado te pega.
- **Empujones de los bots.** Desde la segunda luz verde, algunos bots eligen a quién empujar: a cada jugador le toca uno
  (se le nota en la cara: `>:(`), y otros pocos le tienen ganas a otro bot. Con la luz verde se te pegan;
  con la roja, si quedaron al lado, **te empujan** y te mueves... y quedas eliminado (te avisa quién fue).
  Para salvarte, no dejes que se te acerquen.
- **En la sala, si le pegas a un bot, te devuelve los golpes** un rato.
- **Rencor.** Si muere un bot al que le pegaste o empujaste (por ejemplo, porque lo empujaste con la luz
  roja), los demás lo vieron: por cada uno, dos bots más te van a querer empujar (hasta 7). Dura hasta que se
  cierra el mundo.
- **La meta.** Algunos de los bots que cruzan se quedan en la línea y **empujan fuerte para atrás al que quiere
  cruzar** (con la luz roja, eso lo elimina). Ellos ya cruzaron: a ellos no los elimina nadie.
- En la arena los guardias no se meten.

Para probarlo sin esperar: `/juegosdelpatio juego llamar` (todo, desde que entra el comandante) o
`/juegosdelpatio juego empezar` (directo a la arena, a las reglas). `/juegosdelpatio juego parar` lo corta y
todos vuelven a la sala sin que nadie quede eliminado.

## Instalar

Copia `juegosdelpatio-0.1.0.jar` en la carpeta `mods` de tu instalación de NeoForge 1.21.1.

## Cómo se juega

- Fabrica la **Invitación**: papel + pepita de oro (sin forma, en la mesa de crafteo).
- **Clic derecho** con la invitación (el día 0, 6, 12...): despiertas en el dormitorio del complejo.
- **Clic derecho otra vez** dentro del complejo: vuelves al lugar exacto desde donde entraste (menos el día de juego).
- Puedes dormir en las literas: tu punto de aparición queda en el dormitorio.

La primera vez que alguien entra, el dormitorio se construye solo (puede tardar un segundo).

### Comandos (operadores / trucos activados)

| Comando | Qué hace |
|---|---|
| `/juegosdelpatio entrar` | Entra sin invitación (cualquier día) |
| `/juegosdelpatio salir` | Sale del complejo |
| `/juegosdelpatio reconstruir` | Vuelve a colocar el dormitorio y la torre, y crea 150 bots y los 2 vigilantes |
| `/juegosdelpatio bots <0-150>` | Reemplaza a los bots por la cantidad que digas |
| `/juegosdelpatio guardias <0-2>` | Vuelve a poner los vigilantes del portón (0 los saca) |
| `/juegosdelpatio invocar <rango>` | Pone un guardia fijo donde estás (`vigilante`, `guardia`, `sargento`, `comandante`) |
| `/juegosdelpatio ceremonia` | Empieza ahora la ceremonia de bienvenida |
| `/juegosdelpatio porton abrir` / `cerrar` | Abre o cierra el portón (camino al pasillo y a la torre) |
| `/juegosdelpatio puerta <1-5> abrir` / `cerrar` | Abre una puerta de la torre (aparece el portal a ese juego) o la cierra |
| `/juegosdelpatio juego llamar` | Empieza ahora el día de juego, desde que entra el comandante |
| `/juegosdelpatio juego empezar` | Lleva a todos a la arena de Luz verde, luz roja y empieza con las reglas |
| `/juegosdelpatio juego parar` | Corta el juego: todos vuelven a la sala (nadie queda eliminado) |
| `/give @s juegosdelpatio:invitacion` | Te da una invitación |
| `/give @s juegosdelpatio:huevo_jugador` | Huevo para poner un bot donde quieras |
| `/give @s juegosdelpatio:huevo_guardia` | Huevo de guardia (rango al azar) |

## Estructura del proyecto

| Ruta | Contenido |
|---|---|
| `src/main/java/com/juegosdelpatio/` | Código: registro, invitación, viaje entre dimensiones, comandos |
| `src/main/resources/data/juegosdelpatio/dimension*/` | La dimensión `juegosdelpatio:complejo` (vacía, noche fija) |
| `src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt` | Dormitorio, baños, comedor y pasillo de los guardias (65 × 21 × 102 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/torre.nbt` | La Torre de los Juegos (21 × 56 × 21 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/luz_verde.nbt` | La arena del juego 1, Luz verde, luz roja, con el Vigía (102 × 38 × 308 bloques) |
| `herramientas/gen_sala.py` | Script que genera `dormitorio.nbt` (cambia medidas, camas, luces...) |
| `herramientas/gen_torre.py` | Script que genera `torre.nbt` |
| `herramientas/gen_luz_verde.py` | Script que genera `luz_verde.nbt` |
| `herramientas/render.py` | Genera imágenes de vista previa de la sala |
| `herramientas/ceremonia_render.py` | Imagen de la ceremonia (portón abierto, desfile y público) |
| `herramientas/torre_render.py` | Imágenes de la torre |
| `herramientas/noche_render.py` | Imágenes de la sala de día y de noche, y de un portal abierto |
| `herramientas/luz_verde_render.py` | Imágenes de la arena de Luz verde, luz roja |
| `herramientas/portal_textura.py` | Dibuja la textura animada del portal |
| `herramientas/skins.py` | Dibuja las 48 skins de los bots y las texturas del uniforme |
| `herramientas/guardias.py` | Dibuja las skins de los 4 rangos de guardia, las armas y la bala |

Para regenerar la sala después de editar el script:

```
python3 herramientas/gen_sala.py src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt bloques.pkl
```

## Compilar en tu PC (opcional)

Con Java 21 instalado: `./gradlew build` (Windows: `gradlew.bat build`). El `.jar` queda en `build/libs/`.
