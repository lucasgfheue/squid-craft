# Juegos del Patio — mod para NeoForge 1.21.1

Minijuegos de supervivencia en una dimensión propia.
**Versión 0.1:** el complejo (dimensión nueva) y el dormitorio gigante: 306 camas en literas junto a las
paredes (la zona del portón queda libre), una plaza abierta en el centro con una rayuela gigante, y a los lados
del portón dos salas con puerta: **baños** (8 cubículos, 8 duchas y lavamanos con espejo) y **comedor**
(4 mesas largas con bancos, mostrador y cocina). Lo habitan 150 jugadores bot y dos vigilantes cuidan el portón.
Detrás del portón hay un pasillo por donde entra el comandante en la ceremonia de bienvenida y, al fondo,
la **Torre de los Juegos**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **una** de estas dos cosas a la raíz del repositorio:
   - el archivo `.zip` tal cual, **o**
   - todos los archivos de adentro del zip.
3. Si subiste el `.zip`, crea también el archivo `.github/workflows/compilar.yml`
   (botón *Add file → Create new file*, escribe esa ruta con las barras y pega el contenido del workflow).
   Si subiste los archivos sueltos, el workflow ya viene incluido.
4. Entra a la pestaña **Actions**: la compilación arranca sola (tarda unos minutos la primera vez).
5. Descarga el `.jar` desde **Releases → Última compilación** o desde la ejecución en **Actions → Artifacts**.

> Si la pestaña Actions pide permiso para ejecutar workflows, acéptalo.

### Los otros jugadores (bots)

En el dormitorio viven **150 jugadores controlados por el juego**, cada uno con su nombre y una de
48 skins distintas, todos con el uniforme negro del complejo. Pasean por la plaza, el comedor y los
baños, saludan cuando te acercas, se juntan a charlar con emoticones (`:D`, `jaja`, `♥`, `gg`, `xD`...),
se agachan y saltan como jugadores, a veces salen corriendo (y saltan mientras corren), dan saltitos
de alegría cuando charlan, y a veces se acuestan un rato en las literas de abajo.

Al entrar al complejo te ponen el **uniforme** (camisa, pantalón y zapatillas) si todavía no lo tienes.

### Los guardias

Los guardias llevan máscara de gas, uniforme azul marino y un casco del color de su rango. Cada rango tiene su
**símbolo de ajedrez** en el pecho y la espalda (y en el nombre, al mirarlos) y su arma:

| Rango | Símbolo | Color | Arma | Vida |
|---|---|---|---|---|
| Vigilante | ♟ peón | blanco | Porra (cuerpo a cuerpo) | 12 ❤ |
| Guardia | ♞ caballo | azul | Pistola (rápida) | 14 ❤ |
| Sargento | ♜ torre | rojo | Rifle (preciso, largo alcance) | 17 ❤ |
| Comandante | ♚ rey | dorado | Escopeta (5 perdigones) | 25 ❤ |

En la sala solo hay **dos vigilantes (blancos)**, uno a cada lado del portón. No patrullan ni pasean: se quedan
quietos mirando hacia la sala y solo giran la cabeza si alguien se les acerca. Si tienen que pelear, después
vuelven a su lugar. El **comandante** y los **sargentos** aparecen en la ceremonia de bienvenida; cualquier
rango se puede poner a mano con el huevo de guardia o con `/juegosdelpatio invocar`.

Son **neutrales**: solo atacan a quien los ataque (y avisan a los guardias cercanos), a quien lastime a un
jugador o a un bot cerca de ellos, y a los monstruos que se acerquen. No reaccionan a jugadores en creativo
ni en dificultad Pacífica. A veces sueltan su arma al morir.

**Las armas** también las puedes usar tú (están en la pestaña *Juegos del Patio* del modo creativo):
clic derecho para disparar. Gastan una **bala** por disparo (en creativo no). Balas: pepita de hierro +
pólvora → 8 balas.

### Calendario y ceremonia de bienvenida

Los días se cuentan como en el mundo normal (el mismo número de día que muestra F3).

- **Solo se puede entrar el día 0** (y después cada 6 días: 6, 12, 18...). Los demás días la invitación
  avisa que las puertas están cerradas y qué día vuelven a abrir. Salir se puede siempre.
- **Al atardecer del día de entrada** (hora 12500, como `/time set 12500`), si hay jugadores adentro,
  suena una campana y **se abre el portón grande**: la puerta sube y por el pasillo de atrás entra el
  **comandante** (dorado), escoltado por **cuatro sargentos** (rojos), dos de cada lado.
- Los bots dejan lo que están haciendo y se juntan frente al portón; los guardias de la sala se quedan
  quietos en sus puestos.
- El comandante da la bienvenida, se presenta y explica las reglas: **5 juegos** (uno por día), el
  **premio de 1.000 diamantes**, que se puede **votar para salir** y que el premio **se reparte entre todos
  los jugadores**. Después el desfile vuelve al pasillo y el portón se cierra.

Para probarla sin esperar: `/time set 12500` (pone el mundo en el día 0 al atardecer) o
`/juegosdelpatio ceremonia`. La cantidad de días, la hora, los juegos y el premio se cambian al principio
de `Complejo.java` (`CICLO_DIAS`, `HORA_CEREMONIA`, `JUEGOS`, `PREMIO_DIAMANTES`).

> Por ahora el comandante **anuncia** la votación y los juegos, pero todavía no están programados.

### La Torre de los Juegos

Al fondo del pasillo de los guardias hay una torre de 56 bloques de alto con una escalera que sube en espiral
pegada a las paredes. Cada 8 bloques hay un descanso con una **puerta numerada (1 a 5)**, una por juego,
con el número hecho de lámparas. En el medio queda el hueco abierto, con faroles colgando y el barrilete
del complejo dibujado en el piso.

Por ahora las cinco puertas están cerradas: se van a abrir cuando programemos los juegos. Para visitarla,
`/juegosdelpatio porton abrir` y camina por el pasillo; `/juegosdelpatio porton cerrar` lo vuelve a cerrar
(quien esté en el pasillo o en la torre vuelve a la sala).

## Instalar

Copia `juegosdelpatio-0.1.0.jar` en la carpeta `mods` de tu instalación de NeoForge 1.21.1.

## Cómo se juega

- Fabrica la **Invitación**: papel + pepita de oro (sin forma, en la mesa de crafteo).
- **Clic derecho** con la invitación (el día 0, 6, 12...): despiertas en el dormitorio del complejo.
- **Clic derecho otra vez** dentro del complejo: vuelves al lugar exacto desde donde entraste.
- Puedes dormir en las literas: tu punto de aparición queda en el dormitorio.

La primera vez que alguien entra, el dormitorio se construye solo (puede tardar un segundo).

### Comandos (operadores / trucos activados)

| Comando | Qué hace |
|---|---|
| `/juegosdelpatio entrar` | Entra sin invitación (cualquier día) |
| `/juegosdelpatio salir` | Sale del complejo |
| `/juegosdelpatio reconstruir` | Vuelve a colocar el dormitorio y la torre, y crea 150 bots y los 2 vigilantes |
| `/juegosdelpatio bots <0-150>` | Reemplaza a los bots por la cantidad que digas |
| `/juegosdelpatio guardias <0-2>` | Vuelve a poner los vigilantes del portón (0 los saca) |
| `/juegosdelpatio invocar <rango>` | Pone un guardia fijo donde estás (`vigilante`, `guardia`, `sargento`, `comandante`) |
| `/juegosdelpatio ceremonia` | Empieza ahora la ceremonia de bienvenida |
| `/juegosdelpatio porton abrir` / `cerrar` | Abre o cierra el portón (camino al pasillo y a la torre) |
| `/give @s juegosdelpatio:invitacion` | Te da una invitación |
| `/give @s juegosdelpatio:huevo_jugador` | Huevo para poner un bot donde quieras |
| `/give @s juegosdelpatio:huevo_guardia` | Huevo de guardia (rango al azar) |

## Estructura del proyecto

| Ruta | Contenido |
|---|---|
| `src/main/java/com/juegosdelpatio/` | Código: registro, invitación, viaje entre dimensiones, comandos |
| `src/main/resources/data/juegosdelpatio/dimension*/` | La dimensión `juegosdelpatio:complejo` (vacía, noche fija) |
| `src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt` | Dormitorio, baños, comedor y pasillo de los guardias (65 × 21 × 102 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/torre.nbt` | La Torre de los Juegos (21 × 56 × 21 bloques) |
| `herramientas/gen_sala.py` | Script que genera `dormitorio.nbt` (cambia medidas, camas, luces...) |
| `herramientas/gen_torre.py` | Script que genera `torre.nbt` |
| `herramientas/render.py` | Genera imágenes de vista previa de la sala |
| `herramientas/ceremonia_render.py` | Imagen de la ceremonia (portón abierto, desfile y público) |
| `herramientas/torre_render.py` | Imágenes de la torre |
| `herramientas/skins.py` | Dibuja las 48 skins de los bots y las texturas del uniforme |
| `herramientas/guardias.py` | Dibuja las skins de los 4 rangos de guardia, las armas y la bala |

Para regenerar la sala después de editar el script:

```
python3 herramientas/gen_sala.py src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt bloques.pkl
```

## Compilar en tu PC (opcional)

Con Java 21 instalado: `./gradlew build` (Windows: `gradlew.bat build`). El `.jar` queda en `build/libs/`.
