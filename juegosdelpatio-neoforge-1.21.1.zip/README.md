# Juegos del Patio — mod para NeoForge 1.21.1

Minijuegos de supervivencia en una dimensión propia.
**Versión 0.1:** el complejo (dimensión nueva) y el dormitorio gigante: 306 camas en literas junto a las
paredes (la zona del portón queda libre), una plaza abierta en el centro con una rayuela gigante, y a los lados
del portón dos salas con puerta: **baños** (8 cubículos, 8 duchas y lavamanos con espejo) y **comedor**
(4 mesas largas con bancos, mostrador y cocina). Lo habitan 150 jugadores bot y dos vigilantes cuidan el portón.
Detrás del portón hay un pasillo por donde entra el comandante en la ceremonia de bienvenida y, al fondo,
la **Torre de los Juegos**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **una** de estas dos cosas a la raíz del repositorio:
   - el archivo `.zip` tal cual, **o**
   - todos los archivos de adentro del zip.
3. Si subiste el `.zip`, crea también el archivo `.github/workflows/compilar.yml`
   (botón *Add file → Create new file*, escribe esa ruta con las barras y pega el contenido del workflow).
   Si subiste los archivos sueltos, el workflow ya viene incluido.
4. Entra a la pestaña **Actions**: la compilación arranca sola (tarda unos minutos la primera vez).
5. Descarga el `.jar` desde **Releases → Última compilación** o desde la ejecución en **Actions → Artifacts**.

> Si la pestaña Actions pide permiso para ejecutar workflows, acéptalo.

### Los otros jugadores (bots)

En el dormitorio viven **150 jugadores controlados por el juego**, cada uno con su nombre y una de
48 skins distintas, todos con el uniforme negro del complejo. Pasean por la plaza, el comedor y los
baños, saludan cuando te acercas, se juntan a charlar con emoticones (`:D`, `jaja`, `♥`, `gg`, `xD`...),
se agachan y saltan como jugadores, a veces salen corriendo (y saltan mientras corren), dan saltitos
de alegría cuando charlan, y a veces se acuestan un rato en las literas de abajo.

Al entrar al complejo te ponen el **uniforme** (camisa, pantalón y zapatillas) si todavía no lo tienes.

### Los guardias

Los guardias llevan máscara de gas, uniforme azul marino y un casco del color de su rango. Cada rango tiene su
**símbolo de ajedrez** en el pecho y la espalda (y en el nombre, al mirarlos) y su arma:

| Rango | Símbolo | Color | Arma | Vida |
|---|---|---|---|---|
| Vigilante | ♟ peón | blanco | Porra (cuerpo a cuerpo) | 12 ❤ |
| Guardia | ♞ caballo | azul | Pistola (rápida) | 14 ❤ |
| Sargento | ♜ torre | rojo | Rifle (preciso, largo alcance) | 17 ❤ |
| Comandante | ♚ rey | dorado | Escopeta (5 perdigones) | 25 ❤ |

En la sala solo hay **dos vigilantes (blancos)**, uno a cada lado del portón. No patrullan ni pasean: se quedan
quietos mirando hacia la sala y solo giran la cabeza si alguien se les acerca. Si tienen que pelear, después
vuelven a su lugar. El **comandante** y los **sargentos** aparecen en la ceremonia de bienvenida; cualquier
rango se puede poner a mano con el huevo de guardia o con `/juegosdelpatio invocar`.

Son **neutrales**: solo atacan a quien los ataque (y avisan a los guardias cercanos), a quien lastime a un
jugador o a un bot cerca de ellos, y a los monstruos que se acerquen. No reaccionan a jugadores en creativo
ni en dificultad Pacífica. A veces sueltan su arma al morir.

**Las armas** también las puedes usar tú (están en la pestaña *Juegos del Patio* del modo creativo):
clic derecho para disparar. Gastan una **bala** por disparo (en creativo no). Balas: pepita de hierro +
pólvora → 8 balas.

### Calendario y ceremonia de bienvenida

Los días se cuentan como en el mundo normal (el mismo número de día que muestra F3).

- **Solo se puede entrar el día 0** (y después cada 8 días: 8, 16, 24...). Los demás días la invitación
  avisa que las puertas están cerradas y qué día vuelven a abrir. Salir se puede siempre.
- **Al atardecer del día de entrada** (hora 12500, como `/time set 12500`), si hay jugadores adentro,
  suena una campana y **se abre el portón grande**: la puerta sube y por el pasillo de atrás entra el
  **comandante** (dorado), escoltado por **cuatro sargentos** (rojos), dos de cada lado.
- Los bots dejan lo que están haciendo y se juntan frente al portón; los guardias de la sala se quedan
  quietos en sus puestos.
- El comandante da la bienvenida, se presenta y explica las reglas: **7 juegos** (uno por día), el
  **premio de 1.000 diamantes**, que se puede **votar para salir** y que el premio **se reparte entre todos
  los jugadores**. Después el desfile vuelve al pasillo y el portón se cierra.

Para probarla sin esperar: `/time set 12500` (pone el mundo en el día 0 al atardecer) o
`/juegosdelpatio ceremonia`. La cantidad de días, la hora, los juegos y el premio se cambian al principio
de `Complejo.java` (`CICLO_DIAS`, `HORA_CEREMONIA`, `JUEGOS`, `PREMIO_DIAMANTES`).

### Las noches

- **Un minuto después de la ceremonia** (y los otros días, al anochecer: hora 13000) **se apagan todas las
  luces** del dormitorio (salón, baños y comedor): lámparas, luces del techo y del piso, y **se sacan los
  faroles de las literas** (vuelven a la mañana). **Las únicas que quedan prendidas son los faroles que cuelgan
  del techo**, con una luz azul tenue (soul lanterns). Los baños, que no tienen faroles, quedan a oscuras.
- Los bots dejan lo que estén haciendo y **se acuestan en las literas de abajo** (cada uno busca una cama libre).
- **La noche dura 2 minutos.** Después se prenden las luces, los bots se levantan y **empieza el día
  siguiente** (el reloj del mundo normal también salta a la mañana). Después de un día de juego, el día
  siguiente es siempre el del juego que sigue: juego 1 → día 1, juego 2 → día 2 (aunque alguien haya atrasado el
  reloj, por ejemplo con `/time set day`, que en Minecraft vuelve al día 0).
- Dormir **no adelanta nada**. En el complejo solo te puedes acostar con las luces apagadas, y el juego te
  despierta a los pocos segundos.
- **Cada día nuevo aparece en la pantalla**: "Día 1", con lo que toca (día de entrada, o "Hoy: juego 1 de 7").

### La Torre de los Juegos

Al fondo del pasillo de los guardias hay una torre de 72 bloques de alto con una escalera que sube en espiral
pegada a las paredes. Cada 8 bloques hay un descanso con una **puerta numerada (1 a 7)**, una por juego,
con el número hecho de lámparas. En el medio queda el hueco abierto, con faroles colgando y el barrilete
del complejo dibujado en el piso.

Los juegos **no están detrás de las puertas**: cuando una puerta se abre, en su lugar aparece un **portal**
de luz que te lleva al juego de ese número, que está lejos, en otra parte del complejo. Así cada juego puede ser
tan grande como haga falta. **Los 7 juegos tienen su arena** (si faltara la de alguno, aparece una plataforma
provisoria con su número y un **portal de vuelta** a la sala).

Para probarlo: `/juegosdelpatio porton abrir`, `/juegosdelpatio puerta 1 abrir`, sube hasta la puerta 1 y
entra al portal. `/juegosdelpatio puerta 1 cerrar` vuelve a poner la puerta. `/juegosdelpatio porton cerrar`
cierra el portón (quien esté en el pasillo o en la torre vuelve a la sala).

### El día de juego: Luz verde, luz roja

El día siguiente a la entrada (día 1, 9, 17...) es el primer juego:

1. **Un minuto después de que se prenden las luces**, si hay jugadores en el complejo, se abre el portón y
   entra el **comandante con sus cuatro sargentos**. Avisa que **el primer juego está por comenzar** y que hay
   que ir a la **puerta 1 de la torre**.
2. El desfile vuelve al pasillo, se abre la puerta 1 de la torre como portal y **el comandante sube hasta
   ella y entra**. **Los bots lo siguen**: cruzan el portón, suben la escalera y entran al portal (salen de a
   poco, no todos juntos); los sargentos marcan el camino. **Los jugadores no pueden cruzar el portal todavía**:
   la cuenta regresiva se ve arriba de la pantalla, y **cuando se termina el minuto, pasan todos juntos al
   juego** (con los bots que no llegaron). Después el portón y la puerta se cierran.
3. En la arena, el comandante habla desde su podio y **explica las reglas** (en el chat). Mientras tanto una
   barrera invisible no deja pasar la línea de salida.
4. **El juego dura 3 minutos**, con el tiempo en una barra arriba de la pantalla (verde o roja, según la luz)
   y cuántos faltan llegar. Al fondo está **el Vigía**, un gigante mecánico de 32 bloques, parado de espaldas:
   **luz verde, se avanza**. Cuando **se da vuelta y mira con su visor rojo, es luz roja: hay que quedarse
   quieto, y ni la cabeza se puede mover** (girar la cámara más de 3 grados también cuenta). Cada cambio aparece en grande en la pantalla, con un sonido, y en las luces de las paredes (una
   cada 50 bloques, para que siempre haya una a la vista aunque el gigante quede lejos). Al ponerse en rojo
   hay un instante para frenar; después, **a quien se mueva, el Vigía lo ve** (le tira un rayo rojo) **y queda
   eliminado**. Un mensaje te dice por qué: si te moviste, si moviste la cabeza o si te empujaron. Los bots
   también quedan con la cabeza quieta.
5. **Quien no cruza la meta antes de que se acabe el tiempo también queda eliminado.** Los eliminados
   **mueren y reaparecen en el mundo normal** (en su cama de allá, si tenían una; si no, en el spawn). Lo que
   llevaban queda tirado en la arena.
6. Los que pasaron vuelven a la sala. En la barra de arriba se ve todo el tiempo **cuántos llegaron a la
   meta** y cuántos faltan; al cruzar, te dice qué número llegaste.
7. **A los 10 segundos vuelve el comandante con sus escoltas** y dice cuántos cruzaron la meta, **cuántos
   quedaron eliminados** y **cuántos quedan en total**. **El premio sube 10 diamantes por cada eliminado**
   (jugador o bot), y el comandante dice a cuánto llegó.
8. **Votación: seguir jugando o irse.** En el chat aparecen dos botones, **[ SEGUIR ]** y **[ IRSE ]** (o
   escribe `/votar seguir` o `/votar irse`). Votan los jugadores que siguen en el complejo y también los bots
   (cuantos más eliminados hubo, más quieren irse). Hay un minuto, con el conteo en una barra. Gana la
   mayoría; si empatan, se sigue. **Mientras haya muchos bots (10 o más que jugadores), siempre gana seguir, pero
   por muy poco**: casi todo el minuto va ganando irse por uno o dos votos y, en los últimos 10 segundos ("¡Faltan
   los últimos votos!"), votan los indecisos y la dan vuelta por 1 a 4 votos (o empatan, y con empate se sigue). Con
   pocos bots, cada uno vota lo que quiere y puede ganar cualquiera. **Si gana irse, el premio se reparte entre todos los que quedan**
   (jugadores y bots): a los 10 segundos cada jugador recibe su parte en diamantes y vuelve a su mundo, y el
   premio vuelve a empezar en 1000. Si gana seguir, los juegos siguen (al día siguiente, el juego 2).
9. **La cena.** Si ganó seguir, cuando el comandante se va y se cierra el portón, **aparecen tres vigilantes
   (los de blanco) detrás del mostrador del comedor** con la comida. Suena una campana y una barra arriba
   cuenta cuántos ya tienen la suya. **A cada uno le dan un filete** (después del segundo juego, **una zanahoria y
   una papa cruda**): acércate al mostrador y te lo dan solo.
   **Los bots también van al comedor**, hacen fila y se comen el filete ahí mismo. Si en un minuto y medio
   alguien no vino, se lo llevan igual.
10. **Cuando todos tienen su comida, los vigilantes se van y al minuto se apagan las luces**: todos a dormir.
    La noche dura 2 minutos y amanece el día siguiente.

La arena es un patio gigante al aire libre, de noche: **100 bloques de ancho y 280 de largo** entre la
salida y la meta a cuadros, con carriles, una franja amarilla cada 50 bloques y paredes de 12 de alto con
reflectores. Se construye sola la primera vez (alrededor de x = 1000) y se mantiene cargada mientras se juega.

Los bots también juegan: unos caminan, otros corren, y de vez en cuando alguno no frena a tiempo. Los que
cruzan la meta pasean y festejan del otro lado. **Los bots eliminados no vuelven**; para reponerlos:
`/juegosdelpatio bots <cantidad>`. El día de juego no se puede salir con la invitación.

#### Correr cansa

En el primer juego, **correr cansa a los jugadores** (a los bots no; y en el segundo juego, Las sillas
musicales, no cansa a nadie): con el aire lleno puedes correr 3 segundos seguidos, y sin correr se recupera de a
poco. Si se vacía, **te cansas y no puedes correr por 5 segundos**.
Mientras se juega, **la barra verde de experiencia muestra tu aire**; cuando te cansas, la barra de comida
baja a 3 muslos (es lo que hace que Minecraft no te deje correr) y al descansar vuelve a como estaba. Al
terminar el juego, la barra de experiencia vuelve a ser la tuya. En la sala se corre normal.

**Y en el primer juego, correr da mucha más hambre** (unas 2,5 veces más que afuera: cada carrera de 3 segundos gasta
cerca de medio muslo). Si corres todo el juego llegas con hambre... y la cena es recién a la noche.

#### Nadie juega limpio

- **En este juego no se puede pegar** (ni a jugadores ni a bots): los golpes no hacen nada. Lo único que vale
  es **empujar: clic derecho con la mano vacía** sobre un bot o sobre otro jugador, **una vez cada 5 segundos**
  (la pantalla te avisa cuánto falta y cuándo puedes de nuevo; los bots esperan lo mismo). No saca vida, pero lo
  tira para atrás: **con la luz roja, se movió y queda eliminado** (tú no cuentas como que te moviste).
- El bot que empujas se enoja: en el juego te devuelve los empujones (con la luz roja no te persigue, solo te
  empuja si estás al lado). En la sala también se puede empujar, y ahí el bot enojado te pega.
- **Empujones de los bots.** Desde la segunda luz verde, algunos bots eligen a quién empujar: a cada jugador le toca uno
  (se le nota en la cara: `>:(`), y otros pocos le tienen ganas a otro bot. Con la luz verde se te pegan;
  con la roja, si quedaron al lado, **te empujan** y te mueves... y quedas eliminado (te avisa quién fue).
  Para salvarte, no dejes que se te acerquen. **Si corres, ellos también corren** (y un poco más rápido que tú)
  para no quedarse atrás; caminando también te alcanzan.
- **En la sala, si le pegas a un bot, te devuelve los golpes** un rato.
- **Rencor.** Si muere un bot al que le pegaste o empujaste (por ejemplo, porque lo empujaste con la luz
  roja), los demás lo vieron: por cada uno, dos bots más te van a querer empujar (hasta 7). Dura hasta que se
  cierra el mundo.
- **Pasando la meta estás a salvo**: ahí el Vigía no elimina a nadie, aunque te muevas con la luz roja. Si
  vuelves a la cancha (antes de la línea), te elimina como a cualquiera. Y cuando se acaba el tiempo, queda
  eliminado todo el que esté antes de la línea.
- **La meta.** Algunos de los bots que cruzan se quedan en la línea y **empujan fuerte para atrás al que quiere
  cruzar** (con la luz roja, eso lo elimina). Con la luz roja no pisan la cancha: empujan desde la meta al que
  tienen al lado.
- En la arena los guardias no se meten.

Para probarlo sin esperar: `/juegosdelpatio juego llamar` (todo, desde que entra el comandante) o
`/juegosdelpatio juego empezar` (directo a la arena, a las reglas). `/juegosdelpatio juego parar` lo corta y
todos vuelven a la sala sin que nadie quede eliminado.

### El segundo día de juego: Asientos al vacío

El día 2 del ciclo (2, 10, 18...) es el segundo juego. Empieza igual que el primero: **un minuto después de que se
prenden las luces vuelve el comandante con sus sargentos**, avisa que **el segundo juego está por comenzar** y que el
portal está en la **puerta 2 de la torre**. Los bots lo siguen y, cuando termina el minuto, todos pasan juntos.

Es un juego nuevo, con un guiño a las sillas musicales. Se juega en **un campo de 24 torres altísimas** de piedra
oscura (con ventanas de luz cálida): arriba, cada torre es un piso de baile en damero negro y gris, de 9 × 9, y entre
torre y torre hay **2 bloques de vacío**. En el medio, más alta, la torre del **gramófono** (madera oscura y una
bocina dorada), que pone la música. Abajo, a 59 bloques, el suelo: el que se cae, se mata.

1. El comandante explica las reglas desde su podio, en el palco de la entrada (con baranda).
2. Todos aparecen repartidos por las torres. **Mientras suena el gramófono** (un vals en re menor, de 8 a 16
   segundos: nadie sabe cuándo para) **cada uno anda por donde quiere**: por su torre o saltando a otra.
3. **Cuando la música para**, las luces parpadean, aparece **¡A SENTARSE!** y **aparecen sillas en algunas torres**
   (de terciopelo rojo, mirando al gramófono): **siempre menos sillas que gente**. Hay que llegar a una silla libre
   (saltando de torre en torre, si hace falta) y **sentarse con clic derecho**. **Hay 10 segundos.**
4. **Después se cae el piso de todas las torres**: queda solo lo que está debajo de las sillas. **El que no está
   sentado se cae** y queda eliminado (si ya no quedan sillas libres, el piso se cae al segundo).
5. Vuelve el piso, todos se levantan y vuelve la música. **Son 3 rondas**: en cada una faltan más sillas (el 10, el
   12 y el 15 por ciento de los que quedan). **Los que quedan después de la tercera, pasan.**

Sentado, nadie te puede sacar ni empujar. Parado, **se vale empujar** (clic derecho con la mano vacía, una vez cada 5
segundos): cerca del borde, un empujón es una caída. En este juego correr no cansa. Los bots se dan cuenta enseguida
de que paró la música, van a la silla libre más cercana saltando de torre en torre (casi nunca les sale mal un
salto) y no se chocan entre ellos (en una torre llena se tirarían abajo).

Para probarlo sin esperar: `/juegosdelpatio segundojuego` (desde que entra el comandante) o
`/juegosdelpatio juego empezar 2` (directo al palco, a las reglas).

### El tercer día de juego: Fuego cruzado

El día 3 del ciclo (3, 11, 19...): el comandante llama, el portal está en la **puerta 3 de la torre**.

Es un juego nuevo, con un guiño al quemado. Se juega arriba de **dos torres altísimas, frente a frente**: la de los
rojos (ladrillo del Nether) y la de los azules (prismarina oscura), separadas por **un abismo de 8 bloques** que nadie
puede saltar. Arriba no hay baranda, y el piso es de ladrillo de piedra negra.

1. Se reparten **dos equipos al azar**, cada uno con su chaleco (rojo oscuro o azul oscuro), y cada uno va a su torre.
2. Cada uno tiene **una bola de fuego**: se tira con **clic derecho**, y la nueva llega a los 2 segundos. A los de tu
   equipo la bola los atraviesa.
3. La bola que le pega a alguien del otro equipo **lo empuja y lo quema un poco**. La que pega en el piso **lo
   quema: se vuelve magma** (que quema al que la pisa) y, **si le vuelven a pegar, se rompe** y queda un agujero.
4. **El que se cae** (por el borde o por un agujero) **o se quema, queda eliminado.**
5. **A los 4 minutos** (o cuando un equipo se queda sin nadie) se termina: **los que quedan en pie, pasan.** El piso
   se arregla solo para la próxima vez.

Los bots caminan por su torre esquivando la magma y los agujeros, a veces esquivan las bolas que les vienen, y tiran
al cuerpo o a los pies (para quemar el piso).

Para probarlo sin esperar: `/juegosdelpatio tercerjuego` o `/juegosdelpatio juego empezar 3`.

### El cuarto día de juego: El tejo

El día 4 del ciclo (4, 12, 20...): el comandante llama, el portal está en la **puerta 4 de la torre**.

Es un juego nuevo, con un guiño a la rayuela (el tejo es la piedra que se tira en la rayuela). Se juega en **una
rayuela de torres altísimas**: diez torres de piedra oscura, una por casillero (1, 2, 3-4, 5, 6-7, 8, 9-10), cada
una con su número de oro arriba; al norte, la largada (con baranda y una abertura frente al 1) y al sur, el cielo
(medio círculo de mármol con baranda). **Entre torre y torre hay vacío**: 2 bloques hacia adelante y 3 entre las de
al lado (como la 3 y la 4). Abajo, a 59 bloques, el patio, con la rayuela de verdad dibujada en el piso.

1. Todos empiezan repartidos por las torres. En cada ronda, el comandante **le da el tejo a algunos** (a uno de cada
   10 que quedan): **brillan** y corren un poco más.
2. **El tejo se pasa pegándole a otro** (no lastima). Al que te lo pasó no se lo puedes devolver enseguida.
3. **Nadie sabe cuándo suena la campana** (de 30 a 45 segundos; el tic-tac se acelera). **El que tiene el tejo cae
   con él**: se abre un agujero de 3 × 3 debajo, que **se lleva también a los que estén al lado**. Los agujeros quedan
   hasta el final del juego.
4. **Son 4 rondas.** El que se cae (con el tejo, por un agujero o por un mal salto) queda eliminado.

Los bots que tienen el tejo persiguen al más cercano saltando de torre en torre; los demás se escapan a la torre
que quede más lejos de los que lo tienen. No se chocan entre ellos.

Para probarlo sin esperar: `/juegosdelpatio cuartojuego` o `/juegosdelpatio juego empezar 4`.

### El quinto día de juego: Las escondidas

El día 5 del ciclo (5, 13, 21...) es el quinto juego. Empieza igual que los otros: **un minuto después de que se
prenden las luces vuelve el comandante**, avisa que **el quinto juego está por comenzar** y que el portal está en
la **puerta 5 de la torre**. Los bots lo siguen y, cuando termina el
minuto, todos pasan juntos.

El juego es en una **escuela gigante, de noche** (150 × 120 bloques, paredes oscuras; en los pasillos, techo negro y
piso de baldosas blancas y naranjas): un pasillo con
casilleros que da toda la vuelta, **30 aulas** (bancos, pizarrón y un ropero), **baños** con cubículos,
**depósitos** llenos de barriles, el **gimnasio** (con gradas y su depósito), la **biblioteca** (estanterías
altas), el **comedor** con la cocina, el **salón de actos** (escenario con telón), la dirección, la enfermería y la
**sala de profesores**. En el medio está el **hall**, con el podio del comandante. Hay poca luz, y en los
escondites, menos.

1. El comandante explica las reglas desde el podio del hall.
2. **Se arman dos equipos al azar, mitad y mitad**: la mitad busca y la otra mitad se esconde (si son impares, se
   esconde uno más). En la pantalla te dice qué te tocó, y a cada uno le ponen su chaleco.
   **Después hay 1 minuto para cambiarse de equipo, en el hall** (nadie puede salir del hall todavía): hazle **clic
   derecho a uno del otro equipo** para pedirle cambiar; si él también te hace clic derecho, **se cambian** (de
   equipo y de chaleco) y todos se enteran por el chat. Si un bot te lo pide, viene hasta donde estás: hazle clic
   derecho para aceptar. Los bots contestan solos (a la mitad les gusta buscar y a la otra mitad esconderse: el que
   está en el equipo que no le gusta casi siempre acepta) y también se cambian entre ellos. En la barra de arriba se
   ve el tiempo que queda y cuántos cambios hubo. Los equipos siguen siendo mitad y mitad.
3. **Los buscadores esperan en la sala de profesores**, que tiene rejas en las puertas, **con los ojos cerrados**
   (ceguera), durante **1 minuto**. Mientras tanto, **los demás se esconden** por toda la escuela: hay más de 150
   escondites (roperos, cubículos de los baños, huecos entre las estanterías, debajo de las gradas, detrás del
   telón, casilleros vacíos, depósitos...).
4. **Se abren las rejas y los buscadores salen con una espada de netherite con filo V** (irrompible). Tienen
   **5 minutos** para encontrar a los que se esconden y **matarlos**. **Cada buscador tiene que matar al menos a
   uno: el que no mata a nadie queda eliminado al final.** Al que todavía no atrapó a nadie se le avisa cuando
   quedan 2 minutos y con un cartel en el último minuto (los bots que buscan, en el último minuto, van corriendo).
   **Está prohibido que los buscadores se maten entre ellos**: el golpe no hace nada y te avisa. Los que se esconden no pueden pelear: solo correr y empujar
   (clic derecho con la mano vacía).
5. En ese momento **se abre una de las 6 salidas al patio**, al azar; las otras siguen con rejas. Están en las
   puntas del pasillo y al norte y al sur, con una luz verde arriba. **El que se esconde y cruza la salida
   abierta, pasa**: aparece en el patio y espera ahí. Los buscadores no pueden salir.
6. **Cuando se termina el tiempo, todos los que siguen vivos pasan**: los escondidos que nadie encontró, los que
   salieron y **los buscadores que atraparon al menos a uno** (los que no atraparon a nadie quedan eliminados en ese
   momento). Si ya no queda nadie escondido, termina antes.
7. Después: resultados, votación y la cena (esta vez, **un estofado** para cada uno) y a dormir.

**Para esconderte mejor:** agáchate (Shift) y quédate donde está oscuro. Así no se ve tu nombre a través de las
paredes y a los bots les cuesta mucho más verte. **Los bots que buscan ven desde muy lejos**: donde hay mucha luz,
hasta 56 bloques (44 con luz media, 32 con poca, 14 a oscuras); agachado, un poco menos, y corriendo, más. Ven casi
todo lo que tienen adelante y a los costados (también a través de vidrios y rejas), y si estás cerca te oyen aunque
no te miren (si corres, desde más lejos; agachado, casi nada). Cuando uno te ve, le aparece **«¡!»** arriba del
nombre y a ti te sale en la pantalla **«¡… te vio! ¡Corre!»**.

**Los bots que buscan, más inteligentes:** caminan mirando para los costados y, cuando se paran, para todos lados
(también para atrás). Si ven a alguien, **avisan a los otros buscadores** que estén cerca, que van corriendo para
ahí. Lo persiguen casi tan rápido como un jugador corriendo (5,3 bloques por segundo contra 5,6: el que corre bien
se les escapa, y saltando mientras corres, más); si se les pierde, lo siguen oyendo correr un ratito, van adonde lo
vieron por última vez y **revisan los escondites de alrededor**. A veces "oyen algo" y van a revisar escondites de
la zona donde hay un jugador escondido (no van derecho a él). Y le pegan con la espada (nunca a través de un vidrio
o una reja).

**Los bots que se esconden** corren a un escondite libre en el minuto para esconderse y se agachan ahí (y no se
les ve el nombre). Algunos, uno de cada tres, después se animan a buscar la salida: van de salida en salida hasta
encontrar la abierta. **Si un buscador los vio, está cerca o les pega** (o si tú buscas y los miras de frente),
**salen disparados, muy rápido** (unos 9 bloques y medio por segundo, de 2 y medio a 3 y medio segundos) a otro
escondite lejos y para el otro lado, o a la salida si ya la vieron. Después quedan **cansados** de 7 a 9 segundos: si
tienen que escaparse otra vez, corren más lento que tú, así que si los sigues, los alcanzas.

**Chalecos:** al repartir los equipos, a cada uno le ponen un chaleco: **amarillo el que busca** (con un ojo en la
espalda) y **violeta el que se esconde** (con una luna). No se lo puede sacar; al final le devuelven su camisa.

**Cuerpos:** al que encuentran **queda tirado en el piso**, boca arriba, con su skin y su chaleco, hasta que termina
el juego.

**Los dos trucos de los que se esconden:**

- **Hacerse el muerto (la G):** te tiras al piso **10 segundos** y te ves igual que un cuerpo de verdad (sin nombre
  ni nada). No te puedes mover; con la G otra vez te levantas antes. Después tienes que esperar **30 segundos** para
  volver a hacerlo. Los bots que buscan **no se dan cuenta, salvo los que te vieron tirarte**; y si uno pasa justo
  al lado, a veces (3 de cada 10) nota que respiras. Si te pegan, te levantas (y te encontraron). Los jugadores que
  buscan pueden pegarle a un cuerpo para salir de dudas. Los bots que se esconden también lo hacen: cuando viene un
  buscador que todavía no los vio, a veces se tiran al piso.
- **Quitarle la espada a un buscador:** acércate **por la espalda** (agachado, para que no te oiga), **a un bloque**
  y sin que te vea, y **mantén el clic derecho** sobre él (con la mano vacía). Empieza un **forcejeo**: cada tirón
  llena la barrita (■■■□□□□□□□) y **el buscador tiene que apretar la Z rápido** para aflojarla.
  Si la llenas, **le quitas la espada**: sin espada no puede atrapar a nadie, y **a los 30 segundos le traen otra**.
  Si se suelta (o pasan 8 segundos), te descubrió: ¡corre! (y tienes que esperar 4 segundos para volver a agarrar a
  alguien). Mientras lo tienes agarrado casi no se puede mover ni pegarte, pero los otros buscadores sí. Los bots que
  se esconden (uno de cada tres) también lo intentan, y los bots que buscan se resisten solos, unos más fuerte que
  otros. Las teclas se pueden cambiar en Opciones → Controles ("Hacerse el muerto" y "Aguantar").

La primera vez, la escuela tarda un momento en construirse. Para probarlo sin esperar:
`/juegosdelpatio quintojuego` (desde que entra el comandante) o `/juegosdelpatio juego empezar 5` (directo al
hall, a las reglas).

### El sexto día de juego: El puente de Londres

El día 6 del ciclo (6, 14, 22...) es el sexto juego. Como siempre: el comandante llama, el portal está en la
**puerta 6 de la torre** y al minuto pasan todos juntos.

El juego es en una **plaza de Londres de noche**, techada: alrededor, **fachadas de ladrillo con ventanas** (unas con
luz, otras apagadas), cornisas de piedra y pilastras oscuras, y arriba, todo negro, como el cielo de noche. En el
medio hay una plaza de piedra oscura con un farol alto y, alrededor, **la calle de adoquines** (con cordones de
piedra y faroles de hierro), por donde la fila camina en ronda. Del lado este de la ronda hay **dos robots
gigantes** (de más de 9 bloques), de metal oscuro, con un **visor de luz** en la cabeza (uno rojo y el otro azul) y
la misma luz en el pecho y en los antebrazos (brillan en la oscuridad), parados uno a cada lado de la calle, sobre
una plataforma de metal, y mirándose. **Se dan las dos manos por encima de la calle: con los brazos en alto (y el
codo doblado) forman el puente.**

1. El comandante explica las reglas desde su podio, en la entrada.
2. **Todos van enganchados en fila por la calle**, uno detrás del otro (los bots, con las manos en los hombros del
   de adelante), empezando justo antes del puente. Suena **la canción** (la melodía tradicional del puente de
   Londres, con bloques musicales; las notas salen de las cabezas de los robots, que giran la cabeza mirando la
   fila) y **la fila camina alrededor, como las agujas del reloj, pasando por debajo del puente**. **Nadie se puede
   adelantar ni quedar atrás**: la fila te lleva (no hace falta caminar) y cada uno conserva su lugar hasta el final.
3. Mientras suena, **los robots mueven los brazos**: los bajan un poco y los vuelven a subir, y a veces amagan
   con bajarlos del todo, para dar suspenso.
4. **Cuando termina la canción** (o, en 1 de cada 3 rondas, **en un momento sorpresa**, en el medio) los robots
   **bajan los brazos de golpe**: el que está pasando por debajo **queda atrapado** entre los brazos (los de al lado
   salen de abajo, para adelante o para atrás). Aparece en grande **¡SE CAYÓ EL PUENTE!**, la fila se para, suena
   un redoble y **el atrapado queda eliminado**. Después la fila se vuelve a juntar.
5. **Son 5 rondas. Los que siguen en la fila al final, pasan.** Después, como siempre: resultados, votación, cena
   y a dormir.

A quién le toca es pura suerte: en cada ronda la fila va a un paso un poco distinto (de 1,6 a 3,2 bloques por
segundo) y siempre hay alguien pasando por debajo cuando se caen los brazos. Enganchados no se puede empujar ni
pegar, y en este juego no hace falta correr (ni cansa).

Para probarlo sin esperar: `/juegosdelpatio sextojuego` (desde que entra el comandante) o
`/juegosdelpatio juego empezar 6` (directo a la plaza, a las reglas).

### El séptimo día de juego, el último: Los estandartes

El día 7 del ciclo (7, 15, 23...): el comandante llama, el portal está en la **puerta 7 de la torre**, la más alta.

Es un juego nuevo, con un guiño a capturar la bandera. Se juega en **un campo de torres altísimas** (el suelo está
59 bloques más abajo: el que se cae, se mata). En cada punta hay un **bastión**: el rojo al oeste y el azul al este,
cada uno con una muralla con almenas y banderas de su color, y **su estandarte parado en el medio, sobre oro**. Entre
los dos bastiones hay **tres caminos de torres**: el del medio (saltos de 2, y uno de 3), con **una plaza** de piedra
negra y un anillo de oro en el centro; y dos por los costados, de torres más chicas y **saltos de 3**.

1. Se reparten **dos equipos al azar**, cada uno con su chaleco y **una espada de hierro** (que no se rompe), y cada
   uno empieza en su bastión. Después de **10 segundos** de cuenta, a jugar.
2. **Para ganar hay que robar el estandarte del otro equipo y llevarlo hasta el bastión propio.** Se agarra
   tocándolo. **El que lo lleva lo tiene puesto en la cabeza, brilla y no puede pegar ni empujar**: su equipo lo
   tiene que cuidar. Si muere o se cae, el estandarte vuelve a su bastión.
3. **El que muere (por la espada o por una caída) queda eliminado.** A los de tu propio equipo no les puedes pegar.
4. **Desde el minuto 3, cada 40 segundos se agrietan dos torres de los costados** (una de cada lado, la misma, para
   que sea parejo): el piso se raja, cae polvo, y **a los 5 segundos se derrumban**, con los que estén arriba. El
   camino del medio y la plaza no se caen: al final, todo pasa por el medio.
5. **El equipo que pierde su estandarte, pierde: su bastión se derrumba y quedan todos eliminados.** El estandarte
   robado queda clavado al lado del estandarte del que ganó. Si un equipo muere entero, también pierde. Si a los 8
   minutos nadie trajo un estandarte, pierde el equipo que tenga menos gente en pie (si están parejos, pasan todos).

Los bots se reparten el trabajo: un tercio cuida su estandarte y los demás van a buscar el otro, por el medio o por
un costado, saltando de torre en torre (a veces un salto les sale mal); si les pegan en el aire, el golpe los saca
del salto. El que agarra el estandarte vuelve sin pelear y los de su equipo que están cerca lo acompañan; si les
roban el suyo, persiguen al que lo lleva. En las torres los bots no se chocan entre ellos (si no, se tirarían
abajo), y si su torre se agrieta, saltan a otra. Al terminar, la arena queda como estaba.

**Después de Los estandartes no se vota**: el comandante da los resultados, felicita a los que quedan (**ganaron los
Juegos del Patio**) y **se reparten el premio**: a los 10 segundos, cada jugador se lleva su parte en diamantes y
vuelve a su mundo.

Para probarlo sin esperar: `/juegosdelpatio septimojuego` o `/juegosdelpatio juego empezar 7`.

El mod está en español aunque tengas Minecraft en inglés (o en otro idioma).

## Instalar

Copia `juegosdelpatio-0.1.0.jar` en la carpeta `mods` de tu instalación de NeoForge 1.21.1.

## Cómo se juega

- Fabrica la **Invitación**: papel + pepita de oro (sin forma, en la mesa de crafteo).
- **Clic derecho** con la invitación (el día 0, 8, 16...): despiertas en el dormitorio del complejo.
- **Clic derecho otra vez** dentro del complejo: vuelves al lugar exacto desde donde entraste (menos el día de juego).
- Puedes dormir en las literas: tu punto de aparición queda en el dormitorio.

La primera vez que alguien entra, el dormitorio se construye solo (puede tardar un segundo).

### Comandos (operadores / trucos activados)

| Comando | Qué hace |
|---|---|
| `/juegosdelpatio entrar` | Entra sin invitación (cualquier día) |
| `/juegosdelpatio salir` | Sale del complejo |
| `/juegosdelpatio reconstruir` | Vuelve a colocar el dormitorio y la torre, y crea 150 bots y los 2 vigilantes |
| `/juegosdelpatio bots <0-150>` | Reemplaza a los bots por la cantidad que digas |
| `/juegosdelpatio guardias <0-2>` | Vuelve a poner los vigilantes del portón (0 los saca) |
| `/juegosdelpatio invocar <rango>` | Pone un guardia fijo donde estás (`vigilante`, `guardia`, `sargento`, `comandante`) |
| `/juegosdelpatio ceremonia` | Empieza ahora la ceremonia de bienvenida |
| `/juegosdelpatio porton abrir` / `cerrar` | Abre o cierra el portón (camino al pasillo y a la torre) |
| `/juegosdelpatio puerta <1-7> abrir` / `cerrar` | Abre una puerta de la torre (aparece el portal a ese juego) o la cierra |
| `/juegosdelpatio primerjuego` | Aparece el comandante con sus sargentos y empieza el primer juego (igual que `juego llamar`) |
| `/juegosdelpatio segundojuego` | Lo mismo con el segundo juego, Asientos al vacío (igual que `juego llamar 2`) |
| `/juegosdelpatio tercerjuego` | Lo mismo con el tercer juego, Fuego cruzado (igual que `juego llamar 3`) |
| `/juegosdelpatio cuartojuego` | Lo mismo con el cuarto juego, El tejo (igual que `juego llamar 4`) |
| `/juegosdelpatio quintojuego` | Lo mismo con el quinto juego, Las escondidas (igual que `juego llamar 5`) |
| `/juegosdelpatio sextojuego` | Lo mismo con el sexto juego, El puente de Londres (igual que `juego llamar 6`) |
| `/juegosdelpatio septimojuego` | Lo mismo con el séptimo, Los estandartes (igual que `juego llamar 7`) |
| `/juegosdelpatio juego llamar [1-7]` | Empieza ahora el día de ese juego, desde que entra el comandante |
| `/juegosdelpatio juego empezar [1-7]` | Lleva a todos a la arena de ese juego y empieza con las reglas |
| `/juegosdelpatio juego parar` | Corta el juego: todos vuelven a la sala (nadie queda eliminado) |
| `/juegosdelpatio resultados` | Vuelve el comandante con los resultados del último juego, y se vota |
| `/juegosdelpatio comida` | Aparecen ya los tres vigilantes en el comedor y reparten la comida (después, a dormir) |
| `/votar seguir` / `/votar irse` | Votar (para cualquier jugador, cuando hay una votación) |
| `/give @s juegosdelpatio:invitacion` | Te da una invitación |
| `/give @s juegosdelpatio:huevo_jugador` | Huevo para poner un bot donde quieras |
| `/give @s juegosdelpatio:huevo_guardia` | Huevo de guardia (rango al azar) |

Si llamas a un juego con un comando otro día que no es el suyo (por ejemplo, el juego 1 el día de entrada), **el
calendario salta hacia adelante hasta el día de ese juego**, a la misma hora. Así, después de dormir, toca el
juego que sigue y el cartel dice el día que corresponde: juego 1 → día 1, y al día siguiente juego 2 → día 2.
El calendario nunca vuelve para atrás: repetir el juego 1 el día 2 lo lleva al día 1 del ciclo siguiente (9).

## Estructura del proyecto

| Ruta | Contenido |
|---|---|
| `src/main/java/com/juegosdelpatio/` | Código: registro, invitación, viaje entre dimensiones, comandos |
| `src/main/resources/data/juegosdelpatio/dimension*/` | La dimensión `juegosdelpatio:complejo` (vacía, noche fija) |
| `src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt` | Dormitorio, baños, comedor y pasillo de los guardias (65 × 21 × 102 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/torre.nbt` | La Torre de los Juegos, con 7 puertas (21 × 72 × 21 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/luz_verde.nbt` | La arena del juego 1, Luz verde, luz roja, con el Vigía (102 × 38 × 308 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/asientos.nbt` | El campo de torres del juego 2, Asientos al vacío, con el gramófono (63 × 78 × 80 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/fuego.nbt` | Las dos torres del juego 3, Fuego cruzado (63 × 78 × 70 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/tejo.nbt` | La rayuela de torres del juego 4, El tejo (63 × 78 × 103 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/escuela.nbt` | La escuela del juego 5, Las escondidas, con su patio (150 × 9 × 132 bloques) |
| `src/main/resources/data/juegosdelpatio/structure/puente.nbt` | La plaza de Londres de noche del juego 6, El puente de Londres (63 × 18 × 72 bloques; los robots los pone el juego) |
| `src/main/resources/data/juegosdelpatio/structure/estandartes.nbt` | El campo de torres del juego 7, Los estandartes, con los dos bastiones (91 × 78 × 58 bloques) |
| `herramientas/gen_sala.py` | Script que genera `dormitorio.nbt` (cambia medidas, camas, luces...) |
| `herramientas/gen_torre.py` | Script que genera `torre.nbt` |
| `herramientas/gen_luz_verde.py` | Script que genera `luz_verde.nbt` |
| `herramientas/arenas_comun.py` | Lo común a las arenas nuevas (entrada, podio, portal, barandas, torres, luces) |
| `herramientas/gen_asientos.py` | Script que genera `asientos.nbt` |
| `herramientas/gen_fuego.py` | Script que genera `fuego.nbt` |
| `herramientas/gen_tejo.py` | Script que genera `tejo.nbt` |
| `herramientas/gen_estandartes.py` | Script que genera `estandartes.nbt` |
| `herramientas/gen_escondidas.py` | Script que genera `escuela.nbt` (y un plano visto desde arriba) |
| `herramientas/gen_puente.py` | Script que genera `puente.nbt` |
| `herramientas/render.py` | Genera imágenes de vista previa de la sala |
| `herramientas/ceremonia_render.py` | Imagen de la ceremonia (portón abierto, desfile y público) |
| `herramientas/torre_render.py` | Imágenes de la torre |
| `herramientas/noche_render.py` | Imágenes de la sala de día y de noche, y de un portal abierto |
| `herramientas/luz_verde_render.py` | Imágenes de la arena de Luz verde, luz roja |
| `herramientas/juegos_render.py` | Imágenes de Asientos al vacío, Fuego cruzado, El tejo y Los estandartes |
| `herramientas/escondidas_render.py` | Plano de la escuela e imágenes de Las escondidas |
| `herramientas/chalecos.py` | Texturas e íconos de los chalecos (Las escondidas, y los rojos y azules de Fuego cruzado y Los estandartes) |
| `herramientas/puente_render.py` | Imágenes de El puente de Londres (la plaza, la fila enganchada y el atrapado) |
| `herramientas/portal_textura.py` | Dibuja la textura animada del portal |
| `herramientas/skins.py` | Dibuja las 48 skins de los bots y las texturas del uniforme |
| `herramientas/guardias.py` | Dibuja las skins de los 4 rangos de guardia, las armas y la bala |

Para regenerar la sala después de editar el script:

```
python3 herramientas/gen_sala.py src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt bloques.pkl
```

## Compilar en tu PC (opcional)

Con Java 21 instalado: `./gradlew build` (Windows: `gradlew.bat build`). El `.jar` queda en `build/libs/`.
