# Juegos del Patio — mod para NeoForge 1.21.1

Minijuegos de supervivencia en una dimensión propia.
**Versión 0.1:** el complejo (dimensión nueva) y el dormitorio gigante: 306 camas en literas junto a las
paredes (la zona del portón queda libre), una plaza abierta en el centro con una rayuela gigante, y a los lados
del portón dos salas con puerta: **baños** (8 cubículos, 8 duchas y lavamanos con espejo) y **comedor**
(4 mesas largas con bancos, mostrador y cocina).

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **una** de estas dos cosas a la raíz del repositorio:
   - el archivo `.zip` tal cual, **o**
   - todos los archivos de adentro del zip.
3. Si subiste el `.zip`, crea también el archivo `.github/workflows/compilar.yml`
   (botón *Add file → Create new file*, escribe esa ruta con las barras y pega el contenido del workflow).
   Si subiste los archivos sueltos, el workflow ya viene incluido.
4. Entra a la pestaña **Actions**: la compilación arranca sola (tarda unos minutos la primera vez).
5. Descarga el `.jar` desde **Releases → Última compilación** o desde la ejecución en **Actions → Artifacts**.

> Si la pestaña Actions pide permiso para ejecutar workflows, acéptalo.

### Los otros jugadores (bots)

En el dormitorio viven **150 jugadores controlados por el juego**, cada uno con su nombre y una de
48 skins distintas, todos con el uniforme negro del complejo. Pasean por la plaza, el comedor y los
baños, saludan cuando te acercas, se juntan a charlar con emoticones (`:D`, `jaja`, `♥`, `gg`, `xD`...),
se agachan y saltan como jugadores, a veces salen corriendo (y saltan mientras corren), dan saltitos
de alegría cuando charlan, y a veces se acuestan un rato en las literas de abajo.

Al entrar al complejo te ponen el **uniforme** (camisa, pantalón y zapatillas) si todavía no lo tienes.

## Instalar

Copia `juegosdelpatio-0.1.0.jar` en la carpeta `mods` de tu instalación de NeoForge 1.21.1.

## Cómo se juega

- Fabrica la **Invitación**: papel + pepita de oro (sin forma, en la mesa de crafteo).
- **Clic derecho** con la invitación: despiertas en el dormitorio del complejo.
- **Clic derecho otra vez** dentro del complejo: vuelves al lugar exacto desde donde entraste.
- Puedes dormir en las literas: tu punto de aparición queda en el dormitorio.

La primera vez que alguien entra, el dormitorio se construye solo (puede tardar un segundo).

### Comandos (operadores / trucos activados)

| Comando | Qué hace |
|---|---|
| `/juegosdelpatio entrar` | Entra sin invitación |
| `/juegosdelpatio salir` | Sale del complejo |
| `/juegosdelpatio reconstruir` | Vuelve a colocar el dormitorio y crea 150 bots nuevos |
| `/juegosdelpatio bots <0-150>` | Reemplaza a los bots por la cantidad que digas |
| `/give @s juegosdelpatio:invitacion` | Te da una invitación |
| `/give @s juegosdelpatio:huevo_jugador` | Huevo para poner un bot donde quieras |

## Estructura del proyecto

| Ruta | Contenido |
|---|---|
| `src/main/java/com/juegosdelpatio/` | Código: registro, invitación, viaje entre dimensiones, comandos |
| `src/main/resources/data/juegosdelpatio/dimension*/` | La dimensión `juegosdelpatio:complejo` (vacía, noche fija) |
| `src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt` | Dormitorio, baños y comedor (65 × 21 × 102 bloques) |
| `herramientas/gen_sala.py` | Script que genera `dormitorio.nbt` (cambia medidas, camas, luces...) |
| `herramientas/render.py` | Genera imágenes de vista previa de la sala |
| `herramientas/skins.py` | Dibuja las 48 skins de los bots y las texturas del uniforme |

Para regenerar la sala después de editar el script:

```
python3 herramientas/gen_sala.py src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt bloques.pkl
```

## Compilar en tu PC (opcional)

Con Java 21 instalado: `./gradlew build` (Windows: `gradlew.bat build`). El `.jar` queda en `build/libs/`.
