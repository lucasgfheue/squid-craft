#!/usr/bin/env python3
"""Dibuja las skins de los bots (64x64, formato de jugador) con el uniforme negro del complejo,
las capas de armadura del uniforme para los jugadores reales y los íconos de las prendas.

Uso: python3 skins.py <carpeta resources> <imagen de muestra>
"""
import os
import random
import sys

from PIL import Image

RES = sys.argv[1]
MUESTRA = sys.argv[2]
N_SKINS = 48

# ------------------------------------------------------------------ paleta del uniforme (diseño propio)
UNIF = (34, 34, 38)          # uniforme negro
UNIF_OSC = (22, 22, 26)
UNIF_CLA = (52, 52, 58)
ADORNO = (150, 150, 158)     # cuello, cinturón, puños y franjas en gris
ADORNO_OSC = (112, 112, 120)
CIERRE = (200, 200, 205)
BLANCO = (238, 238, 236)
SUELA = (118, 118, 122)
KITE = [(176, 38, 38), (240, 178, 30), (48, 60, 170), (98, 172, 36)]

TONOS = [(255, 224, 199), (243, 198, 165), (226, 175, 138), (201, 145, 104),
         (180, 128, 90), (152, 103, 68), (122, 80, 50), (94, 60, 38)]
PELOS = {"negro": (28, 24, 24), "castano_osc": (62, 40, 25), "castano": (104, 69, 35),
         "castano_cla": (152, 108, 62), "rubio": (226, 192, 112), "colorado": (186, 88, 40),
         "azul": (62, 102, 204), "rosa": (229, 122, 172), "violeta": (132, 82, 182), "gris": (196, 196, 196)}
OJOS = [(70, 45, 25), (40, 90, 160), (60, 120, 60), (30, 30, 30), (110, 80, 40)]
ESTILOS = ["corto", "flequillo", "largo", "rapado", "cola", "gorra", "rulos", "corto"]
GORRAS = [(200, 40, 40), (40, 80, 180), (30, 30, 30), (240, 240, 240), (60, 150, 70)]


def osc(c, f=0.82):
    return tuple(max(0, min(255, int(v * f))) for v in c)


class Skin:
    def __init__(self):
        self.im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))

    def px(self, x, y, c):
        if c is None:
            return
        self.im.putpixel((x, y), tuple(c) + (255,) if len(c) == 3 else tuple(c))

    def caja(self, ox, oy, w, h, d, fn):
        """Pinta las 6 caras de una caja con fn(cara, u, v, ancho, alto) -> color o None."""
        caras = {
            "arriba": (ox + d, oy, w, d), "abajo": (ox + d + w, oy, w, d),
            "der": (ox, oy + d, d, h), "frente": (ox + d, oy + d, w, h),
            "izq": (ox + d + w, oy + d, d, h), "atras": (ox + d + w + d, oy + d, w, h),
        }
        for cara, (x0, y0, cw, ch) in caras.items():
            for v in range(ch):
                for u in range(cw):
                    self.px(x0 + u, y0 + v, fn(cara, u, v, cw, ch))


def uniforme_cuerpo(cara, u, v, w, h, overlay=False):
    if overlay:
        if cara == "frente" and v <= 1 and (2 <= u <= 5) and not (v == 1 and u in (2, 5)):
            return ADORNO
        return None
    if cara == "arriba":
        return ADORNO
    if cara == "abajo":
        return UNIF_OSC
    if v == 9:
        return ADORNO                                    # cinturón
    if cara == "frente":
        if v == 0 and 2 <= u <= 5:
            return ADORNO_OSC
        if u == 4 and 1 <= v <= 11 and v != 9:
            return CIERRE                                # cierre
        if (u, v) in ((2, 2), (1, 3), (2, 3), (3, 3), (2, 4)):
            return KITE[[(2, 2), (1, 3), (3, 3), (2, 4)].index((u, v))] if (u, v) != (2, 3) else (240, 240, 240)
        if u in (0, 7):
            return UNIF_OSC
        return UNIF
    if cara == "atras":
        if v <= 1:
            return ADORNO
        cx, cy = 3.5, 5
        if abs(u - cx) / 2.0 + abs(v - cy) / 2.5 <= 1.0:  # barrilete en la espalda
            q = (0 if u < cx else 1) + (0 if v < cy else 2)
            return KITE[q]
        return UNIF
    return UNIF_OSC if v > 9 else UNIF


def brazo(tono):
    def fn(cara, u, v, w, h):
        if cara == "arriba":
            return UNIF
        if cara == "abajo":
            return tono
        if v >= 9:
            return tono if v > 9 else osc(tono, 0.9)
        if v == 8:
            return ADORNO                                # puño
        if cara == "der" and v < 8:
            return UNIF_OSC
        return UNIF
    return fn


def pierna(lado):
    def fn(cara, u, v, w, h):
        if cara == "arriba":
            return UNIF
        if cara == "abajo":
            return SUELA
        if v == 11:
            return SUELA
        if v >= 9:
            return BLANCO if not (cara == "frente" and v == 9 and u in (1, 2)) else (200, 200, 205)
        exterior = "der" if lado == "der" else "izq"
        if cara == exterior and u in (1, 2):
            return ADORNO                                # franja lateral
        return UNIF_OSC if cara == "atras" else UNIF
    return fn


def mangas_overlay(cara, u, v, w, h):
    return ADORNO if v == 8 and cara not in ("arriba", "abajo") else None


def cabeza(tono, pelo, estilo, ojos, rng, extra):
    pelo_osc = osc(pelo, 0.78)
    boca = osc(tono, 0.62)

    def fn(cara, u, v, w, h):
        ondas = (u + v) % 2 == 0
        hp = pelo_osc if (estilo == "rulos" and ondas) else pelo
        if cara == "arriba":
            return hp if estilo != "gorra" else pelo
        if cara == "abajo":
            return tono
        if cara == "frente":
            if estilo == "rapado":
                if v == 0:
                    return hp
            elif estilo == "flequillo":
                if v <= 1 or (v == 2 and u not in (3, 4)):
                    return hp
            elif estilo in ("largo",):
                if v == 0 or (v == 1 and u not in (3, 4)) or ((u in (0, 7)) and v <= 5):
                    return hp
            else:
                if v <= 1 or (v == 2 and u in (0, 7)):
                    return hp
            if v == 3 and u in (1, 2, 5, 6) and estilo != "rapado":
                return pelo_osc                          # cejas
            if v == 4:
                if u in (1, 6):
                    return (245, 245, 245)
                if u in (2, 5):
                    return ojos
            if v == 5 and u in (3, 4):
                return osc(tono, 0.9)                    # nariz
            if v == 6 and u in (3, 4):
                return boca
            if v == 6 and u in (2, 5) and extra.get("sonrisa"):
                return boca
            if extra.get("pecas") and v == 5 and u in (1, 2, 5, 6) and (u + v) % 2 == 0:
                return osc(tono, 0.8)
            return tono
        if cara == "atras":
            if estilo == "rapado":
                return hp if v <= 2 else tono
            if estilo in ("largo", "cola"):
                return hp
            return hp if v <= 5 else (tono if v == 7 else hp)
        # costados
        if estilo == "rapado":
            return hp if v <= 1 else tono
        if estilo == "largo":
            return hp
        if v <= 2:
            return hp
        if v <= 5 and ((cara == "der" and u <= 1) or (cara == "izq" and u >= 6)):
            return hp                                    # pelo hacia la nuca
        if v == 4 and ((cara == "der" and u == 4) or (cara == "izq" and u == 3)):
            return osc(tono, 0.85)                       # oreja
        return tono
    return fn


def sombrero(estilo, pelo, gorra, extra):
    def fn(cara, u, v, w, h):
        if extra.get("auriculares") and cara in ("der", "izq") and 2 <= v <= 5 and 2 <= u <= 5:
            return (25, 25, 28) if v in (2, 5) or u in (2, 5) else gorra      # auriculares
        if extra.get("auriculares") and cara == "arriba" and u in (0, 7):
            return (25, 25, 28)
        if extra.get("vincha") and cara in ("frente", "der", "izq", "atras") and v == 1:
            return gorra                                                      # vincha
        if extra.get("vincha") and cara == "arriba" and v in (6, 7):
            return gorra
        if estilo == "gorra":
            if cara == "arriba":
                return gorra
            if cara in ("der", "izq", "atras") and v <= 2:
                return gorra if v <= 1 else osc(gorra, 0.8)
            if cara == "frente" and v <= 2:
                return gorra if v <= 1 else osc(gorra, 0.75)   # visera
            return None
        if estilo == "cola" and cara == "atras" and 3 <= u <= 4 and 2 <= v <= 7:
            return osc(pelo, 0.9)
        if estilo == "largo" and cara in ("atras", "der", "izq") and v >= 4:
            return pelo if (u + v) % 3 else osc(pelo, 0.85)
        if estilo == "rulos" and cara == "arriba" and (u + v) % 3 == 0:
            return osc(pelo, 1.15)
        if extra.get("lentes") and cara == "frente" and v == 4 and u in (1, 2, 3, 4, 5, 6):
            return (20, 20, 22)
        return None
    return fn


def hacer_skin(i):
    rng = random.Random(1000 + i)
    tono = TONOS[i % len(TONOS)]                         # todos los tonos aparecen por igual
    estilo = ESTILOS[(i * 5 + 3) % len(ESTILOS)] if i < 24 else rng.choice(ESTILOS)
    nombres_pelo = list(PELOS)
    pelo = PELOS[nombres_pelo[(i * 7 + 1) % len(nombres_pelo)]] if i < 24 else PELOS[rng.choice(nombres_pelo)]
    ojos = OJOS[(i * 3) % len(OJOS)] if i < 24 else rng.choice(OJOS)
    gorra = GORRAS[i % len(GORRAS)] if i < 24 else rng.choice(GORRAS)
    if i < 24:
        extra = {"pecas": i % 5 == 2, "sonrisa": i % 3 == 0, "lentes": i % 7 == 4}
    else:
        extra = {"pecas": rng.random() < 0.25, "sonrisa": rng.random() < 0.4, "lentes": rng.random() < 0.15,
                 "auriculares": rng.random() < 0.2, "vincha": rng.random() < 0.15}
        if estilo == "gorra":
            extra["vincha"] = extra["auriculares"] = False
    s = Skin()
    s.caja(0, 0, 8, 8, 8, cabeza(tono, pelo, estilo, ojos, rng, extra))
    s.caja(32, 0, 8, 8, 8, sombrero(estilo, pelo, gorra, extra))
    s.caja(16, 16, 8, 12, 4, lambda c, u, v, w, h: uniforme_cuerpo(c, u, v, w, h))
    s.caja(16, 32, 8, 12, 4, lambda c, u, v, w, h: uniforme_cuerpo(c, u, v, w, h, overlay=True))
    s.caja(40, 16, 4, 12, 4, brazo(tono))
    s.caja(32, 48, 4, 12, 4, brazo(tono))
    s.caja(40, 32, 4, 12, 4, mangas_overlay)
    s.caja(48, 48, 4, 12, 4, mangas_overlay)
    s.caja(0, 16, 4, 12, 4, pierna("der"))
    s.caja(16, 48, 4, 12, 4, pierna("izq"))
    return s.im


def armadura():
    """Capas del uniforme para la armadura de los jugadores (64x32)."""
    capa1 = Skin()
    capa1.im = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    capa1.caja(16, 16, 8, 12, 4, lambda c, u, v, w, h: uniforme_cuerpo(c, u, v, w, h))
    capa1.caja(40, 16, 4, 12, 4, lambda c, u, v, w, h: None if v >= 9 or c == "abajo" else brazo((0, 0, 0))(c, u, v, w, h))
    capa1.caja(0, 16, 4, 12, 4, lambda c, u, v, w, h: pierna("der")(c, u, v, w, h) if (v >= 9 or c == "abajo") else None)
    capa2 = Skin()
    capa2.im = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    capa2.caja(16, 16, 8, 12, 4, lambda c, u, v, w, h: uniforme_cuerpo(c, u, v, w, h) if (v >= 8 and c not in ("arriba",)) else None)
    capa2.caja(0, 16, 4, 12, 4, lambda c, u, v, w, h: None if v >= 9 else pierna("der")(c, u, v, w, h))
    return capa1.im, capa2.im


def icono(dibujo):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, fila in enumerate(dibujo):
        for x, ch in enumerate(fila):
            c = {"m": UNIF, "o": UNIF_OSC, "n": ADORNO, "N": ADORNO_OSC, "w": BLANCO, "g": SUELA,
                 "z": CIERRE, "r": KITE[0], "y": KITE[1], "b": KITE[2], "v": KITE[3], "k": (40, 34, 30)}.get(ch)
            if c:
                im.putpixel((x, y), c + (255,))
    return im


CAMISA = [
    "................",
    "....kkk..kkk....",
    "...kmmnnnnmmk...",
    "..kmmmmnnmmmmk..",
    ".kmmmmmzzmmmmmk.",
    "kmmmrmmzzmmmmmmk",
    "kmmyrbmzzmmmmmmk",
    "kooovmmzzmmmmook",
    ".kk.kmmzzmmmk.kk",
    "....kmmzzmmmk...",
    "....kmmzzmmmk...",
    "....knnnnnnnk...",
    "....kmmzzmmmk...",
    "....koooooook...",
    ".....kkkkkkk....",
    "................",
]
PANTALON = [
    "................",
    "....kkkkkkkk....",
    "....knnnnnnk....",
    "....kmmmmmmk....",
    "....kmmmmmmk....",
    "....kmmkkmmk....",
    "...kmnmk.kmnmk..",
    "...kmnmk.kmnmk..",
    "...kmnmk.kmnmk..",
    "...kmnmk.kmnmk..",
    "...kmnmk.kmnmk..",
    "...kmnmk.kmnmk..",
    "...koook.koook..",
    "...kkkkk.kkkkk..",
    "................",
    "................",
]
ZAPATILLAS = [
    "................",
    "................",
    "................",
    "................",
    "..kkk.....kkk...",
    ".kwwwk...kwwwk..",
    ".kwnwk...kwnwk..",
    ".kwwwkk..kwwwkk.",
    ".kwwwwwk.kwwwwwk",
    ".kwwwwwwkkwwwwwwk"[:16],
    ".kgggggk.kgggggk",
    "..kkkkk...kkkkk.",
    "................",
    "................",
    "................",
    "................",
]


def frente(skin, escala=6):
    """Vista de frente (16x32) armada desde la skin, con capas exteriores."""
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))

    def pega(sx, sy, w, h, dx, dy):
        out.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))

    pega(8, 8, 8, 8, 4, 0)
    pega(40, 8, 8, 8, 4, 0)
    pega(20, 20, 8, 12, 4, 8)
    pega(20, 36, 8, 12, 4, 8)
    pega(44, 20, 4, 12, 0, 8)
    pega(44, 36, 4, 12, 0, 8)
    pega(36, 52, 4, 12, 12, 8)
    pega(52, 52, 4, 12, 12, 8)
    pega(4, 20, 4, 12, 4, 20)
    pega(20, 52, 4, 12, 8, 20)
    return out.resize((16 * escala, 32 * escala), Image.NEAREST)


if __name__ == "__main__":
    carpeta = os.path.join(RES, "assets/juegosdelpatio/textures/entity/jugador")
    os.makedirs(carpeta, exist_ok=True)
    skins = []
    for i in range(N_SKINS):
        im = hacer_skin(i)
        im.save(os.path.join(carpeta, f"skin_{i}.png"))
        skins.append(im)
    a1, a2 = armadura()
    arm = os.path.join(RES, "assets/juegosdelpatio/textures/models/armor")
    os.makedirs(arm, exist_ok=True)
    a1.save(os.path.join(arm, "uniforme_layer_1.png"))
    a2.save(os.path.join(arm, "uniforme_layer_2.png"))
    items = os.path.join(RES, "assets/juegosdelpatio/textures/item")
    icono(CAMISA).save(os.path.join(items, "uniforme_camisa.png"))
    icono(PANTALON).save(os.path.join(items, "uniforme_pantalon.png"))
    icono(ZAPATILLAS).save(os.path.join(items, "uniforme_zapatillas.png"))

    # hoja de muestra: los 24 jugadores de frente
    cols, filas, esc = 8, 6, 6
    hoja = Image.new("RGBA", (cols * (16 * esc + 24) + 24, filas * (32 * esc + 30) + 24), (22, 24, 30, 255))
    for i, im in enumerate(skins):
        c, f = i % cols, i // cols
        hoja.alpha_composite(frente(im, esc), (24 + c * (16 * esc + 24), 24 + f * (32 * esc + 30)))
    hoja.convert("RGB").save(MUESTRA)
    print("skins:", len(skins))
