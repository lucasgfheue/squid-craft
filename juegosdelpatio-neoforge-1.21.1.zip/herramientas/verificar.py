#!/usr/bin/env python3
"""Revisa el proyecto: JSON, TOML, YAML, y la plantilla NBT (lectura completa)."""
import glob
import gzip
import json
import os
import struct
import sys
import tomllib

raiz = sys.argv[1]
errores = 0

# --- JSON / mcmeta
for d, _, fs in os.walk(raiz):
    for f in fs:
        if f.endswith((".json", ".mcmeta")):
            p = os.path.join(d, f)
            try:
                json.load(open(p, encoding="utf-8"))
            except Exception as e:
                errores += 1
                print("JSON MAL:", p, e)

# --- TOML
toml = tomllib.load(open(os.path.join(raiz, "src/main/resources/META-INF/neoforge.mods.toml"), "rb"))
assert toml["modLoader"] == "javafml" and toml["mods"][0]["modId"] == "juegosdelpatio", toml
print("toml ok:", toml["mods"][0]["displayName"], toml["mods"][0]["version"])

# --- YAML
try:
    import yaml
    wf = yaml.safe_load(open(os.path.join(raiz, ".github/workflows/compilar.yml")))
    pasos = [s.get("name") for s in wf["jobs"]["compilar"]["steps"]]
    # si falla una descarga, Gradle se vuelve a intentar solo (hasta 3 veces); lo descargado queda guardado para la
    # próxima; y si falla igual, el error sale arriba de todo, en el resumen
    paso_g = [s for s in wf["jobs"]["compilar"]["steps"] if s.get("name") == "Compilar con Gradle"][0]
    assert "for intento in 1 2 3; do" in paso_g["run"] and "::error title=" in paso_g["run"] and "DESCARGA" in paso_g["env"]
    java_wf = [s for s in wf["jobs"]["compilar"]["steps"] if str(s.get("uses", "")).startswith("actions/setup-java")][0]
    assert java_wf["with"]["cache"] == "gradle"
    print("workflow ok:", pasos)
except ImportError:
    print("(sin PyYAML, no se revisó el YAML)")


# --- NBT
def leer_nbt(b):
    pos = 0

    def u(fmt):
        nonlocal pos
        v = struct.unpack_from(fmt, b, pos)
        pos += struct.calcsize(fmt)
        return v[0]

    def s():
        n = u(">H")
        nonlocal pos
        v = b[pos:pos + n].decode("utf-8")
        pos += n
        return v

    def payload(t):
        if t == 1: return u(">b")
        if t == 2: return u(">h")
        if t == 3: return u(">i")
        if t == 4: return u(">q")
        if t == 5: return u(">f")
        if t == 6: return u(">d")
        if t == 8: return s()
        if t == 9:
            et = u(">b"); n = u(">i")
            return [payload(et) for _ in range(n)]
        if t == 10:
            c = {}
            while True:
                ct = u(">b")
                if ct == 0:
                    return c
                nombre = s()
                c[nombre] = payload(ct)
        raise ValueError(f"tag {t}")

    assert u(">b") == 10
    s()
    raiz_tag = payload(10)
    assert pos == len(b), "sobran bytes"
    return raiz_tag


nbt = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt")).read())
sx, sy, sz = nbt["size"]
pal = nbt["palette"]
print("nbt ok: DataVersion", nbt["DataVersion"], "tamaño", nbt["size"], "paleta", len(pal), "bloques", len(nbt["blocks"]))
assert nbt["DataVersion"] == 3955
vistos = set()
for bl in nbt["blocks"]:
    x, y, z = bl["pos"]
    assert 0 <= x < sx and 0 <= y < sy and 0 <= z < sz
    assert 0 <= bl["state"] < len(pal)
    assert (x, y, z) not in vistos
    vistos.add((x, y, z))

# Bloques y propiedades válidos en 1.21.1
VALIDOS = {
    "smooth_stone": {}, "polished_andesite": {}, "polished_deepslate": {}, "deepslate_tiles": {},
    "tuff_bricks": {}, "polished_tuff": {}, "chiseled_tuff_bricks": {}, "iron_block": {},
    "polished_blackstone": {}, "sea_lantern": {},
    "waxed_copper_bulb": {"lit": {"true", "false"}, "powered": {"true", "false"}},
    "waxed_copper_grate": {"waterlogged": {"true", "false"}},
    "white_bed": {"facing": {"north", "south", "east", "west"}, "part": {"head", "foot"}, "occupied": {"true", "false"}},
    "iron_bars": {k: {"true", "false"} for k in ("north", "south", "east", "west", "waterlogged")},
    "chain": {"axis": {"x", "y", "z"}, "waterlogged": {"true", "false"}},
    "lantern": {"hanging": {"true", "false"}, "waterlogged": {"true", "false"}},
}
B = {"true", "false"}
H4 = {"north", "south", "east", "west"}
VALIDOS.update({
    "quartz_stairs": {"facing": H4, "half": {"top", "bottom"}, "shape": {"straight", "inner_left", "inner_right", "outer_left", "outer_right"}, "waterlogged": B},
    "iron_trapdoor": {"facing": H4, "half": {"top", "bottom"}, "open": B, "powered": B, "waterlogged": B},
    "birch_door": {"facing": H4, "half": {"upper", "lower"}, "hinge": {"left", "right"}, "open": B, "powered": B},
    "water_cauldron": {"level": {"1", "2", "3"}},
    "lever": {"face": {"floor", "wall", "ceiling"}, "facing": H4, "powered": B},
    "light_gray_stained_glass": {}, "light_blue_terracotta": {}, "quartz_bricks": {}, "smooth_quartz": {},
    "smooth_quartz_slab": {"type": {"top", "bottom", "double"}, "waterlogged": B},
    "lightning_rod": {"facing": H4 | {"up", "down"}, "powered": B, "waterlogged": B},
    "white_stained_glass_pane": {k: B for k in ("north", "south", "east", "west", "waterlogged")},
    "spruce_planks": {}, "dark_oak_planks": {},
    "spruce_slab": {"type": {"top", "bottom", "double"}, "waterlogged": B},
    "dark_oak_slab": {"type": {"top", "bottom", "double"}, "waterlogged": B},
    "white_candle": {"candles": {"1", "2", "3", "4"}, "lit": B, "waterlogged": B},
    "smoker": {"facing": H4, "lit": B},
    "barrel": {"facing": H4 | {"up", "down"}, "open": B},
    "cake": {"bites": {str(i) for i in range(7)}},
    "spruce_wall_sign": {"facing": H4, "waterlogged": B},
})
for c in ("white", "black", "red", "orange", "yellow", "lime", "green", "cyan", "blue", "purple", "light_blue", "light_gray"):
    VALIDOS[f"{c}_concrete"] = {}
for p in pal:
    ns, name = p["Name"].split(":")
    assert ns == "minecraft", p
    assert name in VALIDOS, f"bloque desconocido {name}"
    props = p.get("Properties", {})
    assert set(props) == set(VALIDOS[name]), (name, props)
    for k, v in props.items():
        assert v in VALIDOS[name][k], (name, k, v)

# Camas: cada mitad tiene su pareja correcta
estado = {tuple(bl["pos"]): pal[bl["state"]] for bl in nbt["blocks"]}
D = {"north": (0, -1), "south": (0, 1), "east": (1, 0), "west": (-1, 0)}
camas = 0
for (x, y, z), p in estado.items():
    if p["Name"] == "minecraft:white_bed" and p["Properties"]["part"] == "foot":
        dx, dz = D[p["Properties"]["facing"]]
        h = estado.get((x + dx, y, z + dz))
        assert h and h["Name"] == p["Name"] and h["Properties"]["part"] == "head" and h["Properties"]["facing"] == p["Properties"]["facing"], (x, y, z)
        camas += 1
print("camas emparejadas:", camas)

# Llegada: el jugador aparece en (32, 1, 33) de la plantilla -> piso sólido y 2 bloques libres
assert estado.get((32, 0, 33)) and (32, 1, 33) not in estado and (32, 2, 33) not in estado
# Carteles con su texto
carteles = [bl for bl in nbt["blocks"] if pal[bl["state"]]["Name"] == "minecraft:spruce_wall_sign"]
for bl in carteles:
    assert len(bl["nbt"]["front_text"]["messages"]) == 4 and len(bl["nbt"]["back_text"]["messages"]) == 4
    json.loads(bl["nbt"]["front_text"]["messages"][1])
print("carteles:", [json.loads(bl["nbt"]["front_text"]["messages"][1])["text"] for bl in carteles])
# Puertas abiertas en la pared del salón (z=29): 3 de ancho x 4 de alto
for xc in (12, 52):
    for x in range(xc - 1, xc + 2):
        for y in range(1, 5):
            assert (x, y, 29) not in estado, (x, y)
# El chequeo "ya construido" usa la esquina (0,0,0): tiene que haber bloque
assert (0, 0, 0) in estado
print("llegada y esquina ok")
print("errores JSON:", errores)

# --- texturas y traducciones de los bots y el uniforme
from PIL import Image
base = os.path.join(raiz, "src/main/resources/assets/juegosdelpatio")
for i in range(48):
    im = Image.open(os.path.join(base, f"textures/entity/jugador/skin_{i}.png"))
    assert im.size == (64, 64) and im.mode == "RGBA", (i, im.size, im.mode)
for capa in (1, 2):
    im = Image.open(os.path.join(base, f"textures/models/armor/uniforme_layer_{capa}.png"))
    assert im.size == (64, 32), im.size
for d, _, fs in os.walk(os.path.join(base, "models/item")):
    for f in fs:
        modelo = json.load(open(os.path.join(d, f)))
        for t in modelo.get("textures", {}).values():
            ns, ruta = t.split(":")
            assert os.path.exists(os.path.join(raiz, f"src/main/resources/assets/{ns}/textures/{ruta}.png")), t
claves = ["entity.juegosdelpatio.jugador", "item.juegosdelpatio.huevo_jugador", "item.juegosdelpatio.uniforme_camisa",
          "item.juegosdelpatio.uniforme_pantalon", "item.juegosdelpatio.uniforme_zapatillas", "mensaje.juegosdelpatio.bots"]
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    faltan = [k for k in claves if k not in lang]
    assert not faltan, (f, faltan)
for item in ("invitacion", "huevo_jugador", "uniforme_camisa", "uniforme_pantalon", "uniforme_zapatillas"):
    assert os.path.exists(os.path.join(base, f"models/item/{item}.json")), item
print("texturas, modelos y traducciones ok")

# --- guardias, armas y balas: todo lo registrado en Java tiene modelo, textura y traducción
import re
java = {}
for d, _, fs in os.walk(os.path.join(raiz, "src/main/java")):
    for f in fs:
        if f.endswith(".java"):
            java[f] = open(os.path.join(d, f), encoding="utf-8").read()
registro = java["Registro.java"]
objetos = re.findall(r'OBJETOS\.register\("([a-z_]+)"', registro) + re.findall(r'registerSimpleItem\("([a-z_]+)"', registro)
entidades = re.findall(r'ENTIDADES\.register\("([a-z_]+)"', registro)
rangos = re.findall(r'^\s+[A-Z]+\("([a-z]+)",', java["Rango.java"], re.M)
assert set(objetos) >= {"porra", "pistola", "rifle", "escopeta", "bala", "huevo_guardia"}, objetos
assert set(entidades) == {"jugador", "guardia", "bala", "asiento", "cuerpo", "robot", "cazador"}, entidades
assert rangos == ["vigilante", "guardia", "sargento", "comandante"], rangos
usadas = set()
for texto in java.values():
    usadas |= set(re.findall(r'Component\.translatable\("([a-z_.]+)"', texto))
    usadas |= set(re.findall(r'"((?:mensaje|titulo|barra|juego|ceremonia|voto|comida)\.juegosdelpatio\.[a-z_0-9]+)"', texto))
usadas = {k for k in usadas if not k.endswith(".") and not k.endswith("_")}   # los que se arman con "+ numero"
hechos_ = int(re.search(r"JUEGOS_HECHOS = (\d+);", java["Juego.java"]).group(1))
necesarias = usadas | {f"item.juegosdelpatio.{o}" for o in objetos} | {f"entity.juegosdelpatio.{e}" for e in entidades} \
    | {f"rango.juegosdelpatio.{r}" for r in rangos} | {f"juego.juegosdelpatio.nombre_{n_}" for n_ in range(1, hechos_ + 1)} \
    | {"comida.juegosdelpatio.menu_1", "comida.juegosdelpatio.menu_2", "item.juegosdelpatio.espada_buscador"}
conjuntos = {}
for f in sorted(os.listdir(os.path.join(base, "lang"))):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    faltan = sorted(necesarias - set(lang))
    assert not faltan, (f, faltan)
    conjuntos[f] = set(lang)
assert len({frozenset(v) for v in conjuntos.values()}) == 1, "los idiomas no tienen las mismas claves"
cer_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/Ceremonia.java"), encoding="utf-8").read()
partes_cer = set()
for bloque_ in re.findall(r"String\[\] DISCURSO\w* = \{([^}]*)\}", cer_txt):
    partes_cer |= set(re.findall(r'"([a-z_]+)"', bloque_))
assert {"bienvenida", "llamado_saludo", "resultados_premio", "resultados_votacion"} <= partes_cer, partes_cer
for f_ in conjuntos:                                            # las frases de las ceremonias se arman con +
    for p_ in partes_cer:
        assert f"ceremonia.juegosdelpatio.{p_}" in conjuntos[f_], (f_, p_)
for f_ in conjuntos:                                            # los motivos de eliminación se arman con +
    for m_ in ("te_moviste", "moviste_cabeza", "no_llegaste", "te_empujaron", "no_te_sentaste", "te_caiste",
               "no_juegas", "todavia_musica", "silla_ocupada", "mas_cerca", "te_encontraron", "no_atrapaste",
               "te_vio_el_cazador", "no_te_escondiste", "te_exploto_la_papa", "te_mataron", "perdio_tu_equipo",
               "cuenta_juego",
               "moriste", "te_caiste_grieta", "perdiste_el_estandarte", "se_cayo_grieta", "estandartes_mato",
               "estandartes_murio", "estandartes_todavia", "ya_termino", "no_pegar_companero", "con_estandarte_no"):
        assert f"mensaje.juegosdelpatio.{m_}" in conjuntos[f_], (f_, m_)
print("claves de idioma usadas:", len(necesarias), "en", len(conjuntos), "idiomas")
PADRES = {"minecraft:item/generated", "minecraft:item/handheld", "minecraft:item/crossbow", "minecraft:item/template_spawn_egg"}
for o in objetos:
    modelo = json.load(open(os.path.join(base, f"models/item/{o}.json")))
    assert modelo["parent"] in PADRES, (o, modelo["parent"])
    if "spawn_egg" not in modelo["parent"]:
        assert modelo["textures"]["layer0"] == f"juegosdelpatio:item/{o}", o
        im = Image.open(os.path.join(base, f"textures/item/{o}.png"))
        assert im.size == (16, 16) and im.mode == "RGBA", (o, im.size, im.mode)
for r in rangos:
    im = Image.open(os.path.join(base, f"textures/entity/guardia/{r}.png"))
    assert im.size == (64, 64) and im.mode == "RGBA", (r, im.size)
    # la cara (capa base de la cabeza) queda tapada entera por la máscara: sin agujeros
    assert all(im.getpixel((x, y))[3] == 255 for x in range(8, 16) for y in range(8, 16)), r
datos = os.path.join(raiz, "src/main/resources/data/juegosdelpatio")
for d, _, fs in os.walk(os.path.join(datos, "recipe")):
    for f in fs:
        receta = json.load(open(os.path.join(d, f)))
        ns, item = receta["result"]["id"].split(":")
        assert ns == "juegosdelpatio" and item in objetos, receta["result"]
        for ing in receta.get("ingredients", []):
            assert ing["item"].startswith("minecraft:"), ing
for d, _, fs in os.walk(os.path.join(datos, "advancement/recipes")):
    for f in fs:
        logro = json.load(open(os.path.join(d, f)))
        for receta in logro["rewards"]["recipes"]:
            assert os.path.exists(os.path.join(datos, "recipe", receta.split(":")[1] + ".json")), receta
print("guardias: rangos", rangos, "| objetos", len(objetos), "| entidades", entidades)

# --- portón, pasillo y ceremonia: el Java coincide con la plantilla y el desfile puede caminar
compl = java["Complejo.java"]
def const(nombre, texto=compl):
    return int(re.search(rf"{nombre}\s*=\s*(-?\d+)", texto).group(1))
PX0, PX1, PY, PZ, PALTO = (const("PORTON_X0"), const("PORTON_X1"), const("PORTON_Y"), const("PORTON_Z"), const("PORTON_ALTO"))
OX, OY, OZ = -32, 64, -33                                   # ORIGEN_DORMITORIO
assert re.search(r"ORIGEN_DORMITORIO = new BlockPos\(-32, 64, -33\)", compl)
def S_(wx, wy, wz):
    return (wx - OX, wy - OY, wz - OZ)
nombre = lambda pos: pal[estado[pos]["__i"]]["Name"] if False else (estado[pos]["Name"] if pos in estado else "minecraft:air")
for x in range(PX0, PX1 + 1):
    for fila in range(PALTO):
        esperado = "minecraft:polished_blackstone" if x in (PX0, PX1) or fila % 4 == 0 else "minecraft:iron_block"
        assert nombre(S_(x, PY + fila, PZ)) == esperado, (x, fila, nombre(S_(x, PY + fila, PZ)))
        assert nombre(S_(x, PY + PALTO + fila, PZ)) == "minecraft:air", ("hueco", x, fila)
        assert nombre(S_(x, PY + fila, PZ + 1)) == "minecraft:air", ("abertura", x, fila)
# caminar del pasillo a la sala con el portón abierto (BFS por el piso)
abierto = {pos: v for pos, v in estado.items()}
for x in range(PX0, PX1 + 1):
    for fila in range(PALTO):
        abierto.pop(S_(x, PY + fila, PZ), None)
def libre(pos):
    n = abierto.get(pos, {"Name": "minecraft:air"})["Name"]
    return n == "minecraft:air" or "carpet" in n
def pisable(x, z):
    return S_(0, 0, 0) and (x, 0, z) in abierto and libre((x, 1, z)) and libre((x, 2, z))
from collections import deque
import collections
cer = java["Ceremonia.java"]
def vec(nombre_v):
    m = re.search(rf"{nombre_v} = new Vec3\(([-\d.]+), ([-\d.]+), ([-\d.]+)\)", cer)
    return tuple(float(v) for v in m.groups())
esc, pas = vec("ESCENARIO"), vec("PASILLO")
form = [tuple(float(v) for v in par) for par in re.findall(r"\{(-?[\d.]+), (-?[\d.]+)\}", cer.split("FORMACION =")[1].split(";")[0])]
assert len(form) == 5, form
import math
import random
def celda(wx, wz):
    sx, _, sz = S_(math.floor(wx), 65, math.floor(wz))
    return (sx, sz)
inicio = celda(pas[0], pas[2])
vistos, cola = {inicio}, deque([inicio])
while cola:
    x, z = cola.popleft()
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        n = (x + dx, z + dz)
        if n not in vistos and 0 <= n[0] < 65 and 0 <= n[1] < 102 and pisable(*n):
            vistos.add(n); cola.append(n)
for cx, cz in [(pas[0] + fx, pas[2] + fz) for fx, fz in form] + [(esc[0] + fx, esc[2] + fz) for fx, fz in form]:
    assert celda(cx, cz) in vistos, ("el desfile no llega a", cx, cz)
for wx in (-12.5, 13.5):                                    # esquinas del público
    for wz in (14.5, 28.5):
        assert celda(wx, wz) in vistos, ("público", wx, wz)
partes = re.findall(r'"([a-z]+)"', cer.split("DISCURSO =")[1].split(";")[0])
assert len(partes) == 8, partes
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for parte in partes:
        assert f"ceremonia.juegosdelpatio.{parte}" in lang, (f, parte)
print("portón y ceremonia ok: el desfile camina", len(vistos), "celdas | frases:", len(partes))

# --- los puestos de guardia (y los lugares de al lado, por si hay más guardias que puestos) son pisables
puestos = re.findall(r"new Vec3\(([-\d.]+), 65, ([-\d.]+)\)", compl.split("PUESTOS = {")[1].split("};")[0])
assert len(puestos) == 2, len(puestos)
for px, pz in puestos:
    for dx in (0.0, 1.0, -1.0):
        assert celda(float(px) + dx, float(pz)) in vistos, ("puesto", px, pz, dx)
print("puestos de guardia ok:", len(puestos))

# --- Torre de los Juegos: bloques válidos y se puede subir caminando desde la sala hasta las 7 puertas
VALIDOS["deepslate_tile_stairs"] = {"facing": H4, "half": {"top", "bottom"},
                                    "shape": {"straight", "inner_left", "inner_right", "outer_left", "outer_right"},
                                    "waterlogged": B}
torre = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/torre.nbt")).read())
assert torre["size"] == [21, 72, 21], torre["size"]
for p_ in torre["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    props = p_.get("Properties", {})
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
assert re.search(r"ORIGEN_TORRE = new BlockPos\(-10, 64, -54\)", compl)
mundo = {}
for bl in nbt["blocks"]:
    x, y, z = bl["pos"]
    mundo[(x - 32, y + 64, z - 33)] = pal[bl["state"]]["Name"]
for bl in torre["blocks"]:
    x, y, z = bl["pos"]
    mundo[(x - 10, y + 64, z - 54)] = torre["palette"][bl["state"]]["Name"]
for x in range(PX0, PX1 + 1):                                 # el portón abierto
    for fila in range(PALTO):
        mundo.pop((x, PY + fila, PZ), None)
def pasa(p_):
    n_ = mundo.get(p_, "minecraft:air")
    return n_ == "minecraft:air" or "carpet" in n_
def parado(x, y, z):
    return not pasa((x, y - 1, z)) and pasa((x, y, z)) and pasa((x, y + 1, z))
inicio = (0, 65, 0)                                           # llegada al dormitorio
assert parado(*inicio)
vistos3, cola = {inicio}, deque([inicio])
while cola:
    x, y, z = cola.popleft()
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for dy in (0, 1, -1):
            n_ = (x + dx, y + dy, z + dz)
            if n_ in vistos3 or not (-33 <= n_[0] <= 33 and 64 < n_[1] < 141 and -55 <= n_[2] <= 69):
                continue
            if dy == 1 and not pasa((x, y + 2, z)):
                continue                                      # sin lugar para la cabeza al subir
            if parado(*n_):
                vistos3.add(n_)
                cola.append(n_)
frente_puertas = {1: (1, 9, 6), 2: (14, 17, 1), 3: (19, 25, 14), 4: (6, 33, 19), 5: (1, 41, 6), 6: (14, 49, 1),
                  7: (19, 57, 14)}
for numero, (lx, ly, lz) in frente_puertas.items():
    p_ = (lx - 10, ly + 64, lz - 54)
    assert p_ in vistos3, ("no se llega a la puerta", numero, p_)
pared = {1: (0, 6), 2: (14, 0), 3: (20, 14), 4: (6, 20), 5: (0, 6), 6: (14, 0), 7: (20, 14)}
for numero, (wx, wz) in pared.items():
    ly = frente_puertas[numero][1]
    assert mundo.get((wx - 10, ly + 64 + 1, wz - 54)) == "minecraft:iron_block", ("puerta", numero)
# --- día de juego: el comandante sube a la puerta 1 y entra al portal (los bots lo siguen); los sargentos en lugares
# pisables
juego_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/Juego.java"), encoding="utf-8").read()
bot_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/JugadorBot.java"), encoding="utf-8").read()
def vecs(texto, nombre_c):
    bloque = texto[texto.index(nombre_c + " = {"):]
    bloque = bloque[:bloque.index("};")]
    return [(math.floor(float(a)), int(float(b)), math.floor(float(c)))
            for a, b, c in re.findall(r"new Vec3\((-?[\d.]+), (-?[\d.]+), (-?[\d.]+)\)", bloque)]
def celda_de(texto, nombre_c):
    return tuple(int(v) for v in re.search(nombre_c + r" = new BlockPos\((-?\d+), (-?\d+), (-?\d+)\)", texto).groups())
camino_cmd = vecs(juego_txt, "CAMINO_COMANDANTE")
puestos_cam = vecs(juego_txt, "PUESTOS_CAMINO")
portal_j = celda_de(juego_txt, "PORTAL_1")
assert portal_j == (-10, 73, -48), portal_j                                 # la celda del medio de la puerta 1
assert len(puestos_cam) == 5, puestos_cam
for p_ in camino_cmd + puestos_cam:
    assert p_ in vistos3, ("lugar del camino que no se pisa", p_)
# los bots siguen al comandante (por el portón, el pasillo y el mismo camino de la torre) y entran al portal
assert "class IrAlJuegoGoal" in bot_txt and "this.goalSelector.addGoal(0, new IrAlJuegoGoal(this));" in bot_txt
assert "EsperarElJuegoGoal" not in bot_txt and "CAMINO_2 = {" not in bot_txt
ir_ = bot_txt.split("static class IrAlJuegoGoal")[1].split("\n    static class ")[0]
for frag_ in ("Juego.caminando()", "!Juego.estaEnArena(bot)", "Juego.caminoDeLaTorre(Juego.numero())",
              "Juego.portal(Juego.numero())", "paso = dondeEsta();", "espera = 10 + bot.getRandom().nextInt(180);"):
    assert frag_ in ir_, frag_
hasta_ = vecs(bot_txt, "HASTA_LA_TORRE")
assert len(hasta_) == 2 and hasta_[1] == (0, 65, -21), hasta_
for (hx_, hy_, hz_) in hasta_:
    for d_ in range(-3, 4):                                       # (cada uno va un poco corrido: hasta 3 al costado)
        assert (hx_ + d_, hy_, hz_) in vistos3, ("camino de los bots que no se pisa", hx_ + d_, hy_, hz_)
torre_j_ = juego_txt.split("static Vec3[] caminoDeLaTorre(int juego) {")[1].split("\n    }")[0]
for n_ in range(2, 8):
    assert f"case {n_} -> CAMINO_COMANDANTE_{n_};" in torre_j_, n_
assert "default -> CAMINO_COMANDANTE;" in torre_j_ and "Vec3[] recorrido = caminoDeLaTorre(numero);" in juego_txt
assert "    static BlockPos portal(int juego) {" in juego_txt
# subiendo a la torre los bots no saltan, y en la sala, el pasillo y la torre las caídas no lastiman a nadie
assert "} else if (Juego.caminando() && !Juego.estaEnArena(this)) {\n                saltitos = 0;" in bot_txt
assert ("if (evento.getSource().is(DamageTypeTags.IS_FALL) && victima.level().dimension().equals(Complejo.DIMENSION)\n"
        "                && !estaEnArena(victima)) {\n            evento.setCanceled(true);") in juego_txt
golpe_ = juego_txt.split("static void alRecibirGolpe(LivingIncomingDamageEvent evento) {")[1]
assert golpe_.index("DamageTypeTags.IS_FALL") < golpe_.index("numero == TEJO")          # antes que todo lo demás
ult = camino_cmd[-1]
assert ult[1] == portal_j[1] and portal_j[0] == ult[0] - 1 and abs(portal_j[2] - ult[2]) <= 1   # el portal, al lado
def pasos(a, b):
    vistos_, cola_ = {a: 0}, deque([a])
    while cola_:
        p_ = cola_.popleft()
        if p_ == b:
            return vistos_[p_]
        x, y, z = p_
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            for dy in (0, 1, -1):
                n_ = (x + dx, y + dy, z + dz)
                if n_ in vistos_ or n_ not in vistos3 or (dy == 1 and not pasa((x, y + 2, z))):
                    continue
                vistos_[n_] = vistos_[p_] + 1
                cola_.append(n_)
    return None
tramos = [pasos(a, b) for a, b in zip([(0, 65, -21)] + camino_cmd[:-1], camino_cmd)]
assert all(t_ is not None and t_ <= 28 for t_ in tramos), ("tramos del comandante", tramos)
sala_c = {n: int(re.search(rf"{n} = (-?\d+);", juego_txt).group(1)) for n in ("SALA_CX0", "SALA_CX1", "SALA_CZ0", "SALA_CZ1")}
for (ox_, oz_, sx_, sz_) in ((-32, -33, nbt["size"][0], nbt["size"][2]), (-10, -54, torre["size"][0], torre["size"][2])):
    assert sala_c["SALA_CX0"] <= ox_ >> 4 and (ox_ + sx_ - 1) >> 4 <= sala_c["SALA_CX1"], ("chunks x de la sala", ox_, sx_)
    assert sala_c["SALA_CZ0"] <= oz_ >> 4 and (oz_ + sz_ - 1) >> 4 <= sala_c["SALA_CZ1"], ("chunks z de la sala", oz_, sz_)
camino_cmd2 = vecs(juego_txt, "CAMINO_COMANDANTE_2")
portal_j2 = celda_de(juego_txt, "PORTAL_2")
assert portal_j2 == (4, 81, -54), portal_j2                                 # la celda del medio de la puerta 2
assert camino_cmd2[:2] == camino_cmd
for p_ in camino_cmd2:
    assert p_ in vistos3, ("lugar del camino a la puerta 2 que no se pisa", p_)
ult2 = camino_cmd2[-1]
assert ult2[1] == portal_j2[1] and ult2[0] == portal_j2[0] and portal_j2[2] == ult2[2] - 2      # el portal, adelante
tramos2 = [pasos(a, b) for a, b in zip(camino_cmd2[:-1], camino_cmd2[1:])]
assert all(t_ is not None and t_ <= 40 for t_ in tramos2), ("tramos a la puerta 2", tramos2)
assert (ult2[0], ult2[1], ult2[2] - 1) in vistos3                                    # el paso de adelante del portal
print("día de juego ok: comandante en tramos de", tramos, "pasos hasta el portal; a la puerta 2:", tramos2,
      "(los bots lo siguen, sin saltar, y en el complejo las caídas no lastiman)")
# --- reparto de comida: vigilantes detrás del mostrador; los bots llegan por la puerta del comedor y hacen la fila
comida_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/Comida.java"), encoding="utf-8").read()
puestos_com = vecs(comida_txt, "PUESTOS")
ruta_com = vecs(bot_txt, "RUTA_COMEDOR")
fila_z = float(re.search(r"FILA_Z = (-?[\d.]+);", bot_txt).group(1))
fila_x0 = float(re.search(r"FILA_X0 = (-?[\d.]+);", bot_txt).group(1))
alcance_c = float(re.search(r"ALCANCE = ([\d.]+);", comida_txt).group(1))
fila_c = [(math.floor(fila_x0 + i_), 65, math.floor(fila_z)) for i_ in range(21)]
assert len(puestos_com) == 3 and len(ruta_com) == 2, (puestos_com, ruta_com)
for p_ in puestos_com + ruta_com + fila_c:
    assert p_ in vistos3 and parado(*p_), ("lugar del comedor que no se pisa", p_)
for x_, _, z_ in fila_c:                                        # desde cualquier lugar de la fila alcanza un vigilante
    d2_ = min((x_ + 0.5 - (px_ + 0.5)) ** 2 + (z_ + 0.5 - (pz_ + 0.5)) ** 2 for px_, _, pz_ in puestos_com)
    assert d2_ <= alcance_c ** 2, ("la fila queda lejos de los vigilantes", x_, d2_)
tramos_c = [pasos(ruta_com[0], ruta_com[1])] + [pasos(ruta_com[1], f_) for f_ in fila_c]
assert all(t_ is not None and t_ <= 40 for t_ in tramos_c), ("camino al comedor", tramos_c)
assert pasos((0, 65, 30), ruta_com[0]) is not None                # desde la plaza hasta la puerta del comedor
mostrador_ = {mundo.get((x_, 65, math.floor(fila_z) - 1), "air").split(":")[-1] for x_ in range(10, 30)}
assert mostrador_ <= {"smooth_quartz", "water_cauldron", "quartz_block", "quartz_bricks"}, ("mostrador", mostrador_)
print("comedor ok: 3 vigilantes detrás del mostrador; la fila (21 lugares) a", max(tramos_c), "pasos como mucho")
lamparas_numeros = sum(1 for bl in torre["blocks"] if "copper_bulb" in torre["palette"][bl["state"]]["Name"])
print("torre ok: se llega caminando a las 7 puertas;", len(vistos3), "lugares pisables; lámparas", lamparas_numeros)

# --- portales: recursos del bloque, puertas del Java iguales a las de torre.nbt, camas para los bots de noche
bloques_reg = re.findall(r'BLOQUES\.register\("([a-z_]+)"', registro)
assert bloques_reg == ["portal_juego", "silla"], bloques_reg
# la silla: 4 colores x 4 direcciones, cada modelo hijo del modelo base, con texturas que existen en Minecraft
silla_e = json.load(open(os.path.join(base, "blockstates/silla.json")))["variants"]
assert set(silla_e) == {f"color={c},facing={f}" for c in range(4) for f in ("north", "east", "south", "west")}, silla_e
assert all(silla_e[f"color={c},facing={f}"].get("y", 0) == g for c in range(4)
           for f, g in (("north", 0), ("east", 90), ("south", 180), ("west", 270)))
silla_base = json.load(open(os.path.join(base, "models/block/silla.json")))
assert len(silla_base["elements"]) >= 8 and silla_base["textures"]["particle"] == "#marco"
for el_ in silla_base["elements"]:
    assert all(-16 <= v <= 32 for v in el_["from"] + el_["to"]) and all(a <= b for a, b in zip(el_["from"], el_["to"]))
    assert {c["texture"] for c in el_["faces"].values()} <= {"#marco", "#color"}
for c in range(4):
    hijo_ = json.load(open(os.path.join(base, f"models/block/silla_{c}.json")))
    assert hijo_["parent"] == "juegosdelpatio:block/silla" and set(hijo_["textures"]) == {"marco", "color", "particle"}
    assert hijo_["textures"]["color"].endswith("_concrete") and "stripped_dark_oak_log" in hijo_["textures"]["marco"]
estado_json = json.load(open(os.path.join(base, "blockstates/portal_juego.json")))
modelo_ref = estado_json["multipart"][0]["apply"]["model"]
assert modelo_ref == "juegosdelpatio:block/portal_juego", modelo_ref
modelo_b = json.load(open(os.path.join(base, "models/block/portal_juego.json")))
assert modelo_b["parent"] == "minecraft:block/cube_all" and modelo_b["render_type"] == "minecraft:translucent"
tex = Image.open(os.path.join(base, "textures/block/portal_juego.png"))
assert tex.mode == "RGBA" and tex.size[0] == 16 and tex.size[1] % 16 == 0 and tex.size[1] > 16, tex.size
anim = json.load(open(os.path.join(base, "textures/block/portal_juego.png.mcmeta")))
assert anim["animation"]["frametime"] >= 1
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for b_ in bloques_reg:
        assert f"block.juegosdelpatio.{b_}" in lang, (f, b_)
port = java["Portales.java"]
tabla = [tuple(int(v) for v in t) for t in re.findall(r"\{(\d), (\d+), (\d+)\}", port.split("PUERTAS =")[1].split(";")[0])]
assert tabla == [(0, 6, 8), (1, 14, 16), (2, 14, 24), (3, 6, 32), (0, 6, 40), (1, 14, 48), (2, 14, 56)], tabla
torre_b = {tuple(bl["pos"]): torre["palette"][bl["state"]]["Name"] for bl in torre["blocks"]}
for pared_, centro_, nivel_ in tabla:
    for col in (-1, 0, 1):
        x_, z_ = {0: (0, centro_ - col), 1: (centro_ + col, 0), 2: (20, centro_ + col), 3: (centro_ - col, 20)}[pared_]
        for fila in range(4):
            esperado = "minecraft:polished_blackstone" if fila in (0, 3) else "minecraft:iron_block"
            assert torre_b.get((x_, nivel_ + 1 + fila, z_)) == esperado, ("puerta", pared_, centro_, nivel_, col, fila)
camas_abajo = sum(1 for bl in nbt["blocks"] if bl["pos"][1] == 1 and "white_bed" in pal[bl["state"]]["Name"]
                  and pal[bl["state"]].get("Properties", {}).get("part") == "head")
assert camas_abajo >= 150, camas_abajo
noche_ = java["Noche.java"]
assert "DURACION = 2 * 60 * 20" in noche_ and "ESPERA_TRAS_CEREMONIA = 60 * 20" in noche_
print("portales ok: 7 puertas con portal; camas de abajo para los bots:", camas_abajo)

# --- arena de Luz verde, luz roja: tamaño, bloques válidos y que coincida con Juego.java
juego_j = java["Juego.java"]
arena = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/luz_verde.nbt")).read())
assert arena["size"] == [102, 38, 308], arena["size"]
assert re.search(r"ORIGEN_ARENA = new BlockPos\(949, 99, -1\)", juego_j)
VALIDOS["light"] = {"level": {str(i) for i in range(16)}, "waterlogged": B}
for extra_b in ("barrier", "gold_block", "iron_block", "gray_concrete", "light_gray_concrete", "black_concrete", "red_concrete"):
    VALIDOS[extra_b] = {}
for p_ in arena["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    props = p_.get("Properties", {})
    if ns == "juegosdelpatio":
        assert nombre_b == "portal_juego" and props == {"juego": "1", "regreso": "true"}, p_
        continue
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
am = {}
for bl in arena["blocks"]:
    x, y, z = bl["pos"]
    am[(x + 949, y + 99, z - 1)] = arena["palette"][bl["state"]]["Name"].split(":")[1]
def entero(nombre_c):
    return int(re.search(rf"{nombre_c} = (-?\d+);", juego_j).group(1))
# la cabeza del Vigía en la plantilla es la de Vigia.java, girada de espaldas (como Vigia.DE_ESPALDAS)
vigia_j = java["Vigia.java"]
tabla_v = vigia_j[vigia_j.index("CABEZA = {"):]
filas_v = re.findall(r'"([IGLKR]{8})"', tabla_v[:tabla_v.index("};")])
assert len(filas_v) == 64, len(filas_v)
letra_v = {"I": "iron_block", "G": "gray_concrete", "L": "light_gray_concrete", "K": "black_concrete", "R": "red_concrete"}
vx0, vy0_, vz0 = (int(re.search(rf"static final int {n} = (-?\d+);", vigia_j).group(1)) for n in ("X0", "Y0", "Z0"))
for y in range(8):
    for z in range(8):
        for x in range(8):
            assert am.get((vx0 + 7 - x, vy0_ + y, vz0 + 7 - z)) == letra_v[filas_v[8 * y + z][x]], ("cabeza", x, y, z)
assert "R" in "".join(filas_v[8 * y] for y in range(8)), "el visor rojo tiene que estar en la cara"
assert am.get((999, 121, 300)) == "gold_block" and am.get((996, 110, 300)) == "iron_block"   # corona en la espalda
assert all(am.get((x, 102, 301)) == "polished_blackstone" for x in range(991, 1009))         # pedestal
assert am.get((vx0 + 3, vy0_ - 1, vz0 + 3)) == "gray_concrete"                               # cuello: hombros del torso
# las luces de las paredes (como Juego.ponerLuces): apagadas en la plantilla
lados_x = [int(v) for v in re.search(r"LADOS_X = \{([^}]*)\}", juego_j).group(1).split(",")]
lados_z = [int(v) for v in re.search(r"LADOS_Z = \{([^}]*)\}", juego_j).group(1).split(",")]
ly0, ly1 = entero("LUZ_Y0"), entero("LUZ_Y1")
for x in lados_x:
    for zc in lados_z:
        for z in range(zc - 1, zc + 2):
            for y in range(ly0, ly1 + 1):
                assert am.get((x, y, z)) == "gray_concrete", ("luz de la pared", x, y, z)
        assert am.get((x, ly0 - 1, zc)) == am.get((x, ly1 + 1, zc)) == "polished_blackstone", ("marco", x, zc)
for x in range(950, 1050):
    for y in range(100, 104):
        assert am.get((x, y, 10)) == "barrier", ("barrera de salida", x, y)
def libre_a(p_):
    return am.get(p_) in (None, "light")                       # las luces invisibles no chocan
for x in range(952, 1037):                                      # lugares de salida (Juego.lugarDeSalida)
    for z in range(1, 9):
        assert (x, 99, z) in am and libre_a((x, 100, z)) and libre_a((x, 101, z)), ("salida", x, z)
assert am.get((1042, 102, 4)) == "polished_blackstone" and libre_a((1042, 103, 4)) and libre_a((1042, 104, 4))
for x in range(999, 1002):
    for y in range(100, 104):
        assert am.get((x, y, -1)) == "portal_juego", ("portal de vuelta", x, y)
meta = float(re.search(r"META_Z = ([\d.]+);", juego_j).group(1))
assert all(am.get((x, 99, int(meta))) in ("black_concrete", "white_concrete") for x in range(950, 1050))
for x0 in (952, 1047):                                          # lugares de los sargentos
    for z0 in (75, 175):
        assert (x0, 99, z0) in am and libre_a((x0, 100, z0)) and libre_a((x0, 101, z0))
partes_r = re.findall(r'"(reglas_\d|sillas_\d)"', juego_j)
assert {"sillas_1", "sillas_7", "reglas_7"} <= set(partes_r), partes_r
reg_s_ = re.search(r"REGLAS_SILLAS = \{([^}]*)\}", juego_j).group(1)
assert re.findall(r'"(\w+)"', reg_s_) == ["sillas_1", "sillas_2", "sillas_3", "sillas_4", "sillas_5", "sillas_6",
                                         "sillas_7", "reglas_7"], reg_s_
assert 'equals("sillas_4") ? Component.translatable(clave, Sillas.TIEMPO_SENTARSE / 20)' in juego_j
# la tecla para aguantar (la Z: en Las escondidas, que no te quiten la espada) y el paquete que avisa al servidor
cli_ = java["Cliente.java"]
teclas_ = re.findall(r'new KeyMapping\("([a-z_.]+)", InputConstants\.Type\.KEYSYM,\s*GLFW\.GLFW_KEY_Z, "([a-z_.]+)"\)', cli_)
assert teclas_ == [("key.juegosdelpatio.aguantar", "key.categories.juegosdelpatio")], teclas_
assert "evento.register(AGUANTAR)" in cli_ and "Cliente.AGUANTAR.consumeClick()" in java["ClienteTeclas.java"]
assert "busDelMod.addListener(Resistir::registrar)" in java["JuegosDelPatio.java"]
assert "registro.playToServer(TIPO, CODEC, Resistir::recibir)" in java["Resistir.java"]
# las luces que parpadean cuando para la música (servidor -> cliente, capa de pantalla, clics al mismo ritmo)
par_ = java["Parpadeo.java"]
patron_ = [int(n_) for n_ in re.search(r"PATRON = \{([\d, ]+)\};", par_).group(1).split(",")]
assert len(patron_) % 2 == 0 and sum(patron_) == 80, patron_          # termina con la luz prendida; 4 segundos
for i_ in range(0, len(patron_), 2):
    assert patron_[i_] + patron_[i_ + 1] >= 7, ("más de 3 destellos por segundo", patron_[i_:i_ + 2])
assert "DURACION = Arrays.stream(PATRON).sum();" in par_ and "registro.playToClient(TIPO, CODEC, Parpadeo::recibir)" in par_
assert "busDelMod.addListener(Parpadeo::registrar)" in java["JuegosDelPatio.java"]
assert 'evento.registerAbove(VanillaGuiLayers.CAMERA_OVERLAYS, Complejo.id("luces"), ClienteLuces::dibujar)' in cli_
assert "ClienteLuces.tick(minecraft);" in java["ClienteTeclas.java"]
assert "options.hideLightningFlash().get()" in java["ClienteLuces.java"]          # la opción de accesibilidad
assert "@EventBusSubscriber" not in java["ClienteLuces.java"] and "Dist.CLIENT" in cli_
sil_ = java["Sillas.java"]
para_ = sil_.split("private static void pararMusica(")[1].split("\n    }\n")[0]
assert "empezarParpadeo(complejo);" in para_ and "ponerSillas(complejo, Math.max(1, GENTE.size() - faltanDeLaRonda()), azar);" in para_
assert "REACCION.put(id, REACCION_MIN + azar.nextInt(REACCION_AZAR));" in para_
assert "cortarParpadeo(complejo);" in sil_.split("static void limpiar(")[1].split("\n    }\n")[0]
assert "parpadear(complejo);" in sil_.split("static boolean tick(")[1].split("switch (estado)")[0]
# Asientos al vacío: 10 segundos para sentarse, con todas ocupadas al segundo se cae el piso; 3 rondas
assert int(re.search(r"TIEMPO_SENTARSE = (\d+);", sil_).group(1)) == 10 * 20
assert int(re.search(r"ESPERA_LLENO = (\d+);", sil_).group(1)) <= 40
assert "static final int RONDAS = 3;" in sil_ and "FALTAN_POR_CIENTO = {8, 10, 12};" in sil_
der_ = sil_.split("private static void derrumbe(ServerLevel complejo) {")[1].split("\n    }\n")[0]
assert "debajo.contains(pos)" in der_ and "cambiar(Estado.CAIDA);" in der_          # queda lo de debajo de las sillas
ter_ = sil_.split("private static void terminarRonda(ServerLevel complejo) {")[1].split("\n    }\n")[0]
assert ter_.index("Juego.eliminar(complejo, quien, false, \"no_te_sentaste\");") < ter_.index("restaurarPiso(complejo);")
assert "evento.setCanceled(true);" in sil_.split("static void alMontar(")[1].split("\n    }\n")[0]
sent_ = sil_.split("private static boolean sentadoAhi(")[1].split("\n    }\n")[0]
assert "asiento.blockPosition().equals(silla)" in sent_ and "asiento.positionRider(quien);" in java["Asiento.java"]
# los bots de las torres saltan con SaltosBot (en Asientos al vacío); en la papa caliente persiguen o se escapan por el
# valle; en Asientos y en la papa caliente no se chocan con nadie
bot_t_ = java["JugadorBot.java"]
bot_sillas_ = bot_t_.split("static class SillasGoal")[1].split("static class ")[0]
assert "saltos.ir(Sillas.CAMPO" in bot_sillas_ and "Sillas.sentarBot(bot, silla)" in bot_sillas_ and "saltos.volando()" in bot_sillas_
bot_tejo_ = bot_t_.split("static class TejoGoal")[1].split("static class ")[0]
assert "bot.doHurtTarget(presa);" in bot_tejo_ and "Tejo.huida(bot, peligro)" in bot_tejo_ and "Tejo.paseo(bot)" in bot_tejo_
assert "saltos" not in bot_tejo_ and "CAMPO" not in bot_tejo_
assert "!Sillas.sinChoques(this) && !Tejo.sinChoques(this)" in bot_t_
assert bot_t_.count("public boolean requiresUpdateEveryTick()") >= 3
sal_ = java["SaltosBot.java"]
jugador_bt = 0.98 * 0.13 / 0.454                                             # un jugador corriendo (bloques por tick)
assert "private static final int VUELO = 12;" in sal_ and "(apuntado.x - bot.getX()) / quedan" in sal_
# el calendario: jugar un juego otro día (con un comando) adelanta hasta el día de ese juego; nunca para atrás
jue_ = java["Juego.java"]
assert jue_.count("marcarDia(complejo, juego);") == 2 and "marcarDia(complejo);" not in jue_
assert "dia += juego - enElCiclo + (enElCiclo > juego ? Complejo.CICLO_DIAS : 0);" in jue_
assert re.search(r"CICLO_DIAS = 8;", java["Complejo.java"]) and re.search(r"JUEGOS = 7;", java["Complejo.java"])
def marcar_(dia_, juego_):
    ciclo_ = dia_ % 8
    return dia_ if ciclo_ == juego_ else dia_ + juego_ - ciclo_ + (8 if ciclo_ > juego_ else 0)
for dia_ in range(0, 40):
    for juego_ in range(1, 8):
        nuevo_ = marcar_(dia_, juego_)
        assert dia_ <= nuevo_ < dia_ + 8 and nuevo_ % 8 == juego_, (dia_, juego_, nuevo_)
# al terminar la noche: mañana del día siguiente, nunca antes del día que sigue al último juego
noc_ = java["Noche.java"]
assert "long manana = Math.max(dia + 1, estado.ultimoJuego() + 1);" in noc_ and "setDayTime(manana * 24000L)" in noc_
assert "setDayTime((dia + 1) * 24000L)" not in noc_
def amanece_(dia_, ultimo_):
    return max(dia_ + 1, ultimo_ + 1)
# el caso del jugador: el juego 1 con un comando el día 0 -> se juega el día 1; se duerme -> día 2 -> juego 2
dia_ = marcar_(0, 1)
assert dia_ == 1 and amanece_(dia_, dia_) % 8 == 2
# y si después del juego 1 alguien pone /time set day (el reloj vuelve al día 0): igual amanece el día 2
assert amanece_(0, dia_) == 2
# sin juegos todavía (-1) o con el último juego hace días: el día siguiente, como siempre
assert amanece_(0, -1) == 1 and amanece_(4, 2) == 5
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for clave in teclas_[0]:
        assert clave in lang, (f, clave)
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for clave in [f"juego.juegosdelpatio.{p_}" for p_ in partes_r] + [
            "ceremonia.juegosdelpatio.llamado_saludo", "ceremonia.juegosdelpatio.llamado_juego",
            "ceremonia.juegosdelpatio.llamado_puerta", "ceremonia.juegosdelpatio.llamado_minuto",
            "ceremonia.juegosdelpatio.resultados_pasaron"] + [f"juego.juegosdelpatio.ordinal_{n_}" for n_ in range(1, 8)]:
        assert clave in lang, (f, clave)
# luz: que no quede ningún rincón del piso a oscuras (la dimensión no tiene cielo que ilumine)
from collections import deque as _dq
luz_ = {}
cola_ = _dq()
EMITE_ = {"light": 15, "sea_lantern": 15, "portal_juego": 12}
for p_, n_ in am.items():
    if n_ in EMITE_:
        luz_[p_] = EMITE_[n_]
        cola_.append(p_)
while cola_:
    p_ = cola_.popleft()
    l_ = luz_[p_]
    if l_ <= 1:
        continue
    for d_ in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        q_ = (p_[0] + d_[0], p_[1] + d_[1], p_[2] + d_[2])
        if not (949 <= q_[0] <= 1050 and 99 <= q_[1] <= 131 and -1 <= q_[2] <= 306):
            continue
        if am.get(q_) not in (None, "light", "barrier", "portal_juego"):
            continue
        if luz_.get(q_, 0) < l_ - 1:
            luz_[q_] = l_ - 1
            cola_.append(q_)
piso_ = [luz_.get((x, 100, z), 0) for x in range(950, 1050) for z in range(0, 306) if libre_a((x, 100, z))]
assert min(piso_) >= 7, ("piso oscuro", min(piso_))
print("arena ok:", len(arena["blocks"]), "bloques; el Vigía (cabeza igual a Vigia.java), luces, barrera, podio, portal y meta;",
      "luz en el piso", min(piso_), "a", max(piso_))

# --- Asientos al vacío (en torres), Sálvese quien pueda (la estación) y La papa caliente (el valle): las arenas coinciden con
# el Java; en las torres se puede estar parado arriba y entre torre y torre hay vacío hasta el suelo
for extra_b in ("polished_blackstone_bricks", "chiseled_deepslate", "shroomlight", "red_nether_bricks", "nether_bricks",
                "dark_prismarine", "magma_block", "blackstone", "gold_block", "polished_diorite", "black_concrete",
                "gray_concrete"):
    VALIDOS[extra_b] = {}
for extra_b in ("ochre_froglight", "pearlescent_froglight", "verdant_froglight"):
    VALIDOS[extra_b] = {"axis": {"x", "y", "z"}}
def arena_torres(nombre_a, origen_a, tam_a, juego_a):
    """La arena (bloque -> nombre, en coordenadas del mundo), después de revisar tamaño y bloques."""
    nbt_a = leer_nbt(gzip.open(os.path.join(raiz, f"src/main/resources/data/juegosdelpatio/structure/{nombre_a}.nbt")).read())
    assert nbt_a["size"] == tam_a, (nombre_a, nbt_a["size"])
    for p_ in nbt_a["palette"]:
        ns, nombre_b = p_["Name"].split(":")
        props = p_.get("Properties", {})
        if ns == "juegosdelpatio":
            assert nombre_b == "portal_juego" and props == {"juego": str(juego_a), "regreso": "true"}, (nombre_a, p_)
            continue
        assert ns == "minecraft" and nombre_b in VALIDOS, (nombre_a, p_)
        assert set(props) == set(VALIDOS[nombre_b]), (nombre_a, nombre_b, props)
        for k, v in props.items():
            assert v in VALIDOS[nombre_b][k], (nombre_a, nombre_b, k, v)
    mapa_ = {}
    for bl in nbt_a["blocks"]:
        x, y, z = bl["pos"]
        mapa_[(x + origen_a[0], y + origen_a[1], z + origen_a[2])] = nbt_a["palette"][bl["state"]]["Name"].split(":")[1]
    return mapa_
def pasa_t(n_):
    return n_ is None or n_ == "light"
def parado_t(mapa_, x, z, y=100):
    return not pasa_t(mapa_.get((x, y - 1, z))) and pasa_t(mapa_.get((x, y, z))) and pasa_t(mapa_.get((x, y + 1, z)))
def vacio_hasta_el_suelo(mapa_, x, z):
    """Del piso de arriba (y = 99) hasta el suelo (y = 40) no hay nada (luces invisibles sí), y el suelo es firme."""
    return all(pasa_t(mapa_.get((x, y, z))) for y in range(41, 100)) and not pasa_t(mapa_.get((x, 40, z)))
def palco_ok(mapa_, texto_j, nombre_a):
    podio_ = re.search(r"PODIO = new Vec3\(([\d.]+), ([\d.]+), (-?[\d.]+)\)", texto_j).groups()
    px_, py_, pz_ = (math.floor(float(v)) for v in podio_)
    assert py_ == 102 and mapa_.get((px_, 101, pz_)) == "smooth_quartz", (nombre_a, "podio")
    for t_ in re.findall(r"new Vec3\(([\d.]+), 100\.0, (-?[\d.]+)\)", texto_j.split("PUESTOS_SARGENTOS = {")[1].split("};")[0]):
        assert parado_t(mapa_, math.floor(float(t_[0])), math.floor(float(t_[1]))), (nombre_a, "sargento", t_)

# Asientos al vacío
asi_ = arena_torres("asientos", (1969, 40, -17), [63, 78, 80], 3)
assert re.search(r"ORIGEN = new BlockPos\(1969, 40, -17\)", sil_) and 'Complejo.id("asientos")' in sil_
xs_ = [int(v) for v in re.search(r"X_TORRES = \{([\d, ]+)\}", sil_).group(1).split(",")]
zs_ = [int(v) for v in re.search(r"Z_TORRES = \{([\d, ]+)\}", sil_).group(1).split(",")]
lado_ = int(re.search(r"static final int LADO = (\d+);", sil_).group(1))
assert xs_ == [1974, 1985, 1996, 2007, 2018] and zs_ == [8, 19, 30, 41, 52] and lado_ == 9
for i_, x0_ in enumerate(xs_):
    for j_, z0_ in enumerate(zs_):
        for x in range(x0_, x0_ + lado_):
            for z in range(z0_, z0_ + lado_):
                if (i_, j_) == (2, 2):
                    assert not pasa_t(asi_.get((x, 103, z))), ("el gramófono", x, z)
                else:
                    assert parado_t(asi_, x, z), ("torre de los asientos", x, z)
                    esperado_ = ("polished_blackstone_bricks" if x in (x0_, x0_ + 8) or z in (z0_, z0_ + 8)
                                 else "polished_blackstone" if (x + z) % 2 == 0 else "polished_deepslate")
                    assert asi_.get((x, 99, z)) == esperado_, ("el piso de baile (Sillas.restaurarPiso)", x, z)
for x0_ in xs_[:-1]:                                            # entre torre y torre, 2 de vacío hasta el suelo
    for z in range(8, 61):
        for x in (x0_ + lado_, x0_ + lado_ + 1):
            assert vacio_hasta_el_suelo(asi_, x, z), ("vacío entre las torres", x, z)
assert "polished_blackstone_bricks" in sil_.lower() or "POLISHED_BLACKSTONE_BRICKS" in sil_
palco_ok(asi_, sil_, "asientos")
for x in range(1980, 2021):                                     # Sillas.lugarDeSalida: en el palco
    for z in range(-10, 0):
        assert parado_t(asi_, x, z), ("palco de los asientos", x, z)
boc_ = [float(v) for v in re.search(r"BOCINA = new Vec3\(([\d.]+), ([\d.]+), ([\d.]+)\)", sil_).groups()]
assert sum(1 for (x, y, z), n_ in asi_.items() if n_ == "gold_block" and y == math.floor(boc_[1]) - 1
           and math.hypot(x - math.floor(boc_[0]), z - math.floor(boc_[2])) <= 5.0) >= 12, "la boca de la bocina"
print("asientos ok:", len(asi_), "bloques; 24 torres de 9 x 9 con 2 de vacío, el gramófono en el medio")

# Sálvese quien pueda: la estación (los casilleros, el recorrido del Cazador, el vestíbulo) y que coincida con Casilleros.java
lang_p = json.load(open(os.path.join(raiz, "src/main/resources/assets/juegosdelpatio/lang/es_es.json"), encoding="utf-8"))
H4_ = {"north", "south", "east", "west"}
for extra_b, props_b in (("bricks", {}), ("stone_bricks", {}), ("cracked_stone_bricks", {}), ("tuff", {}), ("gravel", {}),
                         ("polished_basalt", {"axis": {"x", "y", "z"}}), ("deepslate", {"axis": {"x", "y", "z"}}),
                         ("stripped_dark_oak_wood", {"axis": {"x", "y", "z"}}), ("gray_stained_glass", {}),
                         ("black_stained_glass", {}), ("light_gray_concrete", {}), ("yellow_concrete", {}),
                         ("red_concrete", {}), ("anvil", {"facing": H4_}), ("polished_blackstone", {}),
                         ("polished_blackstone_bricks", {}),
                         ("iron_door", {"facing": H4_, "half": {"upper", "lower"}, "hinge": {"left", "right"}, "open": B,
                                        "powered": B}),
                         ("dark_oak_stairs", {"facing": H4_, "half": {"top", "bottom"}, "shape": {"straight"}, "waterlogged": B}),
                         ("redstone_lamp", {"lit": B}), ("barrier", {})):
    VALIDOS.setdefault(extra_b, props_b)
cas_j = java["Casilleros.java"]
cas_ = arena_torres("casilleros", (5955, 98, -18), [91, 30, 133], 2)
assert re.search(r"ORIGEN = new BlockPos\(5955, 98, -18\)", cas_j) and 'Complejo.id("casilleros")' in cas_j
def num_c(n_):
    return int(re.search(rf"static final int {n_} = (-?\d+);", cas_j).group(1))
assert num_c("PISO") == 100 and num_c("VERSION_ARENA") == 4 and num_c("RONDAS") == 5 and num_c("FALTAN") == 3
assert "private static final int DURACION_MAX_CASILLEROS = 8 * 60 * 20;" in juego_j      # (5 rondas: unos 4 minutos)
assert (num_c("X0"), num_c("X1"), num_c("Z0"), num_c("Z1")) == (5955, 6045, -18, 114)    # (y la fundición de antes)
assert (num_c("NAVE_X0"), num_c("NAVE_X1"), num_c("NAVE_Z0"), num_c("NAVE_Z1")) == (5961, 6039, 3, 103)
assert "static final int ALARMA = 20 * 20;" in cas_j and "static final int ARRANQUE = 3 * 20;" in cas_j
assert "static final double VISTA = 18.0;" in cas_j and "private static final double ANGULO = 35.0;" in cas_j
assert "private static final int ENTRE_RAYOS = 15;" in cas_j
for frag_ in ("RESERVADOS.put(mejor, yo);", "soltar(visto.getUUID());", "soltar(quien.getUUID());",
              "otro != null && !otro.equals(yo)"):                # cada bot corre a un casillero distinto
    assert frag_ in cas_j, frag_
lee_ = open(os.path.join(raiz, "README.md"), encoding="utf-8").read()
assert "**20 segundos**" in lee_ and "a menos de 18 bloques" in lee_ and "a los 3\n   segundos" in lee_
assert "**Son 5 rondas**" in lee_ and "siempre 3 menos que la gente que queda" in lee_
# los casilleros de Casilleros.java (los mismos que arma gen_casilleros.py)
for frag_ in ("for (int z = 8; z <= 98; z += 2) {\n            lista.add(new Casillero(5960, 5959, z));\n"
              "            lista.add(new Casillero(6040, 6041, z));",
              "for (int z = 32; z <= 86; z += 2) {\n            lista.add(new Casillero(5984, 5985, z));\n"
              "            lista.add(new Casillero(5988, 5987, z));\n            lista.add(new Casillero(6012, 6013, z));\n"
              "            lista.add(new Casillero(6016, 6015, z));"):
    assert frag_ in cas_j, frag_
casilleros_ = [(5960, 5959, z) for z in range(8, 99, 2)] + [(6040, 6041, z) for z in range(8, 99, 2)]
casilleros_ += [(px_, ax_, z) for z in range(32, 87, 2) for (px_, ax_) in ((5984, 5985), (5988, 5987), (6012, 6013), (6016, 6015))]
assert len(casilleros_) == 204
pal_c = {}
nbt_c = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/casilleros.nbt")).read())
for bl in nbt_c["blocks"]:
    x, y, z = bl["pos"]
    pal_c[(x + 5955, y + 98, z - 18)] = nbt_c["palette"][bl["state"]]
celdas_c = set()
for (px_, ax_, z) in casilleros_:
    afuera_ = px_ + (px_ - ax_)
    atras_ = ax_ + (ax_ - px_)
    mira_ = "west" if px_ > ax_ else "east"                     # como DoorBlock: cerrada, la hoja queda del lado de afuera
    for y_, mitad_ in ((100, "lower"), (101, "upper")):
        e_ = pal_c.get((px_, y_, z))
        assert e_ and e_["Name"] == "minecraft:iron_door" and e_["Properties"] == {
            "facing": mira_, "half": mitad_, "hinge": "left", "open": "false", "powered": "false"}, ("puerta", px_, y_, z, e_)
        assert pasa_t(cas_.get((ax_, y_, z))), ("adentro del casillero", ax_, y_, z)
        assert not pasa_t(cas_.get((atras_, y_, z))), ("el fondo del casillero", atras_, y_, z)
        for zz_ in (z - 1, z + 1):                               # los costados: nadie entra ni sale por ahí
            for x_ in (px_, ax_):
                assert not pasa_t(cas_.get((x_, y_, zz_))), ("costado del casillero", x_, y_, zz_)
    assert cas_.get((px_, 102, z)) == "red_concrete", ("la luz (Casilleros.Casillero.luz)", px_, z)
    assert not pasa_t(cas_.get((ax_, 102, z))) and not pasa_t(cas_.get((ax_, 99, z))), ("techo y piso", ax_, z)
    assert parado_t(cas_, afuera_, z), ("adelante del casillero (Casilleros.Casillero.afuera)", afuera_, z)
    assert 5961 <= afuera_ <= 6039 and 3 <= z <= 103
    celdas_c |= {(px_, z), (ax_, z)}
# nada de redstone que pueda abrir las puertas de hierro (las abre solo el juego)
assert not [n_ for n_ in cas_.values() if n_ in ("lever", "redstone_wire", "redstone_torch", "redstone_block", "stone_button",
                                                  "stone_pressure_plate", "heavy_weighted_pressure_plate", "observer")]
assert sum(1 for n_ in cas_.values() if n_ == "redstone_lamp") > 0               # (las lámparas del taller, prendidas)
# Casilleros.lugarLibre: en la nave hay lugar de sobra, afuera de los casilleros
libres_c = [(x, z) for x in range(5962, 6039) for z in range(5, 93) if parado_t(cas_, x, z) and (x, z) not in celdas_c]
assert len(libres_c) >= 4500, len(libres_c)
assert "!CELDAS.containsKey(celda(pos.getX(), pos.getZ()))" in cas_j
# el recorrido del Cazador: va por los tres pasillos sin atravesar nada (el cuerpo, de 12 de alto; los brazos, a los lados)
reco_ = [(float(a_), float(b_)) for a_, b_ in re.findall(r"new Vec3\(([\d.]+), PISO, ([\d.]+)\)",
                                                          cas_j.split("RECORRIDO = {")[1].split("};")[0])]
taller_ = [float(v) for v in re.search(r"TALLER = new Vec3\(([\d.]+), PISO, ([\d.]+)\)", cas_j).groups()]
assert reco_ and {x_ for x_, _ in reco_} == {5972.5, 6000.5, 6028.5} and {z_ for _, z_ in reco_} == {20.5, 96.5}, reco_
tramos_ = [(tuple(taller_), reco_[0])] + [(reco_[i_], reco_[(i_ + 1) % len(reco_)]) for i_ in range(len(reco_))]
def cazador_cabe(cxr_, czr_, de_costado_, adelante_):
    """Hasta y = 110 (piernas, pecho y brazos): 3 para cada costado; arriba (la cabeza, hasta y = 112), 1."""
    for y_ in range(100, 113):
        costado_ = de_costado_ if y_ <= 110 else 1
        for c_ in range(-costado_, costado_ + 1):
            for f_ in range(-adelante_, adelante_ + 1):
                dx_, dz_ = (c_, f_) if eje_z_ else (f_, c_)
                n_ = cas_.get((math.floor(cxr_) + dx_, y_, math.floor(czr_) + dz_))
                assert pasa_t(n_), ("el Cazador se choca", (cxr_, czr_), dx_, y_, dz_, n_)
for (a_, b_) in tramos_:
    largo_ = math.hypot(b_[0] - a_[0], b_[1] - a_[1])
    eje_z_ = abs(b_[0] - a_[0]) < 1e-6                           # camina a lo largo de z (si no, de x)
    assert eje_z_ or abs(b_[1] - a_[1]) < 1e-6, ("tramo en diagonal", a_, b_)
    for k_ in range(int(largo_ * 4) + 1):
        t_ = k_ / max(1, int(largo_ * 4))
        cazador_cabe(a_[0] + (b_[0] - a_[0]) * t_, a_[1] + (b_[1] - a_[1]) * t_, 3, 1)
    cazador_cabe(b_[0], b_[1], 3, 3)                             # en las esquinas gira: los brazos dan toda la vuelta
# el vestíbulo: reja al sur (nadie entra a la nave antes de tiempo), Casilleros.lugarDeSalida adentro, podio y sargentos
for x in range(5959, 6042):
    for y_ in (100, 101):
        assert cas_.get((x, y_, 2)) in ("iron_bars", "polished_blackstone_bricks"), ("reja del vestíbulo", x, y_)
for x in range(5977, 6024):
    for z in range(-10, 1):
        assert parado_t(cas_, x, z), ("vestíbulo de la estación", x, z)
palco_ok(cas_, cas_j, "casilleros")
for frag_ in ('Juego.eliminar(complejo, visto, false, "te_vio_el_cazador");',
              'Juego.eliminar(complejo, quien, false, "no_te_escondiste");',
              "int abiertos = Math.min(CASILLEROS.length, Math.max(gente - FALTAN, (gente + 1) / 2));",
              "coseno < Math.cos(Math.toRadians(ANGULO)) || !quien.hasLineOfSight(robot)",
              "if (escondido(quien)) {", "tiempo < ARRANQUE", "estadoComplejo.setVersionCasilleros(VERSION_ARENA);",
              "BlockPos.betweenClosed(X0, ABAJO, Z0, X1, ARRIBA, Z1)", "puerta(complejo, i, false, true);"):
    assert frag_ in cas_j, frag_
assert "private static final int ABAJO = 39;" in cas_j and "private static final int ARRIBA = 127;" in cas_j
for k_ in re.findall(r'"((?:mensaje|titulo|juego|barra)\.juegosdelpatio\.[a-z_]+)"', cas_j):
    assert k_ in lang_p, k_
for k_, n_ in (("juego.juegosdelpatio.casilleros_3", 1), ("juego.juegosdelpatio.casilleros_4", 1),
               ("juego.juegosdelpatio.casilleros_6", 1), ("juego.juegosdelpatio.casilleros_alarma", 3),
               ("barra.juegosdelpatio.casilleros_alarma", 5), ("barra.juegosdelpatio.casilleros_calma", 3),
               ("juego.juegosdelpatio.casilleros_ronda", 2), ("titulo.juegosdelpatio.casilleros_ronda", 2),
               ("juego.juegosdelpatio.casilleros_fin", 1), ("barra.juegosdelpatio.casilleros_fin", 1)):
    assert lang_p[k_].count("%s") == n_, (k_, lang_p[k_])
assert lang_p["juego.juegosdelpatio.nombre_2"] == "Sálvese quien pueda" and lang_p["entity.juegosdelpatio.cazador"] == "El Cazador"
assert 'reglas[regla].equals("casilleros_3") ? Component.translatable(clave, Casilleros.FALTAN)' in juego_j
assert 'reglas[regla].equals("casilleros_4") ? Component.translatable(clave, Casilleros.ALARMA / 20)' in juego_j
assert 'reglas[regla].equals("casilleros_6") ? Component.translatable(clave, Casilleros.RONDAS)' in juego_j
assert not [k_ for k_ in lang_p if "fuego" in k_ or "quemad" in lang_p[k_].lower()], "Fuego cruzado ya no está"
bot_c_ = java["JugadorBot.java"].split("static class CasillerosGoal")[1].split("\n    static class ")[0]
for frag_ in ("Casilleros.casilleroPara(bot)", "Casilleros.meterBot(bot, casillero)", "!Casilleros.libre(casillero)",
              "Casilleros.huida(bot)", "Casilleros.paseo(bot)", "Casilleros.escondido(bot)"):
    assert frag_ in bot_c_, frag_
assert "addGoal(0, new CasillerosGoal(this));" in java["JugadorBot.java"] and "FuegoGoal" not in java["JugadorBot.java"]
# el Cazador: registrado, con su dibujo, y con las medidas del dibujo de prueba (juegos_render.py)
assert re.search(r'ENTIDADES\.register\("cazador",\s*\(\) -> EntityType\.Builder\.<Cazador>of\(Cazador::new, MobCategory\.MISC\)'
                 r'\s*\.sized\(3\.0F, 12\.0F\)\s*\.eyeHeight\(\(float\) Cazador\.ALTO_VISOR\)\s*\.noSave\(\)\s*\.noSummon\(\)', registro)
assert "evento.registerEntityRenderer(Registro.CAZADOR.get(), CazadorRenderer::new);" in java["Cliente.java"]
caz_j, cazr_j = java["Cazador.java"], java["CazadorRenderer.java"]
assert "static final double ALTO_VISOR = 11.2;" in caz_j and "private static final float ESCALA = 1.35F;" in cazr_j
assert abs(8.35 * 1.35 - 11.2) < 0.1                            # el visor del dibujo, a la altura de ALTO_VISOR
for frag_ in ("public boolean hurt(DamageSource fuente, float cantidad) {\n        return false;",
              "public boolean isPickable() {\n        return false;", "public boolean isPushable() {\n        return false;",
              "this.noPhysics = true;"):
    assert frag_ in caz_j, frag_
assert "def cazador(" in open(os.path.join(raiz, "herramientas/juegos_render.py"), encoding="utf-8").read()
print("sálvese quien pueda ok:", len(cas_), "bloques;", len(casilleros_), "casilleros (puerta, adentro, costados, luz);",
      len(libres_c), "lugares libres en la nave; el Cazador recorre", len(tramos_), "tramos sin chocar")


# La papa caliente: el valle (colinas, montañas a las que se sube y túneles), y que coincida con Tejo.java
for extra_b, props_b in (("grass_block", {"snowy": B}), ("dirt", {}), ("coarse_dirt", {}), ("stone", {}), ("andesite", {}),
                         ("gravel", {}), ("snow_block", {}), ("cobblestone", {}), ("mossy_cobblestone", {}),
                         ("stone_bricks", {}), ("spruce_log", {"axis": {"x", "y", "z"}}),
                         ("spruce_leaves", {"distance": {str(i) for i in range(1, 8)}, "persistent": B, "waterlogged": B})):
    VALIDOS.setdefault(extra_b, props_b)
tej_j = java["Tejo.java"]
tej_ = arena_torres("tejo", (6935, 74, -20), [131, 52, 141], 5)
assert re.search(r"ORIGEN = new BlockPos\(6935, 74, -20\)", tej_j) and 'Complejo.id("tejo")' in tej_j
def num_t(n_):
    return int(re.search(rf"static final int {n_} = (-?\d+);", tej_j).group(1))
vx0_, vx1_, vz0_, vz1_ = num_t("VALLE_X0"), num_t("VALLE_X1"), num_t("VALLE_Z0"), num_t("VALLE_Z1")
assert (vx0_, vx1_, vz0_, vz1_) == (6946, 7054, 7, 115) and num_t("VERSION_ARENA") == 2 and num_t("PISO") == 100
assert (num_t("X0"), num_t("X1"), num_t("Z0"), num_t("Z1")) == (6935, 7065, -20, 120)
NO_PASA_T = {"light", "barrier"}
def solido_t(n_):
    return n_ is not None and n_ not in NO_PASA_T
def parado_v(x, y, z):
    return solido_t(tej_.get((x, y - 1, z))) and not solido_t(tej_.get((x, y, z))) and not solido_t(tej_.get((x, y + 1, z)))
PISOS_T = {"grass_block", "dirt", "coarse_dirt", "stone", "andesite", "gravel", "snow_block"}
lugares_t = {(x, y, z) for x in range(vx0_, vx1_ + 1) for z in range(vz0_, vz1_ + 1) for y in range(96, 126)
             if parado_v(x, y, z) and tej_.get((x, y - 1, z)) in PISOS_T}
def vecinos_t(p_):
    x, y, z = p_
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for dy in (1, 0, -1, -2, -3):
            q_ = (x + dx, y + dy, z + dz)
            if q_ in lugares_t and (dy < 1 or not solido_t(tej_.get((x, y + 2, z)))):
                yield q_
inicio_t = (7000, 100, 46)                                       # la boca norte del túnel de la montaña grande
assert inicio_t in lugares_t, "la boca del túnel"
vistos_t, cola_t = {inicio_t}, deque([inicio_t])
while cola_t:
    for q_ in vecinos_t(cola_t.popleft()):
        if q_ not in vistos_t:
            vistos_t.add(q_)
            cola_t.append(q_)
naturales_ = [p_ for p_ in lugares_t if tej_.get((p_[0], p_[1] - 1, p_[2])) in ("grass_block", "coarse_dirt", "gravel", "snow_block")]
assert sum(1 for p_ in naturales_ if p_ in vistos_t) >= 0.97 * len(naturales_), (len(naturales_), len(vistos_t))
for p_ in ((7000, 100, 76), (6970, 100, 76), (7030, 100, 76), (7000, 100, 104), (6968, 100, 18), (6968, 100, 50)):
    assert p_ in vistos_t, ("el túnel (o la cueva) no se recorre", p_)    # la cueva, y las bocas de los túneles
for (mx_, mz_) in ((7000, 76), (6968, 34), (7034, 30)):          # a la punta de las montañas se sube caminando
    altos_ = [p_[1] for p_ in vistos_t if abs(p_[0] - mx_) <= 1 and abs(p_[2] - mz_) <= 1]
    assert altos_ and max(altos_) >= 109, ("la punta de la montaña", mx_, mz_, altos_[:3])
for (x, y, z) in ((7000, 100, 76), (7000, 100, 60), (6985, 100, 76)):   # en los túneles hay techo (es un túnel de verdad)
    assert any(solido_t(tej_.get((x, yy, z))) for yy in range(y + 4, y + 7)), ("techo del túnel", x, z)
borde_t = [(x, z) for x in range(6945, 7056) for z in (6, 116)] + [(x, z) for z in range(6, 117) for x in (6945, 7055)]
for (x, z) in borde_t:                                           # la barrera invisible en todo el borde del valle
    alto_ = max(y for y in range(80, 126) if solido_t(tej_.get((x, y, z))) or tej_.get((x, y, z)) == "barrier"
                if tej_.get((x, y, z)) != "barrier") if any(solido_t(tej_.get((x, y, z))) for y in range(80, 126)) else None
    assert alto_ is not None and all(tej_.get((x, alto_ + k, z)) == "barrier" for k in range(1, 9)), ("barrera", x, z)
for x in range(6980, 7021):                                      # el palco (más alto, separado): Tejo.lugarDeSalida
    for z in range(-11, -3):
        assert parado_v(x, 112, z), ("palco de la papa caliente", x, z)
assert "return new Vec3(PALCO_X0 + azar.nextInt(PALCO_X1 - PALCO_X0 + 1) + 0.5, 112.0," in tej_j
podio_t = [float(v) for v in re.search(r"PODIO = new Vec3\(([\d.]+), ([\d.]+), (-?[\d.]+)\)", tej_j).groups()]
assert podio_t == [7000.5, 114.0, -13.5] and tej_.get((7000, 113, -14)) == "smooth_quartz", podio_t
for t_ in re.findall(r"new Vec3\(([\d.]+), 112\.0, (-?[\d.]+)\)", tej_j.split("PUESTOS_SARGENTOS = {")[1].split("};")[0]):
    assert parado_v(math.floor(float(t_[0])), 112, math.floor(float(t_[1]))), ("sargento", t_)
for x in range(6977, 6984):                                      # el portal de vuelta, en el palco
    for y in range(112, 118):
        assert tej_.get((x, y, -16)) in ("polished_blackstone", "portal_juego"), (x, y)
for frag_ in ("static final int RONDAS = 3;", "static final int PAPAS = 5;", "static final int RONDA = 15 * 20;",
              'Juego.eliminar(complejo, quien, false, "te_exploto_la_papa");', "SoundEvents.GENERIC_EXPLODE.value()",
              "ParticleTypes.EXPLOSION_EMITTER", "int papas = Math.max(1, Math.min(PAPAS, vivos.size() - 1));"):
    assert frag_ in tej_j, frag_
gol_t = tej_j.split("static void alRecibirGolpe(")[1].split("\n    }\n")[0]
assert gol_t.index("evento.setCanceled(true);") < gol_t.index("getSource().getEntity()"), "en la papa caliente no lastima nada"
gj_ = juego_j.split("static void alRecibirGolpe(LivingIncomingDamageEvent evento) {")[1].split("\n    }\n")[0]
assert gj_.index("if (numero == TEJO && Tejo.juega(victima)) {") < gj_.index("if (atacante == null || atacante == victima) {")
assert "Tejo.alRecibirGolpe(evento);" in gj_ and gj_.count("Tejo.alRecibirGolpe(evento);") == 1
for k_ in re.findall(r'"((?:mensaje|titulo|juego|barra)\.juegosdelpatio\.[a-z_]+)"', tej_j):
    assert k_ in lang_p, k_
assert lang_p["juego.juegosdelpatio.nombre_5"] == "La papa caliente" and lang_p["item.juegosdelpatio.tejo"] == "Papa caliente"
assert lang_p["juego.juegosdelpatio.tejo_2"].count("%s") == 1 and lang_p["juego.juegosdelpatio.tejo_4"].count("%s") == 1
assert lang_p["juego.juegosdelpatio.tejo_6"].count("%s") == 1 and lang_p["juego.juegosdelpatio.tejo_ronda"].count("%s") == 4
assert 'reglas[regla].equals("tejo_2") ? Component.translatable(clave, Tejo.PAPAS)' in juego_j
assert 'reglas[regla].equals("tejo_4") ? Component.translatable(clave, Tejo.RONDA / 20)' in juego_j
assert not [k_ for k_ in lang_p if "rayuela" in lang_p[k_].lower()], "la rayuela ya no está"
print("la papa caliente ok:", len(tej_), "bloques; el valle:", len(vistos_t), "lugares a los que se llega caminando",
      "(los túneles, la cueva y las tres puntas incluidas)")
# las arenas: Juego las conoce a todas
for clase_ in ("Sillas", "Casilleros", "Tejo", "Escondidas", "Puente", "Estandartes"):
    assert f"case {clase_.upper() if clase_ not in ('Sillas',) else 'SILLAS'} -> {clase_}.prepararArena(complejo);" in juego_j \
        or f"-> {clase_}.prepararArena(complejo);" in juego_j, clase_
# --- la puerta 3 de la torre: el comandante sube un tramo más (al este) y entra al portal
camino_cmd3 = vecs(juego_txt, "CAMINO_COMANDANTE_3")
portal_j3 = celda_de(juego_txt, "PORTAL_3")
assert portal_j3 == (10, 89, -40), portal_j3                                # la celda del medio de la puerta 3
assert camino_cmd3[:len(camino_cmd2)] == camino_cmd2
for p_ in camino_cmd3:
    assert p_ in vistos3, ("lugar del camino a la puerta 3 que no se pisa", p_)
frente3 = (portal_j3[0] - 1, portal_j3[1], portal_j3[2])                    # el paso de adelante del portal
assert frente3 in vistos3 and mundo.get((portal_j3[0], portal_j3[1] + 1, portal_j3[2])) == "minecraft:iron_block"
tramos3 = [pasos(a, b) for a, b in zip(camino_cmd3[:-1], camino_cmd3[1:])] + [pasos(camino_cmd3[-1], frente3)]
assert all(t_ is not None and t_ <= 40 for t_ in tramos3), ("tramos a la puerta 3", tramos3)
print("puerta 3 ok: tramos", tramos3)

# --- arena de Las escondidas: la escuela (tamaño, bloques, que coincida con Escondidas.java y se llegue a todo)
esc_j = java["Escondidas.java"]
escuela = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/escuela.nbt")).read())
assert escuela["size"] == [150, 9, 132], escuela["size"]
assert re.search(r"ORIGEN = new BlockPos\(2925, 98, -60\)", esc_j)
def num_e(nombre_c):
    return float(re.search(rf"{nombre_c} = (-?[\d.]+);", esc_j).group(1))
assert {n_: int(num_e(n_)) for n_ in ("X0", "X1", "Z0", "Z1")} == {"X0": 2925, "X1": 3074, "Z0": -60, "Z1": 71}
for extra_b in ("bricks", "birch_planks", "oak_planks", "bookshelf", "sponge", "wet_sponge", "lime_stained_glass",
                "glass", "red_terracotta", "red_wool", "white_wool", "blue_wool", "orange_concrete", "gray_concrete",
                "yellow_concrete", "smooth_stone", "cyan_terracotta", "gray_terracotta", "potted_azalea_bush", "cauldron",
                "moss_block", "flowering_azalea", "blue_carpet"):
    VALIDOS[extra_b] = {}
VALIDOS["spruce_wall_sign"] = {"facing": H4, "waterlogged": B}
VALIDOS["ladder"] = {"facing": H4, "waterlogged": B}
for tinte_ in ("blue", "yellow", "red", "green"):
    VALIDOS[f"{tinte_}_wall_banner"] = {"facing": H4}
ESC4 = {"facing": H4, "half": {"top", "bottom"}, "shape": {"straight"}, "waterlogged": B}
VALIDOS.update({
    "spruce_stairs": ESC4, "dark_oak_stairs": ESC4,
    "redstone_lamp": {"lit": B}, "soul_lantern": {"hanging": B, "waterlogged": B},
    "glass_pane": {k: B for k in ("north", "south", "east", "west", "waterlogged")},
    "oak_fence": {k: B for k in ("north", "south", "east", "west", "waterlogged")},
    "hay_block": {"axis": {"x", "y", "z"}}, "oak_log": {"axis": {"x", "y", "z"}},
    "oak_leaves": {"distance": {str(i) for i in range(1, 8)}, "persistent": {"true"}, "waterlogged": B},
})
for p_ in escuela["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    props = p_.get("Properties", {})
    if ns == "juegosdelpatio":
        assert nombre_b == "portal_juego" and props == {"juego": "4", "regreso": "true"}, p_
        continue
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
em = {}
for bl in escuela["blocks"]:
    x, y, z = bl["pos"]
    p_ = escuela["palette"][bl["state"]]
    em[(x + 2925, y + 98, z - 60)] = p_["Name"].split(":")[1]
def pasa_e(p_):
    return em.get(p_) in (None, "light")
def apoyo_e(p_):
    return em.get(p_) not in (None, "light") and "fence" not in em.get(p_)
def parado_e(x, y, z):
    return apoyo_e((x, y - 1, z)) and pasa_e((x, y, z)) and pasa_e((x, y + 1, z))
def altura_e(x, z):
    for y in range(100, 104):
        if parado_e(x, y, z):
            return y
    return None
def bfs_e(desde, sin=()):
    """Se camina (subiendo o bajando de a 1) sin pasar por las celdas de 'sin' (por ejemplo, rejas sacadas)."""
    quitadas = {c_: em.pop(c_) for c_ in sin if c_ in em}
    try:
        vistos_, cola_ = {desde}, deque([desde])
        while cola_:
            x, y, z = cola_.popleft()
            for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                for dy in (0, 1, -1):
                    n_ = (x + dx, y + dy, z + dz)
                    if n_ in vistos_ or not (2925 <= n_[0] <= 3074 and -60 <= n_[2] <= 71) or not parado_e(*n_):
                        continue
                    if dy == 1 and not pasa_e((x, y + 2, z)):
                        continue
                    vistos_.add(n_)
                    cola_.append(n_)
        return vistos_
    finally:
        em.update(quitadas)
podio_e = tuple(float(v) for v in re.search(r"PODIO = new Vec3\(([\d.]+), ([\d.]+), ([\d.]+)\)", esc_j).groups())
assert podio_e == (3000.0, 102.0, 12.0)
for dx in (-1, 0):
    for dz in (-1, 0):
        assert parado_e(int(podio_e[0]) + dx, 102, int(podio_e[2]) + dz), ("podio", dx, dz)
hall_e = (2993, 100, 7)
assert parado_e(*hall_e)
alc_e = bfs_e(hall_e)
escondites_e = [(x, z) for (x, y, z), n_ in em.items() if y == 98 and n_ == "sponge"]
ronda_e = [(x, z) for (x, y, z), n_ in em.items() if y == 98 and n_ == "wet_sponge"]
assert len(escondites_e) >= 120 and len(ronda_e) >= 100, (len(escondites_e), len(ronda_e))
for (x, z) in escondites_e + ronda_e:
    y_ = altura_e(x, z)
    assert y_ is not None and (x, y_, z) in alc_e, ("escondite o ronda al que no se llega", x, z)
assert all(z >= -48 for (x, z) in escondites_e + ronda_e)                    # en la escuela (no en el patio)
# los pasillos, de noche: techo negro, sin las luces de estrellas; el piso, de baldosas blancas y naranjas
from collections import Counter as _Counter
cuenta_e = _Counter(em.values())
assert not any(cuenta_e[n_] for n_ in ("sea_lantern", "glowstone", "ochre_froglight", "pearlescent_froglight",
                                       "verdant_froglight", "shroomlight")), cuenta_e
techo_e = _Counter(n_ for p_, n_ in em.items() if p_[1] == 106)
assert techo_e["black_concrete"] >= 1500, techo_e
piso_e = {(p_[0], p_[2]): n_ for p_, n_ in em.items() if p_[1] == 99}
naranjas_e = [xz_ for xz_, n_ in piso_e.items() if n_ == "orange_concrete"]
assert len(naranjas_e) >= 1200, len(naranjas_e)
damero_e = sum(1 for (x_, z_) in naranjas_e for v_ in ((x_ + 1, z_), (x_, z_ + 1))
               if piso_e.get(v_) == "white_concrete")
assert damero_e >= len(naranjas_e), ("el piso de los pasillos no es un damero blanco y naranja", damero_e, len(naranjas_e))
assert not any(piso_e.get((x_ + 1, z_)) == "orange_concrete" or piso_e.get((x_, z_ + 1)) == "orange_concrete"
               for (x_, z_) in naranjas_e), "dos baldosas naranjas juntas"
assert not any(n_ in ("spruce_wall_sign", "potted_azalea_bush", "cauldron", "ladder") or n_.endswith("_wall_banner")
               for n_ in cuenta_e), "quedaron decoraciones"
# las paredes de adentro, oscuras: gris verdoso con zócalo marrón oscuro (nada blanco de la cintura para arriba)
blancos_e = sum(1 for p_, n_ in em.items() if n_ in ("white_concrete", "smooth_quartz") and p_[1] >= 103)
assert blancos_e == 0, ("paredes blancas en la escuela", blancos_e)
assert cuenta_e["cyan_terracotta"] > 1500 and cuenta_e["gray_terracotta"] > 2500 and cuenta_e["black_concrete"] > 6000
# los escondites, más oscuros que los pasillos (luz de bloques como en el juego)
luz_e, cola_e = {}, _dq()
for p_, n_ in em.items():
    if n_ in ("lantern", "portal_juego", "sea_lantern"):
        luz_e[p_] = 12 if n_ == "portal_juego" else 15
        cola_e.append(p_)
for bl in escuela["blocks"]:
    p_ = escuela["palette"][bl["state"]]
    if p_["Name"] == "minecraft:light":
        x, y, z = bl["pos"]
        q_ = (x + 2925, y + 98, z - 60)
        luz_e[q_] = int(p_["Properties"]["level"])
        cola_e.append(q_)
    elif p_["Name"] == "minecraft:soul_lantern":
        x, y, z = bl["pos"]
        q_ = (x + 2925, y + 98, z - 60)
        luz_e[q_] = 10
        cola_e.append(q_)
while cola_e:
    p_ = cola_e.popleft()
    l_ = luz_e[p_]
    if l_ <= 1:
        continue
    for d_ in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        q_ = (p_[0] + d_[0], p_[1] + d_[1], p_[2] + d_[2])
        if not (2925 <= q_[0] <= 3074 and 99 <= q_[1] <= 106 and -60 <= q_[2] <= 71):
            continue
        if em.get(q_) not in (None, "light", "lantern", "soul_lantern", "chain", "barrier", "portal_juego", "iron_bars",
                              "glass_pane", "oak_fence", "spruce_wall_sign", "ladder", "blue_carpet", "potted_azalea_bush",
                              "flowering_azalea") and not em.get(q_, "").endswith("_wall_banner"):
            continue
        if luz_e.get(q_, 0) < l_ - 1:
            luz_e[q_] = l_ - 1
            cola_e.append(q_)
luz_esc = [luz_e.get((x, altura_e(x, z) + 1, z), 0) for (x, z) in escondites_e]
luz_hall = [luz_e.get((x, 101, z), 0) for x in range(2988, 3012) for z in range(2, 22) if parado_e(x, 100, z)]
luz_piso = [luz_e.get((x, y_ + 1, z), 0) for (x, y_, z) in alc_e]
luz_media = sum(luz_piso) / len(luz_piso)
assert sum(luz_esc) / len(luz_esc) < 3.5 and min(luz_hall) >= 7, (sum(luz_esc) / len(luz_esc), min(luz_hall))
# la sala de profesores: cerrada con rejas (no se entra ni se sale); sacándolas, se llega
rejas_p = [tuple(int(v) for v in t_) for t_ in re.findall(r"\{(-?\d+), (-?\d+), (-?\d+), (-?\d+)\}",
                                                         esc_j.split("REJAS_PROFESORES = {")[1].split("};")[0])]
assert rejas_p == [(2991, 1, 2993, 1), (2997, -6, 2997, -4)], rejas_p
celdas_p = [(x, y, z) for (x0, z0, x1, z1) in rejas_p for x in range(x0, x1 + 1) for z in range(z0, z1 + 1)
            for y in range(100, 103)]
assert all(em.get(c_) == "iron_bars" for c_ in celdas_p), "faltan rejas en la sala de profesores"
prof_ = {n_: int(num_e(n_)) for n_ in ("PROF_X0", "PROF_X1", "PROF_Z0", "PROF_Z1")}
sala_p = [(x, 100, z) for x in range(prof_["PROF_X0"], prof_["PROF_X1"] + 1)
          for z in range(prof_["PROF_Z0"], prof_["PROF_Z1"] + 1) if parado_e(x, 100, z)]
assert len(sala_p) >= 45 and not any(c_ in alc_e for c_ in sala_p), len(sala_p)
alc_abierta = bfs_e(hall_e, sin=celdas_p)
assert all(c_ in alc_abierta for c_ in sala_p)
# las seis salidas: rejas de y 100 a 105; el frente se pisa; sacando las rejas se llega al vestíbulo
salidas_e = re.findall(r'new Salida\("([a-z_]+)", (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), '
                       r'new Vec3\((-?[\d.]+), 100\.0, (-?[\d.]+)\)\)', esc_j)
assert len(salidas_e) == 6, salidas_e
for (nombre_s, *nums) in salidas_e:
    vx0, vz0, vx1, vz1, rx0, rz0, rx1, rz1 = (int(v) for v in nums[:8])
    fx, fz = math.floor(float(nums[8])), math.floor(float(nums[9]))
    barras = [(x, y, z) for x in range(rx0, rx1 + 1) for z in range(rz0, rz1 + 1) for y in range(100, 106)]
    assert all(em.get(c_) == "iron_bars" for c_ in barras), ("rejas de la salida", nombre_s)
    assert (fx, 100, fz) in alc_e, ("frente de la salida", nombre_s)
    vestibulo = [(x, 100, z) for x in range(vx0, vx1 + 1) for z in range(vz0, vz1 + 1)]
    assert all(parado_e(*c_) and c_ not in alc_e for c_ in vestibulo), ("vestíbulo", nombre_s)
    abierta_ = bfs_e(hall_e, sin=barras)
    assert all(c_ in abierta_ for c_ in vestibulo), ("no se llega a la salida abierta", nombre_s)
    assert not any(z_ < -48 for (_, _, z_) in abierta_), ("por la salida se llega al patio", nombre_s)
# el patio: lugar para los que salen, cerrado (no se llega desde la escuela); los sargentos y la llegada, en el hall
pat_ = {n_: int(num_e(n_)) for n_ in ("PATIO_X0", "PATIO_X1", "PATIO_Z0", "PATIO_Z1")}
for x in range(pat_["PATIO_X0"], pat_["PATIO_X1"] + 1):
    for z in range(pat_["PATIO_Z0"], pat_["PATIO_Z1"] + 1):
        assert parado_e(x, 100, z) and (x, 100, z) not in alc_e, ("patio", x, z)
for t_ in re.findall(r"new Vec3\(([\d.]+), 100\.0, ([\d.]+)\)", esc_j.split("PUESTOS_SARGENTOS = {")[1].split("};")[0]):
    assert (math.floor(float(t_[0])), 100, math.floor(float(t_[1]))) in alc_e, ("sargento", t_)
for ang_ in range(0, 360, 10):
    for r_ in (4.0, 6.0, 8.0):
        lx_ = math.floor(podio_e[0] + r_ * math.cos(math.radians(ang_)))
        lz_ = math.floor(podio_e[2] + r_ * math.sin(math.radians(ang_)))
        assert (lx_, 100, lz_) in alc_e, ("lugar de llegada", lx_, lz_)
# las reglas, como dijo el usuario
assert "int buscan = mezcla.size() / 2;" in esc_j                            # mitad y mitad, al azar
assert "Items.NETHERITE_SWORD" in esc_j and "espada.enchant(filo, 5);" in esc_j and "Enchantments.SHARPNESS" in esc_j
assert "esBuscador(atacante) && esEscondido(victima)" in esc_j and '"no_entre_buscadores"' in esc_j
assert re.search(r"TIEMPO_ESCONDERSE = 60 \* 20;", esc_j) and re.search(r"TIEMPO_BUSCAR = 5 \* 60 \* 20;", esc_j)
assert "JUEGOS_HECHOS = 7;" in juego_txt and "Escondidas.empezar(complejo, participantes(complejo));" in juego_txt
assert "static final int ESCONDIDAS = 4;" in juego_txt and "numero == ESCONDIDAS" in juego_txt
assert "addListener(Escondidas::alMorir)" in java["JuegosDelPatio.java"]
com_ = java["Comida.java"]
assert "menu = juego == Juego.ESCONDIDAS ? 3 : juego == Juego.SILLAS || juego == Juego.TEJO ? 2 : 1;" in com_ and "List.of(new ItemStack(Items.CARROT), new ItemStack(Items.POTATO))" in com_
# sin la noche del pastel: después de las escondidas (el cuarto juego), la cena es un estofado
assert "Masacre.java" not in java and "List.of(new ItemStack(Items.RABBIT_STEW))" in com_ and "Masacre" not in com_
for nombre_j, texto_j in java.items():
    assert "Masacre" not in texto_j and "MASACRE" not in texto_j and "espadaPastel" not in texto_j, nombre_j
lang_es_ = json.load(open(os.path.join(raiz, "src/main/resources/assets/juegosdelpatio/lang/es_es.json"), encoding="utf-8"))
assert lang_es_["comida.juegosdelpatio.menu_3"] == "un estofado"
assert not [k_ for k_ in lang_es_ if "masacre" in k_ or "pastel" in k_ or "quietos" in k_]
noche_ = java["Noche.java"]
assert "return deNoche;" in noche_ and "!esDeNoche() && evento.getProblem() == null" in noche_
cer_ = java["Ceremonia.java"]
assert "private enum Tipo { BIENVENIDA, LLAMADO, RESULTADOS }" in cer_ and "apuntar(" not in cer_
assert "decir(complejo, Component.translatable(\"comida.juegosdelpatio.a_dormir\"));" in com_
assert "Noche.ceremoniaTerminada(complejo.getServer());" in com_.split("private static void terminar(")[1].split("\n    }\n")[0]
# el parpadeo de las sillas (el único que queda): un solo patrón, 4 segundos
par_j_ = java["Parpadeo.java"]
assert "public record Parpadeo(int ticks)" in par_j_ and "PATRON_MASACRE" not in par_j_ and "tipoCliente" not in par_j_
assert "new Parpadeo(Parpadeo.DURACION)" in java["Sillas.java"] and "new Parpadeo(0)" in java["Sillas.java"]
assert "Parpadeo.apagadas(t)" in java["ClienteLuces.java"] and "Parpadeo.apagadas(t - 1)" in java["ClienteLuces.java"]
# la votación: con muchos bots siempre gana seguir, por poco (los indecisos votan en los últimos 10 segundos)
vot_ = java["Votacion.java"]
assert "BOTS_PARA_SEGUIR = 10;" in vot_ and "decidenBots = bots.size() >= jugadores + BOTS_PARA_SEGUIR;" in vot_
assert re.search(r"margen = impares \? \(azar\.nextInt\(10\) < 7 \? 1 : 3\) : \(azar\.nextInt\(10\) < 6 \? 2 : 0\);", vot_)
assert "ganoSeguir = irse <= seguir;" in vot_ and "haranFalta > faltan - 1" in vot_ and '"voto.juegosdelpatio.empate"' in vot_
assert "Comida.empezar(complejo, juego);" in java["Ceremonia.java"]
assert "porComer.add(comida);" in bot_txt                                     # el bot se come las dos cosas
# los bots de las escondidas, más listos: ven de muy lejos, avisan, revisan; los escondidos salen disparados
bot_esc_ = java["JugadorBot.java"].split("static class EscondidasGoal")[1].split("static class IrAComerGoal")[0]
vista_ = [float(v) for v in re.search(r"VISTA = \{([\d., ]+)\};", esc_j).group(1).split(",")]
assert vista_ == sorted(vista_) and vista_[-1] >= 48 and vista_[0] >= 12, vista_
assert num_e("CAMPO_VISUAL") <= 0.0 and 0.5 <= num_e("AGACHADO") < 1.0 < num_e("CORRIENDO")
assert num_e("OIDO_AGACHADO") < num_e("OIDO") < num_e("OIDO_CORRIENDO") and num_e("OIDO") >= 5 and num_e("AVISO") >= 24
def bt_(modificador_):
    return 0.98 * (0.3 * 1.3 * modificador_) ** 2 / 0.454                  # corriendo (bloques por tick)
persigue_, disparado_, cansado_ = (float(re.search(rf"{n_} = ([\d.]+);", bot_esc_).group(1))
                                  for n_ in ("PERSIGUE", "DISPARADO", "CANSADO"))
assert bt_(persigue_) < jugador_bt and bt_(disparado_) > jugador_bt * 1.5 and bt_(cansado_) < jugador_bt * 0.85, (
    bt_(persigue_) * 20, bt_(disparado_) * 20, bt_(cansado_) * 20)
assert int(re.search(r"RAFAGA = (\d+);", bot_esc_).group(1)) <= 80 and int(re.search(r"DESCANSO = (\d+);", bot_esc_).group(1)) >= 100
for frase_ in ("Escondidas.loVi(bot, visto);", "Escondidas.pistaCerca(bot)", "Escondidas.esconditeCerca(bot, zona, 12.0, false)",
               "irA(ultimoVisto, 3);", "Escondidas.peligro(bot, escondido ? 5.0 : 9.0)", "mirarAlrededor(true);",
               "mirarAlrededor(false);", "bot.mostrarEmote(Emote.VISTO);", "disparado > 0 ? DISPARADO : CANSADO",
               "&& bot.hasLineOfSight(objetivo)) {"):                    # el golpe, nunca a través de un vidrio
    assert frase_ in bot_esc_, frase_
assert "ClipContext.Block.VISUAL" in esc_j and '"mensaje.juegosdelpatio.te_vio"' in esc_j
assert 'VISTO("¡!", ChatFormatting.RED, false)' in java["Emote.java"]
# en las escondidas nadie guarda rencor ni se enoja: que el buscador te encuentre es el juego
die_ = java["JugadorBot.java"].split("public void die(DamageSource fuente) {")[1].split("\n    }\n")[0]
hurt_ = java["JugadorBot.java"].split("public boolean hurt(DamageSource fuente, float cantidad) {")[1].split("\n    }\n")[0]
assert "!((Juego.numero() == Juego.ESCONDIDAS || Juego.numero() == Juego.ESTANDARTES) && Juego.enArena())" in die_ \
    and "&& !Juego.sinPeleas(this)) {" in hurt_
# las mecánicas nuevas de Las escondidas: chalecos, cuerpos en el piso, hacerse el muerto y quitar la espada
reg_ = java["Registro.java"]
for frase_ in ('"chaleco_buscador"', '"chaleco_escondido"', 'ArmorItem.Type.CHESTPLATE', '"cuerpo"', 'Cuerpo::new'):
    assert frase_ in reg_, frase_
for n_ in ("chaleco_buscador", "chaleco_escondido"):
    assert os.path.exists(os.path.join(raiz, f"src/main/resources/assets/juegosdelpatio/textures/models/armor/{n_}_layer_1.png")), n_
    assert os.path.exists(os.path.join(raiz, f"src/main/resources/assets/juegosdelpatio/textures/item/{n_}.png")), n_
    modelo_ = json.load(open(os.path.join(raiz, f"src/main/resources/assets/juegosdelpatio/models/item/{n_}.json")))
    assert modelo_["textures"]["layer0"] == f"juegosdelpatio:item/{n_}", modelo_
claves_nuevas_ = ["item.juegosdelpatio.chaleco_buscador", "item.juegosdelpatio.chaleco_escondido", "entity.juegosdelpatio.cuerpo",
                  "key.juegosdelpatio.hacerse_el_muerto", "juego.juegosdelpatio.escondidas_8", "juego.juegosdelpatio.escondidas_9",
                  "juego.juegosdelpatio.escondidas_10"]
claves_nuevas_ += ["mensaje.juegosdelpatio." + c_ for c_ in re.findall(r'"mensaje\.juegosdelpatio\.((?:muerto|forcejeo)_\w+)"', esc_j)]
claves_nuevas_ += ["mensaje.juegosdelpatio.sin_espada", "mensaje.juegosdelpatio.espada_nueva"]
assert len(claves_nuevas_) >= 20, claves_nuevas_
for f_ in glob.glob(os.path.join(raiz, "src/main/resources/assets/juegosdelpatio/lang/*.json")):
    lang_ = json.load(open(f_, encoding="utf-8"))
    faltan_ = [c_ for c_ in claves_nuevas_ if c_ not in lang_]
    assert not faltan_, (os.path.basename(f_), faltan_)
    assert lang_["juego.juegosdelpatio.escondidas_9"].count("%s") == 1 and lang_["juego.juegosdelpatio.escondidas_10"].count("%s") == 1
    assert lang_["mensaje.juegosdelpatio.forcejeo_te_agarran"].count("%s") == 2 and lang_["mensaje.juegosdelpatio.forcejeo_agarraste"].count("%s") == 2
reglas_esc_ = re.findall(r'"(escondidas_\d+|reglas_7)"', juego_txt.split("REGLAS_ESCONDIDAS = {")[1].split("};")[0])
assert reglas_esc_ == ["escondidas_1", "escondidas_2", "escondidas_11", "escondidas_3", "escondidas_4", "escondidas_8",
                       "escondidas_5", "escondidas_9", "escondidas_10", "escondidas_6", "escondidas_7", "reglas_7"], reglas_esc_
assert 'equals("escondidas_9")' in juego_txt and 'equals("escondidas_10")' in juego_txt
assert "if (Escondidas.forcejear(jugador, victima)) {" in juego_txt
assert juego_txt.index("if (Escondidas.forcejear(jugador, victima)) {") < juego_txt.index("if (!usarEmpujon(jugador.getUUID(), ahora)) {")
# chalecos: se ponen al repartir los equipos, nadie se los saca, y al final se devuelve la camisa
assert "ponerChaleco(quien, busca);" in esc_j and "sacarChaleco(jugador);" in esc_j and "CAMISAS.remove(quien.getUUID())" in esc_j
# el que muere queda tirado (con su chaleco); el que se hace el muerto: un cuerpo de mentira igual, y él invisible
assert "Cuerpo.dejar(complejo, muerto, chaleco);" in esc_j and "Cuerpo.fingido(complejo, quien, 2)" in esc_j
assert "quien.setInvisible(true);" in esc_j and "quien.setInvisible(false);" in esc_j
assert re.search(r"TIEMPO_MUERTO = 10 \* 20;", esc_j) and re.search(r"ESPERA_MUERTO = 30 \* 20;", esc_j)
assert re.search(r"SIN_ESPADA = 30 \* 20;", esc_j) and re.search(r"AGARRE = 1\.6;", esc_j)
ve_ = esc_j.split("static boolean ve(LivingEntity buscador, LivingEntity escondido) {")[1].split("\n    }\n")[0]
assert "seHaceElMuerto(escondido) && !vioCaer(buscador, escondido)" in ve_.split("double d2")[0]
cuerpo_ = java["Cuerpo.java"]
assert "DUENO" in cuerpo_ and "return false;" in cuerpo_.split("public boolean isPickable()")[1][:60]
assert "noSave()" in reg_ and "noSummon()" in reg_
teclas_ = java["ClienteTeclas.java"]
assert "RenderLivingEvent.Pre<?, ?> evento" in teclas_ and "OCULTOS.contains(quien.getId())" in teclas_
assert "zSostenida <= Z_SOSTENIDA" in teclas_                       # mantener apretada la Z no vale
assert "new HacerseElMuerto()" in teclas_ and "GLFW.GLFW_KEY_G" in java["Cliente.java"]
assert "Escondidas.resistir(" in java["Resistir.java"] and "Escondidas.hacerseElMuerto(" in java["HacerseElMuerto.java"]
for r_ in ("HacerseElMuerto::registrar", "MuertoFingido::registrar"):
    assert r_ in java["JuegosDelPatio.java"], r_
# golpes: sin espada no se atrapa; el agarrado no le puede pegar al que lo agarra
golpe_ = esc_j.split("static void alRecibirGolpe(LivingIncomingDamageEvent evento) {")[1].split("\n    }\n")[0]
assert "esEspada(atacante.getMainHandItem())" in golpe_ and "agarre.escondido.equals(victima.getUUID())" in golpe_
# los bots: se hacen los muertos cuando viene uno que todavía no los vio, agarran por la espalda, los que buscan se resisten
for frase_ in ("Escondidas.convieneHacerseElMuerto(bot)", "Escondidas.tirarse(bot);", "Escondidas.forcejear(bot, acecho);",
               "Escondidas.seHaceElMuerto(bot)", "boolean armado = Escondidas.tieneEspada(bot);"):
    assert frase_ in bot_esc_, frase_
assert "if (buscador instanceof JugadorBot bot && azar.nextFloat()" in esc_j
assert num_e("OIDO_AGACHADO") <= 1.0
# cada buscador tiene que atrapar al menos a uno: si no, al terminar queda eliminado
fin_ = esc_j.split("private static void terminarJuego(ServerLevel complejo, boolean nadieQueda) {")[1].split("\n    }\n")[0]
assert 'Juego.eliminar(complejo, quien, false, "no_atrapaste");' in fin_ and "esBuscador(quien) && atrapados(quien) == 0" in fin_
assert fin_.index('"no_atrapaste"') < fin_.index("pasaron = enJuego(complejo).size();")   # los eliminados no cuentan
morir_ = esc_j.split("static void alMorir(LivingDeathEvent evento) {")[1].split("\n    }\n")[0]
assert "ATRAPO.merge(asesino.getUUID(), 1, Integer::sum)" in morir_ and "BUSCADORES.contains(asesino.getUUID())" in morir_
assert "avisarSinAtrapar(complejo, falta == ULTIMO_MINUTO);" in esc_j and "Escondidas.desesperado(bot)" in bot_esc_
# el minuto para cambiarse de equipo: en el hall, después de los chalecos y antes de esconderse
assert "private enum Estado { NINGUNO, CAMBIOS, ESCONDERSE, BUSCAR, TERMINADO }" in esc_j
assert re.search(r"TIEMPO_CAMBIOS = 60 \* 20;", esc_j) and "estado = Estado.CAMBIOS;" in esc_j
emp_ = esc_j.split("static void empezar(ServerLevel complejo, List<LivingEntity> gente) {")[1].split("\n    }\n")[0]
assert "teleportTo" not in emp_ and "BLINDNESS" not in emp_ and "ponerChaleco(quien, busca);" in emp_   # todavía en el hall
aes_ = esc_j.split("private static void aEsconderse(ServerLevel complejo) {")[1].split("\n    }\n")[0]
assert "teleportTo" in aes_ and "BLINDNESS" in aes_ and "estado = Estado.ESCONDERSE;" in aes_ and "como_buscar" in aes_
assert "if (faltan <= 0) {\n                    aEsconderse(complejo);" in esc_j
assert 'quien.getUUID().equals(PIDE.get(otro.getUUID()))' in esc_j and "cambiar(complejo, quien, otro);" in esc_j
assert "if (Escondidas.pedirCambio(jugador, victima)) {" in juego_txt
assert juego_txt.index("Escondidas.pedirCambio(jugador, victima)") < juego_txt.index("Escondidas.forcejear(jugador, victima)")
assert "if (Escondidas.cambiando()) {" in bot_esc_ and "Escondidas.cambioCon(bot)" in bot_esc_
camb_ = esc_j.split("private static void cambios(ServerLevel complejo) {")[1].split("\n    }\n")[0]
assert "HALL_X0" in camb_ and "lugarDeSalida(azar)" in camb_                # nadie sale del hall
# el hall de las constantes es el de la escuela: el podio y los sargentos adentro
hall_ = {n_: num_e(n_) for n_ in ("HALL_X0", "HALL_X1", "HALL_Z0", "HALL_Z1")}
assert hall_["HALL_X0"] < 3000 < hall_["HALL_X1"] and hall_["HALL_Z0"] < 12 < hall_["HALL_Z1"], hall_
assert (hall_["HALL_X1"] - hall_["HALL_X0"] + 1, hall_["HALL_Z1"] - hall_["HALL_Z0"] + 1) == (86 - 63 + 1, 69 - 50 + 1)
print("mecánicas nuevas ok: chalecos, cuerpos, hacerse el muerto (G), agarrar por la espalda;", len(claves_nuevas_),
      "textos nuevos en los 8 idiomas")
print("bots de las escondidas ok: ven hasta", vista_[-1], "bloques; persiguen a", round(bt_(persigue_) * 20, 1),
      "b/s, disparados", round(bt_(disparado_) * 20, 1), "b/s, cansados", round(bt_(cansado_) * 20, 1),
      "b/s (un jugador corriendo:", round(jugador_bt * 20, 1), "b/s)")
print("escuela ok:", len(escuela["blocks"]), "bloques;", len(escondites_e), "escondites y", len(ronda_e),
      "lugares de ronda (se llega a todos);", "luz media en los escondites", round(sum(luz_esc) / len(luz_esc), 1),
      "y en el hall", min(luz_hall), "a", max(luz_hall), "; en toda la escuela, media", round(luz_media, 1), "; sala de profesores con", len(sala_p),
      "lugares; 6 salidas con rejas; patio cerrado")

# --- la puerta 4 de la torre: el comandante sigue desde la 3 hasta la esquina sureste y el tramo del sur
camino_cmd4 = vecs(juego_txt, "CAMINO_COMANDANTE_4")
portal_j4 = celda_de(juego_txt, "PORTAL_4")
assert portal_j4 == (-4, 97, -34), portal_j4                                # la celda del medio de la puerta 4
assert camino_cmd4[:len(camino_cmd3)] == camino_cmd3
for p_ in camino_cmd4:
    assert p_ in vistos3, ("lugar del camino a la puerta 4 que no se pisa", p_)
frente4 = (portal_j4[0], portal_j4[1], portal_j4[2] - 1)                    # (la puerta 4 está en la pared sur)
assert frente4 in vistos3 and mundo.get((portal_j4[0], portal_j4[1] + 1, portal_j4[2])) == "minecraft:iron_block"
tramos4 = [pasos(a, b) for a, b in zip(camino_cmd4[:-1], camino_cmd4[1:])] + [pasos(camino_cmd4[-1], frente4)]
assert all(t_ is not None and t_ <= 40 for t_ in tramos4), ("tramos a la puerta 4", tramos4)
print("puerta 4 ok: tramos", tramos4)

# --- las puertas 5, 6 y 7: cada una, una vuelta más arriba (la 5 sobre la 1, la 6 sobre la 2 y la 7 sobre la 3)
camino_cmd_ant = camino_cmd4
for n_p, celda_p, frente_d in ((5, (-10, 105, -48), (1, 0, 0)), (6, (4, 113, -54), (0, 0, 1)),
                               (7, (10, 121, -40), (-1, 0, 0))):
    camino_c = vecs(juego_txt, f"CAMINO_COMANDANTE_{n_p}")
    pj_ = celda_de(juego_txt, f"PORTAL_{n_p}")
    assert pj_ == celda_p, (n_p, pj_)
    assert camino_c[:len(camino_cmd_ant)] == camino_cmd_ant and len(camino_c) == len(camino_cmd_ant) + 2, n_p
    for p_ in camino_c:
        assert p_ in vistos3, (f"lugar del camino a la puerta {n_p} que no se pisa", p_)
    frente_ = (celda_p[0] + frente_d[0], celda_p[1], celda_p[2] + frente_d[2])
    assert frente_ in vistos3 and mundo.get((celda_p[0], celda_p[1] + 1, celda_p[2])) == "minecraft:iron_block", n_p
    tramos_n = [pasos(a, b) for a, b in zip(camino_c[:-1], camino_c[1:])] + [pasos(camino_c[-1], frente_)]
    assert all(t_ is not None and t_ <= 40 for t_ in tramos_n), (f"tramos a la puerta {n_p}", tramos_n)
    assert f"case {n_p} -> CAMINO_COMANDANTE_{n_p};" in juego_txt and f"case {n_p} -> PORTAL_{n_p};" in juego_txt
    camino_cmd_ant = camino_c
    print(f"puerta {n_p} ok: tramos", tramos_n)

# --- arena de El puente de Londres: la plaza de Londres de noche (tamaño, bloques, la calle en ronda, lugar para los robots)
pue_j = java["Puente.java"]
rob_j = java["Robot.java"]
ren_j = java["RobotRenderer.java"]
cuarto = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/puente.nbt")).read())
assert cuarto["size"] == [63, 18, 72], cuarto["size"]
assert re.search(r"ORIGEN = new BlockPos\(3969, 99, -17\)", pue_j) and "VERSION_ARENA = 2;" in pue_j
def num_p(n_, texto_=None):
    return float(re.search(rf"{n_} = (-?[\d.]+)F?;", texto_ or pue_j).group(1))
lim_p = {n_: int(num_p(n_)) for n_ in ("X0", "X1", "Z0", "Z1")}
assert lim_p == {"X0": 3969, "X1": 4031, "Z0": -17, "Z1": 54}, lim_p
assert (int(num_p("CENTRO_X")), int(num_p("CENTRO_Z")), int(num_p("PISO"))) == (4000, 26, 100)
radio_p, calle_min, calle_max = num_p("RADIO"), num_p("CALLE_MIN"), num_p("CALLE_MAX")
assert (radio_p, calle_min, calle_max) == (16.0, 14.0, 18.0)
for extra_b in ("bricks", "gray_concrete"):
    VALIDOS.setdefault(extra_b, {})
VALIDOS.setdefault("ochre_froglight", {"axis": {"x", "y", "z"}})
VALIDOS["light"] = {"level": {str(i) for i in range(16)}, "waterlogged": B}
VALIDOS.setdefault("barrier", {})
for p_ in cuarto["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    props = p_.get("Properties", {})
    if ns == "juegosdelpatio":
        assert nombre_b == "portal_juego" and props == {"juego": "6", "regreso": "true"}, p_
        continue
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
pm = {}
for bl in cuarto["blocks"]:
    x, y, z = bl["pos"]
    pm[(x + 3969, y + 99, z - 17)] = cuarto["palette"][bl["state"]]["Name"].split(":")[1]
def libre_p(p_):
    return pm.get(p_) in (None, "light")
def parado_p(x, y, z):
    return pm.get((x, y - 1, z)) not in (None, "light", "barrier") and libre_p((x, y, z)) and libre_p((x, y + 1, z))
CXP, CZP = 4000.5, 26.5
calle_p = [(x, z) for x in range(3980, 4022) for z in range(5, 48) if 14.6 <= math.hypot(x + 0.5 - CXP, z + 0.5 - CZP) <= 17.4]
assert len(calle_p) >= 250, len(calle_p)
for x, z in calle_p:
    assert pm.get((x, 99, z)) == "deepslate_tiles", ("la calle de adoquines", x, z, pm.get((x, 99, z)))
    assert parado_p(x, 100, z), ("algo en la calle", x, z)
# se llega caminando desde la entrada a toda la calle (y al podio y los puestos de los sargentos)
inicio_p = (4000, 100, -5)
assert parado_p(*inicio_p)
vistos_p, cola_p = {inicio_p}, deque([inicio_p])
while cola_p:
    x, y, z = cola_p.popleft()
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for dy in (0, 1, -1):
            n_ = (x + dx, y + dy, z + dz)
            if n_ in vistos_p or not (3969 < n_[0] < 4031 and 99 < n_[1] < 116 and -17 < n_[2] < 54):
                continue
            if dy == 1 and not libre_p((x, y + 2, z)):
                continue
            if parado_p(*n_):
                vistos_p.add(n_)
                cola_p.append(n_)
for x, z in calle_p:
    assert (x, 100, z) in vistos_p, ("no se llega a la calle", x, z)
for p_ in vecs(pue_j, "PUESTOS_SARGENTOS"):
    assert p_ in vistos_p, ("puesto de sargento", p_)
podio_p = vecs(pue_j, "PODIO") if "PODIO = {" in pue_j else [tuple(int(math.floor(float(v))) for v in re.search(r"PODIO = new Vec3\((-?[\d.]+), (-?[\d.]+), (-?[\d.]+)\)", pue_j).groups())]
assert pm.get((podio_p[0][0], podio_p[0][1] - 1, podio_p[0][2])) == "smooth_quartz" and libre_p(podio_p[0]), podio_p
llegada_p = re.search(r"return new Vec3\((-?[\d.]+) \+ azar.nextInt\((\d+)\), PISO, (-?[\d.]+) \+ azar.nextInt\((\d+)\)\);", pue_j)
lx0, lnx, lz0, lnz = float(llegada_p.group(1)), int(llegada_p.group(2)), float(llegada_p.group(3)), int(llegada_p.group(4))
for ix in range(lnx):
    for iz in range(lnz):
        assert (math.floor(lx0 + ix), 100, math.floor(lz0 + iz)) in vistos_p, ("llegada", ix, iz)
# los robots: uno a cada lado de la calle, a 5 del medio, sobre su base, y nada de bloques donde se paran ni por donde
# pasan los brazos (del piso hasta arriba de las manos levantadas)
hombro_x, hombro_y, hombro_z = num_p("HOMBRO_X", rob_j), num_p("HOMBRO_Y", rob_j), num_p("HOMBRO_Z", rob_j)
al_medio, arriba_b, abajo_b = num_p("AL_MEDIO", rob_j), num_p("ARRIBA", rob_j), num_p("ABAJO", rob_j)
alto_arriba = hombro_y + (al_medio - hombro_z) * math.tan(math.radians(arriba_b))
alto_abajo = hombro_y + (al_medio - hombro_z) * math.tan(math.radians(abajo_b))
assert alto_arriba >= 7.0, ("la gente tiene que pasar por debajo", alto_arriba)   # las manos, bien arriba
assert alto_abajo <= 1.9, ("bajados tienen que encerrar al que pasa", alto_abajo)  # y bajadas, a la altura del pecho
assert "ROBOT_ADENTRO = new Vec3(CX + RADIO - Robot.AL_MEDIO, PISO, CZ);" in pue_j
assert "ROBOT_AFUERA = new Vec3(CX + RADIO + Robot.AL_MEDIO, PISO, CZ);" in pue_j
for rx_ in (CXP + radio_p - al_medio, CXP + radio_p + al_medio):
    assert pm.get((math.floor(rx_), 99, 26)) in ("polished_deepslate", "iron_block"), ("plataforma del robot", rx_)
# el codo de los brazos (como RobotRenderer.brazo): la mano llega justo al medio de la calle a cualquier altura, y el
# codo, doblado hacia arriba, nunca pasa de cierto alto (ahí no puede haber nada)
brazo_b, antebrazo_b = num_p("BRAZO", rob_j), num_p("ANTEBRAZO", rob_j)
codo_max = 0.0
for paso_b in range(0, 101):
    th_b = math.radians(abajo_b + (arriba_b - abajo_b) * paso_b / 100)
    largo_b = (al_medio - hombro_z) / math.cos(th_b)
    assert abs(brazo_b - antebrazo_b) < largo_b <= brazo_b + antebrazo_b, ("el brazo no llega al medio", paso_b)
    alfa_b = math.acos((brazo_b ** 2 + largo_b ** 2 - antebrazo_b ** 2) / (2 * brazo_b * largo_b))
    cy_b, cz_b = brazo_b * math.sin(th_b + alfa_b), brazo_b * math.cos(th_b + alfa_b)
    my_b, mz_b = largo_b * math.sin(th_b), largo_b * math.cos(th_b)
    assert abs(math.hypot(my_b - cy_b, mz_b - cz_b) - antebrazo_b) < 1e-6 and abs(mz_b - (al_medio - hombro_z)) < 1e-6
    assert 0.0 < cz_b < al_medio - hombro_z, ("el codo, entre el hombro y la mano", paso_b)
    codo_max = max(codo_max, hombro_y + cy_b + 0.43)
assert codo_max < 11.9, codo_max
for x in range(4008, 4026):
    for z in range(22, 32):
        for y in range(100, 100 + math.ceil(codo_max) + 1):
            assert libre_p((x, y, z)), ("algo donde están los robots o sus brazos", (x, y, z), pm.get((x, y, z)))
# la noche: techo negro, y en las cuatro paredes, fachadas de ladrillo con ventanas (unas prendidas y otras no)
assert all(pm.get((x, 116, z)) == "black_concrete" for x in range(3969, 4032) for z in range(-16, 55))
for pared_ in ([(x, -16) for x in range(3969, 4032)], [(x, 54) for x in range(3969, 4032)],
               [(3969, z) for z in range(-16, 55)], [(4031, z) for z in range(-16, 55)]):
    tipos_ = collections.Counter(pm.get((x, y, z)) for x, z in pared_ for y in range(100, 116))
    assert tipos_["bricks"] > 100 and tipos_["ochre_froglight"] > 20 and tipos_["black_concrete"] > 20, tipos_
gen_p = open(os.path.join(raiz, "herramientas/gen_puente.py"), encoding="utf-8").read()
assert "ROBOTS = ((4011.5, 26.5), (4021.5, 26.5))" in gen_p and "CENTRO_X, CENTRO_Z = 4000, 26" in gen_p
assert "OX, OY, OZ = 3969, 99, -17" in gen_p and "SX, SY, SZ = 63, 18, 72" in gen_p
# las imágenes de prueba dibujan los robots con las mismas medidas que RobotRenderer
pre_p = open(os.path.join(raiz, "herramientas/puente_render.py"), encoding="utf-8").read()
assert f"ARRIBA, ABAJO = {arriba_b}, {abajo_b}" in pre_p and f"HOMBRO_X, HOMBRO_Y, HOMBRO_Z = {hombro_x}, {hombro_y}, {hombro_z}" in pre_p
assert f"BRAZO, ANTEBRAZO, MANO = {brazo_b}, {antebrazo_b}, {num_p('MANO', ren_j)}" in pre_p
def valor_caja(t_):
    t_ = re.sub(r"(\d)F\b", r"\1", t_.strip()).replace("Robot.", "").replace(" ", "").replace("*lado", "*s")
    m_ = re.fullmatch(r"(-?[\d.]+)(\*s)?", t_)
    return (round(float(m_.group(1)), 4), bool(m_.group(2))) if m_ else t_
COLOR_J = {"NEGRO": "negro", "GRIS": "gris", "GRIS_CLARO": "gris_claro", "acento": "luz"}
cajas_j = collections.Counter()
for m_ in re.finditer(r"\b(caja|luz)\(pose, buffers, (?:luz, )?(\w+), ([^;]*)\);", ren_j.split("private void brazo(")[0]):
    cajas_j[(COLOR_J[m_.group(2)],) + tuple(valor_caja(a_) for a_ in m_.group(3).split(","))] += 1
cajas_p = collections.Counter()
for m_ in re.finditer(r"caja\(\(([^()]*)\), \(([^()]*)\), (\"\w+\"|luz)", pre_p.split("def partes(")[1].split("\ndef ")[0]):
    cajas_p[(m_.group(3).strip('"'),) + tuple(valor_caja(a_) for a_ in (m_.group(1) + "," + m_.group(2)).split(","))] += 1
assert len(cajas_j) == 16 and cajas_j == cajas_p, (cajas_j - cajas_p, cajas_p - cajas_j)
for frag_j, frag_p in (("0.75F, 0.75F, Robot.BRAZO", "(0.75, 0.75, BRAZO)"), ("0.85F, 0.85F, 0.85F", "(0.85, 0.85, 0.85)"),
                       ("0.7F, 0.7F, antebrazo", "(0.7, 0.7, ANTEBRAZO - MANO)"), ("0.9F, 0.9F, MANO", "(0.9, 0.9, MANO)"),
                       ("0.0F, 0.36F, antebrazo / 2.0F, 0.08F, 0.06F, antebrazo - 0.6F", "0.36, (ANTEBRAZO - MANO) / 2]), (0.08, 0.06, ANTEBRAZO - MANO - 0.6)")):
    assert frag_j in ren_j and frag_p in pre_p, (frag_j, frag_p)
bra_j = ren_j.split("private void brazo(")[1].split("\n    }\n")[0]
for frag_ in ("float adelante = Robot.AL_MEDIO - Robot.HOMBRO_Z;", "float largo = adelante / Mth.cos(rad);",
              "/ (2.0F * Robot.BRAZO * largo);", "float subeBrazo = rad + (float) Math.acos(Mth.clamp(coseno, -1.0F, 1.0F));",
              "float subeAntebrazo = (float) Math.atan2(largo * Mth.sin(rad) - codoY, largo * Mth.cos(rad) - codoZ);",
              "pose.mulPose(Axis.XP.rotation(-subeBrazo));", "pose.translate(0.0F, codoY, codoZ);",
              "pose.mulPose(Axis.XP.rotation(-subeAntebrazo));"):
    assert frag_ in bra_j, frag_                                   # la mano, siempre en el medio de la calle
# las luces brillan en la oscuridad (como los ojos de las arañas) y la cabeza gira mientras suena la canción
assert "RenderType.eyes(InventoryMenu.BLOCK_ATLAS)" in ren_j and "buffers.getBuffer(BRILLA)" in ren_j
assert "caja(pose, buffers, LightTexture.FULL_BRIGHT, estado, cx, cy, cz, sx, sy, sz);" in ren_j
assert "if (robot.canta()) {" in ren_j and "robot.cantar(canta);" in pue_j and "CUERDA" not in rob_j and "llave" not in ren_j
assert "bloques.renderSingleBlock(estado, pose, buffers, luz, OverlayTexture.NO_OVERLAY);" in ren_j
assert "Puente.elegir" not in rob_j and "public boolean isPickable() {\n        return false;" in rob_j   # los clics lo atraviesan
assert "return getBoundingBox().inflate(7.0, 1.0, 7.0);" in rob_j and "this.noPhysics = true;" in rob_j
reg_p = java["Registro.java"]
assert 'register("robot"' in reg_p and ".sized(5.0F, 10.0F)" in reg_p.split('register("robot"')[1].split(".build(")[0]
assert ".updateInterval(1)" in reg_p.split('register("robot"')[1].split(".build(")[0]
assert "evento.registerEntityRenderer(Registro.ROBOT.get(), RobotRenderer::new);" in java["Cliente.java"]
# el juego: 3 rondas, la canción, la fila enganchada, y que esté conectado con el día de juego
assert int(num_p("RONDAS")) == 3 and "TIEMPO_ELEGIR" not in pue_j and "PALABRAS" not in pue_j
for nombre_j, texto_j in java.items():
    assert "Puente.elegir" not in texto_j and '"/elegir' not in texto_j and 'literal("elegir")' not in texto_j, nombre_j
    assert "Puente.empujado" not in texto_j and "Puente.trastabillando" not in texto_j, nombre_j
mel_p = [int(v) for v in re.sub(r"//[^\n]*", "", re.search(r"MELODIA = \{([^}]*)\}", pue_j).group(1)).split(",") if v.strip()]
assert len(mel_p) == 32 and all(-1 <= n_ <= 24 for n_ in mel_p) and mel_p[:7] == [13, 15, 13, 11, 10, 11, 13], mel_p
assert "static final int CANCION = 32 * PASO_MUSICA;" in pue_j and "PASO_MUSICA = 5;" in pue_j
lang_p = json.load(open(os.path.join(raiz, "src/main/resources/assets/juegosdelpatio/lang/es_es.json"), encoding="utf-8"))
assert not [k_ for k_ in lang_p if k_.startswith(("palabra.juegosdelpatio.", "robot.juegosdelpatio."))]
assert lang_p["juego.juegosdelpatio.nombre_6"] == "El puente de Londres"
assert [lang_p[f"juego.juegosdelpatio.nombre_{n_}"] for n_ in range(1, 8)] == [
    "Luz verde, luz roja", "Sálvese quien pueda", "Asientos al vacío", "Las escondidas", "La papa caliente",
    "El puente de Londres", "Los estandartes"], [lang_p.get(f"juego.juegosdelpatio.nombre_{n_}") for n_ in range(1, 8)]
reg_pu = re.findall(r'"(\w+)"', re.search(r"REGLAS_PUENTE = \{([^}]*)\}", juego_txt).group(1))
assert reg_pu == ["puente_1", "puente_2", "puente_3", "puente_4", "puente_5", "puente_6", "reglas_7"], reg_pu
for r_ in reg_pu:
    assert "juego.juegosdelpatio." + r_ in lang_p, r_
assert lang_p["juego.juegosdelpatio.puente_5"].count("%s") == 0 and lang_p["juego.juegosdelpatio.puente_6"].count("%s") == 1
assert 'reglas[regla].equals("puente_5")' not in juego_txt
assert 'reglas[regla].equals("puente_6") ? Component.translatable(clave, Puente.RONDAS)' in juego_txt
assert "enganchados" in lang_p["juego.juegosdelpatio.puente_3"] and "eliminado" in lang_p["juego.juegosdelpatio.puente_4"]
assert "enganchados" in lang_p["mensaje.juegosdelpatio.camina_fila"] and "enganchado" in lang_p["mensaje.juegosdelpatio.como_puente"]
for frag_ in ("Puente.empezar(complejo, participantes(complejo));", "if (Puente.tick(complejo) || tiempo >= DURACION_MAX_PUENTE) {",
              "Puente.limpiar(complejo);", "case PUENTE -> Puente.pasaron();", "case PUENTE -> Puente.prepararArena(complejo);",
              "case PUENTE -> Puente.lugarDeSalida(azar);", "case PUENTE -> Puente.PODIO;",
              "case PUENTE -> new int[] {Puente.X0, Puente.X1, Puente.Z0, Puente.Z1};", "Puente.olvidar();",
              "case 6 -> CAMINO_COMANDANTE_6;", "case 6 -> PORTAL_6;", "static final int PUENTE = 6;"):
    assert frag_ in juego_txt, frag_
com_p = java["Comandos.java"]
assert 'Commands.literal("sextojuego").executes(ctx -> juego(ctx.getSource(), "llamar", 6))' in com_p
assert "versionPuente" in java["EstadoComplejo.java"]
# enganchados no se empuja (ni el jugador ni los bots), y no gasta el empujón
int_j = juego_txt.split("static void alInteractuar(")[1].split("\n    }\n")[0]
assert int_j.index("if (Puente.participa(victima)) {") < int_j.index("usarEmpujon(jugador.getUUID(), ahora)")
assert '"mensaje.juegosdelpatio.no_empujar_fila"' in int_j and "mensaje.juegosdelpatio.no_empujar_fila" in lang_p
assert "victima.isPassenger() || Puente.participa(victima) ||" in juego_txt.split("static boolean empujar(JugadorBot bot")[1][:300]
assert "como_empujar_puente" not in juego_txt
# la fila enganchada: uno detrás del otro (a 1 bloque; si no entran, da toda la vuelta), la fila avanza al paso de la
# ronda, se junta de a poco cuando sale alguien, y lleva a los jugadores (la velocidad, cada tick) y a los bots
sep_p, paso_p, pmin_p, pmax_p = num_p("SEPARACION"), num_p("PASO"), num_p("PASO_MIN"), num_p("PASO_MAX")
assert sep_p == 1.0 and pmin_p < paso_p < pmax_p and 0.07 <= pmin_p and pmax_p <= 0.17, (paso_p, pmin_p, pmax_p)
assert "return Math.min(SEPARACION, VUELTA / Math.max(1, GENTE.size()));" in pue_j
tick_p = pue_j.split("static boolean tick(ServerLevel complejo) {")[1].split("\n    }\n")[0]
assert "fase += paso;" in tick_p.split("case MUSICA -> {")[1].split("}")[0]
assert "if (estado != Estado.BAJAN && estado != Estado.TERMINADO) {\n            acomodar();\n            llevarJugadores(complejo);" in tick_p
lle_p = pue_j.split("private static void llevarJugadores(ServerLevel complejo) {")[1].split("\n    }\n")[0]
for frag_ in ("double vx = -Math.sin(angulo) * avance + dx * TIRON;", "double vz = Math.cos(angulo) * avance + dz * TIRON;",
              "jugador.setDeltaMovement(vx, -0.08, vz);", "jugador.hurtMarked = true;", "if (dx * dx + dz * dz > LEJOS * LEJOS) {"):
    assert frag_ in lle_p, frag_
# el tirón no oscila aunque el jugador tenga lag (la respuesta llega hasta 5 ticks tarde), y aunque haga fuerza para
# adelante o para atrás (0,098 bloques por tick, caminando), no se mueve de su lugar más de media separación
tiron_p = num_p("TIRON")
for demora_ in range(1, 6):
    errores_t = [1.0] * (demora_ + 1)
    for _ in range(400):
        errores_t.append(errores_t[-1] - tiron_p * errores_t[-1 - demora_])
    assert abs(errores_t[-1]) < 0.01 and max(abs(e_) for e_ in errores_t[-50:]) < 0.05, (demora_, errores_t[-1])
assert 0.098 / tiron_p < sep_p / 2, tiron_p
# los bots: la fila los lleva (siempre en su lugar), con las manos en los hombros del de adelante
pg_ = bot_txt.split("static class PuenteGoal")[1].split("static class EscondidasGoal")[0]
assert "return true;" in pg_.split("requiresUpdateEveryTick()")[1][:120]
assert "Juego.numero() == Juego.PUENTE && (Juego.enArena() || Juego.caminando()) && Juego.estaEnArena(bot)" in pg_
assert "this.goalSelector.addGoal(0, new PuenteGoal(this));" in bot_txt
for frag_ in ("bot.enganchar(Puente.participa(bot) && !Puente.encerrado(bot));", "if (Puente.filaQuieta()) {", "Puente.llevar(bot);"):
    assert frag_ in pg_, frag_
assert "bot.enganchar(false);" in pg_.split("public void stop()")[1]
assert "datos.define(ENGANCHADO, false);" in bot_txt
llb_p = pue_j.split("static void llevar(JugadorBot bot) {")[1].split("\n    }\n")[0]
assert "double maximo = (estado == Estado.MUSICA ? paso : 0.0) + 0.12;" in llb_p and "bot.setPos(" in llb_p
ren_b = java["JugadorBotRenderer.java"]
assert "new Modelo(contexto.bakeLayer(ModelLayers.PLAYER))" in ren_b and "if (bot.enganchado()) {" in ren_b
assert "this.rightSleeve.copyFrom(this.rightArm);" in ren_b and "this.leftSleeve.copyFrom(this.leftArm);" in ren_b
assert -1.6 <= float(re.search(r"BRAZOS_ADELANTE = (-?[\d.]+)F;", ren_b).group(1)) <= -1.2
# se cae el puente: el atrapado queda eliminado (con un redoble); los de al lado salen de abajo de los brazos, en orden
jaula_p = hombro_x - 0.4
assert "JAULA = Robot.HOMBRO_X - 0.4;" in pue_j and 1.2 <= jaula_p <= 1.8, jaula_p
assert 'eliminar(complejo, quien, "atrapado_puente");' in pue_j and "mensaje.juegosdelpatio.atrapado_puente" in lang_p
assert int(num_p("ELIMINA_ATRAPADO")) < int(num_p("LEVANTAN")) and "if (tiempo == ELIMINA_ATRAPADO) {" in pue_j
assert "debajo = porPasar(complejo);" in pue_j and jaula_p < num_p("POR_PASAR") <= 6.0
assert "salirDeAbajo(complejo, pasaron, 1.0);" in pue_j and "salirDeAbajo(complejo, llegaban, -1.0);" in pue_j
assert "AFUERA = JAULA + 0.9;" in pue_j and num_p("SIN_ENCIMARSE") >= 0.6                 # afuera de las manos; sin encimarse
for t_ in ("titulo.juegosdelpatio.cayo_puente", "titulo.juegosdelpatio.cayo_puente_detalle", "titulo.juegosdelpatio.te_atrapo",
           "titulo.juegosdelpatio.te_atrapo_detalle"):
    assert t_ in lang_p, t_
# el plan de cada ronda (como Puente.planear): para cualquier lugar del elegido, hay un paso posible (de 1,6 a 3,2
# bloques por segundo) con el que, cuando bajan los brazos, está justo en el medio del puente
assert "double falta = ((elegido * separacion() - fase) % VUELTA + VUELTA) % VUELTA;" in pue_j
VUELTA_P, CANCION_P = 2 * math.pi * radio_p, 32 * 5
vmin_p, vmax_p, smax_p = int(num_p("VUELTAS_MIN")), int(num_p("VUELTAS_MAX")), int(num_p("SORPRESA_MAX"))
def planear_p(falta_, ronda_, sorpresa_, azar_):
    if not sorpresa_:
        mejor_, plan_ = 1e9, None
        for vueltas_ in range(vmin_p + 1 if ronda_ == 1 else vmin_p, vmax_p + 1):
            for extra_ in range(3):
                p_ = (falta_ + extra_ * VUELTA_P) / (vueltas_ * CANCION_P)
                puntaje_ = abs(p_ / paso_p - 1.0) + 0.04 * vueltas_
                if pmin_p <= p_ <= pmax_p and puntaje_ < mejor_:
                    mejor_, plan_ = puntaje_, (p_, vueltas_ * CANCION_P)
        return plan_
    for extra_ in range(3):
        lejos_ = falta_ + extra_ * VUELTA_P
        desde_ = math.ceil(max(CANCION_P, lejos_ / pmax_p))
        hasta_ = math.floor(min(smax_p * CANCION_P, lejos_ / pmin_p))
        if desde_ <= hasta_:
            dur_ = azar_.randint(desde_, hasta_)
            return lejos_ / dur_, dur_
    return None
azar_p = random.Random(7)
duraciones_p = []
for k_ in range(2011):
    falta_ = VUELTA_P * k_ / 2011
    for ronda_ in (1, 2):
        for sorpresa_ in (False, True):
            plan_ = planear_p(falta_, ronda_, sorpresa_, azar_p)
            assert plan_ is not None, (falta_, ronda_, sorpresa_)
            p_, dur_ = plan_
            assert pmin_p - 1e-9 <= p_ <= pmax_p + 1e-9, (falta_, p_)
            if sorpresa_:
                assert CANCION_P <= dur_ <= smax_p * CANCION_P, dur_
            else:
                assert dur_ % CANCION_P == 0 and (3 if ronda_ == 1 else 2) * CANCION_P <= dur_ <= vmax_p * CANCION_P, dur_
            resto_ = (falta_ - p_ * dur_) % VUELTA_P
            assert min(resto_, VUELTA_P - resto_) < 1e-6, (falta_, resto_)                # justo en el medio del puente
            duraciones_p.append(dur_ / 20)
print("puente de Londres ok:", len(cuarto["blocks"]), "bloques; calle de", len(calle_p), "lugares (se llega a toda);",
      "manos arriba a", round(alto_arriba, 1), "y bajadas a", round(alto_abajo, 1), "; codos hasta", round(codo_max, 1),
      "; jaula de", round(2 * jaula_p, 1), "bloques; 3 rondas; fila enganchada a", sep_p, "bloque, de",
      round(pmin_p * 20, 1), "a", round(pmax_p * 20, 1), "bloques por segundo; la canción dura de", round(min(duraciones_p)),
      "a", round(max(duraciones_p)), "segundos (en promedio", round(sum(duraciones_p) / len(duraciones_p)), ")")
# --- Los estandartes (el juego 7): el campo largo de noche, partido por la grieta; la arena coincide con
# Estandartes.java, arriba de las torres de la grieta y de los bordes se puede estar parado, entre ellas hay vacío de 2
# o 3 hasta el fondo, todo es simétrico, y de cada lado se llega caminando a los tres caminos (pero no al otro lado)
est_j = java["Estandartes.java"]
for t_ in ("red", "blue"):
    VALIDOS[f"{t_}_banner"] = {"rotation": {str(i) for i in range(16)}}
    VALIDOS[f"{t_}_wall_banner"] = {"facing": {"north", "south", "east", "west"}}
for extra_b, props_b in (("grass_block", {"snowy": B}), ("dirt", {}), ("stone", {}), ("andesite", {}), ("tuff", {}),
                         ("gravel", {}), ("magma_block", {}), ("stone_bricks", {}), ("mossy_stone_bricks", {}),
                         ("cracked_stone_bricks", {}), ("chiseled_stone_bricks", {}), ("cobblestone", {}),
                         ("mossy_cobblestone", {}), ("gold_block", {}), ("deepslate", {"axis": {"x", "y", "z"}})):
    VALIDOS.setdefault(extra_b, props_b)
est_ = arena_torres("estandartes", (7895, 40, -20), [211, 96, 111], 7)
assert re.search(r"ORIGEN = new BlockPos\(7895, 40, -20\)", est_j) and 'Complejo.id("estandartes")' in est_j
def num_e(n_):
    expr_ = re.search(rf"static final int {n_} = (-?[\d *]+);", est_j).group(1)
    assert re.fullmatch(r"-?[\d *]+", expr_), expr_
    return int(eval(expr_))
assert (num_e("X0"), num_e("X1"), num_e("Z0"), num_e("Z1")) == (7895, 8105, -20, 90)
assert num_e("PISO") == 101 and num_e("VERSION_ARENA") == 3 and num_e("GRIETA") == 16 and num_e("FONDO") == 41
assert "private static final int[] VIEJAS = {7955, 8045, -17, 54, 38, 118};" in est_j       # las torres y La batalla
tor_e = [tuple(int(v) for v in t_) for t_ in re.findall(r"\{(\d+), (\d+), (-?\d+), (\d+)\}",
                                                         est_j.split("int[][] TORRES = {")[1].split("};")[0])]
vec_e = [[int(v) for v in g_.split(",")] for g_ in re.findall(r"\{([\d, ]+)\}", est_j.split("int[][] VECINOS = {")[1].split("};")[0])]
cam_e = [[int(v) for v in g_.split(",")] for g_ in re.findall(r"\{([\d, ]+)\}", est_j.split("int[][] CAMINOS = {")[1].split("};")[0])]
assert len(tor_e) == 16 and len(vec_e) == 16 and cam_e == [[0, 4], [5, 10], [11, 15]], (len(tor_e), len(vec_e), cam_e)
for a_, b_ in cam_e:                                             # cada camino: una cadena de bordes y torres, de oeste a este
    for k_ in range(a_, b_ + 1):
        assert sorted(vec_e[k_]) == [v_ for v_ in (k_ - 1, k_ + 1) if a_ <= v_ <= b_], (k_, vec_e[k_])
        assert tor_e[k_][2:] == tor_e[a_][2:], ("el camino no es derecho", k_)
    assert tor_e[a_][1] < 7984 and tor_e[b_][0] > 8016, ("los bordes, en lo llano", a_, b_)
def espejo_e(t_):
    return (16000 - t_[1], 16000 - t_[0], t_[2], t_[3])
for k_, t_ in enumerate(tor_e):                                  # todo es simétrico (x -> 16000 - x)
    assert espejo_e(t_) in tor_e, ("sin reflejo", k_)
celdas_e = 0
for k_, (x0_, x1_, z0_, z1_) in enumerate(tor_e):               # arriba de cada torre (y de cada borde), parado en y = 101
    for x in range(x0_, x1_ + 1):
        for z in range(z0_, z1_ + 1):
            assert parado_t(est_, x, z, 101), ("torre de la grieta", k_, x, z)
            celdas_e += 1
def vacio_al_fondo(x, z):
    return all(pasa_t(est_.get((x, y, z))) for y in range(42, 101)) and not pasa_t(est_.get((x, 41, z)))
for k_, vs_ in enumerate(vec_e):                                 # entre vecinas: 2 o 3 de vacío, hasta el fondo
    for v_ in vs_:
        if v_ < k_:
            continue
        a_, b_ = tor_e[k_], tor_e[v_]
        hueco_ = b_[0] - a_[1] - 1
        assert hueco_ in (2, 3), (k_, v_, hueco_)
        for x in range(a_[1] + 1, b_[0]):
            for z in range(a_[2], a_[3] + 1):
                assert vacio_al_fondo(x, z), ("vacío entre", k_, v_, x, z)
for z in range(7, 86):                                           # la grieta, en todo el largo: el que se cae, se mata
    for x in (7984, 7985, 8015, 8016):
        assert vacio_al_fondo(x, z), ("la grieta", x, z)
ped_ = {c_: tuple(int(v) for v in re.search(rf"ESTANDARTE_{c_} = new BlockPos\((\d+), PISO, (\d+)\)", est_j).groups())
        for c_ in ("ROJO", "AZUL")}
assert ped_ == {"ROJO": (7912, 46), "AZUL": (8088, 46)}, ped_
assert num_e("GIRO_ROJO") == 12 and num_e("GIRO_AZUL") == 4
for c_, (px_, pz_) in ped_.items():                              # el estandarte, sobre oro, con lugar alrededor
    assert est_.get((px_, 101, pz_)) == ("red_banner" if c_ == "ROJO" else "blue_banner") and est_.get((px_, 100, pz_)) == "gold_block"
    assert all(parado_t(est_, px_ + a_, pz_ + b_, 101) for a_ in (-1, 0, 1) for b_ in (-1, 0, 1) if (a_, b_) != (0, 0)), c_
est_nbt_ = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/estandartes.nbt")).read())
rot_ = {}
for bl in est_nbt_["blocks"]:
    p_ = est_nbt_["palette"][bl["state"]]
    if p_["Name"].endswith("_banner") and "wall" not in p_["Name"]:
        rot_[p_["Name"].split(":")[1]] = p_["Properties"]["rotation"]
assert rot_ == {"red_banner": "12", "blue_banner": "4"}, rot_
# caminando (subiendo de a un bloque, bajando hasta 3), desde cada estandarte se llega a los tres bordes de su lado, y a
# casi todo su lado; pero nunca al otro lado (se cruza saltando)
PISOS_E = {"grass_block", "dirt", "cobblestone", "mossy_cobblestone", "stone_bricks", "chiseled_stone_bricks"}
def parado_e3(x, y, z):
    return est_.get((x, y - 1, z)) in PISOS_E | {"gold_block"} and pasa_t(est_.get((x, y, z))) and pasa_t(est_.get((x, y + 1, z)))
lugares_e = {}
for x in range(7901, 8100):
    for z in range(7, 86):
        for y in range(99, 112):
            if parado_e3(x, y, z) and est_.get((x, y - 1, z)) != "gold_block":
                lugares_e.setdefault((x, z), []).append(y)
def bfs_e(desde_):
    vistos_, cola_ = {desde_}, deque([desde_])
    while cola_:
        x, y, z = cola_.popleft()
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            for y2 in lugares_e.get((x + dx, z + dz), ()):
                if -3 <= y2 - y <= 1 and (y2 <= y or pasa_t(est_.get((x, y + 2, z)))) and (x + dx, y2, z + dz) not in vistos_:
                    vistos_.add((x + dx, y2, z + dz))
                    cola_.append((x + dx, y2, z + dz))
    return vistos_
for c_, (px_, pz_) in ped_.items():
    rojo_ = c_ == "ROJO"
    vistos_ = bfs_e((px_ + (2 if rojo_ else -2), 101, pz_))
    assert all((x >= 8017) != rojo_ for (x, _, _) in vistos_), ("se llega caminando al otro lado", c_)
    for a_, b_ in cam_e:
        t_ = tor_e[a_ if rojo_ else b_]
        assert any(t_[0] <= x <= t_[1] and t_[2] <= z <= t_[3] for (x, _, z) in vistos_), ("no llega al borde", c_, a_)
    lado_ = [(x, z) for (x, z) in lugares_e if (x < 7984 if rojo_ else x >= 8017)]      # (sin las torres de la grieta)
    llega_ = {(x, z) for (x, _, z) in vistos_}
    assert len(llega_) >= 0.95 * len(lado_), (c_, len(llega_), len(lado_))
borde_e = [(x, z) for x in range(7900, 8101) for z in (6, 86) if not 7984 <= x <= 8016]
borde_e += [(x, z) for z in range(6, 87) for x in (7900, 8100)]
for (x, z) in borde_e:                                           # la barrera invisible en el borde del campo
    tope_ = max(y for y in range(70, 115) if est_.get((x, y, z)) not in (None, "barrier", "light"))
    assert all(est_.get((x, tope_ + k, z)) == "barrier" for k in range(1, 7)), ("barrera", x, z)
for x in range(7980, 8021):                                      # el palco (más alto, separado): Estandartes.lugarDeSalida
    for z in range(-11, -3):
        assert parado_t(est_, x, z, 112), ("palco de los estandartes", x, z)
assert "return new Vec3(7980.5 + azar.nextInt(41), 112.0, -11.5 + azar.nextInt(8));" in est_j
podio_e = [float(v) for v in re.search(r"PODIO = new Vec3\(([\d.]+), ([\d.]+), (-?[\d.]+)\)", est_j).groups()]
assert podio_e == [8000.5, 114.0, -13.5] and est_.get((8000, 113, -14)) == "smooth_quartz", podio_e
for t_ in re.findall(r"new Vec3\(([\d.]+), 112\.0, (-?[\d.]+)\)", est_j.split("PUESTOS_SARGENTOS = {")[1].split("};")[0]):
    assert parado_t(est_, math.floor(float(t_[0])), math.floor(float(t_[1])), 112), ("sargento", t_)
for x in range(7977, 7984):                                      # el portal de vuelta, en el palco
    for y in range(112, 118):
        assert est_.get((x, y, -16)) in ("polished_blackstone", "portal_juego"), (x, y)
# las reglas: 8 minutos, sin derrumbes; el que pierde, con rayos (que no lastiman a nadie más)
for frag_ in ("DURACION = 8 * 60 * 20;", "private static final int CUENTA = 10 * 20;", "EntityType.LIGHTNING_BOLT.create(complejo);",
              "rayo.setVisualOnly(true);", "Juego.eliminar(complejo, quien, false, motivoFinal);", "rayoAlQueSigue(complejo);",
              '"te_caiste_grieta"', "GUARDADOS.putIfAbsent(clavado, complejo.getBlockState(clavado));"):
    assert frag_ in est_j, frag_
for frag_ in ("FallingBlockEntity", "derrumb", "agriet", "CAMPO.quitar(", "bastión"):
    assert frag_ not in est_j, frag_
gol_e = est_j.split("static void alRecibirGolpe(")[1].split("\n    }\n")[0]
for aviso_ in re.findall(r'"([a-z_]+)"', gol_e.split("String aviso =")[1].split(";")[0]):
    assert "mensaje.juegosdelpatio." + aviso_ in lang_p, aviso_
mot_e = est_j.split("static String motivo(")[1].split("\n    }\n")[0]
for m_ in re.findall(r'"([a-z_]+)"', mot_e) + ["perdiste_el_estandarte", "perdio_tu_equipo"]:
    assert "mensaje.juegosdelpatio." + m_ in lang_p, m_
mor_e = est_j.split("static void alMorir(")[1].split("\n    }\n")[0]
for m_ in re.findall(r'"([a-z_]+)"', mor_e.split("String clave =")[1].split(";")[0]):
    assert "mensaje.juegosdelpatio." + m_ in lang_p, m_
for k_ in re.findall(r'"((?:mensaje|titulo|juego|barra|item)\.juegosdelpatio\.[a-z_]+)"', est_j):
    assert k_ in lang_p, k_
assert lang_p["juego.juegosdelpatio.estandartes_6"].count("%s") == 1
assert 'reglas[regla].equals("estandartes_6") ? Component.translatable(clave, Estandartes.DURACION / MINUTO)' in juego_j
assert "DURACION_MAX_ESTANDARTES = 9 * 60 * 20;" in juego_j and "Estandartes.alargue(complejo);" in juego_j
assert not [k_ for k_ in lang_p if "bastión" in lang_p[k_] or "torre_se_cae" in k_ or "agrietan" in k_]
int_e = juego_j.split("static void alInteractuar(")[1].split("\n    }\n")[0]
assert "if (Estandartes.lleva(jugador)) {" in int_e and int_e.index("Estandartes.lleva(jugador)") < int_e.index("usarEmpujon(")
# los bots: cruzan el campo de a tramos, saltan por las torres de su camino y pelean con la espada
bot_e = java["JugadorBot.java"]
assert "this.goalSelector.addGoal(0, new EstandartesGoal(this));" in bot_e and "BatallaGoal" not in bot_e
eg_ = bot_e.split("static class EstandartesGoal")[1]
assert "return Juego.numero() == Juego.ESTANDARTES && Estandartes.juega(bot);" in eg_
for frag_ in ("saltos.ir(Estandartes.CAMPO", "irAlLado(Estandartes.ladoDe(!rojo), Estandartes.ruta(papel))",
              "irAlLado(Estandartes.ladoDe(rojo), Estandartes.caminoCerca(bot.getZ()))", "Estandartes.enemigoCerca(bot,",
              "Estandartes.portador(complejo, rojo);", "Estandartes.portador(complejo, !rojo);", "bot.doHurtTarget(otro);",
              "Estandartes.lugarEnFortin(complejo, rojo, bot.getRandom());", "meta = new Vec3(bot.getX() + dx / d * 26.0"):
    assert frag_ in eg_, frag_
assert "!Estandartes.sinChoques(this)" in bot_e.split("public boolean isPushable()")[1][:200]
assert "!Estandartes.sinChoques(this)" in bot_e.split("protected void doPush(")[1][:200]
assert "versionEstandartes" in java["EstadoComplejo.java"]
# en las arenas no se rompen ni se ponen bloques (salvo en creativo)
jdp_ = java["JuegosDelPatio.java"]
assert "addListener(Juego::alRomper)" in jdp_ and "addListener(Juego::alPoner)" in jdp_
for f_ in ("static void alRomper(BlockEvent.BreakEvent evento) {", "static void alPoner(BlockEvent.EntityPlaceEvent evento) {"):
    cuerpo_ = juego_j.split(f_)[1].split("\n    }\n")[0]
    assert "!jugador.isCreative()" in cuerpo_ and "evento.setCanceled(true);" in cuerpo_ and "enLasArenas(" in cuerpo_, f_
print("los estandartes ok:", len(est_), "bloques;", celdas_e, "lugares en los bordes y las 10 torres de la grieta (tres",
      "caminos), simétrico; de cada lado se llega caminando a los tres caminos, y al otro lado solo saltando")
# los 7 juegos, en orden, en Juego: el número de cada uno, sus reglas (en los idiomas) y su arena
orden_ = {"LUZ_VERDE": 1, "CASILLEROS": 2, "SILLAS": 3, "ESCONDIDAS": 4, "TEJO": 5, "PUENTE": 6, "ESTANDARTES": 7}
for n_, v_ in orden_.items():
    assert f"static final int {n_} = {v_};" in juego_j, n_
assert "JUEGOS_HECHOS = 7;" in juego_j and "BATALLA" not in juego_j and "Batalla" not in juego_j
for arr_ in ("REGLAS_SILLAS", "REGLAS_CASILLEROS", "REGLAS_TEJO", "REGLAS_ESCONDIDAS", "REGLAS_PUENTE", "REGLAS_ESTANDARTES"):
    for r_ in re.findall(r'"(\w+)"', re.search(arr_ + r" = \{([^}]*)\}", juego_j).group(1)):
        assert "juego.juegosdelpatio." + r_ in lang_p, (arr_, r_)
for clave_ in ("casilleros_fin", "tejo_fin", "estandartes_fin"):
    assert f'"{clave_}"' in juego_j and "juego.juegosdelpatio." + clave_ in lang_p and "barra.juegosdelpatio." + clave_ in lang_p
for consejo_ in ("como_casilleros", "como_tejo", "como_estandartes"):
    assert "mensaje.juegosdelpatio." + consejo_ in lang_p
assert not [k_ for k_ in lang_p if "batalla" in k_], [k_ for k_ in lang_p if "batalla" in k_]
com_7 = java["Comandos.java"]
for n_, palabra_ in enumerate(("primerjuego", "segundojuego", "tercerjuego", "cuartojuego", "quintojuego", "sextojuego",
                               "septimojuego"), start=1):
    assert f'Commands.literal("{palabra_}").executes(ctx -> juego(ctx.getSource(), "llamar", {n_}))' in com_7, palabra_
cer_7 = java["Ceremonia.java"]
assert "if (juego >= Juego.JUEGOS_HECHOS) {" in cer_7 and "Votacion.premioFinal(complejo, RESULTADOS[2]);" in cer_7
assert "static void premioFinal(ServerLevel complejo, int quedanTotal) {" in java["Votacion.java"]
assert "voto.juegosdelpatio.final_ganadores" in lang_p
assert "addListener(Juego::alMorir)" in java["JuegosDelPatio.java"]
mor_ = juego_j.split("static void alMorir(LivingDeathEvent evento) {")[1].split("\n    }\n")[0]
assert "numero == ESCONDIDAS" in mor_ and "anotarEliminado(complejo, muerto, motivo);" in mor_
for f_ in ("Quemado.java", "Rayuela.java", "Pelota.java", "PelotaItem.java", "Fuego.java", "BolaDeFuego.java",
           "BolaDeFuegoItem.java"):
    assert f_ not in java, f_
print("los 7 juegos ok: reglas, finales, comandos y el premio final")
sys.exit(1 if errores else 0)
