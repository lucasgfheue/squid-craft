#!/usr/bin/env python3
"""Revisa el proyecto: JSON, TOML, YAML, y la plantilla NBT (lectura completa)."""
import gzip
import json
import os
import struct
import sys
import tomllib

raiz = sys.argv[1]
errores = 0

# --- JSON / mcmeta
for d, _, fs in os.walk(raiz):
    for f in fs:
        if f.endswith((".json", ".mcmeta")):
            p = os.path.join(d, f)
            try:
                json.load(open(p, encoding="utf-8"))
            except Exception as e:
                errores += 1
                print("JSON MAL:", p, e)

# --- TOML
toml = tomllib.load(open(os.path.join(raiz, "src/main/resources/META-INF/neoforge.mods.toml"), "rb"))
assert toml["modLoader"] == "javafml" and toml["mods"][0]["modId"] == "juegosdelpatio", toml
print("toml ok:", toml["mods"][0]["displayName"], toml["mods"][0]["version"])

# --- YAML
try:
    import yaml
    wf = yaml.safe_load(open(os.path.join(raiz, ".github/workflows/compilar.yml")))
    pasos = [s.get("name") for s in wf["jobs"]["compilar"]["steps"]]
    print("workflow ok:", pasos)
except ImportError:
    print("(sin PyYAML, no se revisó el YAML)")


# --- NBT
def leer_nbt(b):
    pos = 0

    def u(fmt):
        nonlocal pos
        v = struct.unpack_from(fmt, b, pos)
        pos += struct.calcsize(fmt)
        return v[0]

    def s():
        n = u(">H")
        nonlocal pos
        v = b[pos:pos + n].decode("utf-8")
        pos += n
        return v

    def payload(t):
        if t == 1: return u(">b")
        if t == 2: return u(">h")
        if t == 3: return u(">i")
        if t == 4: return u(">q")
        if t == 5: return u(">f")
        if t == 6: return u(">d")
        if t == 8: return s()
        if t == 9:
            et = u(">b"); n = u(">i")
            return [payload(et) for _ in range(n)]
        if t == 10:
            c = {}
            while True:
                ct = u(">b")
                if ct == 0:
                    return c
                nombre = s()
                c[nombre] = payload(ct)
        raise ValueError(f"tag {t}")

    assert u(">b") == 10
    s()
    raiz_tag = payload(10)
    assert pos == len(b), "sobran bytes"
    return raiz_tag


nbt = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/dormitorio.nbt")).read())
sx, sy, sz = nbt["size"]
pal = nbt["palette"]
print("nbt ok: DataVersion", nbt["DataVersion"], "tamaño", nbt["size"], "paleta", len(pal), "bloques", len(nbt["blocks"]))
assert nbt["DataVersion"] == 3955
vistos = set()
for bl in nbt["blocks"]:
    x, y, z = bl["pos"]
    assert 0 <= x < sx and 0 <= y < sy and 0 <= z < sz
    assert 0 <= bl["state"] < len(pal)
    assert (x, y, z) not in vistos
    vistos.add((x, y, z))

# Bloques y propiedades válidos en 1.21.1
VALIDOS = {
    "smooth_stone": {}, "polished_andesite": {}, "polished_deepslate": {}, "deepslate_tiles": {},
    "tuff_bricks": {}, "polished_tuff": {}, "chiseled_tuff_bricks": {}, "iron_block": {},
    "polished_blackstone": {}, "sea_lantern": {},
    "waxed_copper_bulb": {"lit": {"true", "false"}, "powered": {"true", "false"}},
    "waxed_copper_grate": {"waterlogged": {"true", "false"}},
    "white_bed": {"facing": {"north", "south", "east", "west"}, "part": {"head", "foot"}, "occupied": {"true", "false"}},
    "iron_bars": {k: {"true", "false"} for k in ("north", "south", "east", "west", "waterlogged")},
    "chain": {"axis": {"x", "y", "z"}, "waterlogged": {"true", "false"}},
    "lantern": {"hanging": {"true", "false"}, "waterlogged": {"true", "false"}},
}
B = {"true", "false"}
H4 = {"north", "south", "east", "west"}
VALIDOS.update({
    "quartz_stairs": {"facing": H4, "half": {"top", "bottom"}, "shape": {"straight", "inner_left", "inner_right", "outer_left", "outer_right"}, "waterlogged": B},
    "iron_trapdoor": {"facing": H4, "half": {"top", "bottom"}, "open": B, "powered": B, "waterlogged": B},
    "birch_door": {"facing": H4, "half": {"upper", "lower"}, "hinge": {"left", "right"}, "open": B, "powered": B},
    "water_cauldron": {"level": {"1", "2", "3"}},
    "lever": {"face": {"floor", "wall", "ceiling"}, "facing": H4, "powered": B},
    "light_gray_stained_glass": {}, "light_blue_terracotta": {}, "quartz_bricks": {}, "smooth_quartz": {},
    "smooth_quartz_slab": {"type": {"top", "bottom", "double"}, "waterlogged": B},
    "lightning_rod": {"facing": H4 | {"up", "down"}, "powered": B, "waterlogged": B},
    "white_stained_glass_pane": {k: B for k in ("north", "south", "east", "west", "waterlogged")},
    "spruce_planks": {}, "dark_oak_planks": {},
    "spruce_slab": {"type": {"top", "bottom", "double"}, "waterlogged": B},
    "dark_oak_slab": {"type": {"top", "bottom", "double"}, "waterlogged": B},
    "white_candle": {"candles": {"1", "2", "3", "4"}, "lit": B, "waterlogged": B},
    "smoker": {"facing": H4, "lit": B},
    "barrel": {"facing": H4 | {"up", "down"}, "open": B},
    "cake": {"bites": {str(i) for i in range(7)}},
    "spruce_wall_sign": {"facing": H4, "waterlogged": B},
})
for c in ("white", "black", "red", "orange", "yellow", "lime", "green", "cyan", "blue", "purple", "light_blue", "light_gray"):
    VALIDOS[f"{c}_concrete"] = {}
for p in pal:
    ns, name = p["Name"].split(":")
    assert ns == "minecraft", p
    assert name in VALIDOS, f"bloque desconocido {name}"
    props = p.get("Properties", {})
    assert set(props) == set(VALIDOS[name]), (name, props)
    for k, v in props.items():
        assert v in VALIDOS[name][k], (name, k, v)

# Camas: cada mitad tiene su pareja correcta
estado = {tuple(bl["pos"]): pal[bl["state"]] for bl in nbt["blocks"]}
D = {"north": (0, -1), "south": (0, 1), "east": (1, 0), "west": (-1, 0)}
camas = 0
for (x, y, z), p in estado.items():
    if p["Name"] == "minecraft:white_bed" and p["Properties"]["part"] == "foot":
        dx, dz = D[p["Properties"]["facing"]]
        h = estado.get((x + dx, y, z + dz))
        assert h and h["Name"] == p["Name"] and h["Properties"]["part"] == "head" and h["Properties"]["facing"] == p["Properties"]["facing"], (x, y, z)
        camas += 1
print("camas emparejadas:", camas)

# Llegada: el jugador aparece en (32, 1, 33) de la plantilla -> piso sólido y 2 bloques libres
assert estado.get((32, 0, 33)) and (32, 1, 33) not in estado and (32, 2, 33) not in estado
# Carteles con su texto
carteles = [bl for bl in nbt["blocks"] if pal[bl["state"]]["Name"] == "minecraft:spruce_wall_sign"]
for bl in carteles:
    assert len(bl["nbt"]["front_text"]["messages"]) == 4 and len(bl["nbt"]["back_text"]["messages"]) == 4
    json.loads(bl["nbt"]["front_text"]["messages"][1])
print("carteles:", [json.loads(bl["nbt"]["front_text"]["messages"][1])["text"] for bl in carteles])
# Puertas abiertas en la pared del salón (z=29): 3 de ancho x 4 de alto
for xc in (12, 52):
    for x in range(xc - 1, xc + 2):
        for y in range(1, 5):
            assert (x, y, 29) not in estado, (x, y)
# El chequeo "ya construido" usa la esquina (0,0,0): tiene que haber bloque
assert (0, 0, 0) in estado
print("llegada y esquina ok")
print("errores JSON:", errores)

# --- texturas y traducciones de los bots y el uniforme
from PIL import Image
base = os.path.join(raiz, "src/main/resources/assets/juegosdelpatio")
for i in range(48):
    im = Image.open(os.path.join(base, f"textures/entity/jugador/skin_{i}.png"))
    assert im.size == (64, 64) and im.mode == "RGBA", (i, im.size, im.mode)
for capa in (1, 2):
    im = Image.open(os.path.join(base, f"textures/models/armor/uniforme_layer_{capa}.png"))
    assert im.size == (64, 32), im.size
for d, _, fs in os.walk(os.path.join(base, "models/item")):
    for f in fs:
        modelo = json.load(open(os.path.join(d, f)))
        for t in modelo.get("textures", {}).values():
            ns, ruta = t.split(":")
            assert os.path.exists(os.path.join(raiz, f"src/main/resources/assets/{ns}/textures/{ruta}.png")), t
claves = ["entity.juegosdelpatio.jugador", "item.juegosdelpatio.huevo_jugador", "item.juegosdelpatio.uniforme_camisa",
          "item.juegosdelpatio.uniforme_pantalon", "item.juegosdelpatio.uniforme_zapatillas", "mensaje.juegosdelpatio.bots"]
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    faltan = [k for k in claves if k not in lang]
    assert not faltan, (f, faltan)
for item in ("invitacion", "huevo_jugador", "uniforme_camisa", "uniforme_pantalon", "uniforme_zapatillas"):
    assert os.path.exists(os.path.join(base, f"models/item/{item}.json")), item
print("texturas, modelos y traducciones ok")

# --- guardias, armas y balas: todo lo registrado en Java tiene modelo, textura y traducción
import re
java = {}
for d, _, fs in os.walk(os.path.join(raiz, "src/main/java")):
    for f in fs:
        if f.endswith(".java"):
            java[f] = open(os.path.join(d, f), encoding="utf-8").read()
registro = java["Registro.java"]
objetos = re.findall(r'OBJETOS\.register\("([a-z_]+)"', registro) + re.findall(r'registerSimpleItem\("([a-z_]+)"', registro)
entidades = re.findall(r'ENTIDADES\.register\("([a-z_]+)"', registro)
rangos = re.findall(r'^\s+[A-Z]+\("([a-z]+)",', java["Rango.java"], re.M)
assert set(objetos) >= {"porra", "pistola", "rifle", "escopeta", "bala", "huevo_guardia"}, objetos
assert set(entidades) == {"jugador", "guardia", "bala", "asiento"}, entidades
assert rangos == ["vigilante", "guardia", "sargento", "comandante"], rangos
usadas = set()
for texto in java.values():
    usadas |= set(re.findall(r'Component\.translatable\("([a-z_.]+)"', texto))
    usadas |= set(re.findall(r'"((?:mensaje|titulo|barra|juego|ceremonia|voto|comida)\.juegosdelpatio\.[a-z_0-9]+)"', texto))
usadas = {k for k in usadas if not k.endswith(".") and not k.endswith("_")}   # los que se arman con "+ numero"
hechos_ = int(re.search(r"JUEGOS_HECHOS = (\d+);", java["Juego.java"]).group(1))
necesarias = usadas | {f"item.juegosdelpatio.{o}" for o in objetos} | {f"entity.juegosdelpatio.{e}" for e in entidades} \
    | {f"rango.juegosdelpatio.{r}" for r in rangos} | {f"juego.juegosdelpatio.nombre_{n_}" for n_ in range(1, hechos_ + 1)} \
    | {"comida.juegosdelpatio.menu_1", "comida.juegosdelpatio.menu_2", "item.juegosdelpatio.espada_buscador"}
conjuntos = {}
for f in sorted(os.listdir(os.path.join(base, "lang"))):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    faltan = sorted(necesarias - set(lang))
    assert not faltan, (f, faltan)
    conjuntos[f] = set(lang)
assert len({frozenset(v) for v in conjuntos.values()}) == 1, "los idiomas no tienen las mismas claves"
cer_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/Ceremonia.java"), encoding="utf-8").read()
partes_cer = set()
for bloque_ in re.findall(r"String\[\] DISCURSO\w* = \{([^}]*)\}", cer_txt):
    partes_cer |= set(re.findall(r'"([a-z_]+)"', bloque_))
assert {"bienvenida", "llamado_saludo", "resultados_premio", "resultados_votacion"} <= partes_cer, partes_cer
for f_ in conjuntos:                                            # las frases de las ceremonias se arman con +
    for p_ in partes_cer:
        assert f"ceremonia.juegosdelpatio.{p_}" in conjuntos[f_], (f_, p_)
for f_ in conjuntos:                                            # los motivos de eliminación se arman con +
    for m_ in ("te_moviste", "moviste_cabeza", "no_llegaste", "te_empujaron", "sin_silla", "no_caminaste",
               "no_juegas", "todavia_musica", "silla_ocupada", "mas_cerca"):
        assert f"mensaje.juegosdelpatio.{m_}" in conjuntos[f_], (f_, m_)
print("claves de idioma usadas:", len(necesarias), "en", len(conjuntos), "idiomas")
PADRES = {"minecraft:item/generated", "minecraft:item/handheld", "minecraft:item/crossbow", "minecraft:item/template_spawn_egg"}
for o in objetos:
    modelo = json.load(open(os.path.join(base, f"models/item/{o}.json")))
    assert modelo["parent"] in PADRES, (o, modelo["parent"])
    if "spawn_egg" not in modelo["parent"]:
        assert modelo["textures"]["layer0"] == f"juegosdelpatio:item/{o}", o
        im = Image.open(os.path.join(base, f"textures/item/{o}.png"))
        assert im.size == (16, 16) and im.mode == "RGBA", (o, im.size, im.mode)
for r in rangos:
    im = Image.open(os.path.join(base, f"textures/entity/guardia/{r}.png"))
    assert im.size == (64, 64) and im.mode == "RGBA", (r, im.size)
    # la cara (capa base de la cabeza) queda tapada entera por la máscara: sin agujeros
    assert all(im.getpixel((x, y))[3] == 255 for x in range(8, 16) for y in range(8, 16)), r
datos = os.path.join(raiz, "src/main/resources/data/juegosdelpatio")
for d, _, fs in os.walk(os.path.join(datos, "recipe")):
    for f in fs:
        receta = json.load(open(os.path.join(d, f)))
        ns, item = receta["result"]["id"].split(":")
        assert ns == "juegosdelpatio" and item in objetos, receta["result"]
        for ing in receta.get("ingredients", []):
            assert ing["item"].startswith("minecraft:"), ing
for d, _, fs in os.walk(os.path.join(datos, "advancement/recipes")):
    for f in fs:
        logro = json.load(open(os.path.join(d, f)))
        for receta in logro["rewards"]["recipes"]:
            assert os.path.exists(os.path.join(datos, "recipe", receta.split(":")[1] + ".json")), receta
print("guardias: rangos", rangos, "| objetos", len(objetos), "| entidades", entidades)

# --- portón, pasillo y ceremonia: el Java coincide con la plantilla y el desfile puede caminar
compl = java["Complejo.java"]
def const(nombre, texto=compl):
    return int(re.search(rf"{nombre}\s*=\s*(-?\d+)", texto).group(1))
PX0, PX1, PY, PZ, PALTO = (const("PORTON_X0"), const("PORTON_X1"), const("PORTON_Y"), const("PORTON_Z"), const("PORTON_ALTO"))
OX, OY, OZ = -32, 64, -33                                   # ORIGEN_DORMITORIO
assert re.search(r"ORIGEN_DORMITORIO = new BlockPos\(-32, 64, -33\)", compl)
def S_(wx, wy, wz):
    return (wx - OX, wy - OY, wz - OZ)
nombre = lambda pos: pal[estado[pos]["__i"]]["Name"] if False else (estado[pos]["Name"] if pos in estado else "minecraft:air")
for x in range(PX0, PX1 + 1):
    for fila in range(PALTO):
        esperado = "minecraft:polished_blackstone" if x in (PX0, PX1) or fila % 4 == 0 else "minecraft:iron_block"
        assert nombre(S_(x, PY + fila, PZ)) == esperado, (x, fila, nombre(S_(x, PY + fila, PZ)))
        assert nombre(S_(x, PY + PALTO + fila, PZ)) == "minecraft:air", ("hueco", x, fila)
        assert nombre(S_(x, PY + fila, PZ + 1)) == "minecraft:air", ("abertura", x, fila)
# caminar del pasillo a la sala con el portón abierto (BFS por el piso)
abierto = {pos: v for pos, v in estado.items()}
for x in range(PX0, PX1 + 1):
    for fila in range(PALTO):
        abierto.pop(S_(x, PY + fila, PZ), None)
def libre(pos):
    n = abierto.get(pos, {"Name": "minecraft:air"})["Name"]
    return n == "minecraft:air" or "carpet" in n
def pisable(x, z):
    return S_(0, 0, 0) and (x, 0, z) in abierto and libre((x, 1, z)) and libre((x, 2, z))
from collections import deque
cer = java["Ceremonia.java"]
def vec(nombre_v):
    m = re.search(rf"{nombre_v} = new Vec3\(([-\d.]+), ([-\d.]+), ([-\d.]+)\)", cer)
    return tuple(float(v) for v in m.groups())
esc, pas = vec("ESCENARIO"), vec("PASILLO")
form = [tuple(float(v) for v in par) for par in re.findall(r"\{(-?[\d.]+), (-?[\d.]+)\}", cer.split("FORMACION =")[1].split(";")[0])]
assert len(form) == 5, form
import math
def celda(wx, wz):
    sx, _, sz = S_(math.floor(wx), 65, math.floor(wz))
    return (sx, sz)
inicio = celda(pas[0], pas[2])
vistos, cola = {inicio}, deque([inicio])
while cola:
    x, z = cola.popleft()
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        n = (x + dx, z + dz)
        if n not in vistos and 0 <= n[0] < 65 and 0 <= n[1] < 102 and pisable(*n):
            vistos.add(n); cola.append(n)
for cx, cz in [(pas[0] + fx, pas[2] + fz) for fx, fz in form] + [(esc[0] + fx, esc[2] + fz) for fx, fz in form]:
    assert celda(cx, cz) in vistos, ("el desfile no llega a", cx, cz)
for wx in (-12.5, 13.5):                                    # esquinas del público
    for wz in (14.5, 28.5):
        assert celda(wx, wz) in vistos, ("público", wx, wz)
partes = re.findall(r'"([a-z]+)"', cer.split("DISCURSO =")[1].split(";")[0])
assert len(partes) == 8, partes
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for parte in partes:
        assert f"ceremonia.juegosdelpatio.{parte}" in lang, (f, parte)
print("portón y ceremonia ok: el desfile camina", len(vistos), "celdas | frases:", len(partes))

# --- los puestos de guardia (y los lugares de al lado, por si hay más guardias que puestos) son pisables
puestos = re.findall(r"new Vec3\(([-\d.]+), 65, ([-\d.]+)\)", compl.split("PUESTOS = {")[1].split("};")[0])
assert len(puestos) == 2, len(puestos)
for px, pz in puestos:
    for dx in (0.0, 1.0, -1.0):
        assert celda(float(px) + dx, float(pz)) in vistos, ("puesto", px, pz, dx)
print("puestos de guardia ok:", len(puestos))

# --- Torre de los Juegos: bloques válidos y se puede subir caminando desde la sala hasta las 5 puertas
VALIDOS["deepslate_tile_stairs"] = {"facing": H4, "half": {"top", "bottom"},
                                    "shape": {"straight", "inner_left", "inner_right", "outer_left", "outer_right"},
                                    "waterlogged": B}
torre = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/torre.nbt")).read())
assert torre["size"] == [21, 56, 21], torre["size"]
for p_ in torre["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    props = p_.get("Properties", {})
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
assert re.search(r"ORIGEN_TORRE = new BlockPos\(-10, 64, -54\)", compl)
mundo = {}
for bl in nbt["blocks"]:
    x, y, z = bl["pos"]
    mundo[(x - 32, y + 64, z - 33)] = pal[bl["state"]]["Name"]
for bl in torre["blocks"]:
    x, y, z = bl["pos"]
    mundo[(x - 10, y + 64, z - 54)] = torre["palette"][bl["state"]]["Name"]
for x in range(PX0, PX1 + 1):                                 # el portón abierto
    for fila in range(PALTO):
        mundo.pop((x, PY + fila, PZ), None)
def pasa(p_):
    n_ = mundo.get(p_, "minecraft:air")
    return n_ == "minecraft:air" or "carpet" in n_
def parado(x, y, z):
    return not pasa((x, y - 1, z)) and pasa((x, y, z)) and pasa((x, y + 1, z))
inicio = (0, 65, 0)                                           # llegada al dormitorio
assert parado(*inicio)
vistos3, cola = {inicio}, deque([inicio])
while cola:
    x, y, z = cola.popleft()
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for dy in (0, 1, -1):
            n_ = (x + dx, y + dy, z + dz)
            if n_ in vistos3 or not (-33 <= n_[0] <= 33 and 64 < n_[1] < 125 and -55 <= n_[2] <= 69):
                continue
            if dy == 1 and not pasa((x, y + 2, z)):
                continue                                      # sin lugar para la cabeza al subir
            if parado(*n_):
                vistos3.add(n_)
                cola.append(n_)
frente_puertas = {1: (1, 9, 6), 2: (14, 17, 1), 3: (19, 25, 14), 4: (6, 33, 19), 5: (1, 41, 6)}
for numero, (lx, ly, lz) in frente_puertas.items():
    p_ = (lx - 10, ly + 64, lz - 54)
    assert p_ in vistos3, ("no se llega a la puerta", numero, p_)
pared = {1: (0, 6), 2: (14, 0), 3: (20, 14), 4: (6, 20), 5: (0, 6)}
for numero, (wx, wz) in pared.items():
    ly = frente_puertas[numero][1]
    assert mundo.get((wx - 10, ly + 64 + 1, wz - 54)) == "minecraft:iron_block", ("puerta", numero)
# --- día de juego: el comandante y los bots suben a la puerta 1 y entran al portal; los sargentos en lugares pisables
juego_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/Juego.java"), encoding="utf-8").read()
bot_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/JugadorBot.java"), encoding="utf-8").read()
def vecs(texto, nombre_c):
    bloque = texto[texto.index(nombre_c + " = {"):]
    bloque = bloque[:bloque.index("};")]
    return [(math.floor(float(a)), int(float(b)), math.floor(float(c)))
            for a, b, c in re.findall(r"new Vec3\((-?[\d.]+), (-?[\d.]+), (-?[\d.]+)\)", bloque)]
def celda_de(texto, nombre_c):
    return tuple(int(v) for v in re.search(nombre_c + r" = new BlockPos\((-?\d+), (-?\d+), (-?\d+)\)", texto).groups())
camino_cmd = vecs(juego_txt, "CAMINO_COMANDANTE")
puestos_cam = vecs(juego_txt, "PUESTOS_CAMINO")
camino_bot = vecs(bot_txt, "CAMINO")
portal_j, portal_b = celda_de(juego_txt, "PORTAL_1"), celda_de(bot_txt, "PORTAL")
assert portal_j == portal_b == (-10, 73, -48), (portal_j, portal_b)          # la celda del medio de la puerta 1
assert len(puestos_cam) == 5 and camino_bot[-1] == camino_cmd[-1], (camino_bot, camino_cmd)
for p_ in camino_cmd + puestos_cam + camino_bot:
    assert p_ in vistos3, ("lugar del camino que no se pisa", p_)
for dx_ in (-3, 3):                                             # los bots se abren hasta 3 bloques a los costados
    for p_ in camino_bot[:2]:
        assert (p_[0] + dx_, p_[1], p_[2]) in vistos3, ("camino ancho", p_, dx_)
ult = camino_cmd[-1]
assert ult[1] == portal_j[1] and portal_j[0] == ult[0] - 1 and abs(portal_j[2] - ult[2]) <= 1   # el portal, al lado
def pasos(a, b):
    vistos_, cola_ = {a: 0}, deque([a])
    while cola_:
        p_ = cola_.popleft()
        if p_ == b:
            return vistos_[p_]
        x, y, z = p_
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            for dy in (0, 1, -1):
                n_ = (x + dx, y + dy, z + dz)
                if n_ in vistos_ or n_ not in vistos3 or (dy == 1 and not pasa((x, y + 2, z))):
                    continue
                vistos_[n_] = vistos_[p_] + 1
                cola_.append(n_)
    return None
tramos = [pasos(a, b) for a, b in zip([(0, 65, -21)] + camino_cmd[:-1], camino_cmd)]
assert all(t_ is not None and t_ <= 28 for t_ in tramos), ("tramos del comandante", tramos)
tramos_b = [pasos(a, b) for a, b in zip(camino_bot[:-1], camino_bot[1:])]
assert all(t_ is not None and t_ <= 40 for t_ in tramos_b), ("tramos de los bots", tramos_b)
sala_c = {n: int(re.search(rf"{n} = (-?\d+);", juego_txt).group(1)) for n in ("SALA_CX0", "SALA_CX1", "SALA_CZ0", "SALA_CZ1")}
for (ox_, oz_, sx_, sz_) in ((-32, -33, nbt["size"][0], nbt["size"][2]), (-10, -54, torre["size"][0], torre["size"][2])):
    assert sala_c["SALA_CX0"] <= ox_ >> 4 and (ox_ + sx_ - 1) >> 4 <= sala_c["SALA_CX1"], ("chunks x de la sala", ox_, sx_)
    assert sala_c["SALA_CZ0"] <= oz_ >> 4 and (oz_ + sz_ - 1) >> 4 <= sala_c["SALA_CZ1"], ("chunks z de la sala", oz_, sz_)
camino_cmd2 = vecs(juego_txt, "CAMINO_COMANDANTE_2")
camino_bot2 = vecs(bot_txt, "CAMINO_2")
portal_j2, portal_b2 = celda_de(juego_txt, "PORTAL_2"), celda_de(bot_txt, "PORTAL_2")
assert portal_j2 == portal_b2 == (4, 81, -54), (portal_j2, portal_b2)       # la celda del medio de la puerta 2
assert camino_bot2[:4] == camino_bot and camino_bot2[-1] == camino_cmd2[-1] and camino_cmd2[:2] == camino_cmd
for p_ in camino_cmd2 + camino_bot2:
    assert p_ in vistos3, ("lugar del camino a la puerta 2 que no se pisa", p_)
ult2 = camino_cmd2[-1]
assert ult2[1] == portal_j2[1] and ult2[0] == portal_j2[0] and portal_j2[2] == ult2[2] - 2      # el portal, adelante
tramos2 = [pasos(a, b) for a, b in zip(camino_cmd2[:-1], camino_cmd2[1:])]
tramos_b2 = [pasos(a, b) for a, b in zip(camino_bot2[:-1], camino_bot2[1:])]
assert all(t_ is not None and t_ <= 40 for t_ in tramos2 + tramos_b2), ("tramos a la puerta 2", tramos2, tramos_b2)
assert (ult2[0], ult2[1], ult2[2] - 1) in vistos3                                    # el paso de adelante del portal
print("día de juego ok: comandante en tramos de", tramos, "y bots en tramos de", tramos_b, "pasos hasta el portal;",
      "a la puerta 2:", tramos2, "y", tramos_b2)
# --- reparto de comida: vigilantes detrás del mostrador; los bots llegan por la puerta del comedor y hacen la fila
comida_txt = open(os.path.join(raiz, "src/main/java/com/juegosdelpatio/Comida.java"), encoding="utf-8").read()
puestos_com = vecs(comida_txt, "PUESTOS")
ruta_com = vecs(bot_txt, "RUTA_COMEDOR")
fila_z = float(re.search(r"FILA_Z = (-?[\d.]+);", bot_txt).group(1))
fila_x0 = float(re.search(r"FILA_X0 = (-?[\d.]+);", bot_txt).group(1))
alcance_c = float(re.search(r"ALCANCE = ([\d.]+);", comida_txt).group(1))
fila_c = [(math.floor(fila_x0 + i_), 65, math.floor(fila_z)) for i_ in range(21)]
assert len(puestos_com) == 3 and len(ruta_com) == 2, (puestos_com, ruta_com)
for p_ in puestos_com + ruta_com + fila_c:
    assert p_ in vistos3 and parado(*p_), ("lugar del comedor que no se pisa", p_)
for x_, _, z_ in fila_c:                                        # desde cualquier lugar de la fila alcanza un vigilante
    d2_ = min((x_ + 0.5 - (px_ + 0.5)) ** 2 + (z_ + 0.5 - (pz_ + 0.5)) ** 2 for px_, _, pz_ in puestos_com)
    assert d2_ <= alcance_c ** 2, ("la fila queda lejos de los vigilantes", x_, d2_)
tramos_c = [pasos(ruta_com[0], ruta_com[1])] + [pasos(ruta_com[1], f_) for f_ in fila_c]
assert all(t_ is not None and t_ <= 40 for t_ in tramos_c), ("camino al comedor", tramos_c)
assert pasos((0, 65, 30), ruta_com[0]) is not None                # desde la plaza hasta la puerta del comedor
mostrador_ = {mundo.get((x_, 65, math.floor(fila_z) - 1), "air").split(":")[-1] for x_ in range(10, 30)}
assert mostrador_ <= {"smooth_quartz", "water_cauldron", "quartz_block", "quartz_bricks"}, ("mostrador", mostrador_)
print("comedor ok: 3 vigilantes detrás del mostrador; la fila (21 lugares) a", max(tramos_c), "pasos como mucho")
lamparas_numeros = sum(1 for bl in torre["blocks"] if "copper_bulb" in torre["palette"][bl["state"]]["Name"])
print("torre ok: se llega caminando a las 5 puertas;", len(vistos3), "lugares pisables; lámparas", lamparas_numeros)

# --- portales: recursos del bloque, puertas del Java iguales a las de torre.nbt, camas para los bots de noche
bloques_reg = re.findall(r'BLOQUES\.register\("([a-z_]+)"', registro)
assert bloques_reg == ["portal_juego", "silla"], bloques_reg
# la silla: 4 colores x 4 direcciones, cada modelo hijo del modelo base, con texturas que existen en Minecraft
silla_e = json.load(open(os.path.join(base, "blockstates/silla.json")))["variants"]
assert set(silla_e) == {f"color={c},facing={f}" for c in range(4) for f in ("north", "east", "south", "west")}, silla_e
assert all(silla_e[f"color={c},facing={f}"].get("y", 0) == g for c in range(4)
           for f, g in (("north", 0), ("east", 90), ("south", 180), ("west", 270)))
silla_base = json.load(open(os.path.join(base, "models/block/silla.json")))
assert len(silla_base["elements"]) >= 8 and silla_base["textures"]["particle"] == "#marco"
for el_ in silla_base["elements"]:
    assert all(-16 <= v <= 32 for v in el_["from"] + el_["to"]) and all(a <= b for a, b in zip(el_["from"], el_["to"]))
    assert {c["texture"] for c in el_["faces"].values()} <= {"#marco", "#color"}
for c in range(4):
    hijo_ = json.load(open(os.path.join(base, f"models/block/silla_{c}.json")))
    assert hijo_["parent"] == "juegosdelpatio:block/silla" and set(hijo_["textures"]) == {"marco", "color", "particle"}
    assert hijo_["textures"]["color"].endswith("_concrete") and "stripped_dark_oak_log" in hijo_["textures"]["marco"]
estado_json = json.load(open(os.path.join(base, "blockstates/portal_juego.json")))
modelo_ref = estado_json["multipart"][0]["apply"]["model"]
assert modelo_ref == "juegosdelpatio:block/portal_juego", modelo_ref
modelo_b = json.load(open(os.path.join(base, "models/block/portal_juego.json")))
assert modelo_b["parent"] == "minecraft:block/cube_all" and modelo_b["render_type"] == "minecraft:translucent"
tex = Image.open(os.path.join(base, "textures/block/portal_juego.png"))
assert tex.mode == "RGBA" and tex.size[0] == 16 and tex.size[1] % 16 == 0 and tex.size[1] > 16, tex.size
anim = json.load(open(os.path.join(base, "textures/block/portal_juego.png.mcmeta")))
assert anim["animation"]["frametime"] >= 1
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for b_ in bloques_reg:
        assert f"block.juegosdelpatio.{b_}" in lang, (f, b_)
port = java["Portales.java"]
tabla = [tuple(int(v) for v in t) for t in re.findall(r"\{(\d), (\d+), (\d+)\}", port.split("PUERTAS =")[1].split(";")[0])]
assert tabla == [(0, 6, 8), (1, 14, 16), (2, 14, 24), (3, 6, 32), (0, 6, 40)], tabla
torre_b = {tuple(bl["pos"]): torre["palette"][bl["state"]]["Name"] for bl in torre["blocks"]}
for pared_, centro_, nivel_ in tabla:
    for col in (-1, 0, 1):
        x_, z_ = {0: (0, centro_ - col), 1: (centro_ + col, 0), 2: (20, centro_ + col), 3: (centro_ - col, 20)}[pared_]
        for fila in range(4):
            esperado = "minecraft:polished_blackstone" if fila in (0, 3) else "minecraft:iron_block"
            assert torre_b.get((x_, nivel_ + 1 + fila, z_)) == esperado, ("puerta", pared_, centro_, nivel_, col, fila)
camas_abajo = sum(1 for bl in nbt["blocks"] if bl["pos"][1] == 1 and "white_bed" in pal[bl["state"]]["Name"]
                  and pal[bl["state"]].get("Properties", {}).get("part") == "head")
assert camas_abajo >= 150, camas_abajo
noche_ = java["Noche.java"]
assert "DURACION = 2 * 60 * 20" in noche_ and "ESPERA_TRAS_CEREMONIA = 60 * 20" in noche_
print("portales ok: 5 puertas con portal; camas de abajo para los bots:", camas_abajo)

# --- arena de Luz verde, luz roja: tamaño, bloques válidos y que coincida con Juego.java
juego_j = java["Juego.java"]
arena = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/luz_verde.nbt")).read())
assert arena["size"] == [102, 38, 308], arena["size"]
assert re.search(r"ORIGEN_ARENA = new BlockPos\(949, 99, -1\)", juego_j)
VALIDOS["light"] = {"level": {str(i) for i in range(16)}, "waterlogged": B}
for extra_b in ("barrier", "gold_block", "iron_block", "gray_concrete", "light_gray_concrete", "black_concrete", "red_concrete"):
    VALIDOS[extra_b] = {}
for p_ in arena["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    props = p_.get("Properties", {})
    if ns == "juegosdelpatio":
        assert nombre_b == "portal_juego" and props == {"juego": "1", "regreso": "true"}, p_
        continue
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
am = {}
for bl in arena["blocks"]:
    x, y, z = bl["pos"]
    am[(x + 949, y + 99, z - 1)] = arena["palette"][bl["state"]]["Name"].split(":")[1]
def entero(nombre_c):
    return int(re.search(rf"{nombre_c} = (-?\d+);", juego_j).group(1))
# la cabeza del Vigía en la plantilla es la de Vigia.java, girada de espaldas (como Vigia.DE_ESPALDAS)
vigia_j = java["Vigia.java"]
tabla_v = vigia_j[vigia_j.index("CABEZA = {"):]
filas_v = re.findall(r'"([IGLKR]{8})"', tabla_v[:tabla_v.index("};")])
assert len(filas_v) == 64, len(filas_v)
letra_v = {"I": "iron_block", "G": "gray_concrete", "L": "light_gray_concrete", "K": "black_concrete", "R": "red_concrete"}
vx0, vy0_, vz0 = (int(re.search(rf"static final int {n} = (-?\d+);", vigia_j).group(1)) for n in ("X0", "Y0", "Z0"))
for y in range(8):
    for z in range(8):
        for x in range(8):
            assert am.get((vx0 + 7 - x, vy0_ + y, vz0 + 7 - z)) == letra_v[filas_v[8 * y + z][x]], ("cabeza", x, y, z)
assert "R" in "".join(filas_v[8 * y] for y in range(8)), "el visor rojo tiene que estar en la cara"
assert am.get((999, 121, 300)) == "gold_block" and am.get((996, 110, 300)) == "iron_block"   # corona en la espalda
assert all(am.get((x, 102, 301)) == "polished_blackstone" for x in range(991, 1009))         # pedestal
assert am.get((vx0 + 3, vy0_ - 1, vz0 + 3)) == "gray_concrete"                               # cuello: hombros del torso
# las luces de las paredes (como Juego.ponerLuces): apagadas en la plantilla
lados_x = [int(v) for v in re.search(r"LADOS_X = \{([^}]*)\}", juego_j).group(1).split(",")]
lados_z = [int(v) for v in re.search(r"LADOS_Z = \{([^}]*)\}", juego_j).group(1).split(",")]
ly0, ly1 = entero("LUZ_Y0"), entero("LUZ_Y1")
for x in lados_x:
    for zc in lados_z:
        for z in range(zc - 1, zc + 2):
            for y in range(ly0, ly1 + 1):
                assert am.get((x, y, z)) == "gray_concrete", ("luz de la pared", x, y, z)
        assert am.get((x, ly0 - 1, zc)) == am.get((x, ly1 + 1, zc)) == "polished_blackstone", ("marco", x, zc)
for x in range(950, 1050):
    for y in range(100, 104):
        assert am.get((x, y, 10)) == "barrier", ("barrera de salida", x, y)
def libre_a(p_):
    return am.get(p_) in (None, "light")                       # las luces invisibles no chocan
for x in range(952, 1037):                                      # lugares de salida (Juego.lugarDeSalida)
    for z in range(1, 9):
        assert (x, 99, z) in am and libre_a((x, 100, z)) and libre_a((x, 101, z)), ("salida", x, z)
assert am.get((1042, 102, 4)) == "polished_blackstone" and libre_a((1042, 103, 4)) and libre_a((1042, 104, 4))
for x in range(999, 1002):
    for y in range(100, 104):
        assert am.get((x, y, -1)) == "portal_juego", ("portal de vuelta", x, y)
meta = float(re.search(r"META_Z = ([\d.]+);", juego_j).group(1))
assert all(am.get((x, 99, int(meta))) in ("black_concrete", "white_concrete") for x in range(950, 1050))
for x0 in (952, 1047):                                          # lugares de los sargentos
    for z0 in (75, 175):
        assert (x0, 99, z0) in am and libre_a((x0, 100, z0)) and libre_a((x0, 101, z0))
partes_r = re.findall(r'"(reglas_\d|sillas_\d)"', juego_j)
assert {"sillas_1", "sillas_7", "reglas_7"} <= set(partes_r), partes_r
# la tecla para aguantar en la silla (la Z) y el paquete que avisa al servidor
cli_ = java["Cliente.java"]
teclas_ = re.findall(r'new KeyMapping\("([a-z_.]+)", InputConstants\.Type\.KEYSYM,\s*GLFW\.GLFW_KEY_Z, "([a-z_.]+)"\)', cli_)
assert teclas_ == [("key.juegosdelpatio.aguantar", "key.categories.juegosdelpatio")], teclas_
assert "evento.register(AGUANTAR)" in cli_ and "Cliente.AGUANTAR.consumeClick()" in java["ClienteTeclas.java"]
assert "busDelMod.addListener(Resistir::registrar)" in java["JuegosDelPatio.java"]
assert "registro.playToServer(TIPO, CODEC, Resistir::recibir)" in java["Resistir.java"]
# las luces que parpadean cuando para la música (servidor -> cliente, capa de pantalla, clics al mismo ritmo)
par_ = java["Parpadeo.java"]
patron_ = [int(n_) for n_ in re.search(r"PATRON = \{([\d, ]+)\};", par_).group(1).split(",")]
assert len(patron_) % 2 == 0 and sum(patron_) == 80, patron_          # termina con la luz prendida; 4 segundos
for i_ in range(0, len(patron_), 2):
    assert patron_[i_] + patron_[i_ + 1] >= 7, ("más de 3 destellos por segundo", patron_[i_:i_ + 2])
assert "DURACION = Arrays.stream(PATRON).sum();" in par_ and "registro.playToClient(TIPO, CODEC, Parpadeo::recibir)" in par_
assert "busDelMod.addListener(Parpadeo::registrar)" in java["JuegosDelPatio.java"]
assert 'evento.registerAbove(VanillaGuiLayers.CAMERA_OVERLAYS, Complejo.id("luces"), ClienteLuces::dibujar)' in cli_
assert "ClienteLuces.tick(minecraft);" in java["ClienteTeclas.java"]
assert "options.hideLightningFlash().get()" in java["ClienteLuces.java"]          # la opción de accesibilidad
assert "@EventBusSubscriber" not in java["ClienteLuces.java"] and "Dist.CLIENT" in cli_
sil_ = java["Sillas.java"]
para_ = sil_.split("private static void pararMusica(")[1].split("\n    }\n")[0]
assert "empezarParpadeo(complejo);" in para_ and "REACCION.put(id, azar.nextInt(REACCION_MAXIMA + 1));" in para_
assert "elegirRivales(complejo);" in para_
# los bots de las sillas, difíciles: al instante, un poco más rápidos que un jugador corriendo, y van por su silla
assert int(re.search(r"REACCION_MAXIMA = (\d+);", sil_).group(1)) <= 1
corrida_ = float(re.search(r"CORRIDA_BOT = ([\d.]+);", sil_).group(1))
bot_bt = 0.98 * (0.3 * 1.3 * corrida_) ** 2 / 0.454                         # bloques por tick (fórmula de los mobs)
jugador_bt = 0.98 * 0.13 / 0.454                                             # un jugador corriendo
assert jugador_bt < bot_bt < jugador_bt * 1.12, (bot_bt * 20, jugador_bt * 20)
assert int(re.search(r"RIVALES_POR_JUGADOR = (\d+);", sil_).group(1)) >= 2
assert float(re.search(r"PREFIEREN_JUGADORES = ([\d.]+);", sil_).group(1)) <= 0.5
assert "return 0.16F + Math.floorMod(bot.getId() * 37, 20) / 100.0F;" in sil_
bot_sillas_ = java["JugadorBot.java"].split("static class SillasGoal")[1].split("static class EscondidasGoal")[0]
assert "0.9)" not in bot_sillas_ and bot_sillas_.count("Sillas.CORRIDA_BOT") >= 4, "velocidad de los bots en las sillas"
assert "esperaTiron = 3 + bot.getRandom().nextInt(2);" in bot_sillas_ and "rival instanceof Player ||" in bot_sillas_
assert "cortarParpadeo(complejo);" in sil_.split("static void limpiar(")[1].split("\n    }\n")[0]
assert "parpadear(complejo);" in sil_.split("static boolean tick(")[1].split("switch (estado)")[0]
# el cliente: tick t del parpadeo -> ¿apagadas? (igual que Parpadeo.apagadas); el servidor suena en cada cambio
def apagadas_(t_):
    resto_ = t_ % sum(patron_)
    for i_, n_ in enumerate(patron_):
        if resto_ < n_:
            return i_ % 2 == 0
        resto_ -= n_
    return False
cambios_ = sum(1 for t_ in range(1, 80) if apagadas_(t_) != apagadas_(t_ - 1))
assert apagadas_(0) and not apagadas_(79) and cambios_ == len(patron_) - 1, cambios_
# los bots se sientan apenas tienen una silla libre a mano (llegan hasta el frente de la silla, a 0,9 del centro)
alc_bot_ = float(re.search(r"ALCANCE_BOT = ([\d.]+);", sil_).group(1))
frente_ = float(re.search(r"mira\.getStepX\(\) \* ([\d.]+)", sil_).group(1))
assert frente_ + 0.45 * 1.5 < alc_bot_ <= 2.0, (frente_, alc_bot_)           # aunque frene un poco antes, llega
corre_ = java["JugadorBot.java"].split("private void correrALaSilla() {")[1].split("\n        }\n")[0]
assert corre_.strip().startswith("if (Sillas.sentarseAMano(bot)) {"), corre_[:80]
assert "createPath(frente.x, frente.y, frente.z, 0)" in corre_ and "getMoveControl().setWantedPosition(frente.x" in corre_
assert "intentarSentar" not in java["JugadorBot.java"] + sil_
# el calendario: jugar un juego otro día (con un comando) adelanta hasta el día de ese juego; nunca para atrás
jue_ = java["Juego.java"]
assert jue_.count("marcarDia(complejo, juego);") == 2 and "marcarDia(complejo);" not in jue_
assert "dia += juego - enElCiclo + (enElCiclo > juego ? Complejo.CICLO_DIAS : 0);" in jue_
def marcar_(dia_, juego_):
    ciclo_ = dia_ % 6
    return dia_ if ciclo_ == juego_ else dia_ + juego_ - ciclo_ + (6 if ciclo_ > juego_ else 0)
for dia_ in range(0, 30):
    for juego_ in (1, 2):
        nuevo_ = marcar_(dia_, juego_)
        assert dia_ <= nuevo_ < dia_ + 6 and nuevo_ % 6 == juego_, (dia_, juego_, nuevo_)
# al terminar la noche: mañana del día siguiente, nunca antes del día que sigue al último juego
noc_ = java["Noche.java"]
assert "long manana = Math.max(dia + 1, estado.ultimoJuego() + 1);" in noc_ and "setDayTime(manana * 24000L)" in noc_
assert "setDayTime((dia + 1) * 24000L)" not in noc_
def amanece_(dia_, ultimo_):
    return max(dia_ + 1, ultimo_ + 1)
# el caso del jugador: el juego 1 con un comando el día 0 -> se juega el día 1; se duerme -> día 2 -> juego 2
dia_ = marcar_(0, 1)
assert dia_ == 1 and amanece_(dia_, dia_) % 6 == 2
# y si después del juego 1 alguien pone /time set day (el reloj vuelve al día 0): igual amanece el día 2
assert amanece_(0, dia_) == 2
# sin juegos todavía (-1) o con el último juego hace días: el día siguiente, como siempre
assert amanece_(0, -1) == 1 and amanece_(4, 2) == 5
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for clave in teclas_[0]:
        assert clave in lang, (f, clave)
for f in os.listdir(os.path.join(base, "lang")):
    lang = json.load(open(os.path.join(base, "lang", f), encoding="utf-8"))
    for clave in [f"juego.juegosdelpatio.{p_}" for p_ in partes_r] + [
            "ceremonia.juegosdelpatio.llamado_saludo", "ceremonia.juegosdelpatio.llamado_juego",
            "ceremonia.juegosdelpatio.llamado_puerta", "ceremonia.juegosdelpatio.llamado_minuto",
            "ceremonia.juegosdelpatio.resultados_pasaron"] + [f"juego.juegosdelpatio.ordinal_{n_}" for n_ in range(1, 6)]:
        assert clave in lang, (f, clave)
# luz: que no quede ningún rincón del piso a oscuras (la dimensión no tiene cielo que ilumine)
from collections import deque as _dq
luz_ = {}
cola_ = _dq()
EMITE_ = {"light": 15, "sea_lantern": 15, "portal_juego": 12}
for p_, n_ in am.items():
    if n_ in EMITE_:
        luz_[p_] = EMITE_[n_]
        cola_.append(p_)
while cola_:
    p_ = cola_.popleft()
    l_ = luz_[p_]
    if l_ <= 1:
        continue
    for d_ in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        q_ = (p_[0] + d_[0], p_[1] + d_[1], p_[2] + d_[2])
        if not (949 <= q_[0] <= 1050 and 99 <= q_[1] <= 131 and -1 <= q_[2] <= 306):
            continue
        if am.get(q_) not in (None, "light", "barrier", "portal_juego"):
            continue
        if luz_.get(q_, 0) < l_ - 1:
            luz_[q_] = l_ - 1
            cola_.append(q_)
piso_ = [luz_.get((x, 100, z), 0) for x in range(950, 1050) for z in range(0, 306) if libre_a((x, 100, z))]
assert min(piso_) >= 7, ("piso oscuro", min(piso_))
print("arena ok:", len(arena["blocks"]), "bloques; el Vigía (cabeza igual a Vigia.java), luces, barrera, podio, portal y meta;",
      "luz en el piso", min(piso_), "a", max(piso_))

# --- arena de Las sillas musicales: tamaño, bloques válidos, la ronda enorme, sillas, luz y que coincida con Sillas.java
sillas_j = java["Sillas.java"]
salon = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/sillas.nbt")).read())
assert salon["size"] == [81, 18, 97], salon["size"]
assert re.search(r"ORIGEN = new BlockPos\(1960, 99, -17\)", sillas_j)
def num_s(nombre_c):
    return float(re.search(rf"{nombre_c} = (-?[\d.]+);", sillas_j).group(1))
lim_ = {n_: int(num_s(n_)) for n_ in ("X0", "X1", "Z0", "Z1")}
assert lim_ == {"X0": 1960, "X1": 2040, "Z0": -17, "Z1": 79}, lim_
ccx, ccz = int(num_s("CENTRO_X")), int(num_s("CENTRO_Z"))
assert (ccx, ccz) == (2000, 41), (ccx, ccz)
radios_s = [float(v) for v in re.search(r"RADIOS_SILLAS = \{([^}]*)\}", sillas_j).group(1).split(",")]
lleno_s = num_s("LLENO_MAXIMO")
pista_r, pista_min, pista_max = num_s("RADIO_PISTA"), num_s("PISTA_MIN"), num_s("PISTA_MAX")
faltan_s = [int(v) for v in re.search(r"FALTAN = \{([^}]*)\}", sillas_j).group(1).split(",")]
assert faltan_s == [3, 5, 7] and sum(faltan_s) == 15, faltan_s
for extra_b in ("pink_concrete", "magenta_concrete", "gold_block", "gray_concrete"):
    VALIDOS[extra_b] = {}
VALIDOS["quartz_pillar"] = {"axis": {"x", "y", "z"}}
for p_ in salon["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    props = p_.get("Properties", {})
    if ns == "juegosdelpatio":
        assert nombre_b == "portal_juego" and props == {"juego": "2", "regreso": "true"}, p_
        continue
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
sm = {}
for bl in salon["blocks"]:
    x, y, z = bl["pos"]
    sm[(x + 1960, y + 99, z - 17)] = salon["palette"][bl["state"]]["Name"].split(":")[1]
def libre_s(p_):
    return sm.get(p_) in (None, "light")
def parado_s(x, y, z):
    return sm.get((x, y - 1, z)) not in (None, "light", "barrier") and libre_s((x, y, z)) and libre_s((x, y + 1, z))
# todo lo que rodea al gramófono, hasta la pista, es piso libre (para correr a las sillas)
for dx in range(-36, 37):
    for dz in range(-36, 37):
        r_ = math.hypot(dx, dz)
        if 6.0 <= r_ <= pista_max:
            assert parado_s(ccx + dx, 100, ccz + dz), ("algo en el medio de la ronda", ccx + dx, ccz + dz)
# la pista, entera y blanca, a la distancia a la que caminan (jugadores y bots, +-0,3)
for a_ in range(0, 360, 2):
    for rr_ in (pista_r - 0.3, pista_r, pista_r + 0.3):
        px_ = math.floor(ccx + 0.5 + rr_ * math.cos(math.radians(a_)))
        pz_ = math.floor(ccz + 0.5 + rr_ * math.sin(math.radians(a_)))
        assert sm.get((px_, 99, pz_)) == "white_concrete" and parado_s(px_, 100, pz_), ("pista", px_, pz_)
assert pista_min - (radios_s[-1] + 0.75) >= 11, "la pista tiene que quedar lejos de las sillas"
# las sillas (como Sillas.anillos y Sillas.ponerSillas): en el vinilo, y a todas se llega desde la pista
anillos_s = []
for radio_ in radios_s:
    celdas_ = [(ccx + dx, ccz + dz) for dx in range(-int(math.ceil(radio_)) - 1, int(math.ceil(radio_)) + 2)
               for dz in range(-int(math.ceil(radio_)) - 1, int(math.ceil(radio_)) + 2)
               if abs(math.sqrt(dx * dx + dz * dz) - radio_) < 0.5]
    celdas_.sort(key=lambda c_: math.atan2(c_[1] - ccz, c_[0] - ccx))
    sueltas_ = []                                               # sin dos pegadas de costado (como Sillas.anillos)
    for c_ in celdas_:
        if not sueltas_ or abs(c_[0] - sueltas_[-1][0]) + abs(c_[1] - sueltas_[-1][1]) != 1:
            sueltas_.append(c_)
    if len(sueltas_) > 1 and abs(sueltas_[0][0] - sueltas_[-1][0]) + abs(sueltas_[0][1] - sueltas_[-1][1]) == 1:
        sueltas_.pop()
    assert not any(abs(a_[0] - b_[0]) + abs(a_[1] - b_[1]) == 1 for i_, a_ in enumerate(sueltas_) for b_ in sueltas_[i_ + 1:])
    anillos_s.append(sueltas_)
def poner_s(cantidad, desfase):
    total_ = sum(len(a_) for a_ in anillos_s)
    cantidad = min(cantidad, total_)
    usados, lugar = 0, 0
    while usados < len(anillos_s) and lugar < cantidad:
        lugar += int(len(anillos_s[usados]) * lleno_s)
        usados += 1
    apretado = lugar < cantidad
    cap = [len(anillos_s[i_]) if apretado else int(len(anillos_s[i_]) * lleno_s) for i_ in range(usados)]
    puestas, sillas_ = 0, []
    for i_ in range(usados):
        celdas_ = anillos_s[i_]
        aca = cantidad - puestas if i_ == usados - 1 else int(math.floor(cantidad * cap[i_] / sum(cap) + 0.5))
        aca = max(0, min(aca, len(celdas_)))
        for j_ in range(aca):
            sillas_.append(celdas_[int((j_ + desfase) * len(celdas_) / aca) % len(celdas_)])
        puestas += aca
    return sillas_
capacidad_s = sum(int(len(a_) * lleno_s) for a_ in anillos_s)
assert capacidad_s >= 160, ("no entran las sillas para 163 personas con paso", capacidad_s)
assert sum(int(len(a_) * lleno_s) for a_ in anillos_s[:4]) >= 83, "con 86 jugadores, las sillas en los 4 anillos de adentro"
for cantidad in sorted(set(list(range(1, capacidad_s + 1, 4)) + [capacidad_s, 83, 78, 71])):
    for desfase in (0.0, 0.37, 0.81):
        sillas_ = poner_s(cantidad, desfase)
        assert len(sillas_) == cantidad == len(set(sillas_)), (cantidad, len(sillas_))
        ocupado = set(sillas_)
        for (sx_, sz_) in sillas_:
            assert sm.get((sx_, 99, sz_)) in ("black_concrete", "gray_concrete", "red_concrete"), ("silla fuera del vinilo", sx_, sz_)
            assert libre_s((sx_, 100, sz_)) and libre_s((sx_, 101, sz_)), ("silla con algo encima", sx_, sz_)
        # desde la pista se llega caminando al frente de cada silla (sin pasar por arriba de ninguna)
        inicio_ = (math.floor(ccx + 0.5 + pista_r), ccz)
        vistos_s, cola_s = {inicio_}, deque([inicio_])
        while cola_s:
            cx_, cz_ = cola_s.popleft()
            for ddx, ddz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n_ = (cx_ + ddx, cz_ + ddz)
                if n_ in vistos_s or n_ in ocupado or math.hypot(n_[0] - ccx, n_[1] - ccz) > pista_max:
                    continue
                if not parado_s(n_[0], 100, n_[1]):
                    continue
                vistos_s.add(n_)
                cola_s.append(n_)
        for (sx_, sz_) in sillas_:
            ddx, ddz = sx_ + 0.5 - ccx - 0.5, sz_ + 0.5 - ccz - 0.5
            if abs(ddx) > abs(ddz):                                 # como Direction.getNearest (empate: norte/sur)
                frente_ = (sx_ + (1 if ddx > 0 else -1), sz_)
            else:
                frente_ = (sx_, sz_ + (1 if ddz > 0 else -1))
            assert frente_ in vistos_s, ("no se llega a una silla", cantidad, (sx_, sz_))
# el gramófono, en el centro: la tarima, el mueble y la bocina dorada (con la boca libre arriba)
assert sm.get((ccx, 100, ccz)) == "dark_oak_planks" and sm.get((ccx, 104, ccz)) == "black_concrete"
assert re.search(r"BOCINA = new Vec3\(2000\.5, 113\.5, 43\.5\)", sillas_j)
assert sm.get((2000, 113, 43)) is None and sum(1 for dx in range(-6, 7) for dz in range(-6, 7) if sm.get((2000 + dx, 113, 43 + dz)) == "gold_block") > 20
# el resto del salón
assert re.search(r"PODIO = new Vec3\(2000\.5, 102\.0, -13\.5\)", sillas_j)
assert sm.get((2000, 101, -14)) == "smooth_quartz" and libre_s((2000, 102, -14)) and libre_s((2000, 103, -14))
for t_ in re.findall(r"new Vec3\(([\d.]+), 100\.0, ([\d.]+)\)", sillas_j.split("PUESTOS_SARGENTOS = {")[1].split("};")[0]):
    gx_, gz_ = math.floor(float(t_[0])), math.floor(float(t_[1]))
    assert parado_s(gx_, 100, gz_) and math.hypot(gx_ - ccx, gz_ - ccz) > pista_max + 2, ("sargento", t_)
for x in range(1985, 2016):                                     # Sillas.lugarDeSalida: la entrada
    for z in range(-11, 2):
        assert parado_s(x, 100, z), ("entrada", x, z)
for x in range(1978, 1983):                                     # el portal de vuelta, con barrera detrás
    for y in range(100, 105):
        assert sm.get((x, y, -16)) == "portal_juego" and sm.get((x, y, -17)) == "barrier", ("portal", x, y)
# luz: ningún lugar del piso a oscuras
luz_s, cola_s = {}, _dq()
EMITE_S = {"light": 15, "sea_lantern": 15, "lantern": 15, "portal_juego": 12}
for p_, n_ in sm.items():
    if n_ in EMITE_S:
        luz_s[p_] = EMITE_S[n_]
        cola_s.append(p_)
while cola_s:
    p_ = cola_s.popleft()
    l_ = luz_s[p_]
    if l_ <= 1:
        continue
    for d_ in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        q_ = (p_[0] + d_[0], p_[1] + d_[1], p_[2] + d_[2])
        if not (1961 <= q_[0] <= 2039 and 100 <= q_[1] <= 115 and -15 <= q_[2] <= 78):
            continue
        if sm.get(q_) not in (None, "light", "chain", "lantern", "barrier", "portal_juego", "lightning_rod"):
            continue
        if luz_s.get(q_, 0) < l_ - 1:
            luz_s[q_] = l_ - 1
            cola_s.append(q_)
piso_s = [luz_s.get((x, 100, z), 0) for x in range(1961, 2040) for z in range(-15, 79) if parado_s(x, 100, z)]
assert min(piso_s) >= 7, ("piso oscuro en el salón", min(piso_s))
print("sillas ok:", len(salon["blocks"]), "bloques; ronda enorme con pista a", pista_r, "y sillas en", len(anillos_s),
      "anillos (", [len(a_) for a_ in anillos_s], "lugares; con paso:", capacidad_s, "); se llega a todas; luz en el piso",
      min(piso_s), "a", max(piso_s))
# --- la puerta 3 de la torre: el comandante y los bots suben un tramo más (al este) y entran al portal
camino_cmd3 = vecs(juego_txt, "CAMINO_COMANDANTE_3")
camino_bot3 = vecs(bot_txt, "CAMINO_3")
portal_j3, portal_b3 = celda_de(juego_txt, "PORTAL_3"), celda_de(bot_txt, "PORTAL_3")
assert portal_j3 == portal_b3 == (10, 89, -40), (portal_j3, portal_b3)       # la celda del medio de la puerta 3
assert camino_bot3[:len(camino_bot2)] == camino_bot2 and camino_cmd3[:len(camino_cmd2)] == camino_cmd2
assert camino_bot3[-1] == camino_cmd3[-1]
for p_ in camino_cmd3 + camino_bot3:
    assert p_ in vistos3, ("lugar del camino a la puerta 3 que no se pisa", p_)
frente3 = (portal_j3[0] - 1, portal_j3[1], portal_j3[2])                    # el paso de adelante del portal
assert frente3 in vistos3 and mundo.get((portal_j3[0], portal_j3[1] + 1, portal_j3[2])) == "minecraft:iron_block"
tramos3 = [pasos(a, b) for a, b in zip(camino_cmd3[:-1], camino_cmd3[1:])] + [pasos(camino_cmd3[-1], frente3)]
assert all(t_ is not None and t_ <= 40 for t_ in tramos3), ("tramos a la puerta 3", tramos3)
assert "paso = bot.getY() > 85.0 && juego == 3 ? 7" in bot_txt and len(camino_bot3) == 8
print("puerta 3 ok: tramos", tramos3)

# --- arena de Las escondidas: la escuela (tamaño, bloques, que coincida con Escondidas.java y se llegue a todo)
esc_j = java["Escondidas.java"]
escuela = leer_nbt(gzip.open(os.path.join(raiz, "src/main/resources/data/juegosdelpatio/structure/escuela.nbt")).read())
assert escuela["size"] == [150, 9, 132], escuela["size"]
assert re.search(r"ORIGEN = new BlockPos\(2925, 98, -60\)", esc_j)
def num_e(nombre_c):
    return float(re.search(rf"{nombre_c} = (-?[\d.]+);", esc_j).group(1))
assert {n_: int(num_e(n_)) for n_ in ("X0", "X1", "Z0", "Z1")} == {"X0": 2925, "X1": 3074, "Z0": -60, "Z1": 71}
for extra_b in ("bricks", "birch_planks", "oak_planks", "bookshelf", "sponge", "wet_sponge", "lime_stained_glass",
                "glass", "red_terracotta", "red_wool", "white_wool", "blue_wool", "orange_concrete", "gray_concrete",
                "yellow_concrete", "smooth_stone"):
    VALIDOS[extra_b] = {}
ESC4 = {"facing": H4, "half": {"top", "bottom"}, "shape": {"straight"}, "waterlogged": B}
VALIDOS.update({
    "spruce_stairs": ESC4, "dark_oak_stairs": ESC4,
    "redstone_lamp": {"lit": B}, "soul_lantern": {"hanging": B, "waterlogged": B},
    "glass_pane": {k: B for k in ("north", "south", "east", "west", "waterlogged")},
    "oak_fence": {k: B for k in ("north", "south", "east", "west", "waterlogged")},
    "hay_block": {"axis": {"x", "y", "z"}}, "oak_log": {"axis": {"x", "y", "z"}},
    "oak_leaves": {"distance": {str(i) for i in range(1, 8)}, "persistent": {"true"}, "waterlogged": B},
})
for p_ in escuela["palette"]:
    ns, nombre_b = p_["Name"].split(":")
    props = p_.get("Properties", {})
    if ns == "juegosdelpatio":
        assert nombre_b == "portal_juego" and props == {"juego": "3", "regreso": "true"}, p_
        continue
    assert ns == "minecraft" and nombre_b in VALIDOS, p_
    assert set(props) == set(VALIDOS[nombre_b]), (nombre_b, props)
    for k, v in props.items():
        assert v in VALIDOS[nombre_b][k], (nombre_b, k, v)
em = {}
for bl in escuela["blocks"]:
    x, y, z = bl["pos"]
    p_ = escuela["palette"][bl["state"]]
    em[(x + 2925, y + 98, z - 60)] = p_["Name"].split(":")[1]
def pasa_e(p_):
    return em.get(p_) in (None, "light")
def apoyo_e(p_):
    return em.get(p_) not in (None, "light") and "fence" not in em.get(p_)
def parado_e(x, y, z):
    return apoyo_e((x, y - 1, z)) and pasa_e((x, y, z)) and pasa_e((x, y + 1, z))
def altura_e(x, z):
    for y in range(100, 104):
        if parado_e(x, y, z):
            return y
    return None
def bfs_e(desde, sin=()):
    """Se camina (subiendo o bajando de a 1) sin pasar por las celdas de 'sin' (por ejemplo, rejas sacadas)."""
    quitadas = {c_: em.pop(c_) for c_ in sin if c_ in em}
    try:
        vistos_, cola_ = {desde}, deque([desde])
        while cola_:
            x, y, z = cola_.popleft()
            for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                for dy in (0, 1, -1):
                    n_ = (x + dx, y + dy, z + dz)
                    if n_ in vistos_ or not (2925 <= n_[0] <= 3074 and -60 <= n_[2] <= 71) or not parado_e(*n_):
                        continue
                    if dy == 1 and not pasa_e((x, y + 2, z)):
                        continue
                    vistos_.add(n_)
                    cola_.append(n_)
        return vistos_
    finally:
        em.update(quitadas)
podio_e = tuple(float(v) for v in re.search(r"PODIO = new Vec3\(([\d.]+), ([\d.]+), ([\d.]+)\)", esc_j).groups())
assert podio_e == (3000.0, 102.0, 12.0)
for dx in (-1, 0):
    for dz in (-1, 0):
        assert parado_e(int(podio_e[0]) + dx, 102, int(podio_e[2]) + dz), ("podio", dx, dz)
hall_e = (2993, 100, 7)
assert parado_e(*hall_e)
alc_e = bfs_e(hall_e)
escondites_e = [(x, z) for (x, y, z), n_ in em.items() if y == 98 and n_ == "sponge"]
ronda_e = [(x, z) for (x, y, z), n_ in em.items() if y == 98 and n_ == "wet_sponge"]
assert len(escondites_e) >= 120 and len(ronda_e) >= 100, (len(escondites_e), len(ronda_e))
for (x, z) in escondites_e + ronda_e:
    y_ = altura_e(x, z)
    assert y_ is not None and (x, y_, z) in alc_e, ("escondite o ronda al que no se llega", x, z)
assert all(z >= -48 for (x, z) in escondites_e + ronda_e)                    # en la escuela (no en el patio)
# los escondites, más oscuros que los pasillos (luz de bloques como en el juego)
luz_e, cola_e = {}, _dq()
for p_, n_ in em.items():
    if n_ in ("lantern", "portal_juego"):
        luz_e[p_] = 15 if n_ == "lantern" else 12
        cola_e.append(p_)
for bl in escuela["blocks"]:
    p_ = escuela["palette"][bl["state"]]
    if p_["Name"] == "minecraft:light":
        x, y, z = bl["pos"]
        q_ = (x + 2925, y + 98, z - 60)
        luz_e[q_] = int(p_["Properties"]["level"])
        cola_e.append(q_)
    elif p_["Name"] == "minecraft:soul_lantern":
        x, y, z = bl["pos"]
        q_ = (x + 2925, y + 98, z - 60)
        luz_e[q_] = 10
        cola_e.append(q_)
while cola_e:
    p_ = cola_e.popleft()
    l_ = luz_e[p_]
    if l_ <= 1:
        continue
    for d_ in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        q_ = (p_[0] + d_[0], p_[1] + d_[1], p_[2] + d_[2])
        if not (2925 <= q_[0] <= 3074 and 99 <= q_[1] <= 106 and -60 <= q_[2] <= 71):
            continue
        if em.get(q_) not in (None, "light", "lantern", "soul_lantern", "chain", "barrier", "portal_juego", "iron_bars",
                              "glass_pane", "oak_fence"):
            continue
        if luz_e.get(q_, 0) < l_ - 1:
            luz_e[q_] = l_ - 1
            cola_e.append(q_)
luz_esc = [luz_e.get((x, altura_e(x, z) + 1, z), 0) for (x, z) in escondites_e]
luz_hall = [luz_e.get((x, 101, z), 0) for x in range(2988, 3012) for z in range(2, 22) if parado_e(x, 100, z)]
luz_piso = [luz_e.get((x, y_ + 1, z), 0) for (x, y_, z) in alc_e]
luz_media = sum(luz_piso) / len(luz_piso)
assert sum(luz_esc) / len(luz_esc) < 6 and min(luz_hall) >= 7, (sum(luz_esc) / len(luz_esc), min(luz_hall))
# la sala de profesores: cerrada con rejas (no se entra ni se sale); sacándolas, se llega
rejas_p = [tuple(int(v) for v in t_) for t_ in re.findall(r"\{(-?\d+), (-?\d+), (-?\d+), (-?\d+)\}",
                                                         esc_j.split("REJAS_PROFESORES = {")[1].split("};")[0])]
assert rejas_p == [(2991, 1, 2993, 1), (2997, -6, 2997, -4)], rejas_p
celdas_p = [(x, y, z) for (x0, z0, x1, z1) in rejas_p for x in range(x0, x1 + 1) for z in range(z0, z1 + 1)
            for y in range(100, 103)]
assert all(em.get(c_) == "iron_bars" for c_ in celdas_p), "faltan rejas en la sala de profesores"
prof_ = {n_: int(num_e(n_)) for n_ in ("PROF_X0", "PROF_X1", "PROF_Z0", "PROF_Z1")}
sala_p = [(x, 100, z) for x in range(prof_["PROF_X0"], prof_["PROF_X1"] + 1)
          for z in range(prof_["PROF_Z0"], prof_["PROF_Z1"] + 1) if parado_e(x, 100, z)]
assert len(sala_p) >= 45 and not any(c_ in alc_e for c_ in sala_p), len(sala_p)
alc_abierta = bfs_e(hall_e, sin=celdas_p)
assert all(c_ in alc_abierta for c_ in sala_p)
# las seis salidas: rejas de y 100 a 105; el frente se pisa; sacando las rejas se llega al vestíbulo
salidas_e = re.findall(r'new Salida\("([a-z_]+)", (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+), '
                       r'new Vec3\((-?[\d.]+), 100\.0, (-?[\d.]+)\)\)', esc_j)
assert len(salidas_e) == 6, salidas_e
for (nombre_s, *nums) in salidas_e:
    vx0, vz0, vx1, vz1, rx0, rz0, rx1, rz1 = (int(v) for v in nums[:8])
    fx, fz = math.floor(float(nums[8])), math.floor(float(nums[9]))
    barras = [(x, y, z) for x in range(rx0, rx1 + 1) for z in range(rz0, rz1 + 1) for y in range(100, 106)]
    assert all(em.get(c_) == "iron_bars" for c_ in barras), ("rejas de la salida", nombre_s)
    assert (fx, 100, fz) in alc_e, ("frente de la salida", nombre_s)
    vestibulo = [(x, 100, z) for x in range(vx0, vx1 + 1) for z in range(vz0, vz1 + 1)]
    assert all(parado_e(*c_) and c_ not in alc_e for c_ in vestibulo), ("vestíbulo", nombre_s)
    abierta_ = bfs_e(hall_e, sin=barras)
    assert all(c_ in abierta_ for c_ in vestibulo), ("no se llega a la salida abierta", nombre_s)
    assert not any(z_ < -48 for (_, _, z_) in abierta_), ("por la salida se llega al patio", nombre_s)
# el patio: lugar para los que salen, cerrado (no se llega desde la escuela); los sargentos y la llegada, en el hall
pat_ = {n_: int(num_e(n_)) for n_ in ("PATIO_X0", "PATIO_X1", "PATIO_Z0", "PATIO_Z1")}
for x in range(pat_["PATIO_X0"], pat_["PATIO_X1"] + 1):
    for z in range(pat_["PATIO_Z0"], pat_["PATIO_Z1"] + 1):
        assert parado_e(x, 100, z) and (x, 100, z) not in alc_e, ("patio", x, z)
for t_ in re.findall(r"new Vec3\(([\d.]+), 100\.0, ([\d.]+)\)", esc_j.split("PUESTOS_SARGENTOS = {")[1].split("};")[0]):
    assert (math.floor(float(t_[0])), 100, math.floor(float(t_[1]))) in alc_e, ("sargento", t_)
for ang_ in range(0, 360, 10):
    for r_ in (4.0, 6.0, 8.0):
        lx_ = math.floor(podio_e[0] + r_ * math.cos(math.radians(ang_)))
        lz_ = math.floor(podio_e[2] + r_ * math.sin(math.radians(ang_)))
        assert (lx_, 100, lz_) in alc_e, ("lugar de llegada", lx_, lz_)
# las reglas, como dijo el usuario
assert "int buscan = mezcla.size() / 2;" in esc_j                            # mitad y mitad, al azar
assert "Items.NETHERITE_SWORD" in esc_j and "espada.enchant(filo, 5);" in esc_j and "Enchantments.SHARPNESS" in esc_j
assert "esBuscador(atacante) && esEscondido(victima)" in esc_j and '"no_entre_buscadores"' in esc_j
assert re.search(r"TIEMPO_ESCONDERSE = 60 \* 20;", esc_j) and re.search(r"TIEMPO_BUSCAR = 5 \* 60 \* 20;", esc_j)
assert "JUEGOS_HECHOS = 3;" in juego_txt and "Escondidas.empezar(complejo, participantes(complejo));" in juego_txt
assert "addListener(Escondidas::alMorir)" in java["JuegosDelPatio.java"]
com_ = java["Comida.java"]
assert "menu = juego == 2 ? 2 : 1;" in com_ and "List.of(new ItemStack(Items.CARROT), new ItemStack(Items.POTATO))" in com_
assert "Comida.empezar(complejo, juego);" in java["Ceremonia.java"]
assert "porComer.add(comida);" in bot_txt                                     # el bot se come las dos cosas
# los bots de las escondidas, más listos: ven de muy lejos, avisan, revisan; los escondidos salen disparados
bot_esc_ = java["JugadorBot.java"].split("static class EscondidasGoal")[1].split("static class IrAComerGoal")[0]
vista_ = [float(v) for v in re.search(r"VISTA = \{([\d., ]+)\};", esc_j).group(1).split(",")]
assert vista_ == sorted(vista_) and vista_[-1] >= 48 and vista_[0] >= 12, vista_
assert num_e("CAMPO_VISUAL") <= 0.0 and 0.5 <= num_e("AGACHADO") < 1.0 < num_e("CORRIENDO")
assert num_e("OIDO_AGACHADO") < num_e("OIDO") < num_e("OIDO_CORRIENDO") and num_e("OIDO") >= 5 and num_e("AVISO") >= 24
def bt_(modificador_):
    return 0.98 * (0.3 * 1.3 * modificador_) ** 2 / 0.454                  # corriendo (bloques por tick)
persigue_, disparado_, cansado_ = (float(re.search(rf"{n_} = ([\d.]+);", bot_esc_).group(1))
                                  for n_ in ("PERSIGUE", "DISPARADO", "CANSADO"))
assert bt_(persigue_) < jugador_bt and bt_(disparado_) > jugador_bt * 1.5 and bt_(cansado_) < jugador_bt * 0.85, (
    bt_(persigue_) * 20, bt_(disparado_) * 20, bt_(cansado_) * 20)
assert int(re.search(r"RAFAGA = (\d+);", bot_esc_).group(1)) <= 80 and int(re.search(r"DESCANSO = (\d+);", bot_esc_).group(1)) >= 100
for frase_ in ("Escondidas.loVi(bot, visto);", "Escondidas.pistaCerca(bot)", "Escondidas.esconditeCerca(bot, zona, 12.0, false)",
               "irA(ultimoVisto, 3);", "Escondidas.peligro(bot, escondido ? 5.0 : 9.0)", "mirarAlrededor(true);",
               "mirarAlrededor(false);", "bot.mostrarEmote(Emote.VISTO);", "disparado > 0 ? DISPARADO : CANSADO",
               "&& bot.hasLineOfSight(objetivo)) {"):                    # el golpe, nunca a través de un vidrio
    assert frase_ in bot_esc_, frase_
assert "ClipContext.Block.VISUAL" in esc_j and '"mensaje.juegosdelpatio.te_vio"' in esc_j
assert 'VISTO("¡!", ChatFormatting.RED, false)' in java["Emote.java"]
# en las escondidas nadie guarda rencor ni se enoja: que el buscador te encuentre es el juego
die_ = java["JugadorBot.java"].split("public void die(DamageSource fuente) {")[1].split("\n    }\n")[0]
hurt_ = java["JugadorBot.java"].split("public boolean hurt(DamageSource fuente, float cantidad) {")[1].split("\n    }\n")[0]
assert "!(Juego.numero() == 3 && Juego.enArena())" in die_ and "&& !Juego.sinPeleas(this)) {" in hurt_
print("bots de las escondidas ok: ven hasta", vista_[-1], "bloques; persiguen a", round(bt_(persigue_) * 20, 1),
      "b/s, disparados", round(bt_(disparado_) * 20, 1), "b/s, cansados", round(bt_(cansado_) * 20, 1),
      "b/s (un jugador corriendo:", round(jugador_bt * 20, 1), "b/s)")
print("escuela ok:", len(escuela["blocks"]), "bloques;", len(escondites_e), "escondites y", len(ronda_e),
      "lugares de ronda (se llega a todos);", "luz media en los escondites", round(sum(luz_esc) / len(luz_esc), 1),
      "y en el hall", min(luz_hall), "a", max(luz_hall), "; en toda la escuela, media", round(luz_media, 1), "; sala de profesores con", len(sala_p),
      "lugares; 6 salidas con rejas; patio cerrado")
sys.exit(1 if errores else 0)
