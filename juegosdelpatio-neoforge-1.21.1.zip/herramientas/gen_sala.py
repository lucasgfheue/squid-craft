#!/usr/bin/env python3
"""Genera el dormitorio de "Juegos del Patio" como plantilla de estructura NBT (Minecraft 1.21.1).

Distribución:
  - Salón principal (65 x 73): literas junto a tres paredes y una plaza abierta en el centro.
  - Delante del salón, a los lados del portón: baños (izquierda) y comedor (derecha),
    con puertas desde el salón.

Las coordenadas se escriben "respecto del salón" (los anexos tienen z negativa) y al final
se desplazan para que la plantilla empiece en 0.

Uso: python3 gen_sala.py <salida.nbt> <bloques.pkl>
"""
import gzip
import io
import pickle
import struct
import sys
from collections import Counter

OFF = 29                         # profundidad de los anexos (delante del salón)
HX, HZ = 65, 73                  # salón: ancho y largo (paredes incluidas)
SX, SY, SZ = HX, 21, HZ + OFF    # tamaño total de la plantilla
DATA_VERSION = 3955              # Minecraft 1.21.1

blocks = {}
bentities = {}                   # datos de bloques con entidad (carteles)


def S(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    if not props:
        return name
    parts = []
    for k, v in sorted(props.items()):
        if isinstance(v, bool):
            v = "true" if v else "false"
        parts.append(f"{k}={v}")
    return f"{name}[{','.join(parts)}]"


def put(x, y, z, state):
    blocks[(x, y, z)] = state


def clear(x, y, z):
    blocks.pop((x, y, z), None)


BULB = S("waxed_copper_bulb", lit=True, powered=False)
SEA = S("sea_lantern")
DEEP = S("polished_deepslate")
BARS = "@iron_bars"                                  # se resuelven al final según los vecinos
PANE = "@white_stained_glass_pane"
LANTERN_STAND = S("lantern", hanging=False, waterlogged=False)
LANTERN = S("lantern", hanging=True, waterlogged=False)
CHAIN = S("chain", axis="y", waterlogged=False)

PILLAR_Z = list(range(4, 69, 8))
Z_INICIO_CAMAS = 20             # antes de esta línea (cerca de baños y comedor) no hay literas
SIDE_BLOCKS = [(20, 34), (38, 52), (56, 70)]
PLAZA_X = (13, 51)
PLAZA_Z = (3, 69)


def side_x(lado, d):
    return d if lado == "izq" else HX - 1 - d


def facing_hacia_pared(lado):
    return "west" if lado == "izq" else "east"


def facing_hacia_centro(lado):
    return "east" if lado == "izq" else "west"


def bed(facing, part):
    return S("white_bed", facing=facing, part=part, occupied=False)


def bunk(facing, head_xz, foot_xz):
    for y in (1, 2):
        put(head_xz[0], y, head_xz[1], bed(facing, "head"))
        put(foot_xz[0], y, foot_xz[1], bed(facing, "foot"))


def sign(x, y, z, facing, texto):
    put(x, y, z, S("spruce_wall_sign", facing=facing, waterlogged=False))
    lineas = ['""', '{"text":"%s","bold":true}' % texto, '""', '""']
    bentities[(x, y, z)] = {
        "id": ("str", "minecraft:sign"),
        "is_waxed": ("byte", 1),
        "front_text": ("comp", {
            "messages": ("strlist", lineas),
            "color": ("str", "white"),
            "has_glowing_text": ("byte", 1),
        }),
        "back_text": ("comp", {
            "messages": ("strlist", ['""', '""', '""', '""']),
            "color": ("str", "black"),
            "has_glowing_text": ("byte", 0),
        }),
    }


# =================================================================== SALÓN PRINCIPAL
for x in range(HX):
    for z in range(HZ):
        put(x, 0, z, S("polished_andesite"))
        put(x, SY - 1, z, S("deepslate_tiles"))

for x in range(PLAZA_X[0], PLAZA_X[1] + 1):
    put(x, 0, PLAZA_Z[0], DEEP)
    put(x, 0, PLAZA_Z[1], DEEP)
for z in range(PLAZA_Z[0], PLAZA_Z[1] + 1):
    put(PLAZA_X[0], 0, z, DEEP)
    put(PLAZA_X[1], 0, z, DEEP)
for x in range(29, 36):
    for z in range(1, 21):
        put(x, 0, z, DEEP)


def wall_state(y):
    if y in (1, 19):
        return S("polished_tuff")
    if y == 8:
        return S("chiseled_tuff_bricks")
    return S("tuff_bricks")


for y in range(1, SY - 1):
    for x in range(HX):
        put(x, y, 0, wall_state(y))
        put(x, y, HZ - 1, wall_state(y))
    for z in range(HZ):
        put(0, y, z, wall_state(y))
        put(HX - 1, y, z, wall_state(y))

GRATE = S("waxed_copper_grate", waterlogged=False)
for z in range(8, 65, 8):
    put(0, 15, z, GRATE)
    put(HX - 1, 15, z, GRATE)
for x in (12, 20, 44, 52):
    put(x, 15, 0, GRATE)
    put(x, 15, HZ - 1, GRATE)


def pilaster(x, z):
    for y in range(1, 20):
        put(x, y, z, BULB if y in (5, 12) else DEEP)


for z in PILLAR_Z:
    pilaster(0, z)
    pilaster(HX - 1, z)
for x in (8, 16, 24, 40, 48, 56):
    pilaster(x, 0)
for x in (8, 16, 48, 56):
    pilaster(x, HZ - 1)

for z in PILLAR_Z:
    for x in range(1, 64):
        put(x, 19, z, DEEP)
for x in (8, 16, 24, 32, 40, 48, 56):
    for z in range(8, 65, 8):
        put(x, 20, z, BULB)
for z in PILLAR_Z:
    for x in (7, 16, 24, 32, 40, 48, 57):
        for y in range(13, 19):
            put(x, y, z, CHAIN)
        put(x, 12, z, LANTERN)

# portón: abertura de 9 x 9 en la pared del salón. La puerta está un bloque más atrás (z = -1) y,
# cuando el mod la abre, sube como un rastrillo a un hueco escondido dentro del muro (y 10..18).
PX0, PX1, PALTO = 28, 36, 9


def puerta_bloque(x, fila):
    """Material de la puerta (fila 0 = abajo). El mod usa el mismo dibujo al moverla."""
    if x in (PX0, PX1) or fila % 4 == 0:
        return S("polished_blackstone")
    return S("iron_block")


for x in range(PX0, PX1 + 1):
    for y in range(1, PALTO + 1):
        clear(x, y, 0)                                    # la abertura
        put(x, y, -1, puerta_bloque(x, y - 1))            # la puerta, cerrada
    put(x, 0, -1, DEEP)
    put(x, 19, -1, wall_state(19))                        # tapa del hueco
    for y in range(PALTO + 1, 20):
        put(x, y, -2, wall_state(y))                      # fondo del hueco
for y in range(1, 20):
    put(PX0 - 1, y, -1, wall_state(y))                    # costados del hueco
    put(PX1 + 1, y, -1, wall_state(y))
for y in range(1, 11):
    put(27, y, 1, DEEP)
    put(37, y, 1, DEEP)
for x in range(27, 38):
    put(x, 10, 1, DEEP)
put(27, 11, 1, BULB)
put(37, 11, 1, BULB)


# literas
def partition(cells, lantern_cell=None):
    for (x, z) in cells:
        put(x, 0, z, S("smooth_stone"))
        for y in (1, 2):
            put(x, y, z, BARS)
    if lantern_cell:
        put(lantern_cell[0], 3, lantern_cell[1], LANTERN_STAND)


def floor_under(cells):
    for (x, z) in cells:
        put(x, 0, z, S("smooth_stone"))


for lado in ("izq", "der"):
    X = lambda d: side_x(lado, d)
    for z in range(Z_INICIO_CAMAS, 71):
        cells = [(X(1), z), (X(2), z)]
        if z % 2 == 0:
            partition(cells, (X(2), z) if z % 4 == 0 else None)
        else:
            floor_under(cells)
            bunk(facing_hacia_pared(lado), (X(1), z), (X(2), z))
    for n, (z0, z1) in enumerate(SIDE_BLOCKS):
        for z in range(z0, z1 + 1):
            cells = [(X(d), z) for d in (6, 7, 8, 9)]
            if z % 2 == 0:
                partition(cells, (X(7 if n % 2 == 0 else 8), z) if z % 4 == 0 else None)
            else:
                floor_under(cells)
                bunk(facing_hacia_centro(lado), (X(7), z), (X(6), z))
                bunk(facing_hacia_pared(lado), (X(8), z), (X(9), z))

for x in range(13, 52):                       # fila contra la pared del fondo
    cells = [(x, HZ - 2), (x, HZ - 3)]
    if x % 2 == 1:
        partition(cells, (x, HZ - 3) if x % 4 == 1 else None)
    else:
        floor_under(cells)
        bunk("south", (x, HZ - 2), (x, HZ - 3))

# luces del piso
for z in (2, 6, 10, 14, 18, 56, 62):
    put(32, 0, z, SEA)
for x in (18, 24, 40, 46):
    for z in range(8, 63, 6):
        put(x, 0, z, SEA)
for lado in ("izq", "der"):
    for z in range(4, 69, 4):
        put(side_x(lado, 4), 0, z, SEA)
        put(side_x(lado, 11), 0, z, SEA)
    for (z0, z1) in zip([b[1] for b in SIDE_BLOCKS[:-1]], [b[0] for b in SIDE_BLOCKS[1:]]):
        put(side_x(lado, 7), 0, (z0 + z1) // 2, SEA)
        put(side_x(lado, 8), 0, (z0 + z1) // 2, SEA)

# rayuela gigante en el centro
W = S("white_concrete")
CX, Z0 = 32, 21


def fill(x0, x1, z0, z1, st, y=0):
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            put(x, y, z, st)


for z0, color in [(Z0 + 1, "red"), (Z0 + 5, "orange"), (Z0 + 9, "yellow"), (Z0 + 17, "cyan")]:
    fill(CX - 1, CX + 1, z0, z0 + 2, S(f"{color}_concrete"))
    fill(CX - 2, CX - 2, z0 - 1, z0 + 3, W)
    fill(CX + 2, CX + 2, z0 - 1, z0 + 3, W)
for z0, c1, c2 in [(Z0 + 13, "lime", "green"), (Z0 + 21, "blue", "purple")]:
    fill(CX - 3, CX - 1, z0, z0 + 2, S(f"{c1}_concrete"))
    fill(CX + 1, CX + 3, z0, z0 + 2, S(f"{c2}_concrete"))
    fill(CX, CX, z0, z0 + 2, W)
    fill(CX - 4, CX - 4, z0 - 1, z0 + 3, W)
    fill(CX + 4, CX + 4, z0 - 1, z0 + 3, W)
for z in (Z0, Z0 + 4, Z0 + 8):
    fill(CX - 2, CX + 2, z, z, W)
for z in (Z0 + 12, Z0 + 16, Z0 + 20, Z0 + 24):
    fill(CX - 4, CX + 4, z, z, W)
disc = set()
for x in range(CX - 5, CX + 6):
    for z in range(Z0 + 25, Z0 + 31):
        if (x - CX) ** 2 + (z - (Z0 + 24)) ** 2 <= 20.25:
            disc.add((x, z))
for (x, z) in disc:
    edge = any((nx, nz) not in disc and nz > Z0 + 24 for nx, nz in ((x + 1, z), (x - 1, z), (x, z + 1)))
    put(x, 0, z, W if edge else S("light_blue_concrete"))

# mural: barrilete en la pared del fondo
ZW = HZ - 1
KX, KY, HW, HH = 32, 13, 5, 6


def inside_kite(x, y):
    return HH * abs(x - KX) + HW * abs(y - KY) <= HW * HH


for x in range(KX - HW, KX + HW + 1):
    for y in range(KY - HH, KY + HH + 1):
        if not inside_kite(x, y):
            continue
        edge = not all(inside_kite(nx, ny) for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))
        dx, dy = x - KX, y - KY
        if edge:
            st = S("black_concrete")
        elif dx == 0 or dy == 0:
            st = S("white_concrete")
        elif dx < 0 < dy:
            st = S("red_concrete")
        elif dx > 0 and dy > 0:
            st = S("yellow_concrete")
        elif dx < 0 and dy < 0:
            st = S("blue_concrete")
        else:
            st = S("lime_concrete")
        put(x, y, ZW, st)
for (x, y) in [(32, 6), (33, 5), (34, 5), (35, 6), (36, 6), (37, 5), (38, 5), (39, 6), (40, 6), (41, 5)]:
    put(x, y, ZW, S("black_concrete"))
for (x, y), c in (((34, 6), "red"), ((34, 4), "red"), ((38, 6), "yellow"), ((38, 4), "yellow")):
    put(x, y, ZW, S(f"{c}_concrete"))


# =================================================================== PUERTAS A LOS ANEXOS
def doorway(xc, texto):
    for x in range(xc - 1, xc + 2):
        for y in range(1, 5):
            clear(x, y, 0)
    for y in range(1, 6):
        put(xc - 2, y, 0, DEEP)
        put(xc + 2, y, 0, DEEP)
    for x in range(xc - 2, xc + 3):
        put(x, 5, 0, DEEP)
    sign(xc, 6, 1, "south", texto)           # cartel del lado del salón
    sign(xc, 5, -1, "north", texto)          # y del lado del anexo


doorway(12, "BAÑOS")
doorway(52, "COMEDOR")

AZ = -OFF                                     # pared del fondo de los anexos (z = -29)

# =================================================================== PASILLO DE LOS GUARDIAS (detrás del portón)
# x 28..36 por dentro, techo en y=10; de acá salen los guardias en la ceremonia de bienvenida.
for z in range(AZ, -1):
    for x in range(PX0 - 1, PX1 + 2):
        put(x, 0, z, S("red_concrete") if 31 <= x <= 33 else DEEP)    # alfombra roja al medio
        put(x, PALTO + 1, z, S("deepslate_tiles"))
    for y in range(1, PALTO + 1):
        put(PX0 - 1, y, z, wall_state(y))
        put(PX1 + 1, y, z, wall_state(y))
for x in range(PX0 - 1, PX1 + 2):
    for y in range(1, PALTO + 1):
        put(x, y, AZ, wall_state(y))
for z in (-4, -10, -16, -22, -27):
    put(PX0 - 1, 5, z, BULB)
    put(PX1 + 1, 5, z, BULB)
for z in (-6, -13, -20, -26):
    put(32, PALTO + 1, z, SEA)


def annex_box(x0, x1, top, wall_fn, floor_fn, ceiling):
    for x in range(x0, x1 + 1):
        for z in range(AZ, 0):
            put(x, 0, z, floor_fn(x, z))
            put(x, top, z, ceiling)
    for y in range(1, top):
        for z in range(AZ, 0):
            put(x0, y, z, wall_fn(y))
            put(x1, y, z, wall_fn(y))
        for x in range(x0, x1 + 1):
            put(x, y, AZ, wall_fn(y))


# =================================================================== BAÑOS  (x 0..24, techo y=6)
BX0, BX1, BTOP = 0, 24, 6
annex_box(BX0, BX1, BTOP,
          lambda y: S("quartz_bricks") if y <= 3 else (S("light_blue_terracotta") if y == 4 else S("smooth_quartz")),
          lambda x, z: S("white_concrete") if (x + z) % 2 == 0 else S("light_gray_concrete"),
          S("smooth_quartz"))
for x in (4, 8, 12, 16, 20):
    for z in range(-4, AZ, -4):
        put(x, BTOP, z, SEA)

# inodoros en cubículos contra la pared oeste
QZ = S("smooth_quartz")
for zp in range(-2, -27, -3):                 # separadores: -2, -5, ..., -26
    for x in range(1, 5):
        for y in range(1, 4):
            put(x, y, zp, QZ)
for zp in range(-2, -24, -3):                 # 8 cubículos
    za, zb = zp - 1, zp - 2
    put(1, 1, za, S("quartz_stairs", facing="west", half="bottom", shape="straight", waterlogged=False))
    put(1, 2, za, S("iron_trapdoor", facing="east", half="bottom", open=True, powered=False, waterlogged=False))
    for y in range(1, 4):
        put(4, y, za, QZ)
    put(4, 1, zb, S("birch_door", facing="west", half="lower", hinge="left", open=False, powered=False))
    put(4, 2, zb, S("birch_door", facing="west", half="upper", hinge="left", open=False, powered=False))
    put(4, 3, zb, QZ)

# duchas contra la pared este: 8 cubículos con separadores de vidrio
for z in range(-2, -27, -1):
    for x in range(20, 24):
        put(x, 0, z, S("light_blue_terracotta"))
for zp in range(-2, -27, -3):
    for x in range(20, 24):
        for y in range(1, 4):
            put(x, y, zp, PANE)
for zp in range(-2, -24, -3):
    put(23, 3, zp - 1, S("lightning_rod", facing="west", powered=False, waterlogged=False))

# isla central de lavamanos con espejo doble
for z in range(-6, -21, -1):
    put(12, 1, z, QZ)
    if z in (-6, -20):
        put(11, 1, z, QZ)
        put(13, 1, z, QZ)
        continue
    put(12, 2, z, S("light_gray_stained_glass"))
    put(12, 3, z, S("light_gray_stained_glass"))
    if z % 2 == 1:
        put(11, 1, z, S("water_cauldron", level=3))
        put(13, 1, z, S("water_cauldron", level=3))
        put(11, 2, z, S("lever", face="wall", facing="west", powered=False))
        put(13, 2, z, S("lever", face="wall", facing="east", powered=False))
    else:
        put(11, 1, z, S("smooth_quartz_slab", type="top", waterlogged=False))
        put(13, 1, z, S("smooth_quartz_slab", type="top", waterlogged=False))

# banco largo junto a la pared del fondo
for x in range(7, 18):
    put(x, 1, -28, S("spruce_slab", type="bottom", waterlogged=False))

# =================================================================== COMEDOR  (x 40..64, techo y=7)
CX0, CX1, CTOP = 40, 64, 7
annex_box(CX0, CX1, CTOP,
          lambda y: S("spruce_planks") if y <= 2 else (S("polished_tuff") if y == 3 else S("tuff_bricks")),
          lambda x, z: S("polished_andesite") if 50 <= x <= 54 else S("smooth_stone"),
          S("dark_oak_planks"))
for x in (44, 48, 52, 56, 60):
    for z in range(-4, AZ, -4):
        put(x, CTOP, z, BULB)

TABLE = S("dark_oak_slab", type="top", waterlogged=False)
BENCH = S("spruce_slab", type="bottom", waterlogged=False)
for tx in (44, 48, 56, 60):                    # mesas largas con bancos a los dos lados
    for z in range(-4, -22, -1):
        put(tx, 1, z, TABLE)
        put(tx - 1, 1, z, BENCH)
        put(tx + 1, 1, z, BENCH)
    for z in (-8, -12, -16, -20):
        put(tx, 2, z, S("white_candle", candles=3, lit=True, waterlogged=False))
    for z in (-6, -10, -14, -18):
        put(tx, CTOP - 1, z, CHAIN)
        put(tx, CTOP - 2, z, LANTERN)

for x in range(42, 62):                        # mostrador
    if x in (48, 55):
        put(x, 1, -24, S("water_cauldron", level=2))
    else:
        put(x, 1, -24, QZ)
        if x in (45, 51, 58):
            put(x, 2, -24, S("cake", bites=0))
for x in range(41, 64):                        # cocina contra la pared del fondo
    if x % 2 == 0:
        put(x, 1, -28, S("smoker", facing="south", lit=False))
    else:
        put(x, 1, -28, S("barrel", facing="south", open=False))

# =================================================================== barrotes y vidrios: conexiones
SOLIDO = ("tuff_bricks", "polished_tuff", "chiseled_tuff_bricks", "polished_deepslate", "waxed_copper_bulb",
          "iron_block", "polished_blackstone", "deepslate_tiles", "smooth_stone", "polished_andesite",
          "sea_lantern", "waxed_copper_grate", "quartz_bricks", "smooth_quartz", "light_blue_terracotta",
          "spruce_planks", "dark_oak_planks", "light_gray_stained_glass", "smoker", "barrel", "smooth_stone")


def conecta(st):
    if st is None:
        return False
    if st.startswith("@"):
        return True
    name = st.split(":")[1].split("[")[0]
    return name in SOLIDO or name.endswith("_concrete")


resueltos = {}
for (x, y, z), st in blocks.items():
    if not st.startswith("@"):
        continue
    resueltos[(x, y, z)] = S(st[1:],
                             north=conecta(blocks.get((x, y, z - 1))), south=conecta(blocks.get((x, y, z + 1))),
                             east=conecta(blocks.get((x + 1, y, z))), west=conecta(blocks.get((x - 1, y, z))),
                             waterlogged=False)
blocks.update(resueltos)

# =================================================================== desplazamiento a coordenadas de plantilla
blocks = {(x, y, z + OFF): s for (x, y, z), s in blocks.items()}
bentities = {(x, y, z + OFF): v for (x, y, z), v in bentities.items()}
for (x, y, z) in blocks:
    if not (0 <= x < SX and 0 <= y < SY and 0 <= z < SZ):
        raise ValueError(f"fuera de la plantilla: {(x, y, z)}")


# =================================================================== escritura NBT
def parse_state(s):
    if "[" in s:
        name, rest = s.split("[", 1)
        props = dict(kv.split("=") for kv in rest[:-1].split(","))
    else:
        name, props = s, {}
    return name, props


class NBT:
    END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTE_ARRAY, STRING, LIST, COMPOUND, INT_ARRAY = range(12)


def w_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">H", len(b)))
    f.write(b)


def w_payload(f, t, v):
    if t == NBT.BYTE:
        f.write(struct.pack(">b", v))
    elif t == NBT.INT:
        f.write(struct.pack(">i", v))
    elif t == NBT.STRING:
        w_str(f, v)
    elif t == NBT.LIST:
        et, items = v
        f.write(struct.pack(">b", et))
        f.write(struct.pack(">i", len(items)))
        for it in items:
            w_payload(f, et, it)
    elif t == NBT.COMPOUND:
        for name, (ct, cv) in v.items():
            f.write(struct.pack(">b", ct))
            w_str(f, name)
            w_payload(f, ct, cv)
        f.write(b"\x00")
    else:
        raise ValueError(t)


def to_tag(spec):
    """Convierte la descripción simple de los carteles a etiquetas NBT."""
    kind, val = spec
    if kind == "str":
        return (NBT.STRING, val)
    if kind == "byte":
        return (NBT.BYTE, val)
    if kind == "strlist":
        return (NBT.LIST, (NBT.STRING, val))
    if kind == "comp":
        return (NBT.COMPOUND, {k: to_tag(v) for k, v in val.items()})
    raise ValueError(kind)


def build_nbt():
    freq = Counter(blocks.values())
    palette = sorted(freq, key=lambda s: (-freq[s], s))
    index = {s: i for i, s in enumerate(palette)}
    pal_tags = []
    for s in palette:
        name, props = parse_state(s)
        c = {"Name": (NBT.STRING, name)}
        if props:
            c["Properties"] = (NBT.COMPOUND, {k: (NBT.STRING, v) for k, v in sorted(props.items())})
        pal_tags.append(c)
    blk_tags = []
    for (x, y, z) in sorted(blocks, key=lambda p: (p[1], p[0], p[2])):
        entry = {
            "pos": (NBT.LIST, (NBT.INT, [x, y, z])),
            "state": (NBT.INT, index[blocks[(x, y, z)]]),
        }
        if (x, y, z) in bentities:
            entry["nbt"] = to_tag(("comp", bentities[(x, y, z)]))
        blk_tags.append(entry)
    root = {
        "DataVersion": (NBT.INT, DATA_VERSION),
        "size": (NBT.LIST, (NBT.INT, [SX, SY, SZ])),
        "palette": (NBT.LIST, (NBT.COMPOUND, pal_tags)),
        "blocks": (NBT.LIST, (NBT.COMPOUND, blk_tags)),
        "entities": (NBT.LIST, (NBT.COMPOUND, [])),
    }
    buf = io.BytesIO()
    buf.write(struct.pack(">b", NBT.COMPOUND))
    w_str(buf, "")
    w_payload(buf, NBT.COMPOUND, root)
    return buf.getvalue(), palette


if __name__ == "__main__":
    out_nbt, out_pkl = sys.argv[1], sys.argv[2]
    raw, palette = build_nbt()
    with gzip.open(out_nbt, "wb", compresslevel=9) as f:
        f.write(raw)
    with open(out_pkl, "wb") as f:
        pickle.dump({"size": (SX, SY, SZ), "blocks": blocks, "offset": OFF}, f)
    beds = sum(1 for s in blocks.values() if "white_bed" in s and "part=head" in s)
    print(f"bloques: {len(blocks)}  paleta: {len(palette)}  camas: {beds}  tamaño: {SX}x{SY}x{SZ}")
