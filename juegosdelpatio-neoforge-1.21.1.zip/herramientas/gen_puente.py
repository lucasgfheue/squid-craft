#!/usr/bin/env python3
"""Genera la arena del juego 4, "El puente de Londres" (puente.nbt).

Una plaza de Londres de noche, techada: alrededor, fachadas de ladrillo con ventanas (unas con luz, otras
apagadas), cornisas de piedra y pilastras oscuras; arriba, todo negro, como el cielo de noche. En el medio, una plaza de
piedra oscura con un farol alto, y alrededor, la calle de adoquines oscuros con cordones de piedra, por donde la fila
camina en ronda (como las agujas del reloj), con faroles de hierro afuera. Del lado este de la ronda, los dos robots
gigantes (no están en la plantilla: los pone el juego, ver Robot.java) se paran uno a cada lado de la calle, sobre una
plataforma de metal, y con los brazos en alto forman el puente.

Coordenadas del mundo: la plantilla empieza en (3969, 99, -17). Adentro: x 3970..4030, z -15..53, piso en y=99.
  entrada   z -15..4   (llegada, podio del comandante y portal de vuelta en la pared norte)
  ronda     centro en el bloque (4000, 26): plaza hasta r 13,4 · cordón · calle de r 14,6 a 17,4 · cordón hasta r 18,2
  puente    en el lado este de la ronda (4016,5; 26,5): robot de adentro en (4011,5; 26,5), de afuera en (4021,5; 26,5)

Uso: python3 gen_puente.py <salida.nbt> <bloques.pkl>
"""
import gzip
import io
import math
import pickle
import struct
import sys
from collections import Counter

OX, OY, OZ = 3969, 99, -17      # esquina de la plantilla en el mundo
SX, SY, SZ = 63, 18, 72         # x 3969..4031, y 99..116, z -17..54
DATA_VERSION = 3955

blocks = {}


def S(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    if not props:
        return name
    parts = []
    for k, v in sorted(props.items()):
        if isinstance(v, bool):
            v = "true" if v else "false"
        parts.append(f"{k}={v}")
    return f"{name}[{','.join(parts)}]"


def put(wx, wy, wz, st):
    """Pone un bloque usando coordenadas del mundo."""
    blocks[(wx - OX, wy - OY, wz - OZ)] = st


def get(wx, wy, wz):
    return blocks.get((wx - OX, wy - OY, wz - OZ))


X0, X1 = 3970, 4030             # adentro
Z0, Z1 = -15, 53
PARED_N, PARED_S, PARED_O, PARED_E = -16, 54, 3969, 4031
PISO = 99
TECHO = 116
CENTRO_X, CENTRO_Z = 4000, 26
CX, CZ = CENTRO_X + 0.5, CENTRO_Z + 0.5
CALLE_MIN, CALLE_MAX = 14.6, 17.4   # la calle (por donde se camina); los cordones de piedra, hasta 14 y 18,2
ROBOTS = ((4011.5, 26.5), (4021.5, 26.5))   # el de adentro y el de afuera (como Puente.java)
LUZ = S("light", level=15, waterlogged=False)
NEGRO = S("polished_blackstone")
DEEP = S("polished_deepslate")
FAROL_PISO = S("lantern", hanging=False, waterlogged=False)
ADOQUIN = S("deepslate_tiles")
CORDON = S("smooth_stone")
VEREDA = S("polished_andesite")
PLAZA = S("polished_blackstone")
FAROL_LUZ = S("lantern", hanging=False, waterlogged=False)
POSTE = S("iron_bars", east=False, north=False, south=False, west=False, waterlogged=False)


def h(*v):
    """Un número fijo (de 0 a 999) para cada lugar: sirve para variar sin azar (siempre sale igual)."""
    x = 0
    for n in v:
        x = (x * 73856093 + n * 19349663 + 83492791) & 0xFFFFFFFF
    return x % 1000


# =================================================================== piso
for x in range(OX, OX + SX):
    for z in range(PARED_N, PARED_S + 1):
        if z <= 4:
            st = DEEP                                              # entrada
        elif z == 5:
            st = CORDON                                            # línea
        else:
            st = VEREDA                                            # la vereda de piedra
        put(x, PISO, z, st)

# la plaza del medio (con dos anillos oscuros), los cordones y la calle de adoquines
for dx in range(-19, 20):
    for dz in range(-19, 20):
        r = math.hypot(dx + 0.0, dz + 0.0)
        x, z = CENTRO_X + dx, CENTRO_Z + dz
        if r <= 13.4:
            anillo = 6.5 <= r <= 7.5 or 12.5 <= r
            st = DEEP if anillo else PLAZA
        elif r < CALLE_MIN or CALLE_MAX < r <= 18.2:
            st = CORDON                                            # los cordones de la calle
        elif r <= CALLE_MAX:
            st = ADOQUIN
        else:
            continue
        put(x, PISO, z, st)

# las plataformas de metal de los robots (una a cada lado de la calle)
for rx, rz in ROBOTS:
    for dx in range(-3, 4):
        for dz in range(-3, 4):
            r = math.hypot(dx + 0.5 - (rx - math.floor(rx)), dz + 0.5 - (rz - math.floor(rz)))
            x, z = int(math.floor(rx)) + dx, int(math.floor(rz)) + dz
            if r <= 2.9 and abs(math.hypot(x + 0.5 - CX, z + 0.5 - CZ) - 16.0) > 2.3:
                put(x, PISO, z, S("iron_block") if r > 2.2 else DEEP)

# el farol alto del medio de la plaza: pedestal de piedra oscura, poste de hierro y el farol arriba
for dx in (-1, 0, 1):
    for dz in (-1, 0, 1):
        put(CENTRO_X + dx, PISO + 1, CENTRO_Z + dz, PLAZA)
for y in range(PISO + 2, PISO + 7):
    put(CENTRO_X, y, CENTRO_Z, POSTE)
put(CENTRO_X, PISO + 7, CENTRO_Z, FAROL_LUZ)

# faroles de hierro alrededor de la calle (afuera), menos cerca del puente (ahí están los robots)
for k in range(12):
    grados = 15.0 + 30.0 * k
    if min(grados, 360.0 - grados) < 40.0:
        continue
    a_ = math.radians(grados)
    fx, fz = round(CENTRO_X + 19.6 * math.cos(a_)), round(CENTRO_Z + 19.6 * math.sin(a_))
    put(fx, PISO + 1, fz, NEGRO)
    for y in range(PISO + 2, PISO + 5):
        put(fx, y, fz, POSTE)
    put(fx, PISO + 5, fz, FAROL_LUZ)

# =================================================================== paredes: fachadas de ladrillo con ventanas
LADRILLO = S("bricks")
VENTANA_LUZ = S("ochre_froglight", axis="y")
VENTANA_OSCURA = S("black_concrete")
NOCHE = S("black_concrete")
PILASTRA = S("polished_deepslate")
PISOS = ((PISO + 2, PISO + 3), (PISO + 5, PISO + 6), (PISO + 9, PISO + 10))   # las filas de ventanas
CORNISAS = (PISO + 4, PISO + 8, PISO + 11)


def fachada(a, y, lado):
    """El bloque de la pared en la columna a (a lo largo de la pared) y la altura y."""
    if y == PISO + 1:
        return DEEP                                                # zócalo
    if y >= PISO + 12:
        return NOCHE                                               # arriba de los techos: la noche
    if a % 10 == 0:
        return PILASTRA                                            # entre casa y casa
    if y in CORNISAS:
        return CORDON
    en_casa = a % 10
    for fila, (y0, y1) in enumerate(PISOS):
        if y0 <= y <= y1 and en_casa in (2, 3, 6, 7):
            ventana = en_casa // 4                                 # dos ventanas por piso en cada casa
            prendida = h(a // 10, fila, ventana, lado) % 100 < 58
            return VENTANA_LUZ if prendida else VENTANA_OSCURA
    return LADRILLO


for y in range(PISO + 1, TECHO):
    for x in range(OX, OX + SX):
        put(x, y, PARED_N, fachada(x, y, 0))
        put(x, y, PARED_S, fachada(x, y, 1))
    for z in range(PARED_N, PARED_S + 1):
        put(PARED_O, y, z, fachada(z, y, 2))
        put(PARED_E, y, z, fachada(z, y, 3))

# =================================================================== el techo: negro (la noche)
for x in range(OX, OX + SX):
    for z in range(PARED_N, PARED_S + 1):
        put(x, TECHO, z, NOCHE)

# =================================================================== entrada: podio, portal de vuelta y faroles
for x in range(3996, 4005):                                     # podio del comandante (arriba: y=102)
    for z in range(-15, -11):
        for y in range(PISO + 1, PISO + 3):
            put(x, y, z, NEGRO if y == PISO + 1 else S("smooth_quartz"))
for x in (3996, 4004):
    put(x, PISO + 3, -12, FAROL_PISO)
for x in range(3977, 3984):                                     # portal de vuelta, en la pared norte
    for y in range(PISO + 1, PISO + 7):
        marco = x in (3977, 3983) or y == PISO + 6
        put(x, y, PARED_N, NEGRO if marco else S("juegosdelpatio:portal_juego", juego=4, regreso=True))
        if not marco:
            put(x, y, PARED_N - 1, S("barrier"))                # que nadie caiga al vacío de atrás
for x in range(3978, 3983):
    put(x, PISO, -15, NEGRO)

# =================================================================== luces invisibles
# A la altura de la cabeza (no chocan con nada) y en damero: cada 6 bloques, una sí y una no.
LUZ_Y = PISO + 2
for x in range(X0, X1 + 1):
    for z in range(Z0, Z1 + 1):
        en_damero = x % 6 == 0 and z % 6 == 0 and (x // 6 + z // 6) % 2 == 0
        junto_a_la_pared = (x in (X0, X1) and z % 6 == 3) or (z in (Z0, Z1) and x % 6 == 3)
        if (en_damero or junto_a_la_pared) and get(x, LUZ_Y, z) is None:
            put(x, LUZ_Y, z, LUZ)

for (x, y, z) in blocks:
    if not (0 <= x < SX and 0 <= y < SY and 0 <= z < SZ):
        raise ValueError(f"fuera de la plantilla: {(x, y, z)}")


# =================================================================== escritura NBT
class NBT:
    END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTE_ARRAY, STRING, LIST, COMPOUND, INT_ARRAY = range(12)


def w_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">H", len(b)))
    f.write(b)


def w_payload(f, t, v):
    if t == NBT.INT:
        f.write(struct.pack(">i", v))
    elif t == NBT.STRING:
        w_str(f, v)
    elif t == NBT.LIST:
        et, items = v
        f.write(struct.pack(">b", et))
        f.write(struct.pack(">i", len(items)))
        for it in items:
            w_payload(f, et, it)
    elif t == NBT.COMPOUND:
        for name, (ct, cv) in v.items():
            f.write(struct.pack(">b", ct))
            w_str(f, name)
            w_payload(f, ct, cv)
        f.write(b"\x00")
    else:
        raise ValueError(t)


def parse_state(s):
    if "[" in s:
        name, rest = s.split("[", 1)
        return name, dict(kv.split("=") for kv in rest[:-1].split(","))
    return s, {}


def build_nbt():
    freq = Counter(blocks.values())
    palette = sorted(freq, key=lambda s: (-freq[s], s))
    index = {s: i for i, s in enumerate(palette)}
    pal_tags = []
    for s in palette:
        name, props = parse_state(s)
        c = {"Name": (NBT.STRING, name)}
        if props:
            c["Properties"] = (NBT.COMPOUND, {k: (NBT.STRING, v) for k, v in sorted(props.items())})
        pal_tags.append(c)
    blk_tags = [{"pos": (NBT.LIST, (NBT.INT, [x, y, z])), "state": (NBT.INT, index[blocks[(x, y, z)]])}
                for (x, y, z) in sorted(blocks, key=lambda p: (p[1], p[0], p[2]))]
    root = {
        "DataVersion": (NBT.INT, DATA_VERSION),
        "size": (NBT.LIST, (NBT.INT, [SX, SY, SZ])),
        "palette": (NBT.LIST, (NBT.COMPOUND, pal_tags)),
        "blocks": (NBT.LIST, (NBT.COMPOUND, blk_tags)),
        "entities": (NBT.LIST, (NBT.COMPOUND, [])),
    }
    buf = io.BytesIO()
    buf.write(struct.pack(">b", NBT.COMPOUND))
    w_str(buf, "")
    w_payload(buf, NBT.COMPOUND, root)
    return buf.getvalue(), palette


if __name__ == "__main__":
    out_nbt, out_pkl = sys.argv[1], sys.argv[2]
    raw, palette = build_nbt()
    with gzip.open(out_nbt, "wb", compresslevel=9) as f:
        f.write(raw)
    with open(out_pkl, "wb") as f:
        pickle.dump({"size": (SX, SY, SZ), "blocks": blocks, "offset": 0, "origen": (OX, OY, OZ)}, f)
    print(f"arena: {len(blocks)} bloques, paleta {len(palette)}, {len(raw) // 1024} KB sin comprimir")
