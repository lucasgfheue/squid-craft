#!/usr/bin/env python3
"""Genera la arena del juego 5, "La papa caliente" (tejo.nbt): un valle de noche, con colinas, montañas y túneles.

Un valle de pasto (sin plantas) bajo la noche estrellada del complejo, encerrado entre laderas. Hay colinas suaves por
todos lados, una montaña grande al sur (con la punta de roca y un poco de nieve) y dos más chicas al norte; a todas se
puede subir (la altura nunca cambia más de un bloque de un lugar al de al lado). La montaña grande tiene dos túneles
que se cruzan en una cueva, en el medio; la del noroeste, otro. Por el valle, pinos y rocas para esconderse. Todo de
noche: luces invisibles (como de luna) y faroles en los túneles. Al norte, más alto y separado del valle por el vacío,
el palco del comandante, con el podio y el portal de vuelta.

Coordenadas del mundo: la plantilla empieza en (6935, 74, -20).
  valle        x 6945..7055, z 6..116 (con una barrera invisible en el borde); el pasto en lo llano, en y = 99
  montañas     la grande con centro en (7000, 76); las chicas en (6968, 34) y (7034, 30)
  túneles      la grande: de oeste a este en z 75..77 y de norte a sur en x 6999..7001, con la cueva en el medio;
               la del noroeste: de norte a sur en x 6967..6969. Adentro se camina en y = 100
  palco        x 6975..7025, z -16..-2, el piso en y = 111 (podio en x 6996..7004, z -15..-12)

Uso: python3 gen_tejo.py <salida.nbt> <bloques.pkl>
"""
import math
import sys

from arenas_comun import Arena, S

OX, OY, OZ = 6935, 74, -20
SX, SY, SZ = 131, 52, 141                 # x 6935..7065, y 74..125, z -20..120
A = Arena(OX, OY, OZ, SX, SY, SZ)
CX = 7000
X0, X1, Z0, Z1 = 6945, 7055, 6, 116       # el borde del valle (ahí va la barrera)
LLANO = 99
PALCO = (6975, 7025, -16, -2)
PALCO_PISO = 111
MONTANAS = [(7000, 76, 24, 24), (6968, 34, 13, 12), (7034, 30, 11, 10)]   # (x, z, radio, alto)
COLINAS = [(6960, 60, 3, 6), (6958, 92, 4, 7), (7040, 64, 3, 6), (7042, 98, 4, 6), (6984, 104, 2, 5),
           (7018, 106, 3, 5), (7000, 22, 2, 6), (6986, 50, 2, 4), (7016, 48, 2, 4), (6950, 14, 3, 5),
           (7050, 14, 3, 5), (7024, 82, 2, 4)]                              # (x, z, alto, radio)
TUNELES = [  # (x0, x1, z0, z1): por dónde pasa (se camina en y = 100, de 4 de alto)
    (6968, 7032, 75, 77),                 # la montaña grande, de oeste a este
    (6999, 7001, 46, 106),                # la montaña grande, de norte a sur
    (6967, 6969, 16, 52),                 # la montaña del noroeste, de norte a sur
]
CUEVA = (6996, 7004, 72, 80)              # donde se cruzan los túneles de la montaña grande (de 5 de alto)

PASTO = S("grass_block", snowy=False)
TIERRA = S("dirt")
PIEDRA = S("stone")
ANDESITA = S("andesite")
GRAVA = S("gravel")
ADOQUIN = S("cobblestone")
ADOQUIN_MUSGO = S("mossy_cobblestone")
TIERRA_GRUESA = S("coarse_dirt")
NIEVE = S("snow_block")
BARRERA = S("barrier")
COLGADO = S("lantern", hanging=True, waterlogged=False)
FAROL = S("lantern", hanging=False, waterlogged=False)
TRONCO = S("spruce_log", axis="y")
HOJAS = S("spruce_leaves", distance=1, persistent=True, waterlogged=False)


def h01(*v):
    """Un número entre 0 y 1 que depende solo de los enteros dados (siempre el mismo)."""
    n = 0
    for k in v:
        n = (n * 1103515245 + k * 2654435761 + 12345) & 0xFFFFFFFF
    n ^= n >> 15
    n = (n * 2246822519) & 0xFFFFFFFF
    n ^= n >> 13
    return n / 0xFFFFFFFF


def en_tunel(x, z):
    return any(a <= x <= b and c <= z <= d for (a, b, c, d) in TUNELES) or (
        CUEVA[0] <= x <= CUEVA[1] and CUEVA[2] <= z <= CUEVA[3])


# =================================================================== la altura del pasto
def altura_cruda(x, z):
    h = LLANO + 0.9 * math.sin(x / 7.1 + 0.4) * math.cos(z / 8.3 + 1.1) + 0.6 * math.sin((x + z) / 5.3)
    for (cx, cz, alto, radio) in COLINAS:
        h += alto * math.exp(-((x - cx) ** 2 + (z - cz) ** 2) / (2.0 * radio ** 2))
    for (mx, mz, radio, alto) in MONTANAS:
        d = math.hypot(x - mx, z - mz) / radio
        if d < 1.0:
            h += alto * (1.0 - d ** 1.3) + 1.6 * (h01(x // 2, z // 2, 9) - 0.5)
    borde = min(x - X0, X1 - x, z - Z0, Z1 - z)
    if borde < 8:
        h += (8 - borde) * 1.1                 # el valle se levanta en los bordes, como laderas
    return h


ALTO = {}
for x in range(X0, X1 + 1):
    for z in range(Z0, Z1 + 1):
        ALTO[(x, z)] = int(round(altura_cruda(x, z)))
for (x, z), h in list(ALTO.items()):           # el piso de los túneles, a ras: se camina en y = 100
    if en_tunel(x, z):
        ALTO[(x, z)] = max(h, LLANO)
cambio = True
while cambio:                                   # nunca más de un bloque entre vecinos (se camina y se sube por todo)
    cambio = False
    for (x, z), h in list(ALTO.items()):
        vecinos = [ALTO[v] for v in ((x + 1, z), (x - 1, z), (x, z + 1), (x, z - 1)) if v in ALTO]
        tope = min(vecinos) + 1
        if h > tope:
            ALTO[(x, z)] = tope
            cambio = True


def superficie(x, z, h):
    """El bloque de arriba según la altura: pasto abajo, piedra y grava más arriba, nieve en la punta."""
    sobre = h - LLANO
    r = h01(x, z, 3)
    if sobre >= 19:
        return NIEVE if r < 0.7 else PIEDRA
    if sobre >= 13:
        return PIEDRA if r < 0.55 else ANDESITA if r < 0.8 else GRAVA
    if sobre >= 8:
        return PASTO if r < 0.5 else TIERRA_GRUESA if r < 0.7 else PIEDRA if r < 0.88 else GRAVA
    return PASTO


# =================================================================== el valle
for (x, z), h in ALTO.items():
    borde = x in (X0, X1) or z in (Z0, Z1)
    if en_tunel(x, z):                          # el túnel: piso de grava y piedra, a ras; techo de piedra (o abierto
        alto_t = 5 if CUEVA[0] <= x <= CUEVA[1] and CUEVA[2] <= z <= CUEVA[3] else 4    # en la entrada: un corte)
        A.put(x, LLANO, z, GRAVA if h01(x, z, 4) < 0.4 else PIEDRA)
        for y in range(LLANO - 3, LLANO):
            A.put(x, y, z, PIEDRA)
        if h > LLANO + alto_t:
            for y in range(LLANO + 1 + alto_t, h + 1):
                A.put(x, y, z, superficie(x, z, h) if y == h else PIEDRA if h01(x, y, z) < 0.8 else ANDESITA)
        continue
    A.put(x, h, z, superficie(x, z, h))
    for y in range(h - 3, h):
        A.put(x, y, z, TIERRA if h - y <= 2 and h - LLANO < 13 else PIEDRA)
    if borde:                                   # el borde del valle: un acantilado, y la barrera arriba
        for y in range(80, h - 3):
            A.put(x, y, z, ANDESITA if h01(x, y, z) < 0.25 else PIEDRA)
        for y in range(h + 1, h + 9):
            A.put(x, y, z, BARRERA)
    elif h - LLANO > 4:                         # adentro de las montañas, piedra maciza (para los túneles)
        for y in range(LLANO - 1, h - 3):
            A.put(x, y, z, PIEDRA)
    else:
        A.put(x, h - 4, z, PIEDRA)

# los túneles: faroles colgando del techo y luces invisibles
for (a, b, c, d) in TUNELES + [CUEVA]:
    for x in range(a, b + 1):
        for z in range(c, d + 1):
            h = ALTO[(x, z)]
            if h <= LLANO + 4:
                continue
            centro = (x == (a + b) // 2) if b - a < d - c else (z == (c + d) // 2)
            if centro and (x + z) % 6 == 0:
                techo = LLANO + 4 if not (CUEVA[0] <= x <= CUEVA[1] and CUEVA[2] <= z <= CUEVA[3]) else LLANO + 5
                if A.get(x, techo + 1, z) is not None:
                    A.put(x, techo, z, COLGADO)
            if (x + 2 * z) % 4 == 0 and A.get(x, LLANO + 2, z) is None:
                A.put(x, LLANO + 2, z, S("light", level=12, waterlogged=False))

# =================================================================== pinos y rocas
PINOS = []
for i in range(400):
    x = X0 + 4 + int(h01(i, 1) * (X1 - X0 - 8))
    z = Z0 + 4 + int(h01(i, 2) * (Z1 - Z0 - 8))
    h = ALTO[(x, z)]
    if h - LLANO > 9 or en_tunel(x, z) or any(abs(x - a) + abs(z - b) < 7 for (a, b) in PINOS):
        continue
    if any(math.hypot(x - mx, z - mz) < r * 0.55 for (mx, mz, r, _) in MONTANAS):
        continue
    PINOS.append((x, z))
    if len(PINOS) >= 30:
        break
for (x, z) in PINOS:                            # pinos: tronco alto y hojas en pisos, angostas (como los de verdad)
    h = ALTO[(x, z)]
    alto = 7 + int(h01(x, z, 7) * 3)
    for y in range(h + 1, h + alto + 1):
        A.put(x, y, z, TRONCO)
    pisos = [2, 1, 2, 1, 1, 0] if alto >= 8 else [2, 1, 1, 0]
    for k, radio in enumerate(pisos):
        y = h + alto - len(pisos) + 2 + k
        for dx in range(-radio, radio + 1):
            for dz in range(-radio, radio + 1):
                if (dx, dz) != (0, 0) and abs(dx) + abs(dz) <= radio + (1 if radio == 2 else 0) and A.get(x + dx, y, z + dz) is None:
                    A.put(x + dx, y, z + dz, HOJAS)
    A.put(x, h + alto + 1, z, HOJAS)
    A.put(x, h + alto + 2, z, HOJAS)
ROCAS = [(6955, 30, 2), (6990, 36, 2), (7046, 46, 3), (6952, 76, 2), (6976, 96, 3), (7030, 94, 2), (7048, 84, 2),
         (6962, 108, 2), (7010, 112, 2), (7044, 112, 2), (6994, 12, 2), (7022, 16, 2), (6978, 64, 2), (7022, 62, 2)]
for (x, z, n) in ROCAS:
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            if h01(x + dx, z + dz, 41) < 0.6 or (dx, dz) == (0, 0):
                h = ALTO[(x + dx, z + dz)]
                for k in range(1, 2 + int(h01(x, z, dx, dz) * n)):
                    A.put(x + dx, h + k, z + dz, (ANDESITA, ADOQUIN, ADOQUIN_MUSGO, PIEDRA)[int(h01(x + dx, k, z + dz) * 4)])

# =================================================================== luces: invisibles, a la altura de la cabeza, en todo el valle
for x in range(X0 + 1, X1):
    for z in range(Z0 + 1, Z1):
        if (x % 6, z % 6) != (2, 4) or en_tunel(x, z):
            continue
        y = ALTO[(x, z)] + 3
        if A.get(x, y, z) is None and A.get(x, y - 1, z) is None and A.get(x, y - 2, z) is None:
            A.put(x, y, z, S("light", level=14, waterlogged=False))
for (x, z) in ((6968, 14), (6968, 54), (6966, 76), (7034, 76), (7000, 44), (7000, 108)):   # faroles en las entradas
    h = ALTO[(x, z)]
    if A.get(x, h + 1, z) is None:
        A.put(x, h + 1, z, ADOQUIN)
        A.put(x, h + 2, z, FAROL)

# =================================================================== el palco del comandante (al norte, separado)
px0, px1, pz0, pz1 = PALCO
for x in range(px0, px1 + 1):
    for z in range(pz0, pz1 + 1):
        borde = x in (px0, px1) or z in (pz0, pz1)
        A.put(x, PALCO_PISO, z, S("stone_bricks") if borde else S("polished_andesite"))
        if borde:
            for y in range(84, PALCO_PISO):
                A.put(x, y, z, ANDESITA if h01(x, y, z) < 0.3 else PIEDRA)
borde = [(x, z) for x in range(px0, px1 + 1) for z in (pz0, pz1)] + [(x, z) for z in range(pz0, pz1 + 1) for x in (px0, px1)]
borde = [(x, z) for (x, z) in borde if not (z == pz0 and CX - 23 <= x <= CX - 17)]   # el portal de vuelta
A.baranda(borde, PALCO_PISO + 1, PALCO_PISO + 2)
A.entrada(5, centro=CX, piso=PALCO_PISO)
for (x, z) in ((px0 + 1, pz1 - 1), (px1 - 1, pz1 - 1), (px0 + 1, pz0 + 1), (px1 - 1, pz0 + 1)):
    A.put(x, PALCO_PISO + 1, z, S("stone_bricks"))
    A.put(x, PALCO_PISO + 2, z, FAROL)
for x in range(px0 + 1, px1, 6):
    for z in (pz0 + 4, pz1 - 3):
        if A.get(x, PALCO_PISO + 2, z) is None:
            A.put(x, PALCO_PISO + 2, z, S("light", level=15, waterlogged=False))

if __name__ == "__main__":
    A.guardar(sys.argv[1], sys.argv[2], "tejo")
