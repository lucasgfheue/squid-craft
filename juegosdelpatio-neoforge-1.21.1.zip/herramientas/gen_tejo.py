#!/usr/bin/env python3
"""Genera la arena del juego 4, "El tejo" (tejo.nbt): una rayuela de torres altísimas.

Diez torres de piedra oscura, una por casillero (de 7 x 7, del 1 al 10, como una rayuela: 1, 2, 3-4, 5, 6-7, 8,
9-10), cada una con su número de oro arriba. Entre una y otra hay vacío (2 bloques hacia adelante; 3 entre las de al
lado, como la 3 y la 4): se salta de torre en torre. Al norte, la largada (una torre ancha con baranda, abierta frente
al 1), con el podio del comandante y el portal de vuelta; al sur, el cielo: medio círculo de mármol con baranda. Abajo
(59 bloques), el patio, con la rayuela de verdad dibujada en el piso.

Coordenadas del mundo: la plantilla empieza en (6969, 40, -17). El suelo en y = 40; arriba de las torres, en y = 99.
  largada     x 6975..7025, z -16..8  (abertura en la baranda sur: x 6997..7003)
  torres (como Tejo.TORRES):
      1: x 6997..7003, z 11..17      2: x 6997..7003, z 20..26
      3: x 6992..6998, z 29..35      4: x 7002..7008, z 29..35
      5: x 6997..7003, z 38..44
      6: x 6992..6998, z 47..53      7: x 7002..7008, z 47..53
      8: x 6997..7003, z 56..62
      9: x 6992..6998, z 65..71     10: x 7002..7008, z 65..71
  cielo       medio círculo de radio 10,5 con centro en (7000, 74): x 6990..7010, z 74..84

Uso: python3 gen_tejo.py <salida.nbt> <bloques.pkl>
"""
import math
import sys

from arenas_comun import DIGITOS, PISO, Arena, S

OX, OY, OZ = 6969, 40, -17
SX, SY, SZ = 63, 78, 103                 # x 6969..7031, y 40..117, z -17..85
A = Arena(OX, OY, OZ, SX, SY, SZ)
SUELO = 40
CENTRO_X = 7000
LARGADA = (6975, 7025, -16, 8)
ABERTURA = (6997, 7003)
TORRES = {
    1: (6997, 7003, 11, 17), 2: (6997, 7003, 20, 26),
    3: (6992, 6998, 29, 35), 4: (7002, 7008, 29, 35),
    5: (6997, 7003, 38, 44),
    6: (6992, 6998, 47, 53), 7: (7002, 7008, 47, 53),
    8: (6997, 7003, 56, 62),
    9: (6992, 6998, 65, 71), 10: (7002, 7008, 65, 71),
}
CIELO_Z, CIELO_R = 74, 10.5
NEGRO = S("polished_blackstone")
BORDE = S("polished_blackstone_bricks")
ORO = S("gold_block")
CALIDA = S("shroomlight")
MARMOL = S("smooth_quartz")
BANDAS = (50, 51, 66, 67, 82, 83, 97)


def en_cielo(x, z):
    return z >= CIELO_Z and math.hypot(x - CENTRO_X, z - CIELO_Z) <= CIELO_R


CIELO = [(x, z) for x in range(CENTRO_X - 11, CENTRO_X + 12) for z in range(CIELO_Z, CIELO_Z + 12) if en_cielo(x, z)]

# =================================================================== el patio, allá abajo (con la rayuela dibujada)
for x in range(OX, OX + SX):
    for z in range(OZ, OZ + SZ):
        A.put(x, SUELO, z, CALIDA if x % 8 == 4 and z % 8 == 4 else S("deepslate_tiles"))
for numero, (x0, x1, z0, z1) in TORRES.items():
    for x in range(x0 - 1, x1 + 2):
        for z in range(z0 - 1, z1 + 2):
            if x in (x0 - 1, x1 + 1) or z in (z0 - 1, z1 + 1):
                A.put(x, SUELO, z, S("polished_diorite"))

# =================================================================== las torres
A.torre(*LARGADA[:2], *LARGADA[2:], SUELO + 1, PISO - 1, S("deepslate_tiles"), bandas=(60, 80),
        banda=S("polished_deepslate"), ventanas=CALIDA, cada=6, alturas=(52, 72, 92))
for numero, (x0, x1, z0, z1) in TORRES.items():
    A.torre(x0, x1, z0, z1, SUELO + 1, PISO - 1, S("polished_deepslate"), bandas=BANDAS,
            banda=S("chiseled_deepslate") if numero % 2 else S("deepslate_tiles"), ventanas=CALIDA, cada=3,
            alturas=(58 + 2 * numero, 74 + 2 * numero))
for (x, z) in CIELO:                                           # el cielo, sobre su torre de medio círculo
    afuera = any(not en_cielo(x + dx, z + dz) for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)))
    for y in range(SUELO + 1, PISO):
        if afuera or z == CIELO_Z:
            A.put(x, y, z, ORO if y in BANDAS else S("quartz_bricks"))

# =================================================================== arriba: la largada, las torres y el cielo
x0, x1, z0, z1 = LARGADA
for x in range(x0, x1 + 1):
    for z in range(z0, z1 + 1):
        A.put(x, PISO, z, BORDE if x in (x0, x1) or z in (z0, z1) else S("polished_andesite"))
for x in range(ABERTURA[0], ABERTURA[1] + 1):
    A.put(x, PISO, z1, ORO)                                    # la línea de largada, en la abertura
borde = [(x, z) for x in range(x0, x1 + 1) for z in (z0, z1)] + [(x, z) for z in range(z0, z1 + 1) for x in (x0, x1)]
borde = [(x, z) for (x, z) in borde if not (z == z0 and OX + 8 <= x <= OX + 14)
         and not (z == z1 and ABERTURA[0] <= x <= ABERTURA[1])]
A.baranda(borde, PISO + 1, PISO + 2)
A.entrada(4)
for (x, z) in ((x0 + 1, z1 - 1), (x1 - 1, z1 - 1), (x0 + 1, z0 + 1), (x1 - 1, z0 + 1)):
    A.put(x, PISO + 1, z, BORDE)
    A.put(x, PISO + 2, z, S("lantern", hanging=False, waterlogged=False))

for numero, (tx0, tx1, tz0, tz1) in TORRES.items():
    for x in range(tx0, tx1 + 1):
        for z in range(tz0, tz1 + 1):
            A.put(x, PISO, z, BORDE if x in (tx0, tx1) or z in (tz0, tz1) else NEGRO)
    cx, cz = (tx0 + tx1) // 2, (tz0 + tz1) // 2
    digitos = [numero] if numero < 10 else [1, 0]
    for i, d in enumerate(digitos):                            # el número, de oro (se lee desde la largada)
        corrido = 0 if len(digitos) == 1 else (2 if i == 0 else -2)
        for fila, renglon in enumerate(DIGITOS[d]):
            for columna, c in enumerate(renglon):
                if c == "X":
                    A.put(cx + corrido + 1 - columna, PISO, cz + 2 - fila, ORO)

for (x, z) in CIELO:
    anillo = any(not en_cielo(x + dx, z + dz) for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)))
    A.put(x, PISO, z, ORO if anillo and z > CIELO_Z else MARMOL)
curva = [(x, z) for (x, z) in CIELO if z > CIELO_Z
         and any(not en_cielo(x + dx, z + dz) for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)))]
A.baranda(curva, PISO + 1, PISO + 2)                           # baranda en la curva; del lado del 9 y el 10, abierto

# =================================================================== luces: arriba, invisibles; y en el vacío, para ver lo alto
A.luces(x0 + 1, x1 - 1, z0 + 1, z1 - 1)
for (tx0, tx1, tz0, tz1) in TORRES.values():
    A.luces(tx0, tx1, tz0, tz1)
A.luces(CENTRO_X - 9, CENTRO_X + 9, CIELO_Z + 1, CIELO_Z + 9)
for z in range(10, 74, 9):
    for y in (52, 68, 84):
        for x in (6989, 7000, 7011):
            if A.get(x, y, z) is None:
                A.put(x, y, z, S("light", level=10, waterlogged=False))

if __name__ == "__main__":
    A.guardar(sys.argv[1], sys.argv[2], "tejo")
