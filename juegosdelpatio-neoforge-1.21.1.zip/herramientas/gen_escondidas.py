#!/usr/bin/env python3
"""Genera la arena del juego 3, "Las escondidas" (escuela.nbt): una escuela gigante, de noche.

Una sola planta enorme (150 x 120) con paredes de ladrillo por fuera. Adentro:
  - un pasillo que da toda la vuelta (con casilleros) y cuatro pasillos que van del hall a ese pasillo;
  - en el medio, el HALL (donde llegan todos, con el podio del comandante en el centro y el portal de vuelta);
  - alrededor del hall: el GIMNASIO (con gradas y un depósito), la BIBLIOTECA (estanterías altas), el COMEDOR
    (con la cocina) y el SALÓN DE ACTOS (escenario con telón); la SALA DE PROFESORES (donde esperan los
    buscadores, con rejas en las puertas), la DIRECCIÓN y la ENFERMERÍA;
  - afuera del pasillo, 30 aulas, baños y depósitos;
  - seis SALIDAS al patio (en las puntas del pasillo y al norte y al sur), cerradas con rejas: el juego abre una.
  - El PATIO, al norte, está separado de la escuela: ahí esperan los que encuentran la salida.

Los escondites (roperos, baños, huecos de las estanterías, debajo de las gradas, detrás del telón...) tienen una
esponja escondida debajo del piso (y=98): el juego los encuentra así. Los lugares por donde pasan los bots que
buscan (el medio de cada sala y puntos del pasillo) tienen una esponja mojada.

Coordenadas: la plantilla empieza en el mundo en (2925, 98, -60) y mide 150 x 9 x 132.
  escuela  x 2925..3074, z -48..71 (coordenadas "de la escuela": x 0..149, z 0..119; mundo = (2925 + x, -48 + z))
  patio    z -60..-49 (escuela z -12..-1)
  alturas  esponjas en y=98 · piso y=99 · se camina en y=100 · paredes hasta y=105 · techo y=106

Uso: python3 gen_escondidas.py <salida.nbt> <bloques.pkl> [plano.png]
"""
import gzip
import io
import pickle
import struct
import sys
from collections import Counter, deque

OX, OY, OZ = 2925, 98, -60
SX, SY, SZ = 150, 9, 132
ZE = OZ + 12                     # z del mundo de la fila 0 de la escuela
W, D = 150, 120                  # la escuela: x 0..149, z 0..119 (paredes de afuera en 0 y 149 / 0 y 119)
MARCA, PISO, Y0, TECHO = 98, 99, 100, 106
DATA_VERSION = 3955

blocks = {}


def S(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    if not props:
        return name
    parts = []
    for k, v in sorted(props.items()):
        if isinstance(v, bool):
            v = "true" if v else "false"
        parts.append(f"{k}={v}")
    return f"{name}[{','.join(parts)}]"


def put(x, y, z, st):
    """Coordenadas de la escuela (x, z) y altura del mundo (y)."""
    lx, ly, lz = x, y - OY, z + 12
    if not (0 <= lx < SX and 0 <= ly < SY and 0 <= lz < SZ):
        raise ValueError(f"fuera de la plantilla: {(x, y, z)}")
    if st is None:
        blocks.pop((lx, ly, lz), None)
    else:
        blocks[(lx, ly, lz)] = st


def get(x, y, z):
    return blocks.get((x, y - OY, z + 12))


# ------------------------------------------------------------------ bloques
LADRILLO = S("bricks")
BLANCO = S("white_concrete")
PARED = S("cyan_terracotta")                     # las paredes de adentro: pintadas de gris verdoso oscuro
ZOCALO = S("gray_terracotta")                    # y abajo, un zócalo más oscuro todavía
TECHO_B = S("smooth_stone")
NEGRO = S("polished_blackstone")
ANDESITA = S("polished_andesite")
MADERA = S("dark_oak_planks")
ABETO = S("spruce_planks")
ABEDUL = S("birch_planks")
ROBLE = S("oak_planks")
ESTANTE = S("bookshelf")
PIZARRON = S("black_concrete")
GRIS = S("light_gray_concrete")
NARANJA = S("orange_concrete")
CASILLERO = S("gray_concrete")                   # casilleros de metal, gris oscuro
CUARZO = S("smooth_quartz")
ESPONJA = S("sponge")
BARRIL = S("barrel", facing="up", open=False)
LAMPARA_OFF = S("redstone_lamp", lit=False)
FAROL_AZUL = S("soul_lantern", hanging=True, waterlogged=False)
FAROL = S("lantern", hanging=False, waterlogged=False)
CADENA = S("chain", axis="y", waterlogged=False)
VIDRIO_VERDE = S("lime_stained_glass")
BARRERA = S("barrier")


def luz(n):
    return S("light", level=n, waterlogged=False)


def mesa(material="spruce"):
    return S(f"{material}_slab", type="top", waterlogged=False)


def banco(material="spruce"):
    return S(f"{material}_slab", type="bottom", waterlogged=False)


def silla(facing, material="spruce"):
    """Una escalera como silla: el respaldo (la parte alta) hacia {facing}."""
    return S(f"{material}_stairs", facing=facing, half="bottom", shape="straight", waterlogged=False)


def reja(eje):
    """Barrotes que se unen a lo largo de x ('x') o de z ('z')."""
    return S("iron_bars", north=eje == "z", south=eje == "z", east=eje == "x", west=eje == "x", waterlogged=False)


def vidrio(eje):
    return S("glass_pane", north=eje == "z", south=eje == "z", east=eje == "x", west=eje == "x", waterlogged=False)


def cerco(n, s, e, w):
    return S("oak_fence", north=n, south=s, east=e, west=w, waterlogged=False)


# ------------------------------------------------------------------ el plano (qué hay en cada celda del piso)
plano = [[None] * D for _ in range(W)]          # None = pared
TIPO = {}                                         # id -> tipo de lugar
CAJAS = {}                                        # id -> rectángulos


def sala(nombre, tipo, *rects):
    TIPO[nombre] = tipo
    CAJAS[nombre] = rects
    for (x0, z0, x1, z1) in rects:
        for x in range(x0, x1 + 1):
            for z in range(z0, z1 + 1):
                assert plano[x][z] is None, ("se pisan", nombre, plano[x][z], x, z)
                plano[x][z] = nombre


PUERTAS = []                                      # (x, z, ancho, eje, reja)


def puerta(x, z, ancho, eje, con_reja=False):
    """Hueco de 3 de alto en una pared: eje 'x' = la pared corre a lo largo de x."""
    for i in range(ancho):
        cx, cz = (x + i, z) if eje == "x" else (x, z + i)
        assert plano[cx][cz] is None, ("puerta sobre algo que no es pared", cx, cz, plano[cx][cz])
        plano[cx][cz] = "puerta"
    PUERTAS.append((x, z, ancho, eje, con_reja))


# pasillos
sala("pasillo", "pasillo",
     (1, 16, 148, 19), (1, 100, 148, 103), (16, 20, 19, 99), (130, 20, 133, 99),     # la vuelta
     (73, 1, 76, 15), (73, 104, 76, 118),                                            # al norte y al sur (salidas)
     (73, 20, 76, 49), (73, 70, 76, 99), (20, 58, 62, 61), (87, 58, 129, 61))        # del hall a la vuelta
sala("hall", "hall", (63, 50, 86, 69))
sala("gimnasio", "gimnasio", (21, 21, 71, 37), (21, 38, 61, 56))
sala("biblioteca", "biblioteca", (78, 21, 128, 37), (88, 38, 128, 56))
sala("comedor", "comedor", (21, 82, 71, 98), (21, 63, 61, 81))
sala("actos", "actos", (78, 82, 128, 98), (88, 63, 128, 81))
sala("profesores", "profesores", (63, 39, 71, 48))
sala("direccion", "direccion", (78, 39, 86, 48))
sala("cocina", "cocina", (63, 71, 71, 80))
sala("enfermeria", "enfermeria", (78, 71, 86, 80))

FILA_X = [(1, 14), (16, 29), (31, 44), (46, 59), (61, 71), (78, 88), (90, 103), (105, 118), (120, 133), (135, 148)]
FILA_TIPOS = ["aula", "aula", "banos", "aula", "deposito", "aula", "aula", "banos", "aula", "aula"]
COLUMNA_Z = [(21, 34), (36, 49), (51, 64), (66, 79), (81, 98)]
AULAS = []                                        # (nombre, x0, z0, x1, z1, lado de la puerta)
for i, (x0, x1) in enumerate(FILA_X):
    for fila, (z0, z1, lado) in (("n", (1, 14, "s")), ("s", (105, 118, "n"))):
        nombre = f"{FILA_TIPOS[i]}_{fila}{i}"
        sala(nombre, FILA_TIPOS[i], (x0, z0, x1, z1))
        AULAS.append((nombre, x0, z0, x1, z1, lado))
for j, (z0, z1) in enumerate(COLUMNA_Z):
    for col, (x0, x1, lado) in (("o", (1, 14, "e")), ("e", (135, 148, "o"))):
        tipo = "lab" if j == 2 else "aula"
        nombre = f"{tipo}_{col}{j}"
        sala(nombre, tipo, (x0, z0, x1, z1))
        AULAS.append((nombre, x0, z0, x1, z1, lado))

# depósito del gimnasio (adentro del gimnasio: se le ponen paredes)
for x in range(21, 32):
    plano[x][46] = None
for z in range(46, 57):
    plano[31][z] = None
for x in range(21, 31):
    for z in range(47, 57):
        plano[x][z] = "deposito_gym"
TIPO["deposito_gym"] = "deposito"
CAJAS["deposito_gym"] = ((21, 47, 30, 56),)

# puertas de las aulas, baños y depósitos (al pasillo)
for (nombre, x0, z0, x1, z1, lado) in AULAS:
    if lado in ("s", "n"):
        c = (x0 + x1) // 2
        puerta(c, z1 + 1 if lado == "s" else z0 - 1, 2, "x")
    else:
        c = (z0 + z1) // 2
        puerta(x1 + 1 if lado == "e" else x0 - 1, c, 2, "z")
# los salones grandes: una puerta a cada lado
puerta(22, 20, 2, "x"); puerta(20, 29, 2, "z"); puerta(72, 28, 2, "z"); puerta(40, 57, 2, "x")       # gimnasio
puerta(108, 20, 2, "x"); puerta(129, 29, 2, "z"); puerta(77, 28, 2, "z"); puerta(108, 57, 2, "x")    # biblioteca
puerta(40, 99, 2, "x"); puerta(20, 89, 2, "z"); puerta(72, 89, 2, "z"); puerta(40, 62, 2, "x")       # comedor
puerta(108, 99, 2, "x"); puerta(129, 89, 2, "z"); puerta(77, 89, 2, "z"); puerta(108, 62, 2, "x")    # actos
puerta(77, 43, 2, "z")                                                                             # dirección
puerta(77, 75, 2, "z")                                                                             # enfermería
puerta(62, 75, 2, "z")                                                                             # cocina
puerta(31, 51, 2, "z")                                                                             # depósito del gimnasio
# la sala de profesores: dos puertas con rejas (las saca el juego cuando salen los buscadores)
REJAS_PROFESORES = [(66, 49, 3, "x"), (72, 42, 3, "z")]
for (x, z, ancho, eje) in REJAS_PROFESORES:
    puerta(x, z, ancho, eje, con_reja=True)

# las seis salidas: el vestíbulo (al pisarlo, el que se esconde pasa) y la línea de rejas que lo cierra
SALIDAS = [
    # nombre, vestíbulo (x0, z0, x1, z1), rejas (x0, z0, x1, z1), eje de las rejas, frente (adentro, antes de las rejas)
    ("oeste_norte", (1, 16, 3, 19), (4, 16, 4, 19), "z", (6, 18)),
    ("este_norte", (146, 16, 148, 19), (145, 16, 145, 19), "z", (143, 18)),
    ("oeste_sur", (1, 100, 3, 103), (4, 100, 4, 103), "z", (6, 102)),
    ("este_sur", (146, 100, 148, 103), (145, 100, 145, 103), "z", (143, 102)),
    ("norte", (73, 1, 76, 3), (73, 4, 76, 4), "x", (75, 6)),
    ("sur", (73, 116, 76, 118), (73, 115, 76, 115), "x", (75, 113)),
]

# ------------------------------------------------------------------ piso, paredes y techo
PISOS = {
    "pasillo": lambda x, z: BLANCO if (x + z) % 2 == 0 else NARANJA,        # baldosas blancas y naranjas
    "hall": lambda x, z: ANDESITA,
    "gimnasio": lambda x, z: ABEDUL,
    "biblioteca": lambda x, z: MADERA,
    "comedor": lambda x, z: S("smooth_stone"),
    "cocina": lambda x, z: BLANCO if (x + z) % 2 == 0 else S("light_blue_terracotta"),
    "actos": lambda x, z: S("red_terracotta"),
    "profesores": lambda x, z: ABETO,
    "direccion": lambda x, z: MADERA,
    "enfermeria": lambda x, z: BLANCO,
    "aula": lambda x, z: ROBLE,
    "lab": lambda x, z: BLANCO if (x // 2 + z // 2) % 2 == 0 else GRIS,
    "banos": lambda x, z: BLANCO if (x + z) % 2 == 0 else S("light_blue_terracotta"),
    "deposito": lambda x, z: ANDESITA,
    "puerta": lambda x, z: GRIS,
}


def es_borde(x, z):
    return x in (0, W - 1) or z in (0, D - 1)


for x in range(W):
    for z in range(D):
        lugar = plano[x][z]
        put(x, TECHO, z, TECHO_B)
        if lugar is None:
            put(x, PISO, z, NEGRO)
            for y in range(Y0, TECHO):
                if es_borde(x, z):
                    put(x, y, z, LADRILLO if y < TECHO - 1 else NEGRO)
                else:
                    put(x, y, z, ZOCALO if y <= Y0 + 1 else PARED)
        elif lugar == "puerta":
            put(x, PISO, z, BLANCO if (x + z) % 2 == 0 else NARANJA)
            for y in range(Y0 + 3, TECHO):
                put(x, y, z, PARED)
        else:
            put(x, PISO, z, PISOS[TIPO[lugar]](x, z))

# ventanas: en las paredes de afuera de las aulas, a los costados del pizarrón
for (nombre, x0, z0, x1, z1, lado) in AULAS:
    if lado == "s":
        lugares = [(x0 + 1, 0), (x1 - 1, 0)]
    elif lado == "n":
        lugares = [(x0 + 1, D - 1), (x1 - 1, D - 1)]
    elif lado == "e":
        lugares = [(0, z0 + 1), (0, z1 - 1)]
    else:
        lugares = [(W - 1, z0 + 1), (W - 1, z1 - 1)]
    for (wx, wz) in lugares:
        for y in (Y0 + 2, Y0 + 3):
            put(wx, y, wz, vidrio("x" if wz in (0, D - 1) else "z"))

# rejas
for (x, z, ancho, eje, con_reja) in PUERTAS:
    if con_reja:
        for i in range(ancho):
            cx, cz = (x + i, z) if eje == "x" else (x, z + i)
            for y in range(Y0, Y0 + 3):
                put(cx, y, cz, reja(eje))
for (_, vest, (rx0, rz0, rx1, rz1), eje, _) in SALIDAS:
    for x in range(rx0, rx1 + 1):
        for z in range(rz0, rz1 + 1):
            for y in range(Y0, TECHO):
                put(x, y, z, reja("z" if eje == "z" else "x"))

# ------------------------------------------------------------------ escondites
escondites = []                                   # (x, z, tipo)
reservado = set()                                 # celdas que no se pueden tapar (pasos)


def escondite(x, z, tipo):
    assert plano[x][z] not in (None, "puerta"), ("escondite en una pared", x, z, tipo)
    escondites.append((x, z, tipo))
    put(x, MARCA, z, ESPONJA)


def libre(x, z):
    return plano[x][z] not in (None, "puerta") and get(x, Y0, z) is None


def ropero(cx, cz, abre):
    """Un ropero de 3 x 3 (paredes de madera de 3 de alto) con un hueco en el medio; abre hacia 'abre' (dx, dz)."""
    for dx in (-1, 0, 1):
        for dz in (-1, 0, 1):
            if (dx, dz) == (0, 0) or (dx, dz) == abre:
                continue
            for y in range(Y0, Y0 + 3):
                put(cx + dx, y, cz + dz, ABETO)
    put(cx, Y0 + 2, cz, S("spruce_slab", type="top", waterlogged=False))     # el estante de arriba
    escondite(cx, cz, "ropero")


# ------------------------------------------------------------------ aulas, laboratorios, baños, depósitos
def marco(x0, z0, x1, z1, lado):
    """Ejes locales: u a lo largo de la pared de la puerta, v desde la puerta hacia el fondo (pizarrón)."""
    if lado == "s":          # la puerta abajo (z grande): el fondo es el norte
        ancho, fondo = x1 - x0 + 1, z1 - z0 + 1
        a_mundo = lambda u, v: (x0 + u, z1 - v)
        hacia_fondo, hacia_puerta = "north", "south"
        pared_fondo = lambda u: (x0 + u, z0 - 1)
    elif lado == "n":
        ancho, fondo = x1 - x0 + 1, z1 - z0 + 1
        a_mundo = lambda u, v: (x1 - u, z0 + v)
        hacia_fondo, hacia_puerta = "south", "north"
        pared_fondo = lambda u: (x1 - u, z1 + 1)
    elif lado == "e":        # la puerta a la derecha (x grande): el fondo es el oeste
        ancho, fondo = z1 - z0 + 1, x1 - x0 + 1
        a_mundo = lambda u, v: (x1 - v, z1 - u)
        hacia_fondo, hacia_puerta = "west", "east"
        pared_fondo = lambda u: (x0 - 1, z1 - u)
    else:
        ancho, fondo = z1 - z0 + 1, x1 - x0 + 1
        a_mundo = lambda u, v: (x0 + v, z0 + u)
        hacia_fondo, hacia_puerta = "east", "west"
        pared_fondo = lambda u: (x1 + 1, z0 + u)
    return ancho, fondo, a_mundo, hacia_fondo, hacia_puerta, pared_fondo


def centro_luz(x0, z0, x1, z1, nivel, lampara=True):
    """Luces en el techo de una sala chica: en el medio, y si es grande, dos o cuatro repartidas."""
    xs = [(x0 + x1) // 2] if x1 - x0 < 10 else [x0 + (x1 - x0) // 3, x1 - (x1 - x0) // 3]
    zs = [(z0 + z1) // 2] if z1 - z0 < 10 else [z0 + (z1 - z0) // 3, z1 - (z1 - z0) // 3]
    for cx in xs:
        for cz in zs:
            if get(cx, Y0 + 4, cz) is None:
                put(cx, Y0 + 4, cz, luz(nivel))
                if lampara:
                    put(cx, TECHO, cz, LAMPARA_OFF)


def amueblar_aula(x0, z0, x1, z1, lado, lab):
    ancho, fondo, M, hacia_fondo, hacia_puerta, pared_fondo = marco(x0, z0, x1, z1, lado)
    # pizarrón en la pared del fondo
    for u in range(2, ancho - 2):
        px, pz = pared_fondo(u)
        for y in (Y0 + 1, Y0 + 2):
            put(px, y, pz, PIZARRON)
    # escritorio del maestro y su silla
    for u in range(ancho // 2 - 1, ancho // 2 + 2):
        x, z = M(u, fondo - 3)
        put(x, Y0, z, MADERA)
    x, z = M(ancho // 2, fondo - 2)
    put(x, Y0, z, silla(hacia_fondo, "dark_oak"))
    # bancos (o mesadas de laboratorio), mirando al pizarrón, con pasillos entre las columnas
    for v in range(3, fondo - 5, 3):
        for u in range(2, ancho - 2, 2):
            if u >= ancho - 4:                   # al lado del ropero queda paso
                continue
            x, z = M(u, v)
            if lab:
                put(x, Y0, z, CUARZO)
                if u % 4 == 2:
                    put(x, Y0 + 1, z, S("water_cauldron", level="3"))
            else:
                put(x, Y0, z, mesa())
                sx, sz = M(u, v - 1)
                put(sx, Y0, sz, silla(hacia_puerta))
    # ropero en la esquina del lado de la puerta (abre hacia adentro del aula)
    cx, cz = M(ancho - 2, 1)
    ax, az = M(ancho - 3, 1)
    ropero(cx, cz, (ax - cx, az - cz))
    # estante con libros en el fondo, del otro lado
    for v in range(fondo - 4, fondo):
        x, z = M(0, v)
        put(x, Y0, z, ESTANTE)
    centro_luz(x0, z0, x1, z1, 12)


def amueblar_banos(x0, z0, x1, z1, lado):
    ancho, fondo, M, hacia_fondo, hacia_puerta, pared_fondo = marco(x0, z0, x1, z1, lado)
    # cubículos contra el fondo: 3 de hondo (el inodoro atrás), separados por tabiques
    for u in range(0, ancho):
        for v in (fondo - 3, fondo - 2, fondo - 1):
            x, z = M(u, v)
            if u % 2 == 0:
                for y in range(Y0, Y0 + 3):
                    put(x, y, z, CUARZO)                 # tabique
            elif v == fondo - 1:
                put(x, Y0, z, S("quartz_stairs", facing=hacia_fondo, half="bottom", shape="straight", waterlogged=False))
        if u % 2 == 1 and u < ancho - 1:
            x, z = M(u, fondo - 2)
            escondite(x, z, "baño")
    # lavatorios contra un costado
    for v in range(2, fondo - 5, 2):
        x, z = M(ancho - 1, v)
        put(x, Y0, z, S("water_cauldron", level="3"))
    centro_luz(x0, z0, x1, z1, 9)


def amueblar_deposito(x0, z0, x1, z1, lado):
    ancho, fondo, M, hacia_fondo, hacia_puerta, pared_fondo = marco(x0, z0, x1, z1, lado)
    # barriles contra las paredes de los costados y el fondo, con huecos (escondites) entre pilas
    for v in range(2, fondo):
        for u in (0, ancho - 1):
            x, z = M(u, v)
            if v % 4 == 1 and v < fondo - 1:
                escondite(x, z, "depósito")
                continue
            for y in (Y0, Y0 + 1):
                put(x, y, z, BARRIL)
    for u in range(1, ancho - 1):
        x, z = M(u, fondo - 1)
        if u % 4 == 2:
            escondite(x, z, "depósito")
            continue
        for y in (Y0, Y0 + 1):
            put(x, y, z, BARRIL)
    # una isla de cajas en el medio
    for u in range(3, ancho - 3):
        for v in range(4, fondo - 4):
            if (u + v) % 5 == 0:
                continue
            if u in (3, ancho - 4) or v in (4, fondo - 5):
                x, z = M(u, v)
                put(x, Y0, z, S("hay_block", axis="y") if (u * 7 + v) % 3 == 0 else BARRIL)
    centro_luz(x0, z0, x1, z1, 6)


for (nombre, x0, z0, x1, z1, lado) in AULAS:
    tipo = TIPO[nombre]
    if tipo in ("aula", "lab"):
        amueblar_aula(x0, z0, x1, z1, lado, tipo == "lab")
    elif tipo == "banos":
        amueblar_banos(x0, z0, x1, z1, lado)
    else:
        amueblar_deposito(x0, z0, x1, z1, lado)

# ------------------------------------------------------------------ gimnasio
for x in range(24, 59):                                        # líneas de la cancha
    for z in (27, 52):
        put(x, PISO, z, BLANCO)
for z in range(27, 53):
    for x in (24, 58):
        put(x, PISO, z, BLANCO)
for z in range(27, 53):
    put(41, PISO, z, BLANCO)
for (x, z) in ((41, 37), (41, 42), (37, 39), (45, 39), (38, 37), (44, 37), (38, 41), (44, 41)):
    put(x, PISO, z, BLANCO)
for x0 in (24, 56):                                            # arcos en las puntas de la cancha
    for z in range(37, 42):
        if z in (37, 41):
            for y in range(Y0, Y0 + 3):
                put(x0 if x0 == 24 else 58, y, z, BLANCO)
        else:
            put(x0 if x0 == 24 else 58, Y0 + 2, z, BLANCO)
# gradas contra la pared norte: 4 escalones que suben hacia el norte; debajo de las dos de atrás se puede pasar
for x in range(27, 67):
    for k, z in enumerate((24, 23, 22, 21)):
        put(x, Y0 + k, z, silla("north"))
    put(x, Y0, 23, cerco(False, False, x > 27, x < 66))         # la grada de 1 de alto se apoya en una baranda
for x in range(30, 66, 6):
    escondite(x, 21, "gradas")
    escondite(x + 3, 22, "gradas")
# el depósito del gimnasio: colchonetas, pelotas y barriles
for x in range(21, 31):
    for z in range(47, 57):
        if z == 56 or x == 21:
            if (x + z) % 4 == 0:
                escondite(x, z, "depósito")
                continue
            put(x, Y0, z, BARRIL)
            put(x, Y0 + 1, z, BARRIL if (x + z) % 2 else S("blue_wool"))
for (x, z) in ((25, 50), (26, 50), (25, 51), (27, 53), (28, 53)):
    put(x, Y0, z, S("blue_wool"))
for (x, z) in ((24, 54), (29, 49), (27, 49)):
    put(x, Y0, z, S("orange_concrete"))
put(26, Y0 + 4, 52, luz(3))

# ------------------------------------------------------------------ biblioteca: estanterías dobles con huecos
def estanteria(x0, x1, z, hueco_z):
    """Dos filas de estantes (z y z+1) de 4 de alto; cada tanto, un hueco de 1 x 1 x 2 en la fila hueco_z."""
    for x in range(x0, x1 + 1):
        for zz in (z, z + 1):
            for y in range(Y0, Y0 + 4):
                put(x, y, zz, ESTANTE)
    for x in range(x0 + 2, x1 - 1, 5):
        for y in (Y0, Y0 + 1):
            put(x, y, hueco_z, None)
        escondite(x, hueco_z, "estantería")


for i, z in enumerate((24, 28, 32)):
    estanteria(81, 99, z, z if i % 2 == 0 else z + 1)
    estanteria(104, 125, z, z + 1 if i % 2 == 0 else z)
for i, z in enumerate((40, 44, 48, 52)):
    estanteria(91, 105, z, z if i % 2 else z + 1)
    estanteria(110, 125, z, z + 1 if i % 2 else z)
for x in range(81, 100, 4):                                    # mesas de lectura
    put(x, Y0, 36, mesa("dark_oak"))
    put(x + 1, Y0, 36, mesa("dark_oak"))
    put(x, Y0, 35, silla("north", "dark_oak"))
    put(x + 1, Y0, 37, silla("south", "dark_oak"))
for z in range(22, 25):                                        # el mostrador de la bibliotecaria
    put(126, Y0, z, MADERA)
escondite(127, 22, "mostrador")

# ------------------------------------------------------------------ comedor y cocina
for z in (66, 71, 76, 86, 91, 96):
    xa, xb = (24, 58) if z < 82 else (24, 68)
    for x in range(xa, xb + 1):
        if (x - xa) % 10 >= 8:
            continue                                            # paso entre mesa y mesa
        put(x, Y0, z, mesa())
        put(x, Y0, z - 1, banco())
        put(x, Y0, z + 1, banco())
for x in range(63, 72):                                        # mesadas de la cocina, contra la pared norte
    put(x, Y0, 71, S("smoker", facing="south", lit=False) if x % 3 == 0 else S("smooth_stone"))
for z in range(73, 79):                                        # y una isla
    put(68, Y0, z, S("smooth_stone"))
ropero(70, 79, (-1, 0))                                         # la despensa
escondite(70, 75, "cocina")                                     # detrás de la isla

# ------------------------------------------------------------------ salón de actos: escenario, telón y butacas
for x in range(84, 123):
    for z in range(91, 99):
        put(x, Y0, z, MADERA)                                   # el escenario (se camina en y=101)
for x in (83, 123):
    for z in range(91, 99):
        put(x, Y0, z, silla("west" if x == 83 else "east"))     # escalones para subir de costado... (se suben)
for x in range(84, 123):
    if x in (84, 85, 121, 122):
        continue
    for y in range(Y0 + 1, TECHO):
        put(x, y, 96, S("red_wool"))                            # el telón de atrás: detrás, el pasillo de bambalinas
for x in list(range(84, 89)) + list(range(118, 123)):
    for y in range(Y0 + 1, TECHO):
        put(x, y, 91, S("red_wool"))                            # los costados del telón de adelante
for x in range(88, 119, 6):
    escondite(x, 97, "telón")
for x in (86, 120):
    escondite(x, 93, "telón")
for z in range(65, 89, 3):                                     # butacas mirando al escenario
    for x in range(81, 126):
        if x in (91, 92, 103, 104, 115, 116) or (z < 82 and x < 90):
            continue
        put(x, Y0, z, silla("north"))

# ------------------------------------------------------------------ enfermería, dirección y sala de profesores
for z in (72, 75, 78):                                         # camas con cortinas
    put(85, Y0, z, S("white_bed", facing="west", part="head", occupied=False))
    put(84, Y0, z, S("white_bed", facing="west", part="foot", occupied=False))
    for x in (84, 85, 86):
        for y in (Y0, Y0 + 1):
            if z + 1 <= 80 and get(x, y, z + 1) is None:
                put(x, y, z + 1, S("white_wool"))
for z in (71, 74, 77):
    escondite(86, z, "enfermería")                              # entre las cortinas, al lado de la cama
ropero(80, 79, (1, 0))
for x in range(80, 85):                                        # dirección: escritorio, estantes y un ropero
    put(x, Y0, 41, MADERA if x != 82 else mesa("dark_oak"))
put(82, Y0, 40, silla("north", "dark_oak"))
for x in range(79, 86):
    for y in (Y0, Y0 + 1, Y0 + 2):
        put(x, y, 39, ESTANTE)
ropero(85, 47, (-1, 0))
for x in range(65, 70):                                        # profesores: la mesa larga
    for z in (43, 44):
        put(x, Y0, z, mesa())
    put(x, Y0, 42, silla("north"))
    put(x, Y0, 45, silla("south"))
put(63, Y0, 39, S("smoker", facing="east", lit=False))
for z in (39, 40, 46, 47):                                     # casilleros de los profesores
    for y in (Y0, Y0 + 1):
        put(71, y, z, CASILLERO)

# ------------------------------------------------------------------ hall: podio en el centro, bancos, vitrinas y portal
for x in range(73, 77):
    for z in range(58, 62):
        put(x, Y0, z, NEGRO)
        put(x, Y0 + 1, z, CUARZO)
for (x, z) in ((73, 58), (76, 58), (73, 61), (76, 61)):
    put(x, Y0 + 2, z, FAROL)
for dx in range(-6, 7):                                        # el barrilete del complejo, alrededor del podio
    for dz in range(-6, 7):
        if abs(dx) + abs(dz) > 6 or (abs(dx) <= 2 and abs(dz) <= 2):
            continue
        c = "black" if dx == 0 or dz == 0 else {(-1, -1): "red", (1, -1): "yellow", (-1, 1): "blue", (1, 1): "lime"}[
            (1 if dx > 0 else -1, 1 if dz > 0 else -1)]
        put(75 + dx if dx > 0 else 74 + dx, PISO, (60 + dz) if dz > 0 else (59 + dz), S(f"{c}_concrete"))
for x in (64, 85):                                             # bancos contra las paredes
    for z in range(52, 57):
        put(x, Y0, z, silla("west" if x == 64 else "east"))
for x in range(78, 85):                                        # vitrina de trofeos
    put(x, Y0, 50, MADERA)
    put(x, Y0 + 1, 50, S("gold_block") if x % 2 else S("glass"))
for x in range(65, 68):                                        # portal de vuelta (pared sur del hall)
    for y in range(Y0, Y0 + 4):
        put(x, y, 70, S("juegosdelpatio:portal_juego", juego=3, regreso=True))
        put(x, y, 71, BARRERA)
for y in range(Y0, Y0 + 5):
    put(64, y, 70, NEGRO)
    put(68, y, 70, NEGRO)
for x in range(64, 69):
    put(x, Y0 + 4, 70, NEGRO)

# ------------------------------------------------------------------ casilleros en el pasillo (contra las aulas)
for z, contra in ((16, 15), (103, 104)):
    for x in range(6, 144):
        if plano[x][contra] == "puerta" or plano[x - 1][contra] == "puerta" or plano[x + 1][contra] == "puerta":
            continue
        if 14 <= x <= 21 or 71 <= x <= 78 or 128 <= x <= 135:
            continue                                            # esquinas y cruces
        if x % 9 == 4:
            escondite(x, z, "casillero")                        # un casillero vacío y abierto
            continue
        for y in (Y0, Y0 + 1, Y0 + 2):
            put(x, y, z, CASILLERO if y < Y0 + 2 else GRIS)

# ------------------------------------------------------------------ salidas: puerta pintada, luz verde arriba
for (nombre, (vx0, vz0, vx1, vz1), rejas_, eje, frente) in SALIDAS:
    if nombre.startswith("oeste") or nombre.startswith("este"):
        wx = 0 if nombre.startswith("oeste") else W - 1
        celdas = [(wx, z) for z in range(vz0, vz1 + 1)]
    else:
        wz = 0 if nombre == "norte" else D - 1
        celdas = [(x, wz) for x in range(vx0, vx1 + 1)]
    for i, (x, z) in enumerate(celdas):
        for y in range(Y0, Y0 + 3):
            put(x, y, z, MADERA if i in (1, 2) else NEGRO)       # la puerta de dos hojas (cerrada con llave)
        put(x, Y0 + 4, z, VIDRIO_VERDE)
    put((vx0 + vx1) // 2, Y0 + 3, (vz0 + vz1) // 2, luz(10))

# ------------------------------------------------------------------ los pasillos, de noche: paredes y techo negros
# La parte de arriba de las paredes de los pasillos (desde la cintura) y el techo de los pasillos son negros.
CIELO = S("black_concrete")


def es_pasillo(x, z):
    return 0 <= x < W and 0 <= z < D and plano[x][z] is not None and TIPO.get(plano[x][z]) == "pasillo"


for x in range(W):
    for z in range(D):
        if es_borde(x, z) or plano[x][z] not in (None, "puerta"):
            continue
        vecinos = [(x + dx, z + dz) for (dx, dz) in ((1, 0), (-1, 0), (0, 1), (0, -1))
                   if 0 <= x + dx < W and 0 <= z + dz < D]
        if not any(es_pasillo(*v) for v in vecinos) or any(plano[v[0]][v[1]] == "hall" for v in vecinos):
            continue                                            # (las paredes del hall quedan como están)
        for y in range(Y0 + 2, TECHO):
            if get(x, y, z) == PARED:
                put(x, y, z, CIELO)
for x in range(W):                                             # el techo de los pasillos, negro
    for z in range(D):
        if es_pasillo(x, z):
            put(x, TECHO, z, CIELO)


# ------------------------------------------------------------------ luces
def luces_en(nombre, nivel, paso, y=Y0 + 4, faroles=False):
    for (x0, z0, x1, z1) in CAJAS[nombre]:
        for x in range(x0, x1 + 1):
            for z in range(z0, z1 + 1):
                if (x - x0) % paso == paso // 2 and (z - z0) % paso == paso // 2 and plano[x][z] == nombre \
                        and get(x, y, z) is None:
                    put(x, y, z, luz(nivel))
                    if get(x, TECHO - 1, z) is None and not faroles:
                        put(x, TECHO, z, LAMPARA_OFF)


luces_en("hall", 14, 5)
luces_en("gimnasio", 12, 5, y=Y0 + 5)
luces_en("biblioteca", 11, 5, y=Y0 + 5)
luces_en("comedor", 12, 5)
luces_en("actos", 10, 6, y=Y0 + 5)
luces_en("profesores", 11, 4)
luces_en("cocina", 10, 5)
luces_en("direccion", 10, 5)
luces_en("enfermeria", 9, 5)
for (x0, z0, x1, z1) in CAJAS["pasillo"]:                    # el pasillo: luz azulada de faroles colgados
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            mitad_x, mitad_z = (x0 + x1) // 2, (z0 + z1) // 2
            largo_en_x = (x1 - x0) > (z1 - z0)
            en_linea = (z == mitad_z and x % 6 == 3) if largo_en_x else (x == mitad_x and z % 6 == 3)
            if en_linea and get(x, Y0 + 4, z) is None and get(x, Y0, z) is None:
                put(x, Y0 + 4, z, luz(12))
                if (x + z) % 14 in (3, 10) and get(x, TECHO - 1, z) is None:
                    put(x, TECHO - 1, z, FAROL_AZUL)

# ------------------------------------------------------------------ el patio (al norte, separado de la escuela)
PX0, PX1, PZ0, PZ1 = 36, 113, -12, -1
for x in range(PX0, PX1 + 1):
    for z in range(PZ0, PZ1 + 1):
        borde = x in (PX0, PX1) or z == PZ0
        put(x, PISO, z, S("gray_concrete") if not borde else NEGRO)
        if borde:
            put(x, Y0, z, cerco(z > PZ0 and x in (PX0, PX1), z < PZ1 and x in (PX0, PX1),
                                z == PZ0 and x < PX1, z == PZ0 and x > PX0))
            for y in range(Y0 + 1, Y0 + 4):
                put(x, y, z, BARRERA)
# rayuela pintada en el piso, y una cancha
for i, (dx, dz) in enumerate(((0, 0), (0, 1), (-1, 2), (1, 2), (0, 3), (-1, 4), (1, 4), (0, 5))):
    put(50 + dx, PISO, -9 + dz, S("white_concrete") if i % 2 == 0 else S("yellow_concrete"))
for x in range(62, 101):
    for z in (-10, -3):
        put(x, PISO, z, BLANCO)
for z in range(-10, -2):
    put(62, PISO, z, BLANCO)
    put(100, PISO, z, BLANCO)
    put(81, PISO, z, BLANCO)
for x in range(40, 112, 12):                                   # faroles en postes
    put(x, Y0, -11, cerco(False, False, False, False))
    put(x, Y0 + 1, -11, cerco(False, False, False, False))
    put(x, Y0 + 2, -11, FAROL)
for x in (44, 56, 106):                                        # bancos
    for dx in range(3):
        put(x + dx, Y0, -2, silla("south"))
for (cx, cz) in ((40, -5), (110, -5)):                          # dos árboles
    for y in range(Y0, Y0 + 4):
        put(cx, y, cz, S("oak_log", axis="y"))
    for dx in range(-2, 3):
        for dz in range(-2, 3):
            for y in range(Y0 + 3, Y0 + 6):
                if abs(dx) + abs(dz) + (y - Y0 - 3) <= 3 and get(cx + dx, y, cz + dz) is None:
                    if PZ0 < cz + dz < 0 and PX0 < cx + dx < PX1:
                        put(cx + dx, y, cz + dz, S("oak_leaves", distance="1", persistent=True, waterlogged=False))

# ------------------------------------------------------------------ la ronda de los buscadores (esponjas mojadas)
rondas = []


def ronda(x, z):
    """Marca un lugar libre por donde pasan los bots que buscan (el más cercano a (x, z) que esté libre)."""
    for r in range(0, 4):
        for dx in range(-r, r + 1):
            for dz in range(-r, r + 1):
                cx, cz = x + dx, z + dz
                if max(abs(dx), abs(dz)) != r or not (0 <= cx < W and 0 <= cz < D):
                    continue
                if plano[cx][cz] in (None, "puerta") or get(cx, MARCA, cz) is not None:
                    continue
                if get(cx, Y0, cz) is None and get(cx, Y0 + 1, cz) is None:
                    rondas.append((cx, cz))
                    put(cx, MARCA, cz, S("wet_sponge"))
                    return


for nombre, rects in CAJAS.items():
    if nombre in ("pasillo", "profesores"):                    # los buscadores salen de la sala de profesores
        continue
    for (x0, z0, x1, z1) in rects:
        ronda((x0 + x1) // 2, (z0 + z1) // 2)
        if (x1 - x0) > 25 or (z1 - z0) > 25:                   # los salones grandes: también en las cuatro esquinas
            for (cx, cz) in ((x0 + 5, z0 + 5), (x1 - 5, z0 + 5), (x0 + 5, z1 - 5), (x1 - 5, z1 - 5)):
                ronda(cx, cz)
for (x0, z0, x1, z1) in CAJAS["pasillo"]:
    largo_en_x = (x1 - x0) > (z1 - z0)
    for k in range(x0 + 4 if largo_en_x else z0 + 4, (x1 if largo_en_x else z1) - 3, 10):
        ronda(k, (z0 + z1) // 2) if largo_en_x else ronda((x0 + x1) // 2, k)

# ------------------------------------------------------------------ revisión: que se llegue a todos los escondites
def es_luz(b):
    return b == "minecraft:light" or b.startswith("minecraft:light[")


def pasa(x, y, z):
    b = get(x, y, z)
    return b is None or es_luz(b)


def apoyo(x, y, z):
    """Sirve para pararse encima (no los cercos: miden 1,5 y no se los puede saltar)."""
    b = get(x, y, z)
    return b is not None and not es_luz(b) and "fence" not in b


def parado(x, y, z):
    return 0 <= x < W and -12 <= z < D and apoyo(x, y - 1, z) and pasa(x, y, z) and pasa(x, y + 1, z)


def altura(x, z):
    """A qué altura se para uno en la celda (x, z): la más baja posible, o None."""
    for y in range(Y0, Y0 + 4):
        if parado(x, y, z):
            return y
    return None


def bfs(desde):
    vistos = {desde}
    cola = deque([desde])
    while cola:
        x, y, z = cola.popleft()
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            for dy in (0, 1, -1):
                n = (x + dx, y + dy, z + dz)
                if n in vistos or not parado(*n):
                    continue
                if dy == 1 and not pasa(x, y + 2, z):
                    continue                                    # sin lugar para la cabeza al subir
                vistos.add(n)
                cola.append(n)
    return vistos


HALL_CENTRO = (68, Y0, 55)
alcanzables = bfs(HALL_CENTRO)
alcanzables_xz = {(x, z) for (x, y, z) in alcanzables}
faltan = [e for e in escondites if (e[0], altura(e[0], e[1]), e[1]) not in alcanzables]
faltan += [("ronda", x, z) for (x, z) in rondas if (x, altura(x, z), z) not in alcanzables]
if faltan:
    raise SystemExit(f"escondites a los que no se llega: {faltan}")

for (x, y, z) in blocks:
    if not (0 <= x < SX and 0 <= y < SY and 0 <= z < SZ):
        raise ValueError(f"fuera de la plantilla: {(x, y, z)}")


# ================================================================== escritura NBT
class NBT:
    END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTE_ARRAY, STRING, LIST, COMPOUND, INT_ARRAY = range(12)


def w_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">H", len(b)))
    f.write(b)


def w_payload(f, t, v):
    if t == NBT.INT:
        f.write(struct.pack(">i", v))
    elif t == NBT.STRING:
        w_str(f, v)
    elif t == NBT.LIST:
        et, items = v
        f.write(struct.pack(">b", et))
        f.write(struct.pack(">i", len(items)))
        for it in items:
            w_payload(f, et, it)
    elif t == NBT.COMPOUND:
        for name, (ct, cv) in v.items():
            f.write(struct.pack(">b", ct))
            w_str(f, name)
            w_payload(f, ct, cv)
        f.write(b"\x00")
    else:
        raise ValueError(t)


def parse_state(s):
    if "[" in s:
        name, rest = s.split("[", 1)
        return name, dict(kv.split("=") for kv in rest[:-1].split(","))
    return s, {}


def build_nbt():
    freq = Counter(blocks.values())
    palette = sorted(freq, key=lambda s: (-freq[s], s))
    index = {s: i for i, s in enumerate(palette)}
    pal_tags = []
    for s in palette:
        name, props = parse_state(s)
        c = {"Name": (NBT.STRING, name)}
        if props:
            c["Properties"] = (NBT.COMPOUND, {k: (NBT.STRING, v) for k, v in sorted(props.items())})
        pal_tags.append(c)
    blk_tags = [{"pos": (NBT.LIST, (NBT.INT, [x, y, z])), "state": (NBT.INT, index[blocks[(x, y, z)]])}
                for (x, y, z) in sorted(blocks, key=lambda p: (p[1], p[0], p[2]))]
    root = {
        "DataVersion": (NBT.INT, DATA_VERSION),
        "size": (NBT.LIST, (NBT.INT, [SX, SY, SZ])),
        "palette": (NBT.LIST, (NBT.COMPOUND, pal_tags)),
        "blocks": (NBT.LIST, (NBT.COMPOUND, blk_tags)),
        "entities": (NBT.LIST, (NBT.COMPOUND, [])),
    }
    buf = io.BytesIO()
    buf.write(struct.pack(">b", NBT.COMPOUND))
    w_str(buf, "")
    w_payload(buf, NBT.COMPOUND, root)
    return buf.getvalue(), palette


def plano_png(ruta):
    """Un plano visto desde arriba (para revisar): un píxel por bloque, escalado."""
    from PIL import Image
    colores = {
        "pasillo": (205, 205, 210), "hall": (150, 150, 158), "gimnasio": (222, 200, 150), "biblioteca": (110, 80, 55),
        "comedor": (175, 175, 175), "cocina": (190, 215, 225), "actos": (160, 70, 60), "profesores": (130, 100, 70),
        "direccion": (100, 70, 50), "enfermeria": (240, 240, 240), "aula": (190, 150, 95), "lab": (215, 215, 220),
        "banos": (170, 210, 225), "deposito": (120, 120, 125), "puerta": (230, 230, 230),
    }
    img = Image.new("RGB", (W, D + 12), (10, 12, 18))
    px = img.load()
    for x in range(W):
        for z in range(-12, D):
            if z < 0:
                b = get(x, Y0, z)
                f = get(x, PISO, z)
                px[x, z + 12] = (40, 40, 44) if f is None else (95, 95, 100) if b is None else (60, 120, 50)
                continue
            lugar = plano[x][z]
            if lugar is None:
                c = (35, 35, 40)
            else:
                c = colores.get(TIPO.get(lugar, lugar), (255, 0, 255))
                b = get(x, Y0, z)
                if b is not None and not (b == "minecraft:light" or b.startswith("minecraft:light[")):
                    c = (70, 50, 35) if "bookshelf" in b else (110, 110, 120) if "iron_bars" in b else \
                        tuple(int(v * 0.55) for v in c)
            px[x, z + 12] = c
    for (x, z) in rondas:
        px[x, z + 12] = (60, 140, 255)
    for (x, z, tipo) in escondites:
        px[x, z + 12] = (255, 60, 200)
    for (_, (vx0, vz0, vx1, vz1), _, _, _) in SALIDAS:
        for x in range(vx0, vx1 + 1):
            for z in range(vz0, vz1 + 1):
                px[x, z + 12] = (60, 220, 90)
    img = img.resize((W * 6, (D + 12) * 6), Image.NEAREST)
    img.save(ruta)


if __name__ == "__main__":
    out_nbt, out_pkl = sys.argv[1], sys.argv[2]
    raw, palette = build_nbt()
    with gzip.open(out_nbt, "wb", compresslevel=9) as f:
        f.write(raw)
    with open(out_pkl, "wb") as f:
        pickle.dump({"size": (SX, SY, SZ), "blocks": blocks, "offset": 0, "origen": (OX, OY, OZ)}, f)
    if len(sys.argv) > 3:
        plano_png(sys.argv[3])
    tipos = Counter(t for (_, _, t) in escondites)
    print(f"escuela: {len(blocks)} bloques, paleta {len(palette)}, {len(raw) // 1024} KB sin comprimir; "
          f"{len(escondites)} escondites {dict(tipos)}, {len(rondas)} lugares de ronda; se llega a todos desde el hall ({len(alcanzables)} lugares)")
    for (nombre, (vx0, vz0, vx1, vz1), _, _, (fx, fz)) in SALIDAS:
        assert (fx, Y0, fz) in alcanzables, ("no se llega al frente de la salida", nombre)
