#!/usr/bin/env python3
"""Stubs mínimos de las APIs usadas, solo para chequear que el Java compila sin errores tontos.
(Reflejan las firmas de Minecraft 1.21.1 / NeoForge 21.1 que usa el mod.)"""
import os
import sys

S = {
# ---------------------------------------------------------------- utilidades y logging
"javax.annotation.Nullable": "@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.CLASS) public @interface Nullable {}",
"com.mojang.logging.LogUtils": "public class LogUtils { public static org.slf4j.Logger getLogger() { return null; } }",
"org.slf4j.Logger": "public interface Logger { void info(String s, Object... a); void error(String s, Object... a); }",
"net.minecraft.Util": "public class Util { public static <T> T make(T t, java.util.function.Consumer<? super T> c) { return t; } }",
"net.minecraft.util.RandomSource": "public interface RandomSource { int nextInt(int n); boolean nextBoolean(); float nextFloat(); }",
"net.minecraft.util.datafix.DataFixTypes": "public enum DataFixTypes { LEVEL }",
# ---------------------------------------------------------------- bus de eventos y carga del mod
"net.neoforged.bus.api.Event": "public abstract class Event {}",
"net.neoforged.bus.api.IEventBus": "public interface IEventBus { <T extends Event> void addListener(java.util.function.Consumer<T> c); }",
"net.neoforged.bus.api.SubscribeEvent": "@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) public @interface SubscribeEvent {}",
"net.neoforged.api.distmarker.Dist": "public enum Dist { CLIENT, DEDICATED_SERVER }",
"net.neoforged.fml.ModContainer": "public abstract class ModContainer {}",
"net.neoforged.fml.common.Mod": "@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) public @interface Mod { String value(); }",
"net.neoforged.fml.common.EventBusSubscriber": "@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) public @interface EventBusSubscriber { String modid() default \"\"; Bus bus() default Bus.GAME; net.neoforged.api.distmarker.Dist[] value() default {}; enum Bus { GAME, MOD } }",
"net.neoforged.neoforge.common.NeoForge": "public class NeoForge { public static final net.neoforged.bus.api.IEventBus EVENT_BUS = null; }",
"net.neoforged.neoforge.event.RegisterCommandsEvent": "public class RegisterCommandsEvent extends net.neoforged.bus.api.Event { public com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack> getDispatcher() { return null; } }",
"net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent": "public class EntityAttributeCreationEvent extends net.neoforged.bus.api.Event { public void put(net.minecraft.world.entity.EntityType<? extends net.minecraft.world.entity.LivingEntity> t, net.minecraft.world.entity.ai.attributes.AttributeSupplier a) {} }",
"net.neoforged.neoforge.client.event.EntityRenderersEvent": "public abstract class EntityRenderersEvent extends net.neoforged.bus.api.Event { public static class RegisterRenderers extends EntityRenderersEvent { public <T extends net.minecraft.world.entity.Entity> void registerEntityRenderer(net.minecraft.world.entity.EntityType<? extends T> t, net.minecraft.client.renderer.entity.EntityRendererProvider<T> p) {} } }",
# ---------------------------------------------------------------- comandos (brigadier)
"com.mojang.brigadier.CommandDispatcher": "public class CommandDispatcher<S> { public Object register(com.mojang.brigadier.builder.LiteralArgumentBuilder<S> b) { return null; } }",
"com.mojang.brigadier.Command": "@FunctionalInterface public interface Command<S> { int run(com.mojang.brigadier.context.CommandContext<S> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException; }",
"com.mojang.brigadier.context.CommandContext": "public class CommandContext<S> { public S getSource() { return null; } }",
"com.mojang.brigadier.exceptions.CommandSyntaxException": "public class CommandSyntaxException extends Exception { private static final long serialVersionUID = 1L; }",
"com.mojang.brigadier.arguments.ArgumentType": "public interface ArgumentType<T> {}",
"com.mojang.brigadier.arguments.IntegerArgumentType": "public class IntegerArgumentType implements ArgumentType<Integer> { public static IntegerArgumentType integer(int a, int b) { return null; } public static int getInteger(com.mojang.brigadier.context.CommandContext<?> c, String n) { return 0; } }",
"com.mojang.brigadier.builder.ArgumentBuilder": "public abstract class ArgumentBuilder<S, T extends ArgumentBuilder<S, T>> { public T then(ArgumentBuilder<S, ?> a) { return null; } public T executes(com.mojang.brigadier.Command<S> c) { return null; } public T requires(java.util.function.Predicate<S> p) { return null; } }",
"com.mojang.brigadier.builder.LiteralArgumentBuilder": "public class LiteralArgumentBuilder<S> extends ArgumentBuilder<S, LiteralArgumentBuilder<S>> {}",
"com.mojang.brigadier.builder.RequiredArgumentBuilder": "public class RequiredArgumentBuilder<S, T> extends ArgumentBuilder<S, RequiredArgumentBuilder<S, T>> {}",
"net.minecraft.commands.Commands": "public class Commands { public static com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> literal(String s) { return null; } public static <T> com.mojang.brigadier.builder.RequiredArgumentBuilder<CommandSourceStack, T> argument(String n, com.mojang.brigadier.arguments.ArgumentType<T> t) { return null; } }",
"net.minecraft.commands.CommandSourceStack": "public class CommandSourceStack { public boolean hasPermission(int l) { return true; } public net.minecraft.server.level.ServerPlayer getPlayerOrException() throws com.mojang.brigadier.exceptions.CommandSyntaxException { return null; } public net.minecraft.server.MinecraftServer getServer() { return null; } public void sendSuccess(java.util.function.Supplier<net.minecraft.network.chat.Component> s, boolean b) {} public void sendFailure(net.minecraft.network.chat.Component c) {} }",
# ---------------------------------------------------------------- texto
"net.minecraft.ChatFormatting": "public enum ChatFormatting { WHITE, GRAY, RED, YELLOW, GOLD, AQUA, BLUE, GREEN, LIGHT_PURPLE }",
"net.minecraft.network.chat.Component": "public interface Component { static MutableComponent translatable(String k) { return null; } static MutableComponent translatable(String k, Object... a) { return null; } static MutableComponent literal(String s) { return null; } }",
"net.minecraft.network.chat.MutableComponent": "public class MutableComponent implements Component { public MutableComponent withStyle(net.minecraft.ChatFormatting f) { return this; } public MutableComponent append(Component c) { return this; } }",
# ---------------------------------------------------------------- registros y recursos
"net.minecraft.core.Registry": "public interface Registry<T> {}",
"net.minecraft.core.Holder": "public interface Holder<T> {}",
"net.minecraft.core.HolderLookup": "public interface HolderLookup<T> { interface Provider {} }",
"net.minecraft.core.registries.Registries": "public class Registries { public static final net.minecraft.resources.ResourceKey<net.minecraft.core.Registry<net.minecraft.world.level.Level>> DIMENSION = null; public static final net.minecraft.resources.ResourceKey<net.minecraft.core.Registry<net.minecraft.world.item.CreativeModeTab>> CREATIVE_MODE_TAB = null; public static final net.minecraft.resources.ResourceKey<net.minecraft.core.Registry<net.minecraft.world.entity.EntityType<?>>> ENTITY_TYPE = null; public static final net.minecraft.resources.ResourceKey<net.minecraft.core.Registry<net.minecraft.world.item.ArmorMaterial>> ARMOR_MATERIAL = null; }",
"net.minecraft.resources.ResourceKey": "public class ResourceKey<T> { public static <T> ResourceKey<T> create(ResourceKey<? extends net.minecraft.core.Registry<T>> r, ResourceLocation l) { return null; } public ResourceLocation location() { return null; } }",
"net.minecraft.resources.ResourceLocation": "public class ResourceLocation { public static ResourceLocation fromNamespaceAndPath(String a, String b) { return null; } }",
"net.neoforged.neoforge.registries.DeferredHolder": "public class DeferredHolder<R, T extends R> implements net.minecraft.core.Holder<R>, java.util.function.Supplier<T> { public T get() { return null; } }",
"net.neoforged.neoforge.registries.DeferredItem": "public class DeferredItem<T extends net.minecraft.world.item.Item> extends DeferredHolder<net.minecraft.world.item.Item, T> {}",
"net.neoforged.neoforge.registries.DeferredRegister": "public class DeferredRegister<T> { public static Items createItems(String m) { return null; } public static <T> DeferredRegister<T> create(net.minecraft.resources.ResourceKey<? extends net.minecraft.core.Registry<T>> k, String m) { return null; } public static <T> DeferredRegister<T> create(net.minecraft.core.Registry<T> r, String m) { return null; } public <I extends T> DeferredHolder<T, I> register(String n, java.util.function.Supplier<? extends I> s) { return null; } public void register(net.neoforged.bus.api.IEventBus b) {} public static class Items extends DeferredRegister<net.minecraft.world.item.Item> { @Override public <I extends net.minecraft.world.item.Item> DeferredItem<I> register(String n, java.util.function.Supplier<? extends I> s) { return null; } } }",
"net.neoforged.neoforge.registries.NeoForgeRegistries": "public class NeoForgeRegistries { public static final net.minecraft.core.Registry<net.neoforged.neoforge.attachment.AttachmentType<?>> ATTACHMENT_TYPES = null; }",
"net.neoforged.neoforge.attachment.IAttachmentHolder": "public interface IAttachmentHolder { default <T> T getData(java.util.function.Supplier<AttachmentType<T>> t) { return null; } default <T> T setData(java.util.function.Supplier<AttachmentType<T>> t, T v) { return null; } }",
"net.neoforged.neoforge.attachment.AttachmentType": "public class AttachmentType<T> { public static <T> Builder<T> builder(java.util.function.Supplier<T> s) { return null; } public static class Builder<T> { public Builder<T> serialize(com.mojang.serialization.Codec<T> c) { return this; } public Builder<T> copyOnDeath() { return this; } public AttachmentType<T> build() { return null; } } }",
# ---------------------------------------------------------------- codecs y nbt
"com.mojang.datafixers.util.Function6": "@FunctionalInterface public interface Function6<T1, T2, T3, T4, T5, T6, R> { R apply(T1 a, T2 b, T3 c, T4 d, T5 e, T6 f); }",
"com.mojang.serialization.Codec": "public interface Codec<A> { Codec<Double> DOUBLE = null; Codec<Float> FLOAT = null; default MapCodec<A> fieldOf(String n) { return null; } default MapCodec<java.util.Optional<A>> optionalFieldOf(String n) { return null; } }",
"com.mojang.serialization.MapCodec": "public class MapCodec<A> { public <O> com.mojang.serialization.codecs.RecordCodecBuilder<O, A> forGetter(java.util.function.Function<O, A> g) { return null; } }",
"com.mojang.serialization.codecs.RecordCodecBuilder": "public class RecordCodecBuilder<O, F> { public static <O> com.mojang.serialization.Codec<O> create(java.util.function.Function<Instance<O>, Object> b) { return null; } public static class Instance<O> { public <T1, T2, T3, T4, T5, T6> P6<O, T1, T2, T3, T4, T5, T6> group(RecordCodecBuilder<O, T1> a, RecordCodecBuilder<O, T2> b, RecordCodecBuilder<O, T3> c, RecordCodecBuilder<O, T4> d, RecordCodecBuilder<O, T5> e, RecordCodecBuilder<O, T6> f) { return null; } } public static class P6<O, T1, T2, T3, T4, T5, T6> { public Object apply(Instance<O> i, com.mojang.datafixers.util.Function6<T1, T2, T3, T4, T5, T6, O> f) { return null; } } }",
"net.minecraft.nbt.CompoundTag": "public class CompoundTag { public int getInt(String k) { return 0; } public void putInt(String k, int v) {} public String getString(String k) { return \"\"; } public void putString(String k, String v) {} public boolean contains(String k) { return false; } }",
"net.minecraft.world.level.saveddata.SavedData": "public abstract class SavedData { public abstract net.minecraft.nbt.CompoundTag save(net.minecraft.nbt.CompoundTag t, net.minecraft.core.HolderLookup.Provider r); public void setDirty() {} public record Factory<T extends SavedData>(java.util.function.Supplier<T> constructor, java.util.function.BiFunction<net.minecraft.nbt.CompoundTag, net.minecraft.core.HolderLookup.Provider, T> deserializer, net.minecraft.util.datafix.DataFixTypes type) {} }",
"net.minecraft.world.level.storage.DimensionDataStorage": "public class DimensionDataStorage { public <T extends net.minecraft.world.level.saveddata.SavedData> T computeIfAbsent(net.minecraft.world.level.saveddata.SavedData.Factory<T> f, String n) { return null; } }",
# ---------------------------------------------------------------- mundo
"net.minecraft.core.Vec3i": "public class Vec3i { public int getX() { return 0; } public int getY() { return 0; } public int getZ() { return 0; } }",
"net.minecraft.core.BlockPos": "public class BlockPos extends Vec3i { public BlockPos(int x, int y, int z) {} public BlockPos offset(int x, int y, int z) { return this; } public BlockPos immutable() { return this; } public static Iterable<BlockPos> betweenClosed(BlockPos a, BlockPos b) { return null; } public static BlockPos containing(double x, double y, double z) { return null; } }",
"net.minecraft.world.phys.Vec3": "public class Vec3 { public final double x = 0, y = 0, z = 0; public Vec3(double x, double y, double z) {} public Vec3 add(double a, double b, double c) { return this; } }",
"net.minecraft.world.phys.AABB": "public class AABB { public AABB inflate(double d) { return this; } }",
"net.minecraft.world.DifficultyInstance": "public class DifficultyInstance {}",
"net.minecraft.server.MinecraftServer": "public class MinecraftServer { public net.minecraft.server.level.ServerLevel getLevel(net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> k) { return null; } public net.minecraft.server.level.ServerLevel overworld() { return null; } }",
"net.minecraft.world.level.ServerLevelAccessor": "public interface ServerLevelAccessor { net.minecraft.server.level.ServerLevel getLevel(); }",
"net.minecraft.world.level.Level": "public abstract class Level { public static final com.mojang.serialization.Codec<net.minecraft.resources.ResourceKey<Level>> RESOURCE_KEY_CODEC = null; public net.minecraft.resources.ResourceKey<Level> dimension() { return null; } public boolean isClientSide() { return false; } public net.minecraft.world.level.block.state.BlockState getBlockState(net.minecraft.core.BlockPos p) { return null; } public net.minecraft.core.BlockPos getSharedSpawnPos() { return null; } public Object getChunk(net.minecraft.core.BlockPos p) { return null; } public Object getChunkAt(net.minecraft.core.BlockPos p) { return null; } public net.minecraft.util.RandomSource getRandom() { return null; } public boolean setBlock(net.minecraft.core.BlockPos p, net.minecraft.world.level.block.state.BlockState s, int f) { return true; } public net.minecraft.core.BlockPos getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types t, net.minecraft.core.BlockPos p) { return null; } public net.minecraft.world.entity.player.Player getNearestPlayer(net.minecraft.world.entity.Entity e, double d) { return null; } public <T extends net.minecraft.world.entity.Entity> java.util.List<T> getEntitiesOfClass(Class<T> c, net.minecraft.world.phys.AABB a, java.util.function.Predicate<? super T> p) { return null; } public net.minecraft.world.DifficultyInstance getCurrentDifficultyAt(net.minecraft.core.BlockPos p) { return null; } public boolean addFreshEntity(net.minecraft.world.entity.Entity e) { return true; } public net.minecraft.server.MinecraftServer getServer() { return null; } }",
"net.minecraft.server.level.ServerLevel": "public class ServerLevel extends net.minecraft.world.level.Level implements net.minecraft.world.level.ServerLevelAccessor { public ServerLevel getLevel() { return this; } public net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager getStructureManager() { return null; } public net.minecraft.world.level.storage.DimensionDataStorage getDataStorage() { return null; } public <T extends net.minecraft.core.particles.ParticleOptions> int sendParticles(T t, double x, double y, double z, int n, double dx, double dy, double dz, double s) { return 0; } public <T extends net.minecraft.world.entity.Entity> java.util.List<? extends T> getEntities(net.minecraft.world.level.entity.EntityTypeTest<net.minecraft.world.entity.Entity, T> t, java.util.function.Predicate<? super T> p) { return null; } }",
"net.minecraft.world.level.entity.EntityTypeTest": "public interface EntityTypeTest<B, T extends B> {}",
"net.minecraft.world.level.block.Block": "public class Block { public static final int UPDATE_CLIENTS = 2; public static final int UPDATE_KNOWN_SHAPE = 16; public net.minecraft.world.level.block.state.BlockState defaultBlockState() { return null; } }",
"net.minecraft.world.level.block.Blocks": "public class Blocks { public static final Block AIR = null; }",
"net.minecraft.world.level.block.BedBlock": "public class BedBlock extends Block { public static final net.minecraft.world.level.block.state.properties.EnumProperty<net.minecraft.world.level.block.state.properties.BedPart> PART = null; public static final net.minecraft.world.level.block.state.properties.BooleanProperty OCCUPIED = null; }",
"net.minecraft.world.level.block.state.properties.Property": "public abstract class Property<T> {}",
"net.minecraft.world.level.block.state.properties.EnumProperty": "public class EnumProperty<T> extends Property<T> {}",
"net.minecraft.world.level.block.state.properties.BooleanProperty": "public class BooleanProperty extends Property<Boolean> {}",
"net.minecraft.world.level.block.state.properties.BedPart": "public enum BedPart { HEAD, FOOT }",
"net.minecraft.world.level.block.state.BlockState": "public class BlockState { public boolean isAir() { return true; } public net.minecraft.world.level.block.Block getBlock() { return null; } public <T> T getValue(net.minecraft.world.level.block.state.properties.Property<T> p) { return null; } }",
"net.minecraft.world.level.levelgen.Heightmap": "public class Heightmap { public enum Types { MOTION_BLOCKING_NO_LEAVES } }",
"net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings": "public class StructurePlaceSettings {}",
"net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate": "public class StructureTemplate { public net.minecraft.core.Vec3i getSize() { return null; } public boolean placeInWorld(net.minecraft.world.level.ServerLevelAccessor l, net.minecraft.core.BlockPos a, net.minecraft.core.BlockPos b, StructurePlaceSettings s, net.minecraft.util.RandomSource r, int f) { return true; } }",
"net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager": "public class StructureTemplateManager { public java.util.Optional<StructureTemplate> get(net.minecraft.resources.ResourceLocation l) { return null; } }",
"net.minecraft.world.level.pathfinder.Path": "public class Path {}",
# ---------------------------------------------------------------- red, sonidos, partículas, efectos
"net.minecraft.network.protocol.Packet": "public interface Packet<T> {}",
"net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket": "public class ClientboundSetTitleTextPacket implements net.minecraft.network.protocol.Packet<Object> { public ClientboundSetTitleTextPacket(net.minecraft.network.chat.Component c) {} }",
"net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket": "public class ClientboundSetSubtitleTextPacket implements net.minecraft.network.protocol.Packet<Object> { public ClientboundSetSubtitleTextPacket(net.minecraft.network.chat.Component c) {} }",
"net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket": "public class ClientboundSetTitlesAnimationPacket implements net.minecraft.network.protocol.Packet<Object> { public ClientboundSetTitlesAnimationPacket(int a, int b, int c) {} }",
"net.minecraft.server.network.ServerGamePacketListenerImpl": "public class ServerGamePacketListenerImpl { public void send(net.minecraft.network.protocol.Packet<?> p) {} }",
"net.minecraft.network.syncher.EntityDataSerializer": "public interface EntityDataSerializer<T> {}",
"net.minecraft.network.syncher.EntityDataSerializers": "public class EntityDataSerializers { public static final EntityDataSerializer<Integer> INT = null; }",
"net.minecraft.network.syncher.EntityDataAccessor": "public class EntityDataAccessor<T> {}",
"net.minecraft.network.syncher.SynchedEntityData": "public class SynchedEntityData { public static <T> EntityDataAccessor<T> defineId(Class<? extends net.minecraft.world.entity.Entity> c, EntityDataSerializer<T> s) { return null; } public <T> T get(EntityDataAccessor<T> a) { return null; } public <T> void set(EntityDataAccessor<T> a, T v) {} public static class Builder { public <T> Builder define(EntityDataAccessor<T> a, T v) { return this; } } }",
"net.minecraft.sounds.SoundEvent": "public class SoundEvent {}",
"net.minecraft.sounds.SoundSource": "public enum SoundSource { PLAYERS }",
"net.minecraft.sounds.SoundEvents": "public class SoundEvents { public static final SoundEvent BELL_RESONATE = null; public static final SoundEvent BELL_BLOCK = null; public static final net.minecraft.core.Holder<SoundEvent> ARMOR_EQUIP_LEATHER = null; }",
"net.minecraft.core.particles.ParticleOptions": "public interface ParticleOptions {}",
"net.minecraft.core.particles.SimpleParticleType": "public class SimpleParticleType implements ParticleOptions {}",
"net.minecraft.core.particles.ParticleTypes": "public class ParticleTypes { public static final SimpleParticleType HEART = null, NOTE = null, HAPPY_VILLAGER = null, ANGRY_VILLAGER = null; }",
"net.minecraft.world.effect.MobEffect": "public class MobEffect {}",
"net.minecraft.world.effect.MobEffects": "public class MobEffects { public static final net.minecraft.core.Holder<MobEffect> BLINDNESS = null; }",
"net.minecraft.world.effect.MobEffectInstance": "public class MobEffectInstance { public MobEffectInstance(net.minecraft.core.Holder<MobEffect> e, int d, int a, boolean amb, boolean vis) {} }",
# ---------------------------------------------------------------- entidades
"net.minecraft.world.InteractionHand": "public enum InteractionHand { MAIN_HAND, OFF_HAND }",
"net.minecraft.world.InteractionResultHolder": "public class InteractionResultHolder<T> { public static <T> InteractionResultHolder<T> sidedSuccess(T t, boolean b) { return null; } }",
"net.minecraft.world.damagesource.DamageType": "public class DamageType {}",
"net.minecraft.world.damagesource.DamageTypes": "public class DamageTypes { public static final net.minecraft.resources.ResourceKey<DamageType> CRAMMING = null; }",
"net.minecraft.world.damagesource.DamageSource": "public class DamageSource { public boolean is(net.minecraft.resources.ResourceKey<DamageType> k) { return false; } }",
"net.minecraft.world.entity.Pose": "public enum Pose { STANDING, CROUCHING, SLEEPING }",
"net.minecraft.world.entity.MobCategory": "public enum MobCategory { CREATURE, MONSTER }",
"net.minecraft.world.entity.MobSpawnType": "public enum MobSpawnType { EVENT, SPAWN_EGG }",
"net.minecraft.world.entity.SpawnGroupData": "public interface SpawnGroupData {}",
"net.minecraft.world.entity.EquipmentSlot": "public enum EquipmentSlot { HEAD, CHEST, LEGS, FEET }",
"net.minecraft.world.entity.EntityType": "public class EntityType<T extends Entity> implements net.minecraft.world.level.entity.EntityTypeTest<Entity, T> { public T create(net.minecraft.world.level.Level l) { return null; } public interface EntityFactory<T extends Entity> { T create(EntityType<T> t, net.minecraft.world.level.Level l); } public static class Builder<T extends Entity> { public static <T extends Entity> Builder<T> of(EntityFactory<T> f, MobCategory c) { return null; } public Builder<T> sized(float w, float h) { return this; } public Builder<T> clientTrackingRange(int r) { return this; } public EntityType<T> build(String id) { return null; } } }",
"net.minecraft.world.entity.Entity": "public abstract class Entity implements net.neoforged.neoforge.attachment.IAttachmentHolder { protected final net.minecraft.util.RandomSource random = null; protected final net.minecraft.network.syncher.SynchedEntityData entityData = null; public int tickCount; public net.minecraft.world.level.Level level() { return null; } public double getX() { return 0; } public double getY() { return 0; } public double getZ() { return 0; } public float getYRot() { return 0; } public float getXRot() { return 0; } public net.minecraft.util.RandomSource getRandom() { return null; } public net.minecraft.world.phys.AABB getBoundingBox() { return null; } public double distanceToSqr(Entity e) { return 0; } public net.minecraft.core.BlockPos blockPosition() { return null; } public void discard() {} public boolean onGround() { return true; } public boolean isCrouching() { return false; } public void setPose(Pose p) {} public boolean isAlive() { return true; } public void moveTo(double x, double y, double z, float a, float b) {} public void setCustomName(net.minecraft.network.chat.Component c) {} public void setCustomNameVisible(boolean b) {} public boolean isSpectator() { return false; } public void setSprinting(boolean b) {} public boolean isSprinting() { return false; } protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder b) {} public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag t) {} public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag t) {} }",
"net.minecraft.world.entity.LivingEntity": "public abstract class LivingEntity extends Entity { public boolean addEffect(net.minecraft.world.effect.MobEffectInstance e) { return true; } public boolean isSleeping() { return false; } public void startSleeping(net.minecraft.core.BlockPos p) {} public void stopSleeping() {} public void swing(net.minecraft.world.InteractionHand h) {} public boolean hurt(net.minecraft.world.damagesource.DamageSource s, float a) { return true; } public net.minecraft.world.item.ItemStack getItemBySlot(EquipmentSlot s) { return null; } public void setItemSlot(EquipmentSlot s, net.minecraft.world.item.ItemStack i) {} }",
"net.minecraft.world.entity.Mob": "public abstract class Mob extends LivingEntity { protected final net.minecraft.world.entity.ai.goal.GoalSelector goalSelector = null; protected Mob(EntityType<? extends Mob> t, net.minecraft.world.level.Level l) {} public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createMobAttributes() { return null; } public net.minecraft.world.entity.ai.navigation.PathNavigation getNavigation() { return null; } public net.minecraft.world.entity.ai.control.LookControl getLookControl() { return null; } public net.minecraft.world.entity.ai.control.JumpControl getJumpControl() { return null; } public void setPersistenceRequired() {} protected void registerGoals() {} protected void customServerAiStep() {} public SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor l, net.minecraft.world.DifficultyInstance d, MobSpawnType t, SpawnGroupData g) { return g; } public boolean removeWhenFarAway(double d) { return true; } }",
"net.minecraft.world.entity.PathfinderMob": "public abstract class PathfinderMob extends Mob { protected PathfinderMob(EntityType<? extends PathfinderMob> t, net.minecraft.world.level.Level l) { super(t, l); } }",
"net.minecraft.world.entity.ai.attributes.Attribute": "public class Attribute {}",
"net.minecraft.world.entity.ai.attributes.Attributes": "public class Attributes { public static final net.minecraft.core.Holder<Attribute> MAX_HEALTH = null, MOVEMENT_SPEED = null, FOLLOW_RANGE = null; }",
"net.minecraft.world.entity.ai.attributes.AttributeSupplier": "public class AttributeSupplier { public static class Builder { public Builder add(net.minecraft.core.Holder<Attribute> a, double v) { return this; } public AttributeSupplier build() { return null; } } }",
"net.minecraft.world.entity.ai.goal.Goal": "public abstract class Goal { public abstract boolean canUse(); public boolean canContinueToUse() { return canUse(); } public void start() {} public void stop() {} public void tick() {} public void setFlags(java.util.EnumSet<Flag> f) {} public enum Flag { MOVE, LOOK, JUMP, TARGET } }",
"net.minecraft.world.entity.ai.goal.GoalSelector": "public class GoalSelector { public void addGoal(int p, Goal g) {} }",
"net.minecraft.world.entity.ai.goal.FloatGoal": "public class FloatGoal extends Goal { public FloatGoal(net.minecraft.world.entity.Mob m) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.LookAtPlayerGoal": "public class LookAtPlayerGoal extends Goal { public LookAtPlayerGoal(net.minecraft.world.entity.Mob m, Class<? extends net.minecraft.world.entity.LivingEntity> c, float d) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.OpenDoorGoal": "public class OpenDoorGoal extends Goal { public OpenDoorGoal(net.minecraft.world.entity.Mob m, boolean b) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.RandomLookAroundGoal": "public class RandomLookAroundGoal extends Goal { public RandomLookAroundGoal(net.minecraft.world.entity.Mob m) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal": "public class WaterAvoidingRandomStrollGoal extends Goal { public WaterAvoidingRandomStrollGoal(net.minecraft.world.entity.PathfinderMob m, double s) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.navigation.PathNavigation": "public abstract class PathNavigation { public void stop() {} public boolean moveTo(net.minecraft.world.entity.Entity e, double s) { return true; } public boolean moveTo(double x, double y, double z, double s) { return true; } public boolean moveTo(net.minecraft.world.level.pathfinder.Path p, double s) { return true; } public net.minecraft.world.level.pathfinder.Path createPath(double x, double y, double z, int a) { return null; } public boolean isDone() { return true; } public boolean isInProgress() { return false; } }",
"net.minecraft.world.entity.ai.navigation.GroundPathNavigation": "public class GroundPathNavigation extends PathNavigation { public void setCanOpenDoors(boolean b) {} }",
"net.minecraft.world.entity.ai.control.LookControl": "public class LookControl { public void setLookAt(net.minecraft.world.entity.Entity e, float a, float b) {} }",
"net.minecraft.world.entity.ai.util.DefaultRandomPos": "public class DefaultRandomPos { public static net.minecraft.world.phys.Vec3 getPos(net.minecraft.world.entity.PathfinderMob m, int h, int v) { return null; } }",
"net.minecraft.world.entity.ai.control.JumpControl": "public class JumpControl { public void jump() {} }",
"net.minecraft.world.entity.player.Inventory": "public class Inventory { public boolean add(net.minecraft.world.item.ItemStack s) { return true; } public boolean hasAnyOf(java.util.Set<net.minecraft.world.item.Item> s) { return false; } }",
"net.minecraft.world.entity.player.Player": "public abstract class Player extends net.minecraft.world.entity.LivingEntity { public net.minecraft.world.item.ItemStack getItemInHand(net.minecraft.world.InteractionHand h) { return null; } public net.minecraft.world.item.ItemCooldowns getCooldowns() { return null; } public void displayClientMessage(net.minecraft.network.chat.Component c, boolean b) {} public Inventory getInventory() { return null; } public Object drop(net.minecraft.world.item.ItemStack s, boolean b) { return null; } }",
"net.minecraft.server.level.ServerPlayer": "public class ServerPlayer extends net.minecraft.world.entity.player.Player { public final net.minecraft.server.MinecraftServer server = null; public net.minecraft.server.network.ServerGamePacketListenerImpl connection; public void teleportTo(ServerLevel l, double x, double y, double z, float a, float b) {} public void playNotifySound(net.minecraft.sounds.SoundEvent s, net.minecraft.sounds.SoundSource src, float v, float p) {} public void sendSystemMessage(net.minecraft.network.chat.Component c) {} }",
# ---------------------------------------------------------------- objetos
"net.minecraft.world.level.ItemLike": "public interface ItemLike {}",
"net.minecraft.world.item.ItemStack": "public class ItemStack { public ItemStack(net.minecraft.world.level.ItemLike i) {} public boolean isEmpty() { return true; } }",
"net.minecraft.world.item.TooltipFlag": "public interface TooltipFlag {}",
"net.minecraft.world.item.Rarity": "public enum Rarity { COMMON, UNCOMMON, RARE, EPIC }",
"net.minecraft.world.item.ItemCooldowns": "public class ItemCooldowns { public void addCooldown(Item i, int t) {} }",
"net.minecraft.world.item.Item": "public class Item implements net.minecraft.world.level.ItemLike { public Item(Properties p) {} public static class Properties { public Properties stacksTo(int n) { return this; } public Properties rarity(Rarity r) { return this; } } public interface TooltipContext {} public net.minecraft.world.InteractionResultHolder<ItemStack> use(net.minecraft.world.level.Level l, net.minecraft.world.entity.player.Player p, net.minecraft.world.InteractionHand h) { return null; } public boolean isFoil(ItemStack s) { return false; } public void appendHoverText(ItemStack s, TooltipContext c, java.util.List<net.minecraft.network.chat.Component> l, TooltipFlag f) {} public ItemStack getDefaultInstance() { return null; } }",
"net.minecraft.world.item.Items": "public class Items { public static final Item BLACK_WOOL = null; }",
"net.minecraft.world.item.SpawnEggItem": "public class SpawnEggItem extends Item { public SpawnEggItem(Properties p) { super(p); } }",
"net.neoforged.neoforge.common.DeferredSpawnEggItem": "public class DeferredSpawnEggItem extends net.minecraft.world.item.SpawnEggItem { public DeferredSpawnEggItem(java.util.function.Supplier<? extends net.minecraft.world.entity.EntityType<? extends net.minecraft.world.entity.Mob>> t, int a, int b, Properties p) { super(p); } }",
"net.minecraft.world.item.ArmorItem": "public class ArmorItem extends Item { public ArmorItem(net.minecraft.core.Holder<ArmorMaterial> m, Type t, Properties p) { super(p); } public enum Type { HELMET, CHESTPLATE, LEGGINGS, BOOTS, BODY } }",
"net.minecraft.world.item.ArmorMaterial": "public record ArmorMaterial(java.util.Map<ArmorItem.Type, Integer> defense, int enchantmentValue, net.minecraft.core.Holder<net.minecraft.sounds.SoundEvent> equipSound, java.util.function.Supplier<net.minecraft.world.item.crafting.Ingredient> repairIngredient, java.util.List<ArmorMaterial.Layer> layers, float toughness, float knockbackResistance) { public static final class Layer { public Layer(net.minecraft.resources.ResourceLocation id) {} } }",
"net.minecraft.world.item.crafting.Ingredient": "public class Ingredient { public static Ingredient of(net.minecraft.world.level.ItemLike... i) { return null; } }",
"net.minecraft.world.item.CreativeModeTab": "public class CreativeModeTab { public static Builder builder() { return null; } public static class Builder { public Builder title(net.minecraft.network.chat.Component c) { return this; } @SafeVarargs public final Builder withTabsBefore(net.minecraft.resources.ResourceKey<CreativeModeTab>... t) { return this; } public Builder icon(java.util.function.Supplier<ItemStack> s) { return this; } public Builder displayItems(DisplayItemsGenerator g) { return this; } public CreativeModeTab build() { return null; } } public interface DisplayItemsGenerator { void accept(ItemDisplayParameters p, Output o); } public static class ItemDisplayParameters {} public interface Output { void accept(net.minecraft.world.level.ItemLike i); } }",
"net.minecraft.world.item.CreativeModeTabs": "public class CreativeModeTabs { public static final net.minecraft.resources.ResourceKey<CreativeModeTab> COMBAT = null; }",
# ---------------------------------------------------------------- cliente: renderizado
"com.mojang.blaze3d.vertex.PoseStack": "public class PoseStack {}",
"net.minecraft.client.renderer.MultiBufferSource": "public interface MultiBufferSource {}",
"net.minecraft.client.model.geom.ModelPart": "public class ModelPart {}",
"net.minecraft.client.model.geom.ModelLayerLocation": "public class ModelLayerLocation {}",
"net.minecraft.client.model.geom.ModelLayers": "public class ModelLayers { public static final ModelLayerLocation PLAYER = null; }",
"net.minecraft.client.model.EntityModel": "public abstract class EntityModel<T extends net.minecraft.world.entity.Entity> {}",
"net.minecraft.client.model.HumanoidModel": "public class HumanoidModel<T extends net.minecraft.world.entity.LivingEntity> extends EntityModel<T> { public boolean crouching; public HumanoidModel(net.minecraft.client.model.geom.ModelPart p) {} }",
"net.minecraft.client.model.PlayerModel": "public class PlayerModel<T extends net.minecraft.world.entity.LivingEntity> extends HumanoidModel<T> { public PlayerModel(net.minecraft.client.model.geom.ModelPart p, boolean slim) { super(p); } }",
"net.minecraft.client.renderer.entity.EntityRendererProvider": "@FunctionalInterface public interface EntityRendererProvider<T extends net.minecraft.world.entity.Entity> { EntityRenderer<T> create(Context c); class Context { public net.minecraft.client.model.geom.ModelPart bakeLayer(net.minecraft.client.model.geom.ModelLayerLocation l) { return null; } } }",
"net.minecraft.client.renderer.entity.EntityRenderer": "public abstract class EntityRenderer<T extends net.minecraft.world.entity.Entity> { public abstract net.minecraft.resources.ResourceLocation getTextureLocation(T e); public net.minecraft.world.phys.Vec3 getRenderOffset(T e, float p) { return null; } public void render(T e, float a, float b, com.mojang.blaze3d.vertex.PoseStack p, net.minecraft.client.renderer.MultiBufferSource m, int l) {} }",
"net.minecraft.client.renderer.entity.LivingEntityRenderer": "public abstract class LivingEntityRenderer<T extends net.minecraft.world.entity.LivingEntity, M extends net.minecraft.client.model.EntityModel<T>> extends EntityRenderer<T> { protected M model; @Override public void render(T e, float a, float b, com.mojang.blaze3d.vertex.PoseStack p, net.minecraft.client.renderer.MultiBufferSource m, int l) {} }",
"net.minecraft.client.renderer.entity.MobRenderer": "public abstract class MobRenderer<T extends net.minecraft.world.entity.Mob, M extends net.minecraft.client.model.EntityModel<T>> extends LivingEntityRenderer<T, M> {}",
"net.minecraft.client.renderer.entity.HumanoidMobRenderer": "public abstract class HumanoidMobRenderer<T extends net.minecraft.world.entity.Mob, M extends net.minecraft.client.model.HumanoidModel<T>> extends MobRenderer<T, M> { public HumanoidMobRenderer(EntityRendererProvider.Context c, M m, float s) { this.model = m; } }",
}


# ================================================================ guardias, armas y balas
def agregar(fq, miembros):
    cuerpo = S[fq].rstrip()
    assert cuerpo.endswith("}"), fq
    S[fq] = cuerpo[:-1] + " " + miembros + " }"

def reemplazar(fq, viejo, nuevo):
    assert viejo in S[fq], (fq, viejo)
    S[fq] = S[fq].replace(viejo, nuevo)

reemplazar("net.minecraft.ChatFormatting", "WHITE, GRAY,", "WHITE, GRAY, DARK_GRAY,")
reemplazar("net.minecraft.world.entity.MobCategory", "CREATURE, MONSTER", "CREATURE, MONSTER, MISC")
reemplazar("net.minecraft.world.entity.EquipmentSlot", "HEAD, CHEST, LEGS, FEET", "MAINHAND, OFFHAND, HEAD, CHEST, LEGS, FEET")
agregar("net.minecraft.world.entity.Entity",
    "public int invulnerableTime; public net.minecraft.world.phys.Vec3 position() { return null; } "
    "public net.minecraft.world.phys.Vec3 getEyePosition() { return null; } public net.minecraft.world.phys.Vec3 getLookAngle() { return null; } "
    "public double getEyeY() { return 0; } public double getY(double f) { return 0; } "
    "public boolean hurt(net.minecraft.world.damagesource.DamageSource s, float a) { return true; } "
    "public net.minecraft.world.damagesource.DamageSources damageSources() { return null; } "
    "public boolean isAlliedTo(Entity e) { return false; } public void tick() {}")
agregar("net.minecraft.world.entity.LivingEntity",
    "public net.minecraft.world.item.ItemStack getMainHandItem() { return null; } public net.minecraft.world.item.ItemStack getOffhandItem() { return null; } "
    "public void setHealth(float v) {} public float getMaxHealth() { return 20; } "
    "public net.minecraft.world.entity.ai.attributes.AttributeInstance getAttribute(net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> a) { return null; } "
    "public boolean canAttack(LivingEntity e) { return true; } public boolean canBeSeenAsEnemy() { return true; } "
    "public HumanoidArm getMainArm() { return HumanoidArm.RIGHT; }")
agregar("net.minecraft.world.entity.Mob",
    "protected final net.minecraft.world.entity.ai.goal.GoalSelector targetSelector = null; "
    "public LivingEntity getTarget() { return null; } public void setTarget(LivingEntity e) {} "
    "public void setAggressive(boolean b) {} public boolean isAggressive() { return false; } "
    "public void setDropChance(EquipmentSlot s, float c) {} public net.minecraft.world.entity.ai.sensing.Sensing getSensing() { return null; }")
agregar("net.minecraft.world.entity.player.Player", "public Abilities getAbilities() { return null; }")
agregar("net.minecraft.world.entity.player.Inventory", "public int getContainerSize() { return 41; } public net.minecraft.world.item.ItemStack getItem(int i) { return null; }")
agregar("net.minecraft.world.level.Level",
    "public void playSound(net.minecraft.world.entity.player.Player p, double x, double y, double z, net.minecraft.sounds.SoundEvent s, net.minecraft.sounds.SoundSource c, float v, float t) {} "
    "public <T extends net.minecraft.world.entity.Entity> java.util.List<T> getEntitiesOfClass(Class<T> c, net.minecraft.world.phys.AABB a) { return null; }")
reemplazar("net.minecraft.world.item.Item", "public Properties rarity(Rarity r) { return this; }",
    "public Properties rarity(Rarity r) { return this; } public Properties attributes(net.minecraft.world.item.component.ItemAttributeModifiers m) { return this; }")
agregar("net.minecraft.world.item.ItemStack",
    "public static final ItemStack EMPTY = null; public boolean is(Item i) { return false; } public void shrink(int n) {} public Item getItem() { return null; }")
agregar("net.minecraft.world.phys.Vec3", "public Vec3 add(Vec3 v) { return this; } public Vec3 scale(double f) { return this; }")
agregar("net.minecraft.world.phys.AABB", "public AABB inflate(double x, double y, double z) { return this; }")
reemplazar("net.minecraft.sounds.SoundEvents", "public static final SoundEvent BELL_BLOCK = null;",
    "public static final SoundEvent BELL_BLOCK = null; public static final SoundEvent FIREWORK_ROCKET_BLAST = null; public static final SoundEvent DISPENSER_FAIL = null;")
reemplazar("net.minecraft.core.particles.ParticleTypes", "ANGRY_VILLAGER = null;", "ANGRY_VILLAGER = null, SMOKE = null;")
reemplazar("net.minecraft.world.entity.ai.attributes.Attributes", "FOLLOW_RANGE = null;", "FOLLOW_RANGE = null, ATTACK_DAMAGE = null, ARMOR = null;")
agregar("net.minecraft.nbt.CompoundTag",
    "public void putDouble(String k, double v) {} public double getDouble(String k) { return 0; } public void putFloat(String k, float v) {} public float getFloat(String k) { return 0; }")
agregar("net.minecraft.world.entity.ai.goal.GoalSelector", "public void removeGoal(Goal g) {}")
agregar("net.minecraft.world.InteractionResultHolder",
    "public static <T> InteractionResultHolder<T> fail(T t) { return null; } public static <T> InteractionResultHolder<T> consume(T t) { return null; }")
reemplazar("net.minecraft.world.entity.EntityType", "public Builder<T> clientTrackingRange(int r) { return this; }",
    "public Builder<T> clientTrackingRange(int r) { return this; } public Builder<T> updateInterval(int r) { return this; }")
reemplazar("net.neoforged.neoforge.registries.DeferredRegister",
    "public static class Items extends DeferredRegister<net.minecraft.world.item.Item> {",
    "public static class Items extends DeferredRegister<net.minecraft.world.item.Item> { public DeferredItem<net.minecraft.world.item.Item> registerSimpleItem(String n) { return null; }")
agregar("net.minecraft.commands.CommandSourceStack",
    "public net.minecraft.server.level.ServerLevel getLevel() { return null; } public net.minecraft.world.phys.Vec3 getPosition() { return null; } public net.minecraft.world.phys.Vec2 getRotation() { return null; }")
agregar("net.minecraft.world.damagesource.DamageSource", "public net.minecraft.world.entity.Entity getEntity() { return null; }")
reemplazar("net.minecraft.client.model.HumanoidModel", "public boolean crouching;",
    "public boolean crouching; public ArmPose leftArmPose; public ArmPose rightArmPose; public enum ArmPose { EMPTY, ITEM, BLOCK, BOW_AND_ARROW, THROW_SPEAR, CROSSBOW_CHARGE, CROSSBOW_HOLD, SPYGLASS, TOOT_HORN, BRUSH }")

S.update({
"net.minecraft.world.phys.Vec2": "public class Vec2 { public final float x = 0, y = 0; }",
"net.minecraft.world.entity.HumanoidArm": "public enum HumanoidArm { LEFT, RIGHT }",
"net.minecraft.world.entity.player.Abilities": "public class Abilities { public boolean instabuild; }",
"net.minecraft.world.damagesource.DamageSources": "public class DamageSources { public DamageSource mobProjectile(net.minecraft.world.entity.Entity p, net.minecraft.world.entity.LivingEntity t) { return null; } }",
"net.minecraft.world.phys.HitResult": "public abstract class HitResult {}",
"net.minecraft.world.phys.EntityHitResult": "public class EntityHitResult extends HitResult { public net.minecraft.world.entity.Entity getEntity() { return null; } }",
"net.minecraft.world.entity.projectile.ItemSupplier": "public interface ItemSupplier { net.minecraft.world.item.ItemStack getItem(); }",
"net.minecraft.world.entity.projectile.Projectile": "public abstract class Projectile extends net.minecraft.world.entity.Entity { public void shoot(double x, double y, double z, float v, float i) {} public net.minecraft.world.entity.Entity getOwner() { return null; } protected boolean canHitEntity(net.minecraft.world.entity.Entity e) { return true; } protected void onHitEntity(net.minecraft.world.phys.EntityHitResult r) {} protected void onHit(net.minecraft.world.phys.HitResult r) {} protected double getDefaultGravity() { return 0; } }",
"net.minecraft.world.entity.projectile.ThrowableProjectile": "public abstract class ThrowableProjectile extends Projectile { @Override protected double getDefaultGravity() { return 0.03; } }",
"net.minecraft.world.entity.projectile.ThrowableItemProjectile": "public abstract class ThrowableItemProjectile extends ThrowableProjectile implements ItemSupplier { public ThrowableItemProjectile(net.minecraft.world.entity.EntityType<? extends ThrowableItemProjectile> t, net.minecraft.world.level.Level l) {} public ThrowableItemProjectile(net.minecraft.world.entity.EntityType<? extends ThrowableItemProjectile> t, net.minecraft.world.entity.LivingEntity s, net.minecraft.world.level.Level l) {} protected abstract net.minecraft.world.item.Item getDefaultItem(); public net.minecraft.world.item.ItemStack getItem() { return null; } }",
"net.minecraft.world.entity.monster.Enemy": "public interface Enemy {}",
"net.minecraft.world.entity.monster.RangedAttackMob": "public interface RangedAttackMob { void performRangedAttack(net.minecraft.world.entity.LivingEntity t, float f); }",
"net.minecraft.world.entity.ai.sensing.Sensing": "public class Sensing { public boolean hasLineOfSight(net.minecraft.world.entity.Entity e) { return true; } }",
"net.minecraft.world.entity.ai.attributes.AttributeInstance": "public class AttributeInstance { public void setBaseValue(double v) {} }",
"net.minecraft.world.entity.ai.goal.MeleeAttackGoal": "public class MeleeAttackGoal extends Goal { public MeleeAttackGoal(net.minecraft.world.entity.PathfinderMob m, double s, boolean b) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.RangedAttackGoal": "public class RangedAttackGoal extends Goal { public RangedAttackGoal(net.minecraft.world.entity.monster.RangedAttackMob m, double s, int i, float r) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.RandomStrollGoal": "public class RandomStrollGoal extends Goal { public RandomStrollGoal(net.minecraft.world.entity.PathfinderMob m, double s, int i) {} public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.target.TargetGoal": "public abstract class TargetGoal extends net.minecraft.world.entity.ai.goal.Goal {}",
"net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal": "public class HurtByTargetGoal extends TargetGoal { public HurtByTargetGoal(net.minecraft.world.entity.PathfinderMob m, Class<?>... ignorar) {} public HurtByTargetGoal setAlertOthers(Class<?>... tipos) { return this; } public boolean canUse() { return false; } }",
"net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal": "public class NearestAttackableTargetGoal<T extends net.minecraft.world.entity.LivingEntity> extends TargetGoal { public NearestAttackableTargetGoal(net.minecraft.world.entity.Mob m, Class<T> c, int i, boolean ver, boolean llegar, java.util.function.Predicate<net.minecraft.world.entity.LivingEntity> p) {} public boolean canUse() { return false; } }",
"net.minecraft.world.item.Tier": "public interface Tier {}",
"net.minecraft.world.item.Tiers": "public enum Tiers implements Tier { WOOD, STONE, IRON, DIAMOND, GOLD, NETHERITE }",
"net.minecraft.world.item.component.ItemAttributeModifiers": "public record ItemAttributeModifiers(java.util.List<Object> modifiers, boolean showInTooltip) {}",
"net.minecraft.world.item.SwordItem": "public class SwordItem extends Item { public SwordItem(Tier t, Properties p) { super(p); } public static net.minecraft.world.item.component.ItemAttributeModifiers createAttributes(Tier t, int d, float s) { return null; } }",
"net.minecraft.client.renderer.entity.ThrownItemRenderer": "public class ThrownItemRenderer<T extends net.minecraft.world.entity.Entity & net.minecraft.world.entity.projectile.ItemSupplier> extends EntityRenderer<T> { public ThrownItemRenderer(EntityRendererProvider.Context c, float s, boolean b) {} public ThrownItemRenderer(EntityRendererProvider.Context c) {} public net.minecraft.resources.ResourceLocation getTextureLocation(T e) { return null; } }",
"net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent": "public class LivingIncomingDamageEvent extends net.neoforged.bus.api.Event { public net.minecraft.world.entity.LivingEntity getEntity() { return null; } public net.minecraft.world.damagesource.DamageSource getSource() { return null; } }",
})


# ================================================================ ceremonia y calendario
reemplazar("net.minecraft.sounds.SoundSource", "PLAYERS", "PLAYERS, BLOCKS")
reemplazar("net.minecraft.sounds.SoundEvents", "public static final SoundEvent DISPENSER_FAIL = null;",
    "public static final SoundEvent DISPENSER_FAIL = null; public static final SoundEvent PISTON_EXTEND = null, PISTON_CONTRACT = null, IRON_DOOR_OPEN = null, IRON_DOOR_CLOSE = null;")
reemplazar("net.minecraft.world.level.block.Blocks", "public static final Block AIR = null;",
    "public static final Block AIR = null, IRON_BLOCK = null, POLISHED_BLACKSTONE = null;")
agregar("net.minecraft.world.level.Level", "public long getDayTime() { return 0; } public boolean isLoaded(net.minecraft.core.BlockPos p) { return true; }")
agregar("net.minecraft.server.level.ServerLevel", "public java.util.List<ServerPlayer> players() { return null; }")
agregar("net.minecraft.server.MinecraftServer", "public int getTickCount() { return 0; }")
agregar("net.minecraft.world.entity.Entity", "public void teleportTo(double x, double y, double z) {} public double distanceToSqr(net.minecraft.world.phys.Vec3 v) { return 0; }")
agregar("net.minecraft.world.entity.ai.control.LookControl", "public void setLookAt(double x, double y, double z) {}")
agregar("net.minecraft.nbt.CompoundTag", "public void putLong(String k, long v) {} public long getLong(String k) { return 0; } public void putBoolean(String k, boolean v) {} public boolean getBoolean(String k) { return false; }")
agregar("net.minecraft.world.phys.AABB", "public AABB(double a, double b, double c, double d, double e, double f) {}")
reemplazar("net.minecraft.network.chat.Component", "static MutableComponent literal(String s) { return null; }",
    "static MutableComponent literal(String s) { return null; } static MutableComponent empty() { return null; }")
S.update({
"net.neoforged.neoforge.event.tick.ServerTickEvent": "public abstract class ServerTickEvent extends net.neoforged.bus.api.Event { public net.minecraft.server.MinecraftServer getServer() { return null; } public boolean hasTime() { return true; } public static class Pre extends ServerTickEvent {} public static class Post extends ServerTickEvent {} }",
"net.neoforged.neoforge.event.server.ServerStoppedEvent": "public class ServerStoppedEvent extends net.neoforged.bus.api.Event { public net.minecraft.server.MinecraftServer getServer() { return null; } }",
})


# ================================================================ guardias quietos
agregar("net.minecraft.world.entity.Entity", "public boolean isPushable() { return true; }")


# ================================================================ noche y portales
reemplazar("net.minecraft.ChatFormatting", "WHITE, GRAY, DARK_GRAY,", "WHITE, GRAY, DARK_GRAY, DARK_AQUA,")
reemplazar("net.minecraft.sounds.SoundSource", "PLAYERS, BLOCKS", "PLAYERS, BLOCKS, AMBIENT")
reemplazar("net.minecraft.sounds.SoundEvents", "public static final SoundEvent DISPENSER_FAIL = null;",
    "public static final SoundEvent DISPENSER_FAIL = null; public static final SoundEvent BEACON_ACTIVATE = null, BEACON_DEACTIVATE = null, ENDERMAN_TELEPORT = null;")
reemplazar("net.minecraft.core.particles.ParticleTypes", "SMOKE = null;", "SMOKE = null, END_ROD = null;")
reemplazar("net.minecraft.world.level.block.Blocks", "public static final Block AIR = null, IRON_BLOCK = null, POLISHED_BLACKSTONE = null;",
    "public static final Block AIR = null, IRON_BLOCK = null, POLISHED_BLACKSTONE = null, WAXED_COPPER_BULB = null, LANTERN = null, SOUL_LANTERN = null, BARRIER = null, POLISHED_ANDESITE = null, SEA_LANTERN = null;")
S["net.minecraft.world.level.block.state.BlockBehaviour"] = ("public abstract class BlockBehaviour { "
    "protected void entityInside(net.minecraft.world.level.block.state.BlockState s, net.minecraft.world.level.Level l, net.minecraft.core.BlockPos p, net.minecraft.world.entity.Entity e) {} "
    "protected boolean skipRendering(net.minecraft.world.level.block.state.BlockState s, net.minecraft.world.level.block.state.BlockState v, net.minecraft.core.Direction d) { return false; } "
    "public static class Properties { public static Properties of() { return null; } public Properties noCollission() { return this; } public Properties noOcclusion() { return this; } "
    "public Properties strength(float a, float b) { return this; } public Properties noLootTable() { return this; } "
    "public Properties lightLevel(java.util.function.ToIntFunction<net.minecraft.world.level.block.state.BlockState> f) { return this; } "
    "public Properties sound(net.minecraft.world.level.block.SoundType t) { return this; } public Properties pushReaction(net.minecraft.world.level.material.PushReaction r) { return this; } } }")
S["net.minecraft.world.level.block.Block"] = ("public class Block extends net.minecraft.world.level.block.state.BlockBehaviour implements net.minecraft.world.level.ItemLike { "
    "public static final int UPDATE_CLIENTS = 2; public static final int UPDATE_KNOWN_SHAPE = 16; "
    "protected final net.minecraft.world.level.block.state.StateDefinition<Block, net.minecraft.world.level.block.state.BlockState> stateDefinition = null; "
    "public Block() {} public Block(Properties p) {} "
    "public net.minecraft.world.level.block.state.BlockState defaultBlockState() { return null; } "
    "protected final void registerDefaultState(net.minecraft.world.level.block.state.BlockState s) {} "
    "protected void createBlockStateDefinition(net.minecraft.world.level.block.state.StateDefinition.Builder<Block, net.minecraft.world.level.block.state.BlockState> b) {} "
    "public void animateTick(net.minecraft.world.level.block.state.BlockState s, net.minecraft.world.level.Level l, net.minecraft.core.BlockPos p, net.minecraft.util.RandomSource r) {} }")
S["net.minecraft.world.level.block.state.StateDefinition"] = ("public class StateDefinition<O, S> { public S any() { return null; } "
    "public static class Builder<O, S> { public Builder<O, S> add(net.minecraft.world.level.block.state.properties.Property<?>... p) { return this; } } }")
reemplazar("net.minecraft.world.level.block.state.BlockState", "public boolean isAir() { return true; }",
    "public boolean isAir() { return true; } public <T extends Comparable<T>, V extends T> BlockState setValue(net.minecraft.world.level.block.state.properties.Property<T> p, V v) { return this; } "
    "public boolean is(net.minecraft.world.level.block.Block b) { return false; }")
S["net.minecraft.world.level.block.state.properties.Property"] = "public abstract class Property<T extends Comparable<T>> {}"
S["net.minecraft.world.level.block.state.properties.EnumProperty"] = "public class EnumProperty<T extends Enum<T>> extends Property<T> {}"
S["net.minecraft.world.level.block.state.properties.BooleanProperty"] = "public class BooleanProperty extends Property<Boolean> { public static BooleanProperty create(String n) { return null; } }"
S["net.minecraft.world.level.block.state.properties.IntegerProperty"] = "public class IntegerProperty extends Property<Integer> { public static IntegerProperty create(String n, int a, int b) { return null; } }"
S["net.minecraft.world.level.block.state.properties.BlockStateProperties"] = "public class BlockStateProperties { public static final BooleanProperty LIT = null; }"
S["net.minecraft.world.level.block.LanternBlock"] = "public class LanternBlock extends Block { public static final net.minecraft.world.level.block.state.properties.BooleanProperty HANGING = null; }"
S["net.minecraft.world.level.block.SoundType"] = "public class SoundType { public static final SoundType GLASS = null, WOOD = null; }"
S["net.minecraft.world.level.material.PushReaction"] = "public enum PushReaction { NORMAL, DESTROY, BLOCK, IGNORE, PUSH_ONLY }"
S["net.minecraft.core.Direction"] = "public enum Direction { DOWN, UP, NORTH, SOUTH, WEST, EAST }"
S["net.neoforged.neoforge.registries.DeferredBlock"] = "public class DeferredBlock<T extends net.minecraft.world.level.block.Block> extends DeferredHolder<net.minecraft.world.level.block.Block, T> {}"
reemplazar("net.neoforged.neoforge.registries.DeferredRegister", "public static Items createItems(String m) { return null; }",
    "public static Items createItems(String m) { return null; } public static Blocks createBlocks(String m) { return null; } "
    "public static class Blocks extends DeferredRegister<net.minecraft.world.level.block.Block> { @Override public <B extends net.minecraft.world.level.block.Block> DeferredBlock<B> register(String n, java.util.function.Supplier<? extends B> s) { return null; } }")
agregar("net.minecraft.world.level.Level",
    "public long getGameTime() { return 0; } "
    "public void addParticle(net.minecraft.core.particles.ParticleOptions o, double x, double y, double z, double a, double b, double c) {} "
    "public void playSound(net.minecraft.world.entity.player.Player p, net.minecraft.core.BlockPos pos, net.minecraft.sounds.SoundEvent s, net.minecraft.sounds.SoundSource c, float v, float t) {}")
agregar("net.minecraft.server.level.ServerLevel", "public void setDayTime(long t) {}")
agregar("net.minecraft.server.level.ServerPlayer", "public ServerLevel serverLevel() { return null; }")
agregar("net.minecraft.world.entity.Entity", "public java.util.UUID getUUID() { return null; } public int getId() { return 0; } public double distanceToSqr(double x, double y, double z) { return 0; }")
agregar("net.minecraft.core.BlockPos", "public static Iterable<BlockPos> betweenClosed(int a, int b, int c, int d, int e, int f) { return null; }")
reemplazar("net.minecraft.world.entity.player.Player", "public abstract class Player extends net.minecraft.world.entity.LivingEntity {",
    "public abstract class Player extends net.minecraft.world.entity.LivingEntity { public enum BedSleepingProblem { NOT_POSSIBLE_HERE, NOT_POSSIBLE_NOW, TOO_FAR_AWAY, OBSTRUCTED, OTHER_PROBLEM, NOT_SAFE }")
S["net.neoforged.neoforge.event.entity.player.CanPlayerSleepEvent"] = ("public class CanPlayerSleepEvent extends net.neoforged.bus.api.Event { "
    "public net.minecraft.server.level.ServerPlayer getEntity() { return null; } public net.minecraft.world.level.Level getLevel() { return null; } "
    "public net.minecraft.core.BlockPos getPos() { return null; } public net.minecraft.world.entity.player.Player.BedSleepingProblem getProblem() { return null; } "
    "public void setProblem(net.minecraft.world.entity.player.Player.BedSleepingProblem p) {} }")


reemplazar("net.minecraft.world.level.block.state.BlockState", "public <T> T getValue(net.minecraft.world.level.block.state.properties.Property<T> p) { return null; }",
    "public <T extends Comparable<T>> T getValue(net.minecraft.world.level.block.state.properties.Property<T> p) { return null; }")
reemplazar("net.minecraft.util.RandomSource", "float nextFloat();", "float nextFloat(); double nextDouble();")

reemplazar("net.minecraft.world.level.block.Blocks", "SEA_LANTERN = null;", "SEA_LANTERN = null, PRISMARINE_BRICKS = null;")
reemplazar("net.minecraft.world.level.block.Blocks", "PRISMARINE_BRICKS = null;", "PRISMARINE_BRICKS = null, LIGHT = null;")
S["net.minecraft.world.level.block.LightBlock"] = "public class LightBlock extends Block { public static final net.minecraft.world.level.block.state.properties.IntegerProperty LEVEL = null; }"

# ================================================================ juego 1
reemplazar("net.minecraft.sounds.SoundSource", "PLAYERS, BLOCKS, AMBIENT", "PLAYERS, BLOCKS, AMBIENT, HOSTILE, MASTER")
reemplazar("net.minecraft.sounds.SoundEvents", "public static final SoundEvent BEACON_ACTIVATE = null, BEACON_DEACTIVATE = null, ENDERMAN_TELEPORT = null;",
    "public static final SoundEvent BEACON_ACTIVATE = null, BEACON_DEACTIVATE = null, ENDERMAN_TELEPORT = null, PLAYER_LEVELUP = null, ANVIL_LAND = null;")
reemplazar("net.minecraft.world.level.block.Blocks", "PRISMARINE_BRICKS = null, LIGHT = null;",
    "PRISMARINE_BRICKS = null, LIGHT = null, LIME_CONCRETE = null, GREEN_TERRACOTTA = null, RED_CONCRETE = null, RED_TERRACOTTA = null;")
agregar("net.minecraft.world.level.Level", "public static final net.minecraft.resources.ResourceKey<Level> OVERWORLD = null; public Object getChunk(int x, int z) { return null; }")
agregar("net.minecraft.server.level.ServerLevel", "public boolean setChunkForced(int x, int z, boolean f) { return true; }")
agregar("net.minecraft.server.level.ServerPlayer", "public net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> getRespawnDimension() { return null; }")
agregar("net.minecraft.server.level.ServerPlayer", "public void setRespawnPosition(net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> d, net.minecraft.core.BlockPos p, float a, boolean f, boolean m) {}")
agregar("net.minecraft.world.entity.Entity", "public void kill() {} public void setYRot(float y) {} public void setYHeadRot(float y) {}")
agregar("net.minecraft.world.entity.LivingEntity", "public void setYBodyRot(float y) {}")
reemplazar("net.minecraft.world.entity.player.Player", "public Abilities getAbilities() { return null; }",
    "public Abilities getAbilities() { return null; } public boolean isCreative() { return false; }")
S["net.minecraft.world.BossEvent"] = ("public abstract class BossEvent { public enum BossBarColor { PINK, BLUE, RED, GREEN, YELLOW, PURPLE, WHITE } "
    "public enum BossBarOverlay { PROGRESS, NOTCHED_6, NOTCHED_10, NOTCHED_12, NOTCHED_20 } "
    "public void setName(net.minecraft.network.chat.Component c) {} public void setProgress(float p) {} public void setColor(BossBarColor c) {} }")
S["net.minecraft.server.level.ServerBossEvent"] = ("public class ServerBossEvent extends net.minecraft.world.BossEvent { "
    "public ServerBossEvent(net.minecraft.network.chat.Component n, BossBarColor c, BossBarOverlay o) {} "
    "public void addPlayer(ServerPlayer p) {} public void removePlayer(ServerPlayer p) {} public void removeAllPlayers() {} "
    "public java.util.Collection<ServerPlayer> getPlayers() { return null; } }")


# ================================================================ el Vigía, empujones y peleas
reemplazar("net.minecraft.sounds.SoundSource", "PLAYERS, BLOCKS, AMBIENT, HOSTILE, MASTER", "PLAYERS, BLOCKS, AMBIENT, HOSTILE, MASTER, NEUTRAL")
reemplazar("net.minecraft.sounds.SoundEvents", "PLAYER_LEVELUP = null, ANVIL_LAND = null;",
    "PLAYER_LEVELUP = null, ANVIL_LAND = null, PLAYER_ATTACK_KNOCKBACK = null, PLAYER_ATTACK_WEAK = null;")
reemplazar("net.minecraft.world.level.block.Blocks", "RED_CONCRETE = null, RED_TERRACOTTA = null;",
    "RED_CONCRETE = null, RED_TERRACOTTA = null, GRAY_CONCRETE = null, LIGHT_GRAY_CONCRETE = null, BLACK_CONCRETE = null;")
reemplazar("net.minecraft.world.entity.ai.attributes.Attributes", "ATTACK_DAMAGE = null,", "ATTACK_DAMAGE = null, ATTACK_KNOCKBACK = null,")
agregar("net.minecraft.world.phys.Vec3", "public Vec3 subtract(Vec3 v) { return this; } public double lengthSqr() { return 0; } "
    "public Vec3 normalize() { return this; } public double distanceTo(Vec3 v) { return 0; } public Vec3 lerp(Vec3 v, double t) { return this; }")
agregar("net.minecraft.core.BlockPos", "public static class MutableBlockPos extends BlockPos { public MutableBlockPos() { super(0, 0, 0); } "
    "public MutableBlockPos set(int x, int y, int z) { return this; } }")
agregar("net.minecraft.world.entity.ai.navigation.PathNavigation", "public net.minecraft.world.level.pathfinder.Path createPath(net.minecraft.core.BlockPos p, int a) { return null; }")
agregar("net.minecraft.world.damagesource.DamageSources", "public DamageSource mobAttack(net.minecraft.world.entity.LivingEntity m) { return null; }")
agregar("net.minecraft.world.entity.LivingEntity", "public void die(net.minecraft.world.damagesource.DamageSource f) {} "
    "public void knockback(double s, double x, double z) {}")
agregar("net.minecraft.world.entity.Entity", "public boolean hurtMarked;")
agregar("net.minecraft.server.MinecraftServer", "public net.minecraft.server.players.PlayerList getPlayerList() { return null; }")
S["net.minecraft.server.players.PlayerList"] = ("public class PlayerList { public net.minecraft.server.level.ServerPlayer getPlayer(java.util.UUID id) { return null; } "
    "public java.util.List<net.minecraft.server.level.ServerPlayer> getPlayers() { return null; } }")
agregar("net.minecraft.server.level.ServerLevel", "public <T extends net.minecraft.core.particles.ParticleOptions> boolean sendParticles(ServerPlayer j, T t, boolean lejos, "
    "double x, double y, double z, int n, double dx, double dy, double dz, double s) { return true; }")
S["net.minecraft.core.particles.DustParticleOptions"] = "public class DustParticleOptions implements ParticleOptions { public DustParticleOptions(org.joml.Vector3f c, float s) {} }"
S["org.joml.Vector3f"] = "public class Vector3f { public Vector3f(float x, float y, float z) {} }"


# ================================================================ empujar con clic derecho
S["net.minecraft.world.InteractionResult"] = "public enum InteractionResult { SUCCESS, CONSUME, PASS, FAIL }"
S["net.neoforged.neoforge.event.entity.player.PlayerInteractEvent"] = (
    "public abstract class PlayerInteractEvent extends net.neoforged.bus.api.Event { "
    "public net.minecraft.world.entity.player.Player getEntity() { return null; } "
    "public net.minecraft.world.InteractionHand getHand() { return null; } "
    "public net.minecraft.world.level.Level getLevel() { return null; } "
    "public void setCancellationResult(net.minecraft.world.InteractionResult r) {} "
    "public static class EntityInteract extends PlayerInteractEvent { "
    "public net.minecraft.world.entity.Entity getTarget() { return null; } public void setCanceled(boolean c) {} } }")
agregar("net.minecraft.world.entity.Entity", "public net.minecraft.network.chat.Component getName() { return null; }")

agregar("net.minecraft.network.chat.Component", "default String getString() { return \"\"; }")

agregar("net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent", "public void setCanceled(boolean c) {}")

S["net.minecraft.util.Mth"] = "public class Mth { public static float wrapDegrees(float f) { return f; } }"


# ================================================================ cansancio
S["net.minecraft.world.food.FoodData"] = "public class FoodData { public int getFoodLevel() { return 20; } public void setFoodLevel(int f) {} }"
S["net.minecraft.network.protocol.game.ClientboundSetExperiencePacket"] = (
    "public class ClientboundSetExperiencePacket implements net.minecraft.network.protocol.Packet<Object> { "
    "public ClientboundSetExperiencePacket(float p, int t, int l) {} }")
agregar("net.minecraft.world.entity.player.Player", "public float experienceProgress; public int totalExperience; public int experienceLevel; "
    "public net.minecraft.world.food.FoodData getFoodData() { return null; }")
S["net.neoforged.neoforge.event.entity.player.PlayerEvent"] = (
    "public abstract class PlayerEvent extends net.neoforged.bus.api.Event { "
    "public net.minecraft.world.entity.player.Player getEntity() { return null; } "
    "public static class PlayerLoggedOutEvent extends PlayerEvent {} }")


# ================================================================ votación y reparto del premio
S["net.minecraft.network.chat.ClickEvent"] = ("public class ClickEvent { public enum Action { RUN_COMMAND, SUGGEST_COMMAND, OPEN_URL } "
    "public ClickEvent(Action a, String v) {} }")
S["net.minecraft.network.chat.HoverEvent"] = ("public class HoverEvent { public static class Action<T> { "
    "public static final Action<net.minecraft.network.chat.Component> SHOW_TEXT = null; } public <T> HoverEvent(Action<T> a, T v) {} }")
S["net.minecraft.network.chat.Style"] = ("public class Style { public Style withColor(net.minecraft.ChatFormatting f) { return this; } "
    "public Style withBold(Boolean b) { return this; } public Style withClickEvent(ClickEvent c) { return this; } "
    "public Style withHoverEvent(HoverEvent h) { return this; } }")
agregar("net.minecraft.network.chat.MutableComponent", "public MutableComponent withStyle(java.util.function.UnaryOperator<Style> f) { return this; }")
reemplazar("net.minecraft.core.Holder", "public interface Holder<T> {}", "public interface Holder<T> { default T value() { return null; } interface Reference<T> extends Holder<T> {} }")
agregar("net.minecraft.sounds.SoundEvents", "public static final net.minecraft.core.Holder.Reference<SoundEvent> NOTE_BLOCK_PLING = null;")
reemplazar("net.minecraft.world.item.Items", "public static final Item BLACK_WOOL = null;", "public static final Item BLACK_WOOL = null, DIAMOND = null;")
agregar("net.minecraft.world.item.ItemStack", "public ItemStack(net.minecraft.world.level.ItemLike i, int n) {} public int getCount() { return 1; }")

# ================================================================ reparto de comida
S["net.minecraft.core.particles.ParticleType"] = "public abstract class ParticleType<T extends ParticleOptions> {}"
S["net.minecraft.core.particles.ItemParticleOption"] = ("public class ItemParticleOption implements ParticleOptions { "
    "public ItemParticleOption(ParticleType<ItemParticleOption> t, net.minecraft.world.item.ItemStack s) {} }")
reemplazar("net.minecraft.core.particles.ParticleTypes", "public class ParticleTypes {",
    "public class ParticleTypes { public static final ParticleType<ItemParticleOption> ITEM = null;")
reemplazar("net.minecraft.world.item.Items", "DIAMOND = null;", "DIAMOND = null, COOKED_BEEF = null;")
agregar("net.minecraft.sounds.SoundEvents", "public static final SoundEvent GENERIC_EAT = null, PLAYER_BURP = null, ITEM_PICKUP = null;")
agregar("net.minecraft.world.entity.LivingEntity", "public void heal(float f) {}")
agregar("net.minecraft.world.entity.player.Player", "public void causeFoodExhaustion(float f) {}")
agregar("net.minecraft.world.entity.Entity", "public double xo, yo, zo; public void playSound(net.minecraft.sounds.SoundEvent s, float v, float p) {}")

# ================================================================ sillas musicales (juego 2)
S["net.minecraft.world.phys.shapes.VoxelShape"] = "public abstract class VoxelShape {}"
S["net.minecraft.world.phys.shapes.Shapes"] = ("public final class Shapes { public static VoxelShape or(VoxelShape a, VoxelShape... b) { return a; } "
    "public static VoxelShape block() { return null; } }")
S["net.minecraft.world.phys.shapes.CollisionContext"] = "public interface CollisionContext {}"
S["net.minecraft.world.level.BlockGetter"] = "public interface BlockGetter {}"
S["net.minecraft.world.phys.BlockHitResult"] = "public class BlockHitResult {}"
S["net.minecraft.world.level.pathfinder.PathComputationType"] = "public enum PathComputationType { LAND, WATER, AIR }"
agregar("net.minecraft.world.level.block.state.BlockBehaviour", "protected boolean isPathfindable("
    "net.minecraft.world.level.block.state.BlockState s, net.minecraft.world.level.pathfinder.PathComputationType t) { return true; }")
S["net.minecraft.world.level.block.state.properties.DirectionProperty"] = (
    "public class DirectionProperty extends EnumProperty<net.minecraft.core.Direction> {}")
S["net.minecraft.world.level.block.HorizontalDirectionalBlock"] = (
    "public abstract class HorizontalDirectionalBlock extends Block { "
    "public static final net.minecraft.world.level.block.state.properties.DirectionProperty FACING = null; "
    "protected HorizontalDirectionalBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties p) { super(p); } "
    "protected abstract com.mojang.serialization.MapCodec<? extends HorizontalDirectionalBlock> codec(); }")
reemplazar("net.minecraft.world.level.block.Block", "public static final int UPDATE_CLIENTS = 2;",
    "public static final int UPDATE_CLIENTS = 2; public static final int UPDATE_ALL = 3; "
    "public static net.minecraft.world.phys.shapes.VoxelShape box(double a, double b, double c, double d, double e, double f) { return null; } "
    "public static <B extends Block> com.mojang.serialization.MapCodec<B> simpleCodec(java.util.function.Function<Properties, B> f) { return null; }")
agregar("net.minecraft.world.level.block.state.BlockBehaviour",
    "protected net.minecraft.world.phys.shapes.VoxelShape getShape(net.minecraft.world.level.block.state.BlockState s, "
    "net.minecraft.world.level.BlockGetter l, net.minecraft.core.BlockPos p, net.minecraft.world.phys.shapes.CollisionContext c) { return null; } "
    "protected net.minecraft.world.InteractionResult useWithoutItem(net.minecraft.world.level.block.state.BlockState s, "
    "net.minecraft.world.level.Level l, net.minecraft.core.BlockPos p, net.minecraft.world.entity.player.Player j, "
    "net.minecraft.world.phys.BlockHitResult h) { return null; }")
S["net.minecraft.core.Direction"] = ("public enum Direction { DOWN, UP, NORTH, SOUTH, WEST, EAST; "
    "public float toYRot() { return 0; } public static Direction fromYRot(double y) { return NORTH; } "
    "public int getStepX() { return 0; } public int getStepZ() { return 0; } "
    "public static Direction getNearest(double x, double y, double z) { return NORTH; } }")
reemplazar("net.minecraft.sounds.SoundSource", "MASTER, NEUTRAL", "MASTER, NEUTRAL, RECORDS")
agregar("net.minecraft.sounds.SoundEvents", "public static final net.minecraft.core.Holder.Reference<SoundEvent> NOTE_BLOCK_HARP = null, "
    "NOTE_BLOCK_BASS = null, NOTE_BLOCK_BASEDRUM = null, NOTE_BLOCK_SNARE = null, NOTE_BLOCK_HAT = null, NOTE_BLOCK_DIDGERIDOO = null; "
    "public static final SoundEvent WOOD_BREAK = null, WOOD_PLACE = null;")
reemplazar("net.minecraft.core.particles.ParticleTypes", "END_ROD = null;", "END_ROD = null, POOF = null;")
agregar("net.minecraft.world.phys.AABB", "public AABB(net.minecraft.core.BlockPos p) {}")
agregar("net.minecraft.world.level.Level", "public <T extends net.minecraft.world.entity.Entity> java.util.List<T> getEntities("
    "net.minecraft.world.level.entity.EntityTypeTest<net.minecraft.world.entity.Entity, T> t, net.minecraft.world.phys.AABB a, "
    "java.util.function.Predicate<? super T> p) { return null; }")
S["net.minecraft.world.entity.EntityDimensions"] = "public class EntityDimensions {}"
reemplazar("net.minecraft.world.entity.Entity", "public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag t)",
    "protected void addAdditionalSaveData(net.minecraft.nbt.CompoundTag t)")
reemplazar("net.minecraft.world.entity.Entity", "public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag t)",
    "protected void readAdditionalSaveData(net.minecraft.nbt.CompoundTag t)")
agregar("net.minecraft.world.entity.Entity",
    "public Entity() {} public Entity(EntityType<?> t, net.minecraft.world.level.Level l) {} "
    "public boolean noPhysics; public float yRotO; "
    "public boolean isPassenger() { return false; } public java.util.List<Entity> getPassengers() { return null; } "
    "public void ejectPassengers() {} public boolean isRemoved() { return false; } public Entity getVehicle() { return null; } "
    "public boolean startRiding(Entity e, boolean f) { return true; } public void stopRiding() {} "
    "public net.minecraft.world.phys.Vec3 getVehicleAttachmentPoint(Entity e) { return null; } "
    "@FunctionalInterface public interface MoveFunction { void accept(Entity e, double x, double y, double z); } "
    "protected void positionRider(Entity e, MoveFunction m) {} public void onPassengerTurned(Entity e) {} "
    "protected boolean canAddPassenger(Entity e) { return true; } "
    "protected net.minecraft.world.phys.Vec3 getPassengerAttachmentPoint(Entity e, EntityDimensions d, float f) { return null; } "
    "public net.minecraft.world.phys.Vec3 getDismountLocationForPassenger(LivingEntity e) { return null; } "
    "public boolean isPickable() { return false; } public void setYBodyRot(float y) {}")
S["net.minecraft.world.entity.ai.control.MoveControl"] = ("public class MoveControl { "
    "public void setWantedPosition(double x, double y, double z, double s) {} }")
agregar("net.minecraft.world.entity.Mob", "public net.minecraft.world.entity.ai.control.MoveControl getMoveControl() { return null; }")
reemplazar("net.minecraft.util.Mth", "public static float wrapDegrees(float f) { return f; }",
    "public static float wrapDegrees(float f) { return f; } public static float clamp(float v, float a, float b) { return v; }")
reemplazar("net.minecraft.world.entity.EntityType", "public Builder<T> updateInterval(int r) { return this; }",
    "public Builder<T> updateInterval(int r) { return this; } public Builder<T> noSave() { return this; } "
    "public Builder<T> noSummon() { return this; }")
S["net.minecraft.client.renderer.entity.NoopRenderer"] = ("public class NoopRenderer<T extends net.minecraft.world.entity.Entity> "
    "extends EntityRenderer<T> { public NoopRenderer(EntityRendererProvider.Context c) {} "
    "public net.minecraft.resources.ResourceLocation getTextureLocation(T e) { return null; } }")
S["net.neoforged.neoforge.event.entity.EntityMountEvent"] = ("public class EntityMountEvent extends net.neoforged.bus.api.Event { "
    "public boolean isMounting() { return false; } public boolean isDismounting() { return false; } "
    "public net.minecraft.world.entity.Entity getEntityMounting() { return null; } "
    "public net.minecraft.world.entity.Entity getEntityBeingMounted() { return null; } public void setCanceled(boolean c) {} }")

# ================================================================ sacar de la silla: la Z (cliente -> servidor)
S["io.netty.buffer.ByteBuf"] = "public abstract class ByteBuf {}"
S["net.minecraft.network.FriendlyByteBuf"] = "public abstract class FriendlyByteBuf extends io.netty.buffer.ByteBuf {}"
S["net.minecraft.network.RegistryFriendlyByteBuf"] = "public abstract class RegistryFriendlyByteBuf extends FriendlyByteBuf {}"
S["net.minecraft.network.codec.StreamCodec"] = ("public interface StreamCodec<B, V> { "
    "static <B, V> StreamCodec<B, V> unit(V v) { return null; } }")
S["net.minecraft.network.protocol.common.custom.CustomPacketPayload"] = ("public interface CustomPacketPayload { "
    "Type<? extends CustomPacketPayload> type(); "
    "record Type<T extends CustomPacketPayload>(net.minecraft.resources.ResourceLocation id) {} }")
S["net.neoforged.neoforge.network.handling.IPayloadContext"] = ("public interface IPayloadContext { "
    "net.minecraft.world.entity.player.Player player(); java.util.concurrent.CompletableFuture<Void> enqueueWork(Runnable r); }")
S["net.neoforged.neoforge.network.handling.IPayloadHandler"] = ("@FunctionalInterface public interface IPayloadHandler<T> { "
    "void handle(T payload, IPayloadContext context); }")
S["net.neoforged.neoforge.network.registration.PayloadRegistrar"] = ("public class PayloadRegistrar { "
    "public <T extends net.minecraft.network.protocol.common.custom.CustomPacketPayload> PayloadRegistrar playToServer("
    "net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<T> t, "
    "net.minecraft.network.codec.StreamCodec<? super net.minecraft.network.RegistryFriendlyByteBuf, T> c, "
    "net.neoforged.neoforge.network.handling.IPayloadHandler<T> h) { return this; } }")
S["net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent"] = ("public class RegisterPayloadHandlersEvent extends "
    "net.neoforged.bus.api.Event { public net.neoforged.neoforge.network.registration.PayloadRegistrar registrar(String v) { return null; } }")
S["net.neoforged.neoforge.network.PacketDistributor"] = ("public final class PacketDistributor { public static void sendToServer("
    "net.minecraft.network.protocol.common.custom.CustomPacketPayload p, net.minecraft.network.protocol.common.custom.CustomPacketPayload... o) {} }")
S["com.mojang.blaze3d.platform.InputConstants"] = "public class InputConstants { public enum Type { KEYSYM, SCANCODE, MOUSE } }"
S["org.lwjgl.glfw.GLFW"] = "public class GLFW { public static final int GLFW_KEY_Z = 90; }"
S["net.minecraft.client.KeyMapping"] = ("public class KeyMapping { public KeyMapping(String n, "
    "com.mojang.blaze3d.platform.InputConstants.Type t, int k, String c) {} public boolean consumeClick() { return false; } }")
S["net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent"] = ("public class RegisterKeyMappingsEvent extends "
    "net.neoforged.bus.api.Event { public void register(net.minecraft.client.KeyMapping k) {} }")
S["net.neoforged.neoforge.client.event.ClientTickEvent"] = ("public abstract class ClientTickEvent extends "
    "net.neoforged.bus.api.Event { public static class Post extends ClientTickEvent {} }")
S["net.minecraft.client.player.LocalPlayer"] = "public abstract class LocalPlayer extends net.minecraft.world.entity.player.Player {}"
S["net.minecraft.client.multiplayer.ClientPacketListener"] = "public class ClientPacketListener {}"
S["net.minecraft.client.Minecraft"] = ("public class Minecraft { public net.minecraft.client.player.LocalPlayer player; "
    "public static Minecraft getInstance() { return null; } "
    "public net.minecraft.client.multiplayer.ClientPacketListener getConnection() { return null; } }")

# ================================================================ luces que parpadean (servidor -> cliente, capa de pantalla)
S["net.minecraft.network.codec.ByteBufCodecs"] = ("public interface ByteBufCodecs { "
    "StreamCodec<io.netty.buffer.ByteBuf, Integer> VAR_INT = null; }")
agregar("net.minecraft.network.codec.StreamCodec",
    "static <B, C, T1> StreamCodec<B, C> composite(StreamCodec<? super B, T1> c1, "
    "java.util.function.Function<C, T1> g1, java.util.function.Function<T1, C> f) { return null; }")
agregar("net.neoforged.neoforge.network.registration.PayloadRegistrar",
    "public <T extends net.minecraft.network.protocol.common.custom.CustomPacketPayload> PayloadRegistrar playToClient("
    "net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<T> t, "
    "net.minecraft.network.codec.StreamCodec<? super net.minecraft.network.RegistryFriendlyByteBuf, T> c, "
    "net.neoforged.neoforge.network.handling.IPayloadHandler<T> h) { return this; }")
agregar("net.neoforged.neoforge.network.PacketDistributor",
    "public static void sendToPlayer(net.minecraft.server.level.ServerPlayer j, "
    "net.minecraft.network.protocol.common.custom.CustomPacketPayload p, "
    "net.minecraft.network.protocol.common.custom.CustomPacketPayload... o) {}")
S["net.minecraft.client.DeltaTracker"] = "public interface DeltaTracker { float getGameTimeDeltaPartialTick(boolean b); }"
S["net.minecraft.client.gui.GuiGraphics"] = ("public class GuiGraphics { public int guiWidth() { return 0; } "
    "public int guiHeight() { return 0; } public void fill(int a, int b, int c, int d, int color) {} }")
S["net.minecraft.client.gui.LayeredDraw"] = ("public class LayeredDraw { @FunctionalInterface public interface Layer { "
    "void render(GuiGraphics g, net.minecraft.client.DeltaTracker d); } }")
S["net.neoforged.neoforge.client.event.RegisterGuiLayersEvent"] = ("public class RegisterGuiLayersEvent extends "
    "net.neoforged.bus.api.Event { public void registerAbove(net.minecraft.resources.ResourceLocation otra, "
    "net.minecraft.resources.ResourceLocation id, net.minecraft.client.gui.LayeredDraw.Layer capa) {} }")
S["net.neoforged.neoforge.client.gui.VanillaGuiLayers"] = ("public final class VanillaGuiLayers { "
    "public static final net.minecraft.resources.ResourceLocation CAMERA_OVERLAYS = null, CROSSHAIR = null; }")
S["net.minecraft.client.OptionInstance"] = "public final class OptionInstance<T> { public T get() { return null; } }"
S["net.minecraft.client.Options"] = ("public class Options { "
    "public OptionInstance<Boolean> hideLightningFlash() { return null; } }")
S["net.minecraft.client.multiplayer.ClientLevel"] = "public class ClientLevel extends net.minecraft.world.level.Level {}"
agregar("net.minecraft.client.Minecraft", "public final Options options = null; "
    "public net.minecraft.client.multiplayer.ClientLevel level; public boolean isPaused() { return false; }")
agregar("net.minecraft.sounds.SoundEvents", "public static final SoundEvent COPPER_BULB_TURN_ON = null, COPPER_BULB_TURN_OFF = null;")

# ================================================================ las escondidas (juego 3): espada, equipos, escuela
reemplazar("net.minecraft.world.level.Level", "public abstract class Level {",
    "public abstract class Level implements BlockGetter { public net.minecraft.core.RegistryAccess registryAccess() { return null; } "
    "public int getBrightness(LightLayer l, net.minecraft.core.BlockPos p) { return 0; } ")
S["net.minecraft.world.level.LightLayer"] = "public enum LightLayer { SKY, BLOCK }"
agregar("net.minecraft.world.level.block.Blocks", "public static final Block IRON_BARS = null, SPONGE = null, WET_SPONGE = null;")
agregar("net.minecraft.world.item.Items", "public static final Item NETHERITE_SWORD = null, CARROT = null, POTATO = null;")
reemplazar("net.minecraft.ChatFormatting", "WHITE, GRAY, DARK_GRAY, DARK_AQUA,", "WHITE, GRAY, DARK_GRAY, DARK_AQUA, DARK_RED,")
S["net.minecraft.core.component.DataComponentType"] = "public interface DataComponentType<T> {}"
S["net.minecraft.core.component.DataComponents"] = ("public class DataComponents { "
    "public static final DataComponentType<net.minecraft.world.item.component.Unbreakable> UNBREAKABLE = null; "
    "public static final DataComponentType<net.minecraft.network.chat.Component> ITEM_NAME = null; "
    "public static final DataComponentType<net.minecraft.world.item.component.CustomData> CUSTOM_DATA = null; }")
S["net.minecraft.world.item.component.Unbreakable"] = "public record Unbreakable(boolean showInTooltip) {}"
S["net.minecraft.world.item.component.CustomData"] = ("public final class CustomData { "
    "public static CustomData of(net.minecraft.nbt.CompoundTag t) { return null; } "
    "public net.minecraft.nbt.CompoundTag copyTag() { return null; } }")
S["net.minecraft.world.item.enchantment.Enchantment"] = "public final class Enchantment {}"
S["net.minecraft.world.item.enchantment.Enchantments"] = ("public class Enchantments { "
    "public static final net.minecraft.resources.ResourceKey<Enchantment> SHARPNESS = null; }")
agregar("net.minecraft.core.registries.Registries", "public static final net.minecraft.resources.ResourceKey<"
    "net.minecraft.core.Registry<net.minecraft.world.item.enchantment.Enchantment>> ENCHANTMENT = null;")
S["net.minecraft.core.RegistryAccess"] = ("public interface RegistryAccess { "
    "<E> Registry<E> registryOrThrow(net.minecraft.resources.ResourceKey<? extends Registry<? extends E>> k); }")
agregar("net.minecraft.core.Registry", "Holder.Reference<T> getHolderOrThrow(net.minecraft.resources.ResourceKey<T> k);")
agregar("net.minecraft.world.item.ItemStack", "public ItemStack copy() { return this; } "
    "public <T> T set(net.minecraft.core.component.DataComponentType<? super T> t, T v) { return null; } "
    "public <T> T get(net.minecraft.core.component.DataComponentType<? extends T> t) { return null; } "
    "public void enchant(net.minecraft.core.Holder<net.minecraft.world.item.enchantment.Enchantment> e, int n) {}")
agregar("net.minecraft.world.entity.player.Inventory", "public void setItem(int i, net.minecraft.world.item.ItemStack s) {}")
agregar("net.minecraft.world.entity.ai.attributes.AttributeInstance",
    "public void addOrUpdateTransientModifier(AttributeModifier m) {} "
    "public boolean removeModifier(net.minecraft.resources.ResourceLocation id) { return true; }")
S["net.minecraft.world.entity.ai.attributes.AttributeModifier"] = ("public record AttributeModifier("
    "net.minecraft.resources.ResourceLocation id, double amount, Operation operation) { "
    "public enum Operation { ADD_VALUE, ADD_MULTIPLIED_BASE, ADD_MULTIPLIED_TOTAL } }")
agregar("net.minecraft.world.entity.LivingEntity",
    "public boolean removeEffect(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> e) { return true; } "
    "public boolean hasLineOfSight(net.minecraft.world.entity.Entity e) { return true; }")
agregar("net.minecraft.world.entity.Entity", "public void setShiftKeyDown(boolean b) {} "
    "public boolean isShiftKeyDown() { return false; } public Pose getPose() { return null; }")
agregar("net.minecraft.server.level.ServerLevel", "public net.minecraft.world.entity.Entity getEntity(java.util.UUID id) { return null; }")
reemplazar("net.minecraft.world.phys.Vec3", "public class Vec3 {",
    "public class Vec3 implements net.minecraft.core.Position { public double x() { return x; } "
    "public double y() { return y; } public double z() { return z; } ")
S["net.minecraft.core.Position"] = "public interface Position { double x(); double y(); double z(); }"
agregar("net.minecraft.world.phys.Vec3", "public double dot(Vec3 v) { return 0; } "
    "public double distanceToSqr(double x, double y, double z) { return 0; }")
agregar("net.minecraft.world.entity.Mob", "public boolean doHurtTarget(net.minecraft.world.entity.Entity e) { return true; }")
agregar("net.minecraft.world.entity.Entity", "public net.minecraft.world.phys.Vec3 getViewVector(float f) { return null; }")
agregar("net.minecraft.world.entity.LivingEntity", "public void setItemInHand(net.minecraft.world.InteractionHand h, "
    "net.minecraft.world.item.ItemStack s) {}")
agregar("net.minecraft.core.BlockPos", "public BlockPos below() { return this; } public BlockPos above() { return this; } "
    "public static BlockPos containing(net.minecraft.core.Position p) { return null; }")
agregar("net.minecraft.world.level.block.state.BlockState", "public net.minecraft.world.phys.shapes.VoxelShape "
    "getCollisionShape(net.minecraft.world.level.BlockGetter l, net.minecraft.core.BlockPos p) { return null; }")
agregar("net.minecraft.world.phys.shapes.VoxelShape", "public boolean isEmpty() { return false; }")
S["net.neoforged.neoforge.event.entity.living.LivingDeathEvent"] = ("public class LivingDeathEvent extends "
    "net.neoforged.bus.api.Event { public net.minecraft.world.entity.LivingEntity getEntity() { return null; } "
    "public net.minecraft.world.damagesource.DamageSource getSource() { return null; } }")

# las escondidas, bots más listos: ven de lejos (rayos de vista), para dónde mira la cabeza, avisos
agregar("net.minecraft.world.phys.Vec3", "public double distanceToSqr(Vec3 v) { return 0; }")
agregar("net.minecraft.world.entity.Entity", "public final float getBbHeight() { return 0; }")
agregar("net.minecraft.world.entity.LivingEntity", "public float getYHeadRot() { return 0; }")
S["net.minecraft.world.level.ClipContext"] = ("public class ClipContext { public ClipContext(net.minecraft.world.phys.Vec3 a, "
    "net.minecraft.world.phys.Vec3 b, Block c, Fluid d, net.minecraft.world.entity.Entity e) {} "
    "public enum Block { COLLIDER, OUTLINE, VISUAL, FALLDAMAGE_RESETTING } public enum Fluid { NONE, SOURCE_ONLY, ANY, WATER } }")
reemplazar("net.minecraft.world.phys.HitResult", "public abstract class HitResult {}",
    "public abstract class HitResult { public Type getType() { return null; } public enum Type { MISS, BLOCK, ENTITY } }")
reemplazar("net.minecraft.world.phys.BlockHitResult", "public class BlockHitResult {}",
    "public class BlockHitResult extends HitResult {}")
reemplazar("net.minecraft.world.level.BlockGetter", "public interface BlockGetter {}",
    "public interface BlockGetter { default net.minecraft.world.phys.BlockHitResult clip(ClipContext c) { return null; } }")

if "net.minecraft.world.entity.item.ItemEntity" not in S:
    S["net.minecraft.world.entity.item.ItemEntity"] = "public class ItemEntity extends net.minecraft.world.entity.Entity {}"
agregar("net.minecraft.world.entity.item.ItemEntity", "public net.minecraft.world.item.ItemStack getItem() { return null; }")

# las escondidas: cuerpos en el piso, hacerse el muerto, quitar la espada y los chalecos
S["com.mojang.math.Axis"] = ("@FunctionalInterface public interface Axis { Axis XP = null, YP = null, ZP = null; "
    "org.joml.Quaternionf rotation(float r); default org.joml.Quaternionf rotationDegrees(float g) { return null; } }")
S["org.joml.Quaternionf"] = "public class Quaternionf {}"
S["com.mojang.blaze3d.vertex.VertexConsumer"] = "public interface VertexConsumer {}"
S["com.mojang.blaze3d.vertex.PoseStack"] = ("public class PoseStack { public void pushPose() {} public void popPose() {} "
    "public void translate(float x, float y, float z) {} public void translate(double x, double y, double z) {} "
    "public void scale(float x, float y, float z) {} public void mulPose(org.joml.Quaternionf q) {} "
    "public Pose last() { return null; } public static final class Pose {} }")
S["net.minecraft.client.renderer.RenderType"] = ("public abstract class RenderType { "
    "public static RenderType armorCutoutNoCull(net.minecraft.resources.ResourceLocation r) { return null; } "
    "public static RenderType entityCutoutNoCull(net.minecraft.resources.ResourceLocation r) { return null; } "
    "public static RenderType eyes(net.minecraft.resources.ResourceLocation r) { return null; } }")
S["net.minecraft.client.renderer.MultiBufferSource"] = ("public interface MultiBufferSource { "
    "com.mojang.blaze3d.vertex.VertexConsumer getBuffer(net.minecraft.client.renderer.RenderType t); }")
S["net.minecraft.client.renderer.texture.OverlayTexture"] = "public class OverlayTexture { public static final int NO_OVERLAY = 0; }"
S["net.minecraft.client.model.Model"] = ("public abstract class Model { "
    "public final net.minecraft.client.renderer.RenderType renderType(net.minecraft.resources.ResourceLocation r) { return null; } "
    "public final void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack p, com.mojang.blaze3d.vertex.VertexConsumer b, int l, int o) {} "
    "public abstract void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack p, com.mojang.blaze3d.vertex.VertexConsumer b, int l, int o, int c); }")
S["net.minecraft.client.model.EntityModel"] = ("public abstract class EntityModel<T extends net.minecraft.world.entity.Entity> "
    "extends Model { public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack p, com.mojang.blaze3d.vertex.VertexConsumer b, "
    "int l, int o, int c) {} }")
S["net.minecraft.client.model.geom.ModelPart"] = "public class ModelPart { public boolean visible; }"
reemplazar("net.minecraft.client.model.HumanoidModel", "public boolean crouching;",
    "public boolean crouching; public final net.minecraft.client.model.geom.ModelPart body = null; "
    "public void setAllVisible(boolean v) {}")
S["net.minecraft.client.model.geom.ModelLayers"] = ("public class ModelLayers { public static final ModelLayerLocation PLAYER = null, "
    "PLAYER_SLIM = null, PLAYER_INNER_ARMOR = null, PLAYER_OUTER_ARMOR = null; }")
S["net.minecraft.client.resources.model.ModelManager"] = "public class ModelManager {}"
reemplazar("net.minecraft.client.renderer.entity.EntityRendererProvider",
    "class Context { public net.minecraft.client.model.geom.ModelPart bakeLayer(net.minecraft.client.model.geom.ModelLayerLocation l) { return null; } }",
    "class Context { public net.minecraft.client.model.geom.ModelPart bakeLayer(net.minecraft.client.model.geom.ModelLayerLocation l) { return null; } "
    "public net.minecraft.client.resources.model.ModelManager getModelManager() { return null; } }")
reemplazar("net.minecraft.client.renderer.entity.EntityRenderer",
    "public abstract class EntityRenderer<T extends net.minecraft.world.entity.Entity> {",
    "public abstract class EntityRenderer<T extends net.minecraft.world.entity.Entity> { protected float shadowRadius; "
    "protected EntityRenderer(EntityRendererProvider.Context c) {} protected EntityRenderer() {}")
S["net.minecraft.client.renderer.entity.RenderLayerParent"] = ("public interface RenderLayerParent<T extends "
    "net.minecraft.world.entity.Entity, M extends net.minecraft.client.model.EntityModel<T>> { M getModel(); }")
S["net.minecraft.client.renderer.entity.layers.RenderLayer"] = ("public abstract class RenderLayer<T extends "
    "net.minecraft.world.entity.Entity, M extends net.minecraft.client.model.EntityModel<T>> {}")
S["net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer"] = ("public class HumanoidArmorLayer<T extends "
    "net.minecraft.world.entity.LivingEntity, M extends net.minecraft.client.model.HumanoidModel<T>, A extends "
    "net.minecraft.client.model.HumanoidModel<T>> extends RenderLayer<T, M> { public HumanoidArmorLayer("
    "net.minecraft.client.renderer.entity.RenderLayerParent<T, M> p, A i, A o, net.minecraft.client.resources.model.ModelManager m) {} }")
reemplazar("net.minecraft.client.renderer.entity.LivingEntityRenderer",
    "public abstract class LivingEntityRenderer<T extends net.minecraft.world.entity.LivingEntity, M extends net.minecraft.client.model.EntityModel<T>> extends EntityRenderer<T> {",
    "public abstract class LivingEntityRenderer<T extends net.minecraft.world.entity.LivingEntity, M extends net.minecraft.client.model.EntityModel<T>> extends EntityRenderer<T> implements RenderLayerParent<T, M> { "
    "public M getModel() { return model; } protected final boolean addLayer(net.minecraft.client.renderer.entity.layers.RenderLayer<T, M> l) { return true; }")
S["net.minecraft.client.resources.PlayerSkin"] = ("public record PlayerSkin(net.minecraft.resources.ResourceLocation texture, "
    "String textureUrl, net.minecraft.resources.ResourceLocation capeTexture, net.minecraft.resources.ResourceLocation elytraTexture, "
    "Model model, boolean secure) { public enum Model { SLIM, WIDE } }")
S["net.minecraft.client.resources.DefaultPlayerSkin"] = ("public class DefaultPlayerSkin { "
    "public static net.minecraft.client.resources.PlayerSkin get(java.util.UUID id) { return null; } }")
S["net.minecraft.client.multiplayer.PlayerInfo"] = ("public class PlayerInfo { "
    "public net.minecraft.client.resources.PlayerSkin getSkin() { return null; } }")
S["net.minecraft.client.multiplayer.ClientPacketListener"] = ("public class ClientPacketListener { "
    "public net.minecraft.client.multiplayer.PlayerInfo getPlayerInfo(java.util.UUID id) { return null; } }")
reemplazar("net.minecraft.network.syncher.EntityDataSerializers", "public static final EntityDataSerializer<Integer> INT = null;",
    "public static final EntityDataSerializer<Integer> INT = null; "
    "public static final EntityDataSerializer<java.util.Optional<java.util.UUID>> OPTIONAL_UUID = null;")
reemplazar("org.lwjgl.glfw.GLFW", "public static final int GLFW_KEY_Z = 90;", "public static final int GLFW_KEY_Z = 90, GLFW_KEY_G = 71;")
agregar("net.minecraft.network.codec.ByteBufCodecs", "StreamCodec<io.netty.buffer.ByteBuf, Boolean> BOOL = null;")

agregar("net.minecraft.world.item.Items", "public static final Item YELLOW_WOOL = null, PURPLE_WOOL = null;")
agregar("net.minecraft.world.entity.Entity", "public void setInvisible(boolean b) {} "
    "public net.minecraft.world.phys.Vec3 getDeltaMovement() { return null; } public void setDeltaMovement(double x, double y, double z) {}")
agregar("net.minecraft.sounds.SoundEvents", "public static final SoundEvent PLAYER_SMALL_FALL = null, ITEM_BREAK = null;")
agregar("net.minecraft.world.entity.ai.attributes.Attributes",
    "public static final net.minecraft.core.Holder<Attribute> JUMP_STRENGTH = null;")
agregar("net.minecraft.world.entity.LivingEntity", "public net.minecraft.world.item.ItemStack getItemInHand(net.minecraft.world.InteractionHand h) { return null; }")

S["net.minecraft.client.CameraType"] = "public enum CameraType { FIRST_PERSON, THIRD_PERSON_BACK, THIRD_PERSON_FRONT; public boolean isFirstPerson() { return this == FIRST_PERSON; } }"
agregar("net.minecraft.client.Options", "public CameraType getCameraType() { return null; }")
agregar("net.minecraft.client.multiplayer.ClientLevel", "public Iterable<net.minecraft.world.entity.Entity> entitiesForRendering() { return null; }")
S["net.neoforged.neoforge.client.event.RenderLivingEvent"] = ("public abstract class RenderLivingEvent<T extends "
    "net.minecraft.world.entity.LivingEntity, M extends net.minecraft.client.model.EntityModel<T>> extends net.neoforged.bus.api.Event { "
    "public T getEntity() { return null; } "
    "public static class Pre<T extends net.minecraft.world.entity.LivingEntity, M extends net.minecraft.client.model.EntityModel<T>> "
    "extends RenderLivingEvent<T, M> implements net.neoforged.bus.api.ICancellableEvent {} }")
if "net.neoforged.bus.api.ICancellableEvent" not in S:
    S["net.neoforged.bus.api.ICancellableEvent"] = "public interface ICancellableEvent { default void setCanceled(boolean c) {} default boolean isCanceled() { return false; } }"
agregar("net.minecraft.world.entity.LivingEntity", "public boolean isDeadOrDying() { return false; }")

agregar("net.minecraft.client.KeyMapping", "public boolean isDown() { return false; }")

agregar("net.minecraft.sounds.SoundEvents", "public static final net.minecraft.core.Holder.Reference<SoundEvent> NOTE_BLOCK_CHIME = null;")

agregar("net.minecraft.world.entity.Entity", "public final void positionRider(Entity e) {}")


# varios: metas que piensan en cada tick, comida y huir (algunos ya no se usan, no molestan)
reemplazar("net.minecraft.world.entity.ai.goal.Goal", "public void tick() {}",
    "public void tick() {} public boolean requiresUpdateEveryTick() { return false; }")
agregar("net.minecraft.world.item.Items", "public static final Item CAKE = null, IRON_SWORD = null;")
S["net.minecraft.world.food.FoodProperties"] = ("public record FoodProperties(int nutrition, float saturation) { "
    "public static class Builder { public Builder nutrition(int n) { return this; } "
    "public Builder saturationModifier(float s) { return this; } public FoodProperties build() { return null; } } }")
reemplazar("net.minecraft.core.component.DataComponents",
    "public static final DataComponentType<net.minecraft.network.chat.Component> ITEM_NAME = null; ",
    "public static final DataComponentType<net.minecraft.network.chat.Component> ITEM_NAME = null; "
    "public static final DataComponentType<net.minecraft.world.food.FoodProperties> FOOD = null; ")
reemplazar("net.minecraft.world.entity.ai.util.DefaultRandomPos",
    "public static net.minecraft.world.phys.Vec3 getPos(net.minecraft.world.entity.PathfinderMob m, int h, int v) { return null; }",
    "public static net.minecraft.world.phys.Vec3 getPos(net.minecraft.world.entity.PathfinderMob m, int h, int v) { return null; } "
    "public static net.minecraft.world.phys.Vec3 getPosAway(net.minecraft.world.entity.PathfinderMob m, int h, int v, "
    "net.minecraft.world.phys.Vec3 lejosDe) { return null; }")
agregar("net.minecraft.world.entity.LivingEntity", "public float getHealth() { return 20; }")
agregar("net.minecraft.world.entity.player.Player", "public void stopSleepInBed(boolean a, boolean b) {} "
    "public net.minecraft.world.inventory.AbstractContainerMenu containerMenu;")
S["net.minecraft.world.inventory.AbstractContainerMenu"] = ("public abstract class AbstractContainerMenu { "
    "public net.minecraft.world.item.ItemStack getCarried() { return null; } "
    "public void setCarried(net.minecraft.world.item.ItemStack s) {} }")
agregar("net.minecraft.sounds.SoundEvents", "public static final net.minecraft.core.Holder.Reference<SoundEvent> RAID_HORN = null; "
    "")
agregar("net.minecraft.network.codec.StreamCodec",
    "static <B, C, T1, T2> StreamCodec<B, C> composite(StreamCodec<? super B, T1> c1, java.util.function.Function<C, T1> g1, "
    "StreamCodec<? super B, T2> c2, java.util.function.Function<C, T2> g2, "
    "java.util.function.BiFunction<T1, T2, C> f) { return null; }")

agregar("net.minecraft.world.phys.AABB", "public boolean contains(net.minecraft.world.phys.Vec3 v) { return false; }")

# el puente de Londres: los robots (bloques estirados), sus datos y los textos con color
S["net.minecraft.client.renderer.LightTexture"] = "public class LightTexture { public static final int FULL_BRIGHT = 15728880; }"
S["net.minecraft.client.renderer.block.BlockRenderDispatcher"] = ("public class BlockRenderDispatcher { "
    "public void renderSingleBlock(net.minecraft.world.level.block.state.BlockState s, com.mojang.blaze3d.vertex.PoseStack p, "
    "net.minecraft.client.renderer.MultiBufferSource b, int l, int o) {} "
    "public net.minecraft.client.renderer.block.ModelBlockRenderer getModelRenderer() { return null; } "
    "public net.minecraft.client.resources.model.BakedModel getBlockModel(net.minecraft.world.level.block.state.BlockState s) { return null; } }")
S["net.minecraft.client.resources.model.BakedModel"] = "public interface BakedModel {}"
S["net.minecraft.client.renderer.block.ModelBlockRenderer"] = ("public class ModelBlockRenderer { "
    "@Deprecated public void renderModel(com.mojang.blaze3d.vertex.PoseStack.Pose p, com.mojang.blaze3d.vertex.VertexConsumer c, "
    "net.minecraft.world.level.block.state.BlockState s, net.minecraft.client.resources.model.BakedModel m, "
    "float r, float g, float b, int l, int o) {} }")
reemplazar("net.minecraft.client.renderer.entity.EntityRendererProvider",
    "public net.minecraft.client.resources.model.ModelManager getModelManager() { return null; }",
    "public net.minecraft.client.resources.model.ModelManager getModelManager() { return null; } "
    "public net.minecraft.client.renderer.block.BlockRenderDispatcher getBlockRenderDispatcher() { return null; }")
S["net.minecraft.world.inventory.InventoryMenu"] = ("public class InventoryMenu extends AbstractContainerMenu { "
    "public static final net.minecraft.resources.ResourceLocation BLOCK_ATLAS = null; }")
agregar("net.minecraft.world.level.block.Blocks", "public static final Block BLUE_CONCRETE = null, WHITE_CONCRETE = null, "
    "GOLD_BLOCK = null, YELLOW_CONCRETE = null, ORANGE_CONCRETE = null, OCHRE_FROGLIGHT = null;")
agregar("net.minecraft.util.Mth", "public static final float DEG_TO_RAD = 0.017453292F; "
    "public static float lerp(float d, float a, float b) { return a + d * (b - a); } "
    "public static float cos(float v) { return (float) Math.cos(v); }")
reemplazar("net.minecraft.network.syncher.EntityDataSerializers", "public static final EntityDataSerializer<Integer> INT = null; ",
    "public static final EntityDataSerializer<Integer> INT = null; public static final EntityDataSerializer<Float> FLOAT = null; "
    "public static final EntityDataSerializer<Boolean> BOOLEAN = null; ")
agregar("net.minecraft.world.entity.Entity",
    "public net.minecraft.world.InteractionResult interact(net.minecraft.world.entity.player.Player p, net.minecraft.world.InteractionHand h) { return null; } "
    "public net.minecraft.world.phys.AABB getBoundingBoxForCulling() { return null; }")
agregar("net.minecraft.sounds.SoundEvents", "public static final net.minecraft.core.Holder.Reference<SoundEvent> NOTE_BLOCK_BELL = null, "
    "NOTE_BLOCK_BIT = null;")
agregar("net.minecraft.network.chat.Component", "default MutableComponent copy() { return null; }")

agregar("net.minecraft.world.item.Items", "public static final Item RABBIT_STEW = null;")

agregar("net.minecraft.util.Mth", "public static float sin(float v) { return (float) Math.sin(v); }")
agregar("net.minecraft.world.level.block.Blocks", "public static final Block LIGHT_BLUE_CONCRETE = null;")

out = sys.argv[1]
for fq, body in S.items():
    pkg, cls = fq.rsplit(".", 1)
    d = os.path.join(out, *pkg.split("."))
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, cls + ".java"), "w") as f:
        f.write(f"package {pkg};\n{body}\n")
print(len(S), "stubs")
