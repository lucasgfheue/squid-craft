#!/usr/bin/env python3
"""Genera la arena del juego 3, "Asientos al vacío" (asientos.nbt): un campo de torres altísimas.

Veinticuatro torres oscuras en una grilla de 5 x 5 (arriba, de 9 x 9, con un piso de baile en damero negro y gris),
separadas por 2 bloques de vacío: se puede saltar de una a la de al lado. En el medio, más alta, la torre del
gramófono, que pone la música (no se puede subir). Mientras suena, cada uno anda por donde quiere; cuando para,
aparecen sillas en algunas torres, menos que gente: el que no está sentado cuando se cae el piso, se cae con él (59
bloques). Al norte, la entrada (el palco, con baranda), con el podio del comandante y el portal de vuelta.

Coordenadas del mundo: la plantilla empieza en (1969, 40, -17). El suelo en y = 40; arriba de las torres, en y = 99.
  palco             x 1975..2025, z -16..1   (el podio en x 1996..2004, z -15..-12)
  torres            arriba, de x0 = 1974 + 11 i a x0 + 8, y de z0 = 8 + 11 j a z0 + 8 (i, j de 0 a 4)
  el gramófono      la torre del medio (i = j = 2: x 1996..2004, z 30..38), con el piso en y = 103

Uso: python3 gen_asientos.py <salida.nbt> <bloques.pkl>
"""
import math
import sys

from arenas_comun import PISO, Arena, S

OX, OY, OZ = 1969, 40, -17
SX, SY, SZ = 63, 78, 80                  # x 1969..2031, y 40..117, z -17..62
A = Arena(OX, OY, OZ, SX, SY, SZ)
SUELO = 40
PALCO = (1975, 2025, -16, 1)
LADO, PASO = 9, 11                       # cada torre, de 9 x 9; de una a la otra, 11 (2 de vacío)
X_TORRES = [1974 + PASO * i for i in range(5)]
Z_TORRES = [8 + PASO * j for j in range(5)]
GRAMOFONO = (2, 2)
PISO_GRAMOFONO = 103
NEGRO = S("polished_blackstone")
GRIS = S("polished_deepslate")
BORDE = S("polished_blackstone_bricks")
ORO = S("gold_block")
CALIDA = S("shroomlight")


def torres():
    for i, x0 in enumerate(X_TORRES):
        for j, z0 in enumerate(Z_TORRES):
            yield i, j, x0, z0


# =================================================================== el suelo, allá abajo
for x in range(OX, OX + SX):
    for z in range(OZ, OZ + SZ):
        A.put(x, SUELO, z, CALIDA if x % 8 == 4 and z % 8 == 4 else S("deepslate_tiles"))

# =================================================================== las torres
A.torre(*PALCO[:2], *PALCO[2:], SUELO + 1, PISO - 1, S("deepslate_tiles"), bandas=(60, 80),
        banda=S("polished_deepslate"), ventanas=CALIDA, cada=6, alturas=(52, 72, 92))
for i, j, x0, z0 in torres():
    arriba = PISO_GRAMOFONO if (i, j) == GRAMOFONO else PISO
    A.torre(x0, x0 + LADO - 1, z0, z0 + LADO - 1, SUELO + 1, arriba - 1, S("deepslate_tiles"),
            bandas=(56, 57, 76, 77, 96), banda=S("chiseled_deepslate"), ventanas=CALIDA, cada=4,
            alturas=(66, 86) if (i + j) % 2 == 0 else (61, 81))
    for x in range(x0, x0 + LADO):
        for z in range(z0, z0 + LADO):
            if (i, j) == GRAMOFONO:
                A.put(x, arriba, z, BORDE if x in (x0, x0 + LADO - 1) or z in (z0, z0 + LADO - 1) else NEGRO)
            else:                                              # el piso de baile: damero negro y gris, borde oscuro
                borde = x in (x0, x0 + LADO - 1) or z in (z0, z0 + LADO - 1)
                A.put(x, arriba, z, BORDE if borde else NEGRO if (x + z) % 2 == 0 else GRIS)

# =================================================================== el palco: baranda, entrada y faroles
x0, x1, z0, z1 = PALCO
for x in range(x0, x1 + 1):
    for z in range(z0, z1 + 1):
        A.put(x, PISO, z, BORDE if x in (x0, x1) or z in (z0, z1) else S("polished_andesite"))
borde = [(x, z) for x in range(x0, x1 + 1) for z in (z0, z1)] + [(x, z) for z in range(z0, z1 + 1) for x in (x0, x1)]
borde = [(x, z) for (x, z) in borde if not (z == z0 and OX + 8 <= x <= OX + 14)]
A.baranda(borde, PISO + 1, PISO + 2)
A.entrada(3)
for (x, z) in ((x0 + 1, z1 - 1), (x1 - 1, z1 - 1), (x0 + 1, z0 + 1), (x1 - 1, z0 + 1)):
    A.put(x, PISO + 1, z, BORDE)
    A.put(x, PISO + 2, z, S("lantern", hanging=False, waterlogged=False))

# =================================================================== el gramófono, arriba de la torre del medio
CX = X_TORRES[2] + 4                     # 2000
CZ = Z_TORRES[2] + 4                     # 34
P = PISO_GRAMOFONO
MADERA = S("dark_oak_planks")
for dx in range(-3, 4):                                        # el mueble: madera oscura con cantos dorados
    for dz in range(-3, 4):
        for y in range(P + 1, P + 4):
            canto = abs(dx) == 3 and abs(dz) == 3 or y == P + 3 and (abs(dx) == 3 or abs(dz) == 3)
            A.put(CX + dx, y, CZ + dz, ORO if canto else MADERA)
for dx in range(-2, 3):                                        # el disco negro y el eje
    for dz in range(-2, 3):
        if dx * dx + dz * dz <= 5:
            A.put(CX + dx, P + 4, CZ + dz, S("black_concrete"))
A.put(CX, P + 5, CZ, S("lightning_rod", facing="up", powered=False, waterlogged=False))
BOCA_Z = CZ + 2                                                # la bocina: aros dorados que se abren hacia arriba
for radio, yc in ((0.5, P + 6), (0.9, P + 7), (1.4, P + 8), (2.0, P + 9), (2.7, P + 10), (3.4, P + 11),
                  (4.0, P + 12), (4.5, P + 13)):
    for dx in range(-5, 6):
        for dz in range(-5, 6):
            r = math.hypot(dx, dz)
            if radio - 0.55 <= r <= radio + 0.45 or (radio < 1.0 and r <= radio):
                A.put(CX + dx, yc, BOCA_Z + dz, ORO)
for y in range(P + 4, P + 6):
    A.put(CX, y, BOCA_Z, ORO)
for k in range(4):                                             # cuatro faroles en las esquinas de la torre
    A.put(X_TORRES[2] + (0 if k % 2 == 0 else LADO - 1), P + 1, Z_TORRES[2] + (0 if k < 2 else LADO - 1),
          S("lantern", hanging=False, waterlogged=False))

# =================================================================== luces: arriba, invisibles; y en el vacío, para ver lo alto
A.luces(x0 + 1, x1 - 1, z0 + 1, z1 - 1)
for i, j, tx, tz in torres():
    if (i, j) != GRAMOFONO:
        A.luces(tx, tx + LADO - 1, tz, tz + LADO - 1)
for x in [tx + LADO for tx in X_TORRES[:-1]]:
    for z in range(10, 62, 9):
        for y in (54, 70, 86):
            if A.get(x, y, z) is None:
                A.put(x, y, z, S("light", level=10, waterlogged=False))

if __name__ == "__main__":
    A.guardar(sys.argv[1], sys.argv[2], "asientos")
