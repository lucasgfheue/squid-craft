#!/usr/bin/env python3
"""Imágenes de la noche del complejo (comparada con el día) y de un portal abierto en la torre.
Uso: python3 noche_render.py <bloques.pkl> <torre.pkl> <carpeta de salida> <ancho> <alto> <supermuestreo>"""
import os
import pickle
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont

salon, torre, carpeta = sys.argv[1], sys.argv[2], sys.argv[3]
W, H, SS = sys.argv[4], sys.argv[5], sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
tmp = tempfile.gettempdir()

# ---------------------------------------------------------------- 1) la sala de día y de noche
datos = pickle.load(open(salon, "rb"))
OFF = datos["offset"]
noche = {}
for (x, y, z), st in datos["blocks"].items():
    en_salon = 0 <= z - OFF <= 72
    if en_salon and "waxed_copper_bulb" in st and y in (20, 12):
        st = st.replace("lit=true", "lit=false")              # lámparas del techo y de arriba de las columnas
    elif en_salon and st.startswith("minecraft:lantern"):
        st = st.replace("minecraft:lantern", "minecraft:soul_lantern")   # faroles con luz azul tenue
    elif en_salon and y == 0 and st == "minecraft:sea_lantern":
        hz = z - OFF
        if not (x == 32 or (x in (18, 46) and (hz - 8) % 12 == 0)):
            st = "minecraft:prismarine_bricks"                  # luces del piso apagadas (quedan algunas)
    noche[(x, y, z)] = st
pkl_noche = os.path.join(tmp, "bloques_noche.pkl")
pickle.dump({"size": datos["size"], "blocks": noche, "offset": OFF}, open(pkl_noche, "wb"))
partes = []
for nombre, pkl in (("dia", salon), ("noche", pkl_noche)):
    salida = os.path.join(tmp, f"sala_{nombre}.png")
    subprocess.run([sys.executable, os.path.join(AQUI, "render.py"), pkl, "plaza", salida, W, H, SS], check=True)
    partes.append((nombre, Image.open(salida).convert("RGB")))
ancho, alto = partes[0][1].size
hoja = Image.new("RGB", (ancho, 2 * alto + 12), (12, 13, 16))
dib = ImageDraw.Draw(hoja)
letra = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", max(16, alto // 18))
for i, (nombre, im) in enumerate(partes):
    hoja.paste(im, (0, i * (alto + 12)))
    texto = "De día" if nombre == "dia" else "De noche (luces apagadas)"
    dib.rectangle((10, i * (alto + 12) + 10, 22 + dib.textlength(texto, font=letra), i * (alto + 12) + 16 + letra.size), fill=(0, 0, 0))
    dib.text((16, i * (alto + 12) + 12), texto, font=letra, fill=(255, 255, 255))
hoja.save(os.path.join(carpeta, "12_sala_dia_y_noche.png"), optimize=True)
print("guardado 12_sala_dia_y_noche.png")

# ---------------------------------------------------------------- 2) la puerta 1 de la torre, abierta con su portal
t = pickle.load(open(torre, "rb"))
bloques = dict(t["blocks"])
portal = "juegosdelpatio:portal_juego[juego=1,regreso=false]"
for z in (5, 6, 7):
    for y in (9, 10, 11, 12):
        bloques[(0, y, z)] = portal
pkl_torre = os.path.join(tmp, "torre_portal.pkl")
pickle.dump({"size": t["size"], "blocks": bloques, "offset": 0}, open(pkl_torre, "wb"))
codigo = (
    "import sys; sys.argv=['render.py', %r]; sys.path.insert(0, %r)\n"
    "import render as R\n"
    "W2, H2 = %d, %d\n"
    "o, d = R.perspective(W2, H2, (11.5, 13.2, 9.0), (0.5, 12.6, 6.3), 64)\n"
    "R.save(R.render(R.FULL_GRID, o, d, W2, H2), %r, %d)\n"
) % (pkl_torre, AQUI, int(W) * int(SS), int(H) * int(SS), os.path.join(carpeta, "13_puerta_portal.png"), int(SS))
subprocess.run([sys.executable, "-c", codigo], check=True)
