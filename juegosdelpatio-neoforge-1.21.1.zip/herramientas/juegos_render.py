#!/usr/bin/env python3
"""Vistas previas de los juegos en torres (Asientos al vacío, Fuego cruzado, El tejo y Los estandartes), con render.py
y recortes (billboards) de las personas, como puente_render.py.

Uso: python3 juegos_render.py <arena.pkl> <salida.png> <ancho> <alto> <supermuestreo> <escena>
  asientos: paró la música: aparecieron sillas en algunas torres y todos saltan a buscar una; uno no llegó
  fuego:    los rojos contra los azules, con bolas de fuego volando sobre el abismo; el piso, quemado y con agujeros
  tejo:     los que tienen el tejo (brillan) persiguen a los demás de torre en torre; hay agujeros de otras rondas
  estandartes: todo el campo: un rojo vuelve con el estandarte azul en la cabeza, se pelea en la plaza y se derrumban
            dos torres de los costados (otras dos ya cayeron)
  bastion:  el bastión rojo de cerca: los azules llegan saltando y uno está por agarrar el estandarte rojo
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
ESCENA = sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")
FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FUENTE_NEGRITA = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

datos = pickle.load(open(entrada, "rb"))
OX, OY, OZ = datos["origen"]
bloques = dict(datos["blocks"])


def L(wx, wy, wz):
    return np.array([wx - OX, wy - OY, wz - OZ], float)


azar_b = random.Random(11)
if ESCENA == "fuego":                                   # el piso quemado (magma) y con agujeros, más cerca del abismo
    for (z0_, z1_, frente_) in ((9, 23, 23), (34, 48, 34)):
        for x_ in range(5987, 6014):
            for z_ in range(z0_, z1_ + 1):
                cerca = 1.0 - abs(z_ - frente_) / 15.0
                r_ = azar_b.random()
                clave_ = (x_ - OX, 99 - OY, z_ - OZ)
                if r_ < 0.05 * cerca:
                    bloques.pop(clave_, None)
                elif r_ < 0.20 * cerca:
                    bloques[clave_] = "minecraft:magma_block"
elif ESCENA == "tejo":                                  # agujeros de 3 x 3 de las rondas de antes
    for (hx, hz) in ((7000, 22), (6995, 50), (7005, 68)):
        for x_ in range(hx - 1, hx + 2):
            for z_ in range(hz - 1, hz + 2):
                bloques.pop((x_ - OX, 99 - OY, z_ - OZ), None)
elif ESCENA in ("estandartes", "bastion"):              # torres de los costados: dos caídas y dos agrietadas
    CAIDAS = [(7971, 7975, 10, 14), (8025, 8029, 10, 14)]
    AGRIETADAS = [(7979, 7983, 32, 36), (8017, 8021, 32, 36)]
    for (x0_, x1_, z0_, z1_) in CAIDAS:
        for x_ in range(x0_, x1_ + 1):
            for z_ in range(z0_, z1_ + 1):
                for y_ in range(92, 102):
                    borde_ = x_ in (x0_, x1_) or z_ in (z0_, z1_)
                    if y_ >= 99 or borde_ and y_ >= 92 + (x_ * 7 + z_ * 3) % 6:
                        bloques.pop((x_ - OX, y_ - OY, z_ - OZ), None)
    for k_, (x0_, x1_, z0_, z1_) in enumerate(AGRIETADAS):
        for x_ in range(x0_, x1_ + 1):
            for z_ in range(z0_, z1_ + 1):
                clave_ = (x_ - OX, 99 - OY, z_ - OZ)
                if k_ == 0 and azar_b.random() < 0.55:      # la primera ya se está cayendo: faltan pedazos
                    bloques.pop(clave_, None)
                    continue
                antes_ = bloques.get(clave_, "")
                bloques[clave_] = ("minecraft:cracked_polished_blackstone_bricks" if "blackstone_bricks" in antes_
                                   else "minecraft:cracked_deepslate_tiles")
tmp = os.path.join(tempfile.gettempdir(), "juegos_escena.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": 0}, open(tmp, "wb"))
sys.argv = ["render.py", tmp]
sys.path.insert(0, AQUI)
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
if ESCENA == "asientos":
    POS, TGT, FOV = L(2035.0, 110.0, 6.0), L(2006.0, 88.0, 26.0), 72
elif ESCENA == "fuego":
    POS, TGT, FOV = L(6023.0, 114.0, 12.0), L(6000.0, 86.0, 33.0), 76
elif ESCENA == "tejo":
    POS, TGT, FOV = L(7024.0, 118.0, 28.0), L(6998.0, 86.0, 46.0), 76
elif ESCENA == "estandartes":
    POS, TGT, FOV = L(8000.0, 124.0, 61.0), L(8000.0, 95.0, 19.0), 64
else:
    POS, TGT, FOV = L(7977.5, 104.6, 25.2), L(7962.0, 100.8, 22.8), 60
if os.environ.get("CAMARA"):                            # para probar otras cámaras: "x,y,z;x,y,z;fov"
    a_, b_, c_ = os.environ["CAMARA"].split(";")
    POS, TGT, FOV = L(*map(float, a_.split(","))), L(*map(float, b_.split(","))), float(c_)
O, D = R.perspective(W2, H2, POS, TGT, FOV)

golpe, t, n, celda, kid = R.trace(O, D, R.FULL_GRID)
img = np.zeros((len(O), 3))
img[:] = (0.03, 0.03, 0.04)
hi = np.nonzero(golpe)[0]
Pp = O[hi] + D[hi] * t[hi][:, None]
nn, cc, k = n[hi], celda[hi], kid[hi]
local = Pp - cc
eje = np.argmax(np.abs(nn), 1)
u = np.where(eje == 0, local[:, 2], local[:, 0])
v = np.where(eje == 1, local[:, 2], local[:, 1])
alb = R.shade_colors(k, u, v, local, cc, nn)
cara = np.select([nn[:, 1] > 0, nn[:, 1] < 0, eje == 2], [1.0, 0.5, 0.8], 0.6)
Lz, ao = R.smooth_light(Pp, nn, R.opaque_of[R.FULL_GRID])
col = alb * R.brightness(Lz) * (cara * ao)[:, None]
em = np.array([R.kinds[kk][0] in R.EMISSIVE and R.emit_of[kk] > 0 for kk in k])
col[em] = alb[em] * (0.92 + 0.08 * cara[em])[:, None]
img[hi] = col
img = np.clip(img, 0, 1).reshape(H2, W2, 3)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
arriba = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    d = np.asarray(p) - POS
    z = d @ f
    x = (d @ r) / z / (th * W2 / H2)
    y = (d @ arriba) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(p):
    cx, cy, cz = int(math.floor(p[0])), int(math.floor(p[1])), int(math.floor(p[2]))
    niveles = [R.LIGHTF[cx + dx, yy, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1) for yy in (cy, cy + 1)
               if 0 <= cx + dx < R.LIGHTF.shape[0] and 0 <= cz + dz < R.LIGHTF.shape[2] and 0 <= yy < R.LIGHTF.shape[1]]
    return R.brightness(np.array([max(niveles)]))[0] * 0.95


COLOR = {"pelota": (0.86, 0.18, 0.14), "pelota_azul": (0.20, 0.40, 0.86), "espada": (0.78, 0.80, 0.84),
         "fuego": (1.0, 0.62, 0.18), "llama": (1.0, 0.40, 0.08), "asiento": (0.46, 0.06, 0.08),
         "madera": (0.20, 0.14, 0.09), "tejo": (0.95, 0.16, 0.10), "oro": (0.95, 0.78, 0.30),
         "tela_roja": (0.74, 0.16, 0.13), "tela_azul": (0.22, 0.30, 0.78), "palo": (0.33, 0.24, 0.15),
         "baldosa": (0.20, 0.20, 0.22), "ladrillo": (0.18, 0.15, 0.19), "polvo": (0.32, 0.31, 0.33)}


def caja(centro, tam, color, brillo=False, giro=None):
    return (np.array(centro, float), np.array(tam, float) / 2.0, COLOR[color] if isinstance(color, str) else color,
            brillo, np.eye(3) if giro is None else giro)


def dibujar_cajas(cajas):
    for centro, medio, colr, brillo, ejes in cajas:
        esquinas = [centro + ejes @ (medio * np.array([sx, sy, sz])) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
        if any((e - POS) @ f <= 0.05 for e in esquinas):
            continue
        pts = [proyectar(e) for e in esquinas]
        i0 = max(int(min(q[0] for q in pts)) - 1, 0)
        i1 = min(int(max(q[0] for q in pts)) + 2, W2)
        j0 = max(int(min(q[1] for q in pts)) - 1, 0)
        j1 = min(int(max(q[1] for q in pts)) + 2, H2)
        if i0 >= i1 or j0 >= j1:
            continue
        dirs = DIRS[j0:j1, i0:i1].reshape(-1, 3)
        o_ = (POS - centro) @ ejes                                   # en el sistema de la caja
        d_ = dirs @ ejes
        with np.errstate(divide="ignore", invalid="ignore"):
            t1 = (-medio - o_) / d_
            t2 = (medio - o_) / d_
        tmin = np.minimum(t1, t2)
        tmax = np.maximum(t1, t2)
        entra = np.max(tmin, 1)
        sale = np.min(tmax, 1)
        cara_ = np.argmax(tmin, 1)
        ver = (sale >= entra) & (entra > 0)
        zona_p = prof[j0:j1, i0:i1].reshape(-1)
        ver &= entra < zona_p
        if not ver.any():
            continue
        signo = -np.sign(d_[np.arange(len(d_)), cara_])
        normal = ejes[:, cara_].T * signo[:, None]                   # en el mundo
        sombra_cara = np.where(normal[:, 1] > 0.6, 1.0, np.where(normal[:, 1] < -0.6, 0.5,
                               np.where(np.abs(normal[:, 2]) > np.abs(normal[:, 0]), 0.8, 0.6)))
        punto = POS + dirs * entra[:, None]
        luz = luz_en(punto[ver].mean(0)) if not brillo else 1.0
        c_ = np.array(colr)[None, :] * (np.ones((len(d_), 1)) if brillo else sombra_cara[:, None] * luz)
        zona_i = img[j0:j1, i0:i1].reshape(-1, 3)
        zona_i[ver] = c_[ver]
        zona_p[ver] = entra[ver]
        img[j0:j1, i0:i1] = zona_i.reshape(j1 - j0, i1 - i0, 3)
        prof[j0:j1, i0:i1] = zona_p.reshape(j1 - j0, i1 - i0)


def recorte(sprite, base, alto, ancho, luz, adelante=0.0):
    base = np.asarray(base, float)
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    c = arr[py, px]
    efectivo = tt - adelante
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (c[..., 3] > 0) & (tt > 0) & (efectivo < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = c[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = efectivo[ver]


def sombra(base, ancho):
    cx, cy = proyectar(base)
    ex, _ = proyectar(np.asarray(base) + DERECHA * ancho * 0.6)
    rx = abs(ex - cx)
    ry = rx * 0.55
    if rx < 1:
        return
    j0, j1 = max(int(cy - ry) - 1, 0), min(int(cy + ry) + 2, H2)
    i0, i1 = max(int(cx - rx) - 1, 0), min(int(cx + rx) + 2, W2)
    if i0 >= i1 or j0 >= j1:
        return
    jj_, ii_ = np.ogrid[j0:j1, i0:i1]
    m = ((ii_ - cx) / rx) ** 2 + ((jj_ - cy) / max(ry, 1)) ** 2 <= 1
    img[j0:j1, i0:i1][m] *= 0.62


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


def perfil(skin, derecha):
    out = Image.new("RGBA", (8, 32), (0, 0, 0, 0))
    cara_ = (0, 8) if derecha else (16, 8)
    pegar(out, skin, cara_[0], cara_[1], 8, 8, 0, 0)
    pegar(out, skin, 16 if derecha else 28, 20, 4, 12, 2, 8)
    pegar(out, skin, 40 if derecha else 48, 20, 4, 12, 2, 8)
    pegar(out, skin, 0 if derecha else 8, 20, 4, 12, 2, 20)
    return out


def sprite_caminando(x, z, dx, dz, skin):
    hacia_camara = (dx * FRENTE[0] + dz * FRENTE[2])
    if hacia_camara > 0.4:
        return frente(skin), ANCHO
    if hacia_camara < -0.4:
        return espalda(skin), ANCHO
    return perfil(skin, (dx * DERECHA[0] + dz * DERECHA[2]) > 0), ANCHO / 2


ALTO, ANCHO = 1.85, 0.925
skins = [Image.open(os.path.join(TEX, f"entity/jugador/skin_{i}.png")).convert("RGBA") for i in range(48)]
azar = random.Random(5)
ROJO, AZUL = (138, 28, 26, 255), (36, 60, 140, 255)


def chaleco(sprite, color):
    """Le pone el chaleco del equipo: el torso del color del equipo, con dos franjas oscuras."""
    out = sprite.copy()
    px = out.load()
    cols = range(2, 6) if out.size[0] == 8 else range(4, 12)
    for y in range(8, 20):
        for x in cols:
            if px[x, y][3] > 0:
                px[x, y] = (30, 28, 30, 255) if y in (13, 16) else color
    return out


def brillo_rojo(sprite):
    """El que tiene el tejo: brilla (un borde rojo alrededor, como el efecto de brillo del juego)."""
    w_, h_ = sprite.size
    out = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_ = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_.alpha_composite(sprite, (1, 1))
    a_ = base_.split()[3]
    for dx_, dy_ in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        borde_ = Image.new("RGBA", base_.size, (255, 60, 40, 255))
        out.paste(borde_, (dx_, dy_), a_)
    out.alpha_composite(base_)
    return out


def brillo(sprite, color):
    """El efecto de brillo del juego: un borde del color dado alrededor de la persona."""
    w_, h_ = sprite.size
    out = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_ = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_.alpha_composite(sprite, (1, 1))
    a_ = base_.split()[3]
    for dx_, dy_ in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        out.paste(Image.new("RGBA", base_.size, color), (dx_, dy_), a_)
    out.alpha_composite(base_)
    return out


def persona(x, z, mira_x, mira_z, color=None, y=100.0, skin=None, sentado=False, tejo=False, brilla=None):
    """Una persona en (x, z) mirando hacia (mira_x, mira_z): de frente, de espaldas o de perfil, según la cámara."""
    dx, dz = mira_x - x, mira_z - z
    largo = math.hypot(dx, dz) or 1.0
    sprite, ancho = sprite_caminando(x, z, dx / largo, dz / largo, skin or skins[azar.randrange(48)])
    if color is not None:
        sprite = chaleco(sprite, color)
    alto = ALTO
    if sentado:                                         # sentado: sin piernas, a la altura del asiento
        sprite = sprite.crop((0, 0, sprite.size[0], 20))
        alto = ALTO * 20 / 32
    if tejo:
        sprite = brillo_rojo(sprite)
        ancho *= sprite.size[0] / (sprite.size[0] - 2)
    if brilla:
        sprite = brillo(sprite, brilla)
        ancho *= sprite.size[0] / (sprite.size[0] - 2)
    if np.linalg.norm(L(x, y + 1.6, z) - POS) > 3.0:
        personas.append((x, y, z, sprite, alto, ancho))
    return dx / largo, dz / largo


def silla(x, z, mira_z):
    """Una silla (patas de madera oscura, asiento de terciopelo rojo y respaldo del lado contrario a donde mira)."""
    cajas.append(caja(L(x, 100.22, z), (0.62, 0.44, 0.62), "madera"))
    cajas.append(caja(L(x, 100.5, z), (0.8, 0.12, 0.8), "asiento"))
    atras = -0.36 if mira_z > z else 0.36
    cajas.append(caja(L(x, 100.95, z + atras), (0.8, 0.85, 0.1), "madera"))
    cajas.append(caja(L(x, 101.0, z + atras * 0.92), (0.6, 0.55, 0.06), "asiento"))


personas = []                                          # (x, y, z, sprite, alto, ancho)
cajas = []
if ESCENA == "asientos":
    XT = [1974 + 11 * i_ for i_ in range(5)]
    ZT = [8 + 11 * j_ for j_ in range(5)]
    con_sillas = [(0, 1), (1, 3), (3, 0), (4, 2), (3, 3), (1, 0), (0, 4)]
    for (i_, j_) in con_sillas:                         # las sillas que aparecieron (menos que gente)
        x0_, z0_ = XT[i_], ZT[j_]
        lugares = azar.sample([(a_, b_) for a_ in range(1, 8, 2) for b_ in range(1, 8, 3)], 4)
        for k_, (a_, b_) in enumerate(lugares):
            sx, sz = x0_ + a_ + 0.5, z0_ + b_ + 0.5
            silla(sx, sz, sz - 3)
            if k_ < 2:
                persona(sx, sz + 0.05, sx, sz - 3, y=100.55, sentado=True)
    for (i_, j_) in [(a_, b_) for a_ in range(5) for b_ in range(5) if (a_, b_) != (2, 2)]:
        for _ in range(azar.choice((0, 1, 1, 2))):      # los que corren a buscar silla
            x0_, z0_ = XT[i_], ZT[j_]
            x, z = azar.uniform(x0_ + 0.8, x0_ + 8.2), azar.uniform(z0_ + 0.8, z0_ + 8.2)
            persona(x, z, x + azar.uniform(-6, 6), z + azar.uniform(-6, 6))
    persona(1994.3, 13.0, 1997.0, 13.0, y=101.1)        # uno saltando de una torre a la otra
    persona(2006.0, 51.0, 2006.0, 47.0, y=78.0)         # y uno que no llegó: se cae entre las torres
    for k_, (nx, ny, nz) in enumerate(((1999.0, 118.5, 37.5), (2002.5, 117.0, 39.0), (2001.0, 116.0, 41.5))):
        cajas.append(caja(L(nx, ny, nz), (0.35, 0.35, 0.12), "oro", brillo=True))     # notas que se apagan
elif ESCENA == "fuego":
    for _ in range(14):                                 # los rojos, arriba de su torre (miran a los azules)
        x, z = azar.uniform(5988.5, 6012.5), azar.uniform(10.0, 22.5)
        persona(x, z, x + azar.uniform(-3, 3), 44, ROJO)
    for _ in range(13):                                 # los azules, en la suya
        x, z = azar.uniform(5988.5, 6012.5), azar.uniform(35.5, 47.5)
        persona(x, z, x + azar.uniform(-3, 3), 16, AZUL)
    persona(6015.4, 18.5, 6011.0, 18.0, ROJO, y=90.0)  # a uno lo empujó una bola de fuego: se cae
    for (bx, by, bz, vz) in ((5996.0, 102.1, 29.5, 1), (6004.5, 101.6, 27.0, -1), (6001.0, 102.6, 31.5, 1),
                             (5992.0, 101.4, 26.0, -1), (6008.0, 101.9, 30.0, 1), (5999.0, 102.3, 22.0, 1)):
        cajas.append(caja(L(bx, by, bz), (0.45, 0.45, 0.45), "fuego", brillo=True))
        for k_ in range(1, 4):                          # la estela
            cajas.append(caja(L(bx, by + 0.05 * k_, bz - vz * 0.45 * k_), (0.3 - 0.06 * k_,) * 3, "llama",
                              brillo=True))
elif ESCENA == "tejo":
    TORRES = {1: (6997, 7003, 11, 17), 2: (6997, 7003, 20, 26), 3: (6992, 6998, 29, 35), 4: (7002, 7008, 29, 35),
              5: (6997, 7003, 38, 44), 6: (6992, 6998, 47, 53), 7: (7002, 7008, 47, 53), 8: (6997, 7003, 56, 62),
              9: (6992, 6998, 65, 71), 10: (7002, 7008, 65, 71)}
    for numero, (x0, x1, z0, z1) in TORRES.items():    # repartidos por las torres
        for _ in range(azar.choice((1, 2, 2, 3))):
            x, z = azar.uniform(x0 + 0.8, x1 + 0.2), azar.uniform(z0 + 0.8, z1 + 0.2)
            if abs(x - 7000) < 2.2 and 20.5 < z < 23.5 or abs(x - 6995) < 2.2 and 48.5 < z < 51.5:
                continue                                # ahí hay agujeros
            persona(x, z, x + azar.uniform(-4, 4), z + azar.uniform(-6, 6))
    for _ in range(9):                                  # en la largada
        x, z = azar.uniform(6984, 7016), azar.uniform(-6.0, 6.0)
        persona(x, z, 7000 + azar.uniform(-3, 3), 12)
    for _ in range(3):                                  # en el cielo
        x, z = azar.uniform(6994, 7006), azar.uniform(76.5, 81.0)
        persona(x, z, x + azar.uniform(-4, 4), 70)
    for (tx, tz, mx, mz) in ((7000.5, 41.0, 7000.5, 37.0), (6994.0, 32.0, 6996.0, 36.0)):
        persona(tx, tz, mx, mz, tejo=True)               # los que tienen el tejo, persiguiendo
        cajas.append(caja(L(tx + 0.4, 101.0, tz), (0.32, 0.22, 0.32), "tejo", brillo=True))
    persona(7000.6, 36.6, 7000.6, 33.0, y=101.2)         # uno salta para escaparse
    persona(6994.8, 50.3, 6995.0, 47.0, y=86.0)          # y uno cae por un agujero
elif ESCENA in ("estandartes", "bastion"):
    def giro_y(dx_, dz_):
        """Los ejes de una caja que mira hacia (dx, dz): x a lo ancho, z hacia adelante."""
        lz_ = math.hypot(dx_, dz_) or 1.0
        fx_, fz_ = dx_ / lz_, dz_ / lz_
        return np.array([[fz_, 0, fx_], [0, 1, 0], [-fx_, 0, fz_]])

    def estandarte_parado(x_, z_, tela, mira_x):
        """El estandarte en su pedestal: el palo, el travesaño y la tela (mira al campo)."""
        cajas.append(caja(L(x_, 101.32, z_), (0.13, 2.64, 0.13), "palo"))
        cajas.append(caja(L(x_, 102.58, z_), (0.12, 0.12, 1.30), "palo"))
        cajas.append(caja(L(x_ + 0.11 * mira_x, 101.45, z_), (0.06, 2.20, 1.20), tela))

    def con_espada(x_, z_, mx_, mz_, y_=100.0):
        lado_ = np.array([-(mz_ - z_), 0.0, mx_ - x_])
        lado_ = lado_ / (np.linalg.norm(lado_) or 1.0) * 0.40
        p_ = L(x_, y_ + 0.95, z_) + lado_
        g_ = giro_y(mx_ - x_, mz_ - z_) @ np.array([[1, 0, 0], [0, math.cos(0.6), -math.sin(0.6)],
                                                      [0, math.sin(0.6), math.cos(0.6)]])
        cajas.append(caja(p_ + g_ @ np.array([0, 0.36, 0]), (0.09, 0.78, 0.09), "espada", giro=g_))

    def peleador(x_, z_, mx_, mz_, color_, y_=100.0, espada=True):
        persona(x_, z_, mx_, mz_, color_, y=y_)
        if espada:
            con_espada(x_, z_, mx_, mz_, y_)

    def portador(x_, z_, mx_, mz_, color_, tela):
        """El que lleva el estandarte: brilla (borde blanco), sin espada, y el estandarte puesto en la cabeza."""
        persona(x_, z_, mx_, mz_, color_, brilla=(255, 255, 255, 255))
        g_ = giro_y(mx_ - x_, mz_ - z_)
        atras_ = -np.array([mx_ - x_, 0.0, mz_ - z_]) / (math.hypot(mx_ - x_, mz_ - z_) or 1.0) * 0.18
        base_ = L(x_, 101.9, z_) + atras_
        cajas.append(caja(base_ + np.array([0, 0.62, 0]), (0.08, 1.30, 0.08), "palo"))
        cajas.append(caja(base_ + g_ @ np.array([0, 1.22, 0]), (0.70, 0.07, 0.07), "palo", giro=g_))
        cajas.append(caja(base_ + g_ @ np.array([0, 0.74, -0.05]), (0.64, 0.92, 0.04), tela, giro=g_))

    # los estandartes: el rojo en su bastión; el azul, robado (lo lleva un rojo)
    estandarte_parado(7962.5, 23.5, "tela_roja", 1)
    if ESCENA == "bastion":
        estandarte_parado(8038.5, 23.5, "tela_azul", -1)
    # la torre que se está cayendo: pedazos en el aire
    for k_ in range(34):
        alto_ = azar.uniform(0.0, 1.0)
        abre_ = 0.6 + 2.4 * (1.0 - alto_)                    # los que ya cayeron más, se abrieron más
        bx_, bz_ = azar.uniform(7979.0 - abre_, 7984.0 + abre_), azar.uniform(32.0 - abre_, 37.0 + abre_)
        by_ = 74.0 + 24.5 * alto_
        a_ = azar.uniform(-0.6, 0.6)
        g_ = np.array([[math.cos(a_), -math.sin(a_), 0], [math.sin(a_), math.cos(a_), 0], [0, 0, 1]]) @ giro_y(
            azar.uniform(-1, 1), azar.uniform(-1, 1))
        cajas.append(caja(L(bx_, by_, bz_), (azar.choice((0.98, 0.98, 0.6, 0.45)),) * 3,
                          azar.choice(("baldosa", "baldosa", "ladrillo")), giro=g_))
    for _ in range(18):
        cajas.append(caja(L(azar.uniform(7979, 7984), azar.uniform(98.5, 100.4), azar.uniform(32, 37)), (0.08,) * 3,
                          "polvo"))
    if ESCENA == "estandartes":
        for (x_, z_) in ((7960.5, 21.0), (7964.0, 25.5), (7961.0, 27.5), (7963.5, 19.0)):   # cuidan el estandarte
            peleador(x_, z_, 7975, 23, ROJO)
        for (x_, z_) in ((8037.0, 21.5), (8039.5, 25.0), (8035.5, 27.0)):                  # se lo robaron...
            peleador(x_, z_, 8020, 23, AZUL)
        portador(8010.5, 23.2, 8004.0, 27.5, ROJO, "tela_azul")                            # ...y vuelve con él
        peleador(8011.8, 21.6, 8000, 22.0, ROJO)
        peleador(8012.2, 24.8, 8016, 24.0, ROJO)
        peleador(8017.8, 23.5, 8012, 23.4, AZUL)                                           # lo persiguen
        peleador(8019.5, 22.0, 8013, 23.0, AZUL)
        for (x_, z_, mx_, mz_, c_) in ((7998.0, 21.0, 8000.5, 23.0, ROJO), (8000.5, 22.6, 7998.0, 21.0, AZUL),
                                       (8002.5, 25.5, 8000.0, 26.5, AZUL), (8000.0, 26.8, 8002.5, 25.5, ROJO),
                                       (7996.5, 25.0, 7998.5, 24.0, ROJO), (8003.5, 20.0, 8001.0, 19.5, AZUL)):
            peleador(x_, z_, mx_, mz_, c_)                                                  # se pelea en la plaza
        peleador(7982.0, 23.0, 7995, 23, ROJO)
        peleador(7989.5, 24.0, 7998, 23, ROJO)
        peleador(7973.0, 22.5, 7985, 23, ROJO)
        peleador(8000.0, 12.5, 8000, 20, AZUL)                                             # por el costado norte
        peleador(7989.0, 12.0, 7984, 12, AZUL)
        peleador(8000.5, 34.0, 7995, 34, ROJO)                                             # y por el sur
        peleador(8011.0, 34.5, 8003, 34, AZUL)
        peleador(7989.5, 34.5, 7994, 34, ROJO)
        persona(7985.4, 33.6, 7982.0, 31.0, ROJO, y=91.0)                                  # cae con su torre
        persona(8006.8, 19.5, 8008.0, 18.0, AZUL, y=94.5)                                  # lo tiraron de la plaza
    else:
        for (x_, z_, mx_, mz_) in ((7961.2, 25.8, 7964.0, 22.5), (7964.8, 26.4, 7966.5, 23.0), (7960.0, 19.8, 7963.0, 21.5),
                                   (7959.5, 28.0, 7964.0, 26.0), (7961.0, 14.5, 7966.0, 13.0)):
            peleador(x_, z_, mx_, mz_, ROJO)                                               # los rojos cuidan
        peleador(7963.4, 21.8, 7962.6, 23.4, AZUL)                                          # ¡uno está por agarrarlo!
        peleador(7965.9, 20.3, 7963.0, 21.5, AZUL)
        peleador(7968.6, 21.8, 7962.0, 22.5, AZUL, y_=100.9)                                # otro llega saltando
        peleador(7969.8, 13.0, 7963.0, 13.0, AZUL, y_=101.0)                                # y otro por el norte
        peleador(7972.8, 33.5, 7966.0, 33.0, ROJO)

dibujar_cajas(cajas)
personas.sort(key=lambda p: -np.linalg.norm(L(p[0], p[1], p[2]) - POS))
for x, y, z, sprite, alto, ancho in personas:
    if y == 100.0 and abs(alto - ALTO) < 0.01:
        sombra(L(x, 100.0, z), ancho)
for x, y, z, sprite, alto, ancho in personas:
    base = L(x, y, z)
    recorte(sprite, base, alto, ancho, luz_en(L(x, y, z)))

if ESCENA in ("estandartes", "bastion"):
    img = np.clip(img, 0, 1) ** 0.85                     # un poco más claro (la noche se come los detalles)
final = Image.fromarray((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8))
if SS > 1:
    final = final.resize((W, H), Image.LANCZOS)
dib = ImageDraw.Draw(final, "RGBA")


def texto_con_sombra(xy, texto, letra, color, desplazar):
    dib.text((xy[0] + desplazar, xy[1] + desplazar), texto, font=letra,
             fill=(int(color[0] * 0.25), int(color[1] * 0.25), int(color[2] * 0.25)))
    dib.text(xy, texto, font=letra, fill=color)


def cartel_nombre(p, texto, color):
    """Como el nombre sobre una entidad: letras con un fondo oscuro transparente."""
    x, y = proyectar(p)
    x, y = x / SS, y / SS
    d = np.linalg.norm(p - POS)
    letra = ImageFont.truetype(FUENTE, max(9, int(0.27 * H / (2 * d * th))))     # como en el juego: unos 0,25 bloques
    an = dib.textlength(texto, font=letra)
    dib.rectangle((x - an / 2 - 4, y - letra.size * 0.62, x + an / 2 + 4, y + letra.size * 0.62), fill=(0, 0, 0, 110))
    dib.text((x - an / 2, y - letra.size * 0.58), texto, font=letra, fill=color)


def chat(lineas):
    """El chat, abajo a la izquierda (fondo oscuro transparente)."""
    letra_c = ImageFont.truetype(FUENTE, max(11, H // 50))
    alto_l = int(letra_c.size * 1.3)
    y_ = int(H * 0.80) - alto_l * len(lineas)
    for texto, color_c in lineas:
        an = dib.textlength(texto, font=letra_c)
        dib.rectangle((6, y_ - 2, 14 + an, y_ + alto_l - 2), fill=(0, 0, 0, 120))
        texto_con_sombra((10, y_), texto, letra_c, color_c, max(1, H // 400))
        y_ += alto_l

# ------------------------------------------------------------------ la barra de arriba y los textos
BARRAS = {
    "asientos": ("Asientos al vacío · ronda 2 de 3 · ¡paró la música!", 0.4, (255, 85, 85)),
    "fuego": ("Fuego cruzado · 2:41 · rojos 14 · azules 13", 0.67, (255, 170, 0)),
    "tejo": ("El tejo · ronda 2 de 4 · 2 tejos", 1.0, (255, 85, 85)),
    "estandartes": ("Los estandartes · 3:24 · rojos 14 · azules 12", 0.43, (170, 0, 170)),
    "bastion": ("Los estandartes · 5:51 · rojos 9 · azules 9", 0.73, (170, 0, 170)),
}
LINEAS = {
    "asientos": "¡Siéntate! Clic derecho en una silla libre",
    "fuego": "Clic derecho: tirar · la magma quema · ¡cuidado con los agujeros!",
    "tejo": "Lejos de los que tienen el tejo: cuando suene la campana, caen con él",
    "estandartes": "Roba el estandarte del otro equipo y llévalo a tu bastión",
    "bastion": "Toca el estandarte para agarrarlo · con el estandarte no puedes pegar",
}
nombre_barra, progreso, color = BARRAS[ESCENA]
letra_b = ImageFont.truetype(FUENTE, max(12, H // 46))
ancho_b = int(W * 0.30)
x0 = (W - ancho_b) // 2
y0 = int(H * 0.035)
an_t = dib.textlength(nombre_barra, font=letra_b)
texto_con_sombra(((W - an_t) / 2, y0), nombre_barra, letra_b, (255, 255, 255), max(1, H // 400))
yb = y0 + int(letra_b.size * 1.35)
alto_b = max(5, H // 110)
dib.rectangle((x0 - 1, yb - 1, x0 + ancho_b + 1, yb + alto_b + 1), fill=(0, 0, 0, 200))
dib.rectangle((x0, yb, x0 + ancho_b, yb + alto_b), fill=(int(color[0] * 0.35), int(color[1] * 0.35), int(color[2] * 0.35), 255))
dib.rectangle((x0, yb, x0 + int(ancho_b * progreso), yb + alto_b), fill=color + (255,))
letra = ImageFont.truetype(FUENTE, max(11, H // 52))
linea = LINEAS[ESCENA]
an_l = dib.textlength(linea, font=letra)
texto_con_sombra(((W - an_l) / 2, H * 0.86), linea, letra, (255, 255, 255), max(1, H // 400))
if ESCENA == "asientos":
    chat([("<Comandante> ¡Siéntense! En diez segundos se cae el piso.", (255, 255, 85))])
elif ESCENA == "fuego":
    chat([("Lucía_Pérez se cayó por un agujero", (170, 0, 0))])
elif ESCENA == "tejo":
    chat([("<Comandante> Ronda 2: dos tejos. Corran.", (255, 255, 85)), ("Martín_Silva cayó con el tejo", (170, 0, 0))])
elif ESCENA == "estandartes":
    chat([("Valentina_Díaz robó el estandarte azul", (255, 85, 85)),
          ("<Comandante> Se agrietan dos torres de los costados.", (255, 255, 85)),
          ("Tomás_Acosta cayó con su torre", (170, 0, 0))])
elif ESCENA == "bastion":
    chat([("<Comandante> Quedan 2 minutos.", (255, 255, 85)), ("Bruno_Castro mató a Lucas_Ferreira", (85, 85, 255))])
final.save(salida, optimize=True)
print("guardado", salida, final.size)
