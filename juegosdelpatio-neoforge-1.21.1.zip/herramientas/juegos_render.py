#!/usr/bin/env python3
"""Vistas previas de Asientos al vacío, Sálvese quien pueda, La papa caliente y Los estandartes, con render.py y recortes
(billboards) de las personas, como puente_render.py.

Uso: python3 juegos_render.py <arena.pkl> <salida.png> <ancho> <alto> <supermuestreo> <escena>
  asientos: paró la música: aparecieron sillas en algunas torres y todos saltan a buscar una; uno no llegó
  casilleros: Sálvese quien pueda, en la estación de noche: sonó la alarma y el Cazador (ojos rojos, la cabeza girando)
            camina por el pasillo del medio; algunos se meten en los casilleros de luz verde y otros todavía corren
  tejo:     La papa caliente, en el valle de noche: los cinco que tienen la papa (brillan y humean) persiguen a los
            demás por las colinas; dos se meten en el túnel de la montaña; otra papa acaba de explotar
  estandartes: el campo largo de noche, partido por la grieta: un rojo vuelve con el estandarte azul en la cabeza,
            saltando por las torres del medio, y se pelea con espadas en las torres
  grieta:   lo mismo, de cerca, desde el borde rojo de la grieta
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
ESCENA = sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")
FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FUENTE_NEGRITA = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

datos = pickle.load(open(entrada, "rb"))
OX, OY, OZ = datos["origen"]
bloques = dict(datos["blocks"])


def L(wx, wy, wz):
    return np.array([wx - OX, wy - OY, wz - OZ], float)


azar_b = random.Random(11)
if ESCENA == "casilleros":                              # la alarma: unos casilleros abiertos (luz verde), otros ya ocupados
    CASILLEROS_E = []
    for z_ in range(8, 99, 2):
        CASILLEROS_E += [(5960, z_), (6040, z_)]
    for z_ in range(32, 87, 2):
        CASILLEROS_E += [(5984, z_), (5988, z_), (6012, z_), (6016, z_)]
    for (px_, pz_) in CASILLEROS_E:
        r_ = azar_b.random()
        if r_ < 0.55:                                   # abierto: puerta abierta y luz verde
            for y_ in (100, 101):
                k_ = (px_ - OX, y_ - OY, pz_ - OZ)
                bloques[k_] = bloques[k_].replace("open=false", "open=true")
            bloques[(px_ - OX, 102 - OY, pz_ - OZ)] = "minecraft:verdant_froglight[axis=y]"
tmp = os.path.join(tempfile.gettempdir(), "juegos_escena.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": 0}, open(tmp, "wb"))
sys.argv = ["render.py", tmp]
sys.path.insert(0, AQUI)
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
if ESCENA == "asientos":
    POS, TGT, FOV = L(2035.0, 110.0, 6.0), L(2006.0, 88.0, 26.0), 72
elif ESCENA == "casilleros":
    POS, TGT, FOV = L(6009.0, 102.0, 27.0), L(6000.5, 106.0, 44.0), 74
elif ESCENA == "tejo":
    POS, TGT, FOV = L(7000.0, 134.0, -12.0), L(7000.0, 104.0, 60.0), 72
elif ESCENA == "estandartes":
    POS, TGT, FOV = L(8000.0, 146.0, 0.0), L(8000.0, 110.0, 62.0), 72
else:
    POS, TGT, FOV = L(7978.0, 106.5, 37.5), L(7998.0, 100.5, 47.0), 66
if os.environ.get("CAMARA"):                            # para probar otras cámaras: "x,y,z;x,y,z;fov"
    a_, b_, c_ = os.environ["CAMARA"].split(";")
    POS, TGT, FOV = L(*map(float, a_.split(","))), L(*map(float, b_.split(","))), float(c_)
O, D = R.perspective(W2, H2, POS, TGT, FOV)

golpe, t, n, celda, kid = R.trace(O, D, R.FULL_GRID)
img = np.zeros((len(O), 3))
img[:] = (0.03, 0.03, 0.04)
hi = np.nonzero(golpe)[0]
Pp = O[hi] + D[hi] * t[hi][:, None]
nn, cc, k = n[hi], celda[hi], kid[hi]
local = Pp - cc
eje = np.argmax(np.abs(nn), 1)
u = np.where(eje == 0, local[:, 2], local[:, 0])
v = np.where(eje == 1, local[:, 2], local[:, 1])
alb = R.shade_colors(k, u, v, local, cc, nn)
cara = np.select([nn[:, 1] > 0, nn[:, 1] < 0, eje == 2], [1.0, 0.5, 0.8], 0.6)
Lz, ao = R.smooth_light(Pp, nn, R.opaque_of[R.FULL_GRID])
col = alb * R.brightness(Lz) * (cara * ao)[:, None]
em = np.array([R.kinds[kk][0] in R.EMISSIVE and R.emit_of[kk] > 0 for kk in k])
col[em] = alb[em] * (0.92 + 0.08 * cara[em])[:, None]
img[hi] = col
if ESCENA in ("estandartes", "grieta", "tejo", "casilleros"):   # la noche estrellada (lo que no choca con nada)
    nada_ = np.nonzero(~golpe)[0]
    dd_ = D[nada_]
    el_ = np.arcsin(np.clip(dd_[:, 1], -1, 1))
    t_ = np.clip(el_ / 0.7, 0, 1)[:, None]
    cielo_ = (1 - t_) * np.array([0.050, 0.065, 0.125]) + t_ * np.array([0.010, 0.014, 0.040])
    az_ = np.arctan2(dd_[:, 2], dd_[:, 0])
    ia_ = np.floor(az_ * 520).astype(np.int64)
    ie_ = np.floor(el_ * 520).astype(np.int64)
    h_ = ((ia_ * 73856093) ^ (ie_ * 19349663)) & 0xFFFFFF
    h_ = (h_ * 2654435761 % 4294967296) / 4294967296.0
    estrella_ = (h_ < 0.012) & (el_ > -0.45)                 # (el campo flota: se ven también abajo)
    brillo_ = 0.45 + 0.55 * ((h_ * 7919.0) % 1.0)
    cielo_[estrella_] = brillo_[estrella_, None] * np.array([0.95, 0.96, 1.0])
    img[nada_] = cielo_
img = np.clip(img, 0, 1).reshape(H2, W2, 3)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
arriba = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    d = np.asarray(p) - POS
    z = d @ f
    x = (d @ r) / z / (th * W2 / H2)
    y = (d @ arriba) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(p):
    cx, cy, cz = int(math.floor(p[0])), int(math.floor(p[1])), int(math.floor(p[2]))
    niveles = [R.LIGHTF[cx + dx, yy, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1) for yy in (cy, cy + 1)
               if 0 <= cx + dx < R.LIGHTF.shape[0] and 0 <= cz + dz < R.LIGHTF.shape[2] and 0 <= yy < R.LIGHTF.shape[1]]
    return R.brightness(np.array([max(niveles)]))[0] * 0.95


COLOR = {"pelota": (0.86, 0.18, 0.14), "pelota_azul": (0.20, 0.40, 0.86), "espada": (0.78, 0.80, 0.84),
         "fuego": (1.0, 0.62, 0.18), "llama": (1.0, 0.40, 0.08), "asiento": (0.46, 0.06, 0.08),
         "madera": (0.20, 0.14, 0.09), "tejo": (0.95, 0.16, 0.10), "oro": (0.95, 0.78, 0.30),
         "papa": (0.86, 0.60, 0.26),
         "tela_roja": (0.74, 0.16, 0.13), "tela_azul": (0.22, 0.30, 0.78), "palo": (0.33, 0.24, 0.15),
         "baldosa": (0.20, 0.20, 0.22), "ladrillo": (0.18, 0.15, 0.19), "polvo": (0.32, 0.31, 0.33),
         "rifle": (0.13, 0.13, 0.14), "culata": (0.30, 0.20, 0.12), "fogonazo": (1.0, 0.86, 0.45),
         "bala": (1.0, 0.92, 0.60), "robot_negro": (0.07, 0.07, 0.08), "robot_gris": (0.33, 0.34, 0.36),
         "robot_claro": (0.55, 0.56, 0.58), "visor": (1.0, 0.12, 0.10), "haz": (0.55, 0.05, 0.04)}


def caja(centro, tam, color, brillo=False, giro=None):
    return (np.array(centro, float), np.array(tam, float) / 2.0, COLOR[color] if isinstance(color, str) else color,
            brillo, np.eye(3) if giro is None else giro)


def dibujar_cajas(cajas):
    for centro, medio, colr, brillo, ejes in cajas:
        esquinas = [centro + ejes @ (medio * np.array([sx, sy, sz])) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
        if any((e - POS) @ f <= 0.05 for e in esquinas):
            continue
        pts = [proyectar(e) for e in esquinas]
        i0 = max(int(min(q[0] for q in pts)) - 1, 0)
        i1 = min(int(max(q[0] for q in pts)) + 2, W2)
        j0 = max(int(min(q[1] for q in pts)) - 1, 0)
        j1 = min(int(max(q[1] for q in pts)) + 2, H2)
        if i0 >= i1 or j0 >= j1:
            continue
        dirs = DIRS[j0:j1, i0:i1].reshape(-1, 3)
        o_ = (POS - centro) @ ejes                                   # en el sistema de la caja
        d_ = dirs @ ejes
        with np.errstate(divide="ignore", invalid="ignore"):
            t1 = (-medio - o_) / d_
            t2 = (medio - o_) / d_
        tmin = np.minimum(t1, t2)
        tmax = np.maximum(t1, t2)
        entra = np.max(tmin, 1)
        sale = np.min(tmax, 1)
        cara_ = np.argmax(tmin, 1)
        ver = (sale >= entra) & (entra > 0)
        zona_p = prof[j0:j1, i0:i1].reshape(-1)
        ver &= entra < zona_p
        if not ver.any():
            continue
        signo = -np.sign(d_[np.arange(len(d_)), cara_])
        normal = ejes[:, cara_].T * signo[:, None]                   # en el mundo
        sombra_cara = np.where(normal[:, 1] > 0.6, 1.0, np.where(normal[:, 1] < -0.6, 0.5,
                               np.where(np.abs(normal[:, 2]) > np.abs(normal[:, 0]), 0.8, 0.6)))
        punto = POS + dirs * entra[:, None]
        luz = luz_en(punto[ver].mean(0)) if not brillo else 1.0
        c_ = np.array(colr)[None, :] * (np.ones((len(d_), 1)) if brillo else sombra_cara[:, None] * luz)
        zona_i = img[j0:j1, i0:i1].reshape(-1, 3)
        zona_i[ver] = c_[ver]
        zona_p[ver] = entra[ver]
        img[j0:j1, i0:i1] = zona_i.reshape(j1 - j0, i1 - i0, 3)
        prof[j0:j1, i0:i1] = zona_p.reshape(j1 - j0, i1 - i0)


def recorte(sprite, base, alto, ancho, luz, adelante=0.0):
    base = np.asarray(base, float)
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    c = arr[py, px]
    efectivo = tt - adelante
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (c[..., 3] > 0) & (tt > 0) & (efectivo < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = c[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = efectivo[ver]


def sombra(base, ancho):
    cx, cy = proyectar(base)
    ex, _ = proyectar(np.asarray(base) + DERECHA * ancho * 0.6)
    rx = abs(ex - cx)
    ry = rx * 0.55
    if rx < 1:
        return
    j0, j1 = max(int(cy - ry) - 1, 0), min(int(cy + ry) + 2, H2)
    i0, i1 = max(int(cx - rx) - 1, 0), min(int(cx + rx) + 2, W2)
    if i0 >= i1 or j0 >= j1:
        return
    jj_, ii_ = np.ogrid[j0:j1, i0:i1]
    m = ((ii_ - cx) / rx) ** 2 + ((jj_ - cy) / max(ry, 1)) ** 2 <= 1
    img[j0:j1, i0:i1][m] *= 0.62


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


def perfil(skin, derecha):
    out = Image.new("RGBA", (8, 32), (0, 0, 0, 0))
    cara_ = (0, 8) if derecha else (16, 8)
    pegar(out, skin, cara_[0], cara_[1], 8, 8, 0, 0)
    pegar(out, skin, 16 if derecha else 28, 20, 4, 12, 2, 8)
    pegar(out, skin, 40 if derecha else 48, 20, 4, 12, 2, 8)
    pegar(out, skin, 0 if derecha else 8, 20, 4, 12, 2, 20)
    return out


def sprite_caminando(x, z, dx, dz, skin):
    hacia_camara = (dx * FRENTE[0] + dz * FRENTE[2])
    if hacia_camara > 0.4:
        return frente(skin), ANCHO
    if hacia_camara < -0.4:
        return espalda(skin), ANCHO
    return perfil(skin, (dx * DERECHA[0] + dz * DERECHA[2]) > 0), ANCHO / 2


ALTO, ANCHO = 1.85, 0.925
skins = [Image.open(os.path.join(TEX, f"entity/jugador/skin_{i}.png")).convert("RGBA") for i in range(48)]
azar = random.Random(5)
ROJO, AZUL = (138, 28, 26, 255), (36, 60, 140, 255)


def chaleco(sprite, color):
    """Le pone el chaleco del equipo: el torso del color del equipo, con dos franjas oscuras."""
    out = sprite.copy()
    px = out.load()
    cols = range(2, 6) if out.size[0] == 8 else range(4, 12)
    for y in range(8, 20):
        for x in cols:
            if px[x, y][3] > 0:
                px[x, y] = (30, 28, 30, 255) if y in (13, 16) else color
    return out


def brillo_rojo(sprite):
    """El que tiene el tejo: brilla (un borde rojo alrededor, como el efecto de brillo del juego)."""
    w_, h_ = sprite.size
    out = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_ = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_.alpha_composite(sprite, (1, 1))
    a_ = base_.split()[3]
    for dx_, dy_ in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        borde_ = Image.new("RGBA", base_.size, (255, 60, 40, 255))
        out.paste(borde_, (dx_, dy_), a_)
    out.alpha_composite(base_)
    return out


def brillo(sprite, color):
    """El efecto de brillo del juego: un borde del color dado alrededor de la persona."""
    w_, h_ = sprite.size
    out = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_ = Image.new("RGBA", (w_ + 2, h_ + 2), (0, 0, 0, 0))
    base_.alpha_composite(sprite, (1, 1))
    a_ = base_.split()[3]
    for dx_, dy_ in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        out.paste(Image.new("RGBA", base_.size, color), (dx_, dy_), a_)
    out.alpha_composite(base_)
    return out


def persona(x, z, mira_x, mira_z, color=None, y=100.0, skin=None, sentado=False, tejo=False, brilla=None):
    """Una persona en (x, z) mirando hacia (mira_x, mira_z): de frente, de espaldas o de perfil, según la cámara."""
    dx, dz = mira_x - x, mira_z - z
    largo = math.hypot(dx, dz) or 1.0
    sprite, ancho = sprite_caminando(x, z, dx / largo, dz / largo, skin or skins[azar.randrange(48)])
    if color is not None:
        sprite = chaleco(sprite, color)
    alto = ALTO
    if sentado:                                         # sentado: sin piernas, a la altura del asiento
        sprite = sprite.crop((0, 0, sprite.size[0], 20))
        alto = ALTO * 20 / 32
    if tejo:
        sprite = brillo_rojo(sprite)
        ancho *= sprite.size[0] / (sprite.size[0] - 2)
    if brilla:
        sprite = brillo(sprite, brilla)
        ancho *= sprite.size[0] / (sprite.size[0] - 2)
    if np.linalg.norm(L(x, y + 1.6, z) - POS) > 3.0:
        personas.append((x, y, z, sprite, alto, ancho))
    return dx / largo, dz / largo


def silla(x, z, mira_z):
    """Una silla (patas de madera oscura, asiento de terciopelo rojo y respaldo del lado contrario a donde mira)."""
    cajas.append(caja(L(x, 100.22, z), (0.62, 0.44, 0.62), "madera"))
    cajas.append(caja(L(x, 100.5, z), (0.8, 0.12, 0.8), "asiento"))
    atras = -0.36 if mira_z > z else 0.36
    cajas.append(caja(L(x, 100.95, z + atras), (0.8, 0.85, 0.1), "madera"))
    cajas.append(caja(L(x, 101.0, z + atras * 0.92), (0.6, 0.55, 0.06), "asiento"))


personas = []                                          # (x, y, z, sprite, alto, ancho)
cajas = []
if ESCENA == "asientos":
    XT = [1974 + 11 * i_ for i_ in range(5)]
    ZT = [8 + 11 * j_ for j_ in range(5)]
    con_sillas = [(0, 1), (1, 3), (3, 0), (4, 2), (3, 3), (1, 0), (0, 4)]
    for (i_, j_) in con_sillas:                         # las sillas que aparecieron (menos que gente)
        x0_, z0_ = XT[i_], ZT[j_]
        lugares = azar.sample([(a_, b_) for a_ in range(1, 8, 2) for b_ in range(1, 8, 3)], 4)
        for k_, (a_, b_) in enumerate(lugares):
            sx, sz = x0_ + a_ + 0.5, z0_ + b_ + 0.5
            silla(sx, sz, sz - 3)
            if k_ < 2:
                persona(sx, sz + 0.05, sx, sz - 3, y=100.55, sentado=True)
    for (i_, j_) in [(a_, b_) for a_ in range(5) for b_ in range(5) if (a_, b_) != (2, 2)]:
        for _ in range(azar.choice((0, 1, 1, 2))):      # los que corren a buscar silla
            x0_, z0_ = XT[i_], ZT[j_]
            x, z = azar.uniform(x0_ + 0.8, x0_ + 8.2), azar.uniform(z0_ + 0.8, z0_ + 8.2)
            persona(x, z, x + azar.uniform(-6, 6), z + azar.uniform(-6, 6))
    persona(1994.3, 13.0, 1997.0, 13.0, y=101.1)        # uno saltando de una torre a la otra
    persona(2006.0, 51.0, 2006.0, 47.0, y=78.0)         # y uno que no llegó: se cae entre las torres
    for k_, (nx, ny, nz) in enumerate(((1999.0, 118.5, 37.5), (2002.5, 117.0, 39.0), (2001.0, 116.0, 41.5))):
        cajas.append(caja(L(nx, ny, nz), (0.35, 0.35, 0.12), "oro", brillo=True))     # notas que se apagan
elif ESCENA == "casilleros":
    def libre_c(x_, z_):
        return all(bloques.get((int(math.floor(x_)) - OX, y_ - OY, int(math.floor(z_)) - OZ)) in (None,)
                   or "light" in bloques.get((int(math.floor(x_)) - OX, y_ - OY, int(math.floor(z_)) - OZ), "")
                   for y_ in (100, 101))

    def girar_y(grados):
        a_ = math.radians(grados)
        return np.array([[math.cos(a_), 0, math.sin(a_)], [0, 1, 0], [-math.sin(a_), 0, math.cos(a_)]])

    def girar_x(grados):
        a_ = math.radians(grados)
        return np.array([[1, 0, 0], [0, math.cos(a_), -math.sin(a_)], [0, math.sin(a_), math.cos(a_)]])

    def cazador(x_, z_, rumbo, cabeza, paso, s=1.35):
        """El robot gigante (como CazadorRenderer): mira para rumbo (grados, 0 = sur), la cabeza girada, caminando."""
        G = girar_y(-rumbo)
        base = L(x_, 100.0, z_)

        def parte(cx_, cy_, cz_, sx_, sy_, sz_, color_, brillo_=False, extra=None, pivote=None):
            local = np.array([cx_, cy_, cz_]) * s
            ejes_ = G
            if extra is not None:
                pv = np.array(pivote) * s
                local = pv + extra @ (local - pv)
                ejes_ = G @ extra
            cajas.append(caja(base + G @ local, (sx_ * s, sy_ * s, sz_ * s), color_, brillo=brillo_, giro=ejes_))

        for lado in (-1, 1):
            pierna = girar_x(lado * paso)
            piv = (0.7 * lado, 4.5, 0.0)
            parte(0.7 * lado, 0.225, 0.2, 1.0, 0.45, 1.5, "robot_negro", extra=pierna, pivote=piv)
            parte(0.7 * lado, 1.55, 0.0, 0.75, 2.2, 0.75, "robot_gris", extra=pierna, pivote=piv)
            parte(0.7 * lado, 2.75, 0.08, 0.9, 0.4, 0.9, "robot_negro", extra=pierna, pivote=piv)
            parte(0.7 * lado, 3.75, 0.0, 0.85, 1.6, 0.85, "robot_gris", extra=pierna, pivote=piv)
            brazo = girar_x(-lado * paso * 0.8)
            pivb = (1.95 * lado, 7.0, 0.2)
            parte(1.9 * lado, 7.25, 0.2, 1.15, 0.85, 1.4, "robot_claro")
            parte(1.95 * lado, 5.9, 0.2, 0.75, 2.2, 0.75, "robot_gris", extra=brazo, pivote=pivb)
            parte(1.95 * lado, 4.55, 0.2, 0.85, 0.6, 0.85, "robot_negro", extra=brazo, pivote=pivb)
            parte(1.95 * lado, 3.4, 0.25, 0.7, 1.8, 0.7, "robot_gris", extra=brazo, pivote=pivb)
            parte(1.95 * lado, 2.2, 0.3, 0.9, 0.9, 0.9, "robot_negro", extra=brazo, pivote=pivb)
            parte(1.95 * lado + 0.36 * lado, 3.4, 0.25, 0.06, 1.4, 0.08, "visor", True, extra=brazo, pivote=pivb)
        parte(0.0, 4.7, 0.0, 2.2, 0.6, 1.2, "robot_negro")
        parte(0.0, 5.3, 0.0, 1.4, 0.6, 1.0, "robot_gris")
        parte(0.0, 6.45, 0.0, 3.1, 1.9, 1.7, "robot_gris")
        parte(0.0, 6.6, 0.88, 2.3, 1.1, 0.12, "robot_negro")
        parte(0.0, 6.15, 0.95, 1.5, 0.16, 0.06, "visor", True)
        parte(0.0, 7.6, 0.0, 0.6, 0.35, 0.6, "robot_negro")
        cab = girar_y(-cabeza)
        piv = (0.0, 8.0, 0.0)
        parte(0.0, 8.25, 0.05, 1.3, 1.0, 1.3, "robot_gris", extra=cab, pivote=piv)
        parte(0.0, 8.35, 0.71, 1.1, 0.2, 0.08, "visor", True, extra=cab, pivote=piv)
        parte(0.0, 8.85, -0.05, 0.22, 0.25, 1.2, "robot_negro", extra=cab, pivote=piv)

    rx_, rz_, rumbo_, cabeza_ = 6000.5, 44.0, 180.0, 22.0  # camina hacia el norte, la cabeza girada a su izquierda
    cazador(rx_, rz_, rumbo_, cabeza_, 18.0)
    puestos = 0
    while puestos < 58:                                 # corriendo a los casilleros de luz verde
        x, z = azar.uniform(5962.0, 6038.0), azar.uniform(6.0, 100.0)
        if libre_c(x, z) and math.hypot(x - rx_, z - rz_) > 5:
            mx_ = 5958.0 if x < 5972 else 6042.0 if x > 6028 else (5984.0 if x < 6000 else 6016.0)
            persona(x, z, mx_, z + azar.uniform(-4, 4), y=100.0)
            puestos += 1
    for (px_, pz_, mx_) in ((5961.4, 20.5, 5958.0), (5961.4, 26.5, 5958.0), (6038.6, 44.5, 6042.0),
                            (5989.6, 50.5, 5988.0), (5983.4, 70.5, 5986.0), (6011.4, 40.5, 6014.0)):
        persona(px_, pz_, mx_, pz_, y=100.0)            # entrando a un casillero
    persona(5992.0, 30.0, 5989.0, 27.0, y=100.0, brilla=(255, 60, 60, 255))   # lo vio el Cazador: ¡le pega el rayo!
    for k_ in range(40):                                # el rayo, del visor al que vio
        t_ = k_ / 40.0
        p0_ = np.array([rx_ - 0.6, 111.3, rz_ - 1.2])
        p1_ = np.array([5992.0, 101.2, 30.0])
        q_ = p0_ + (p1_ - p0_) * t_
        cajas.append(caja(L(*q_), (0.16, 0.16, 0.16), "haz", brillo=True))
elif ESCENA == "tejo":
    def suelo_t(x_, z_):
        """Dónde se para uno en (x, z): arriba del bloque más alto del suelo (sin luces, barreras ni hojas)."""
        cx_, cz_ = int(math.floor(x_)), int(math.floor(z_))
        for y_ in range(124, 90, -1):
            b_ = bloques.get((cx_ - OX, y_ - OY, cz_ - OZ))
            if b_ and "light" not in b_ and "barrier" not in b_ and "lantern" not in b_:
                return None if ("leaves" in b_ or "log" in b_) else y_ + 1.0
        return None

    def papa(px_, py_, pz_):
        cajas.append(caja(L(px_, py_, pz_), (0.34, 0.26, 0.40), "papa", brillo=True))
        for k_ in range(3):                             # humea: está caliente
            cajas.append(caja(L(px_ + azar.uniform(-0.15, 0.15), py_ + 0.35 + 0.3 * k_, pz_ + azar.uniform(-0.15, 0.15)),
                              (0.10, 0.10, 0.10), "llama", brillo=True))

    puestos = 0
    while puestos < 44:                                 # repartidos por el valle (en lo bajo y en las colinas)
        x, z = azar.uniform(6950.0, 7050.0), azar.uniform(12.0, 112.0)
        y = suelo_t(x, z)
        if y is not None and y <= 108 and math.hypot(x - 7000, z - 76) > 14:
            persona(x, z, x + azar.uniform(-6, 6), z + azar.uniform(-6, 6), y=y)
            puestos += 1
    for (tx, tz, mx, mz) in ((6996.5, 33.0, 7000.0, 37.5), (6979.0, 49.5, 6983.0, 46.0), (7021.5, 52.0, 7025.0, 56.0),
                             (6988.0, 92.0, 6991.0, 96.0), (7040.5, 70.0, 7036.0, 74.0)):
        y = suelo_t(tx, tz) or 100.0
        persona(tx, tz, mx, mz, tejo=True, y=y)          # los cinco que tienen la papa, persiguiendo
        papa(tx + 0.45, y + 1.0, tz)
    for (x, z, mx, mz) in ((7000.4, 47.5, 7000.4, 52.0), (7000.6, 50.0, 7000.6, 56.0)):
        persona(x, z, mx, mz, y=100.0)                   # dos se meten en el túnel de la montaña
    for k_ in range(14):                                # una papa que acaba de explotar: fuego y humo
        y0_ = (suelo_t(7012.0, 38.0) or 100.0)
        cajas.append(caja(L(7012.0 + azar.uniform(-1.2, 1.2), y0_ + 0.4 + azar.uniform(0, 2.2), 38.0 + azar.uniform(-1.2, 1.2)),
                          (azar.uniform(0.3, 0.8),) * 3, "fogonazo" if k_ % 3 else "llama", brillo=True))
elif ESCENA in ("estandartes", "grieta"):
    def suelo_y(x_, z_):
        """Dónde se para uno en (x, z): arriba del bloque más alto del suelo (sin luces ni barreras)."""
        cx_, cz_ = int(math.floor(x_)), int(math.floor(z_))
        for y_ in range(112, 41, -1):
            b_ = bloques.get((cx_ - OX, y_ - OY, cz_ - OZ))
            if b_ and "light" not in b_ and "barrier" not in b_ and "lantern" not in b_ and "_banner" not in b_:
                return y_ + 1.0
        return 101.0

    def giro_y(dx_, dz_):
        lz_ = math.hypot(dx_, dz_) or 1.0
        fx_, fz_ = dx_ / lz_, dz_ / lz_
        return np.array([[fz_, 0, fx_], [0, 1, 0], [-fx_, 0, fz_]])

    def estandarte_parado(x_, y_, z_, tela, mira_x):
        cajas.append(caja(L(x_, y_ + 1.32, z_), (0.13, 2.64, 0.13), "palo"))
        cajas.append(caja(L(x_, y_ + 2.58, z_), (0.12, 0.12, 1.30), "palo"))
        cajas.append(caja(L(x_ + 0.11 * mira_x, y_ + 1.45, z_), (0.06, 2.20, 1.20), tela))

    def con_espada(x_, y_, z_, mx_, mz_, alzada=0.6):
        lado_ = np.array([-(mz_ - z_), 0.0, mx_ - x_])
        lado_ = lado_ / (np.linalg.norm(lado_) or 1.0) * 0.40
        p_ = L(x_, y_ + 0.95, z_) + lado_
        g_ = giro_y(mx_ - x_, mz_ - z_) @ np.array([[1, 0, 0], [0, math.cos(alzada), -math.sin(alzada)],
                                                      [0, math.sin(alzada), math.cos(alzada)]])
        cajas.append(caja(p_ + g_ @ np.array([0, 0.36, 0]), (0.09, 0.78, 0.09), "espada", giro=g_))
        cajas.append(caja(p_ + g_ @ np.array([0, -0.02, 0]), (0.26, 0.05, 0.07), "culata", giro=g_))

    def peleador(x_, z_, mx_, mz_, color_, y_=None, alzada=0.6):
        y_ = suelo_y(x_, z_) if y_ is None else y_
        persona(x_, z_, mx_, mz_, color_, y=y_)
        con_espada(x_, y_, z_, mx_, mz_, alzada)

    def portador(x_, y_, z_, mx_, mz_, color_, tela):
        persona(x_, z_, mx_, mz_, color_, y=y_, brilla=(255, 255, 255, 255))
        g_ = giro_y(mx_ - x_, mz_ - z_)
        atras_ = -np.array([mx_ - x_, 0.0, mz_ - z_]) / (math.hypot(mx_ - x_, mz_ - z_) or 1.0) * 0.18
        base_ = L(x_, y_ + 1.9, z_) + atras_
        cajas.append(caja(base_ + np.array([0, 0.62, 0]), (0.08, 1.30, 0.08), "palo"))
        cajas.append(caja(base_ + g_ @ np.array([0, 1.22, 0]), (0.70, 0.07, 0.07), "palo", giro=g_))
        cajas.append(caja(base_ + g_ @ np.array([0, 0.74, -0.05]), (0.64, 0.92, 0.04), tela, giro=g_))

    estandarte_parado(7912.5, 101.0, 46.5, "tela_roja", 1)            # el rojo, en su fortín; el azul, robado
    portador(7992.0, 102.2, 46.3, 7986.0, 47.5, ROJO, "tela_azul")     # ¡vuelve saltando de torre en torre!
    peleador(7988.3, 45.2, 7996.0, 46.0, ROJO, y_=101.0)              # lo espera uno de los suyos
    peleador(7996.6, 47.2, 7990.0, 46.5, AZUL, y_=101.0, alzada=1.2)   # lo persiguen
    peleador(8004.2, 45.4, 7996.0, 46.0, AZUL, y_=101.0)
    peleador(8011.6, 45.6, 8013.0, 47.5, ROJO, y_=101.0, alzada=1.3)   # pelea en la última torre
    peleador(8012.8, 47.4, 8011.5, 45.5, AZUL, y_=101.0)
    persona(8008.6, 50.2, 8009.5, 52.0, AZUL, y=89.0)                   # se cayó a la grieta
    peleador(7999.5, 21.5, 8010.0, 21.0, ROJO, y_=101.0)                # por el norte
    peleador(8011.0, 20.5, 8000.0, 21.0, AZUL, y_=101.0)
    peleador(7989.0, 71.0, 7978.0, 71.0, AZUL, y_=101.0)                # por el sur
    peleador(7978.5, 71.5, 7989.0, 71.0, ROJO)
    if ESCENA == "estandartes":
        for (x_, z_) in ((7915.5, 42.0), (7916.5, 50.5), (7909.5, 47.5)):        # cuidan su estandarte
            peleador(x_, z_, 7960.0, 46.0, ROJO)
        for (x_, z_) in ((8085.5, 42.5), (8086.0, 50.0)):                       # se lo robaron
            peleador(x_, z_, 8040.0, 46.0, AZUL)
        peleador(7955.5, 49.0, 7980.0, 46.0, ROJO)
        peleador(7970.0, 36.0, 7990.0, 40.0, ROJO)
        peleador(8044.5, 47.0, 8020.0, 46.0, AZUL)
        peleador(8030.0, 60.0, 8010.0, 60.0, AZUL)

dibujar_cajas(cajas)
personas.sort(key=lambda p: -np.linalg.norm(L(p[0], p[1], p[2]) - POS))
for x, y, z, sprite, alto, ancho in personas:
    if y == 100.0 and abs(alto - ALTO) < 0.01:
        sombra(L(x, 100.0, z), ancho)
for x, y, z, sprite, alto, ancho in personas:
    base = L(x, y, z)
    recorte(sprite, base, alto, ancho, luz_en(L(x, y, z)))

if ESCENA in ("estandartes", "grieta"):
    img = np.clip(img, 0, 1) ** 0.85                     # un poco más claro (la noche se come los detalles)
final = Image.fromarray((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8))
if SS > 1:
    final = final.resize((W, H), Image.LANCZOS)
dib = ImageDraw.Draw(final, "RGBA")


def texto_con_sombra(xy, texto, letra, color, desplazar):
    dib.text((xy[0] + desplazar, xy[1] + desplazar), texto, font=letra,
             fill=(int(color[0] * 0.25), int(color[1] * 0.25), int(color[2] * 0.25)))
    dib.text(xy, texto, font=letra, fill=color)


def cartel_nombre(p, texto, color):
    """Como el nombre sobre una entidad: letras con un fondo oscuro transparente."""
    x, y = proyectar(p)
    x, y = x / SS, y / SS
    d = np.linalg.norm(p - POS)
    letra = ImageFont.truetype(FUENTE, max(9, int(0.27 * H / (2 * d * th))))     # como en el juego: unos 0,25 bloques
    an = dib.textlength(texto, font=letra)
    dib.rectangle((x - an / 2 - 4, y - letra.size * 0.62, x + an / 2 + 4, y + letra.size * 0.62), fill=(0, 0, 0, 110))
    dib.text((x - an / 2, y - letra.size * 0.58), texto, font=letra, fill=color)


def chat(lineas):
    """El chat, abajo a la izquierda (fondo oscuro transparente)."""
    letra_c = ImageFont.truetype(FUENTE, max(11, H // 50))
    alto_l = int(letra_c.size * 1.3)
    y_ = int(H * 0.80) - alto_l * len(lineas)
    for texto, color_c in lineas:
        an = dib.textlength(texto, font=letra_c)
        dib.rectangle((6, y_ - 2, 14 + an, y_ + alto_l - 2), fill=(0, 0, 0, 120))
        texto_con_sombra((10, y_), texto, letra_c, color_c, max(1, H // 400))
        y_ += alto_l

# ------------------------------------------------------------------ la barra de arriba y los textos
BARRAS = {
    "asientos": ("Asientos al vacío · ronda 2 de 3 · ¡paró la música!", 0.4, (255, 85, 85)),
    "casilleros": ("Sálvese quien pueda · ronda 1 de 3 · ¡ALARMA! 0:09 · 112 casilleros para 117", 0.6, (255, 85, 85)),
    "tejo": ("La papa caliente · ronda 2 de 3 · explota en 0:09 · 5 papas", 0.6, (255, 85, 85)),
    "estandartes": ("Los estandartes · 4:12 · rojos 9 · azules 8", 0.53, (170, 0, 170)),
    "grieta": ("Los estandartes · 4:05 · rojos 9 · azules 8", 0.51, (170, 0, 170)),
}
LINEAS = {
    "asientos": "¡Siéntate! Clic derecho en una silla libre",
    "casilleros": "¡Métete en un casillero de luz verde! Afuera, el Cazador te ve",
    "tejo": "Lejos de los que brillan: escóndete en las colinas o en los túneles",
    "estandartes": "Roba el estandarte del otro equipo y llévalo a tu lado",
    "grieta": "Para cruzar la grieta, salta de torre en torre · con el estandarte no puedes pegar",
}
nombre_barra, progreso, color = BARRAS[ESCENA]
letra_b = ImageFont.truetype(FUENTE, max(12, H // 46))
ancho_b = int(W * 0.30)
x0 = (W - ancho_b) // 2
y0 = int(H * 0.035)
an_t = dib.textlength(nombre_barra, font=letra_b)
texto_con_sombra(((W - an_t) / 2, y0), nombre_barra, letra_b, (255, 255, 255), max(1, H // 400))
yb = y0 + int(letra_b.size * 1.35)
alto_b = max(5, H // 110)
dib.rectangle((x0 - 1, yb - 1, x0 + ancho_b + 1, yb + alto_b + 1), fill=(0, 0, 0, 200))
dib.rectangle((x0, yb, x0 + ancho_b, yb + alto_b), fill=(int(color[0] * 0.35), int(color[1] * 0.35), int(color[2] * 0.35), 255))
dib.rectangle((x0, yb, x0 + int(ancho_b * progreso), yb + alto_b), fill=color + (255,))
letra = ImageFont.truetype(FUENTE, max(11, H // 52))
linea = LINEAS[ESCENA]
an_l = dib.textlength(linea, font=letra)
texto_con_sombra(((W - an_l) / 2, H * 0.86), linea, letra, (255, 255, 255), max(1, H // 400))
if ESCENA == "asientos":
    chat([("<Comandante> ¡Siéntense! En diez segundos se cae el piso.", (255, 255, 85))])
elif ESCENA == "casilleros":
    chat([("<Comandante> ¡Alarma! El Cazador despertó.", (255, 255, 85)), ("Lucía_Pérez se salvó", (85, 255, 85)),
          ("A Martín_Silva lo vio el Cazador", (170, 0, 0))])
elif ESCENA == "tejo":
    chat([("Martín_Silva explotó con la papa", (170, 0, 0)),
          ("<Comandante> Ronda 2 de 3: cinco papas calientes. Tienen 15 segundos.", (255, 255, 85))])
elif ESCENA in ("estandartes", "grieta"):
    chat([("Valentina_Díaz robó el estandarte azul", (255, 85, 85)),
          ("<Comandante> Quedan 4 minutos.", (255, 255, 85)),
          ("Bruno_Castro mató a Lucas_Ferreira", (85, 85, 255))])
final.save(salida, optimize=True)
print("guardado", salida, final.size)
