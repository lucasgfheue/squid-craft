#!/usr/bin/env python3
"""Vistas previas del juego 3, "Las escondidas": la escuela de noche (con render.py y recortes de las personas).

Uso: python3 escondidas_render.py <escuela.pkl> <salida.png> <ancho> <alto> <supermuestreo> <escena>
  plano:   la escuela vista desde arriba, con los nombres de cada lugar, las salidas y los escondites
  hall:    las reglas: todos alrededor del podio del comandante, en el hall
  biblioteca: buscando: un buscador con su espada por un pasillo entre las estanterías, y uno escondido, agachado,
              en un hueco de los estantes
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
ESCENA = sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")
FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FUENTE_NEGRITA = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
sys.path.insert(0, AQUI)

# ================================================================== el plano
if ESCENA == "plano":
    sys.argv = ["gen_escondidas.py"]
    import gen_escondidas as G  # noqa: E402  (arma la escuela al importarlo)

    E = 6                                                 # píxeles por bloque
    MARGEN = 40
    img = Image.new("RGB", (G.W * E + 2 * MARGEN, (G.D + 12) * E + 2 * MARGEN + 70), (14, 15, 20))
    d = ImageDraw.Draw(img)
    colores = {
        "pasillo": (205, 205, 212), "hall": (150, 152, 160), "gimnasio": (222, 200, 150), "biblioteca": (128, 92, 62),
        "comedor": (178, 178, 178), "cocina": (190, 215, 225), "actos": (165, 72, 62), "profesores": (180, 60, 60),
        "direccion": (118, 84, 60), "enfermeria": (240, 240, 240), "aula": (196, 156, 100), "lab": (215, 215, 222),
        "banos": (170, 210, 228), "deposito": (122, 122, 128), "puerta": (215, 215, 222),
    }

    def caja(x, z, c):
        px, pz = MARGEN + x * E, MARGEN + (z + 12) * E
        d.rectangle([px, pz, px + E - 1, pz + E - 1], fill=c)

    for x in range(G.W):                                  # el patio
        for z in range(-12, 0):
            f = G.get(x, G.PISO, z)
            if f is not None:
                b = G.get(x, G.Y0, z)
                caja(x, z, (92, 96, 100) if b is None or b.startswith("minecraft:light") else (64, 110, 52))
    for x in range(G.W):
        for z in range(G.D):
            lugar = G.plano[x][z]
            if lugar is None:
                caja(x, z, (52, 30, 26) if G.es_borde(x, z) else (40, 40, 46))
                continue
            c = colores.get(G.TIPO.get(lugar, lugar), (255, 0, 255))
            b = G.get(x, G.Y0, z)
            if b is not None and not (b == "minecraft:light" or b.startswith("minecraft:light[")):
                c = (60, 42, 30) if "bookshelf" in b else (90, 92, 100) if "iron_bars" in b else \
                    tuple(int(v * 0.6) for v in c)
            caja(x, z, c)
    for (_, (vx0, vz0, vx1, vz1), _, _, _) in G.SALIDAS:
        for x in range(vx0, vx1 + 1):
            for z in range(vz0, vz1 + 1):
                caja(x, z, (60, 220, 90))
    for (x, z, _) in G.escondites:
        px, pz = MARGEN + x * E + E // 2, MARGEN + (z + 12) * E + E // 2
        d.ellipse([px - 2, pz - 2, px + 2, pz + 2], fill=(255, 70, 205))
    chica = ImageFont.truetype(FUENTE_NEGRITA, 13)
    grande = ImageFont.truetype(FUENTE_NEGRITA, 17)

    def texto(x, z, t, f=chica, c=(20, 20, 24), sombra=(250, 250, 250)):
        px, pz = MARGEN + x * E, MARGEN + (z + 12) * E
        w = d.textlength(t, font=f)
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            d.text((px - w / 2 + dx, pz - 8 + dy), t, font=f, fill=sombra)
        d.text((px - w / 2, pz - 8), t, font=f, fill=c)

    texto(75, -7, "PATIO (los que salen esperan acá)", grande, (240, 240, 240), (20, 40, 20))
    texto(46, 31, "GIMNASIO", grande)
    texto(46, 34.5, "gradas y depósito", chica)
    texto(108, 30, "BIBLIOTECA", grande, (250, 240, 225), (40, 25, 15))
    texto(46, 88, "COMEDOR", grande)
    texto(108, 77, "SALÓN DE ACTOS", grande, (255, 240, 235), (60, 15, 12))
    texto(108, 94, "escenario y telón", chica, (255, 240, 235), (60, 15, 12))
    texto(75, 54.5, "HALL", grande)
    texto(75, 65, "podio", chica)
    texto(67, 37, "SALA DE", chica, (255, 235, 235), (90, 20, 20))
    texto(67, 39.5, "PROFESORES", chica, (255, 235, 235), (90, 20, 20))
    texto(82, 44, "dirección", chica)
    texto(67, 76, "cocina", chica)
    texto(82, 76, "enfermería", chica)
    for (x0, x1) in G.FILA_X:
        for (z, fila) in ((7.5, 0), (111.5, 1)):
            tipo = G.TIPO[[n for n in G.TIPO if n.endswith(f"_{'ns'[fila]}{G.FILA_X.index((x0, x1))}")][0]]
            texto((x0 + x1 + 1) / 2, z, {"aula": "aula", "banos": "baños", "deposito": "depósito"}[tipo], chica)
    for (z0, z1) in G.COLUMNA_Z:
        for x in (7.5, 141.5):
            texto(x, (z0 + z1 + 1) / 2, "lab." if (z0, z1) == G.COLUMNA_Z[2] else "aula", chica)
    for (nombre, (vx0, vz0, vx1, vz1), _, _, _) in G.SALIDAS:
        cx, cz = (vx0 + vx1 + 1) / 2, (vz0 + vz1 + 1) / 2 + 0.3
        if nombre.startswith("oeste"):
            cx += 8.5
        elif nombre.startswith("este"):
            cx -= 8.5
        else:
            cx += 8.5
        texto(cx, cz, "salida", chica, (230, 255, 235), (20, 90, 40))
    # leyenda
    ly = MARGEN + (G.D + 12) * E + 22
    d.ellipse([MARGEN, ly + 4, MARGEN + 10, ly + 14], fill=(255, 70, 205))
    d.text((MARGEN + 16, ly), f"{len(G.escondites)} escondites", font=chica, fill=(235, 235, 240))
    d.rectangle([MARGEN + 170, ly + 2, MARGEN + 184, ly + 16], fill=(60, 220, 90))
    d.text((MARGEN + 190, ly), "6 salidas al patio (el juego abre una sola, al azar)", font=chica, fill=(235, 235, 240))
    d.rectangle([MARGEN + 590, ly + 2, MARGEN + 604, ly + 16], fill=(180, 60, 60))
    d.text((MARGEN + 610, ly), "acá esperan los buscadores (rejas)", font=chica, fill=(235, 235, 240))
    d.text((MARGEN, ly + 26), "Imagen aproximada: plano de la escuela de Las escondidas visto desde arriba (150 × 120 bloques).",
           font=ImageFont.truetype(FUENTE, 12), fill=(170, 170, 180))
    img.save(salida)
    print("plano guardado", img.size)
    sys.exit(0)

# ================================================================== las escenas en 3D
datos = pickle.load(open(entrada, "rb"))
OX, OY, OZ = datos["origen"]
bloques = dict(datos["blocks"])
azar = random.Random(11)


def L(wx, wy, wz):
    return np.array([wx - OX, wy - OY, wz - OZ], float)


tmp = os.path.join(tempfile.gettempdir(), "escuela_escena.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": 0}, open(tmp, "wb"))
sys.argv = ["render.py", tmp]
import render as R  # noqa: E402

R.BASE.update({
    "birch_planks": (0.78, 0.71, 0.50), "oak_planks": (0.66, 0.53, 0.32), "bookshelf": (0.45, 0.30, 0.18),
    "bricks": (0.55, 0.30, 0.25), "spruce_stairs": (0.42, 0.30, 0.18), "dark_oak_stairs": (0.26, 0.17, 0.09),
    "glass": (0.70, 0.82, 0.86), "glass_pane": (0.62, 0.75, 0.80), "hay_block": (0.72, 0.60, 0.15),
    "lime_stained_glass": (0.45, 0.85, 0.30), "oak_fence": (0.66, 0.53, 0.32), "oak_leaves": (0.25, 0.45, 0.18),
    "oak_log": (0.40, 0.31, 0.19), "red_wool": (0.62, 0.13, 0.12), "white_wool": (0.90, 0.90, 0.90),
    "blue_wool": (0.20, 0.25, 0.62), "redstone_lamp": (0.46, 0.28, 0.17), "sponge": (0.80, 0.75, 0.30),
    "wet_sponge": (0.65, 0.62, 0.25),
})

_colores_base = R.shade_colors


def colores_con_libros(kid, u, v, local, cell, n):
    """Como render.py, y además los estantes con libros de colores (de costado) en vez de madera lisa."""
    col = _colores_base(kid, u, v, local, cell, n)
    tu = np.clip(np.floor(u * 16), 0, 15).astype(np.int64)
    tv = np.clip(np.floor(v * 16), 0, 15).astype(np.int64)
    libros = np.array([(0.55, 0.13, 0.11), (0.16, 0.30, 0.55), (0.20, 0.45, 0.22), (0.62, 0.52, 0.16),
                       (0.42, 0.21, 0.46), (0.74, 0.70, 0.60), (0.30, 0.20, 0.12)])
    for kidx in np.unique(kid):
        if R.kinds[kidx][0] != "bookshelf":
            continue
        m = kid == kidx
        lado = np.abs(n[m][:, 1]) < 0.5
        a, b = tu[m], tv[m]
        estante = (b % 8 == 0) | (b % 8 == 7) | (a == 0) | (a == 15)
        semilla = (cell[m][:, 0] * 7 + cell[m][:, 1] * 13 + cell[m][:, 2] * 5).astype(np.int64)
        tono = libros[((a // 2) * 3 + (b // 8) * 5 + semilla) % len(libros)]
        c = col[m]
        c[lado & ~estante] = tono[lado & ~estante] * (0.9 + 0.1 * ((a[lado & ~estante] % 2) == 0))[:, None]
        c[lado & estante] = (0.42, 0.29, 0.17)
        col[m] = c
    return col


R.shade_colors = colores_con_libros

W2, H2 = W * SS, H * SS
if ESCENA == "hall":
    POS, TGT, FOV = L(2989.0, 105.2, 20.8), L(3000.0, 100.6, 10.5), 74
else:
    POS, TGT, FOV = L(3004.6, 101.65, -17.15), L(3030.0, 101.0, -17.4), 66
O, D = R.perspective(W2, H2, POS, TGT, FOV)

golpe, t, n, celda, kid = R.trace(O, D, R.FULL_GRID)
img = np.zeros((len(O), 3))
img[:] = (0.02, 0.02, 0.03)
hi = np.nonzero(golpe)[0]
Pp = O[hi] + D[hi] * t[hi][:, None]
nn, cc, k = n[hi], celda[hi], kid[hi]
local = Pp - cc
eje = np.argmax(np.abs(nn), 1)
u = np.where(eje == 0, local[:, 2], local[:, 0])
v = np.where(eje == 1, local[:, 2], local[:, 1])
alb = R.shade_colors(k, u, v, local, cc, nn)
cara = np.select([nn[:, 1] > 0, nn[:, 1] < 0, eje == 2], [1.0, 0.5, 0.8], 0.6)
Lz, ao = R.smooth_light(Pp, nn, R.opaque_of[R.FULL_GRID])
col = alb * R.brightness(Lz) * (cara * ao)[:, None]
em = np.array([R.kinds[kk][0] in R.EMISSIVE and R.emit_of[kk] > 0 for kk in k])
col[em] = alb[em] * (0.92 + 0.08 * cara[em])[:, None]
verde = np.array([R.kinds[kk][0] == "lime_stained_glass" for kk in k])
col[verde] = alb[verde] * 1.1                                          # la luz verde de la salida
img[hi] = col
img = np.clip(img, 0, 1).reshape(H2, W2, 3)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
arriba = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    dd = np.asarray(p) - POS
    z = dd @ f
    x = (dd @ r) / z / (th * W2 / H2)
    y = (dd @ arriba) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(p):
    cx, cy, cz = int(math.floor(p[0])), int(math.floor(p[1])), int(math.floor(p[2]))
    niveles = [R.LIGHTF[cx + dx, yy, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1) for yy in (cy, cy + 1)]
    return R.brightness(np.array([max(niveles)]))[0] * 0.95


def recorte(sprite, base, alto, ancho, luz):
    base = np.asarray(base, float)
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    c = arr[py, px]
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (c[..., 3] > 0) & (tt > 0) & (tt < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = c[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = tt[ver]


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


def perfil(skin, derecha):
    out = Image.new("RGBA", (8, 32), (0, 0, 0, 0))
    cara_ = (0, 8) if derecha else (16, 8)
    pegar(out, skin, cara_[0], cara_[1], 8, 8, 0, 0)
    pegar(out, skin, 16 if derecha else 28, 20, 4, 12, 2, 8)
    pegar(out, skin, 40 if derecha else 48, 20, 4, 12, 2, 8)
    pegar(out, skin, 0 if derecha else 8, 20, 4, 12, 2, 20)
    return out


def agachado(skin):
    """De frente y agachado: cabeza y torso un poco más abajo, piernas dobladas (más cortas)."""
    parado = frente(skin)
    out = Image.new("RGBA", (16, 27), (0, 0, 0, 0))
    out.alpha_composite(parado.crop((0, 0, 16, 20)), (0, 0))
    out.alpha_composite(parado.crop((0, 20, 16, 32)).resize((16, 7)), (0, 20))
    return out


def con_espada(sprite):
    """Le dibuja la espada de netherite en la mano derecha (que se ve a la izquierda, de frente)."""
    out = sprite.copy()
    dd = ImageDraw.Draw(out)
    for i in range(9):
        x, y = 1 - i // 3, 18 - i
        if 0 <= x < out.width and y >= 0:
            dd.point((x, y), fill=(68, 58, 66, 255) if i > 2 else (40, 32, 40, 255))
    dd.point((1, 19), fill=(90, 70, 50, 255))
    return out


ALTO, ANCHO = 1.85, 0.925
skins = [Image.open(os.path.join(TEX, f"entity/jugador/skin_{i}.png")).convert("RGBA") for i in range(48)]
guardias = {nm: Image.open(os.path.join(TEX, f"entity/guardia/{nm}.png")).convert("RGBA")
            for nm in ("sargento", "comandante")}
personas = []                                                          # (x, y, z, sprite, alto, ancho)
if ESCENA == "hall":
    # las reglas: todos alrededor del podio, mirando al comandante
    for i in range(46):
        a = azar.random() * math.pi * 2
        rr = 4.2 + azar.random() * 4.0
        x, z = 3000.0 + rr * math.cos(a), 12.0 + rr * math.sin(a)
        hacia = np.array([3000.0 - x, 0.0, 12.0 - z])
        hacia /= np.linalg.norm(hacia)
        skin = skins[azar.randrange(48)]
        if hacia @ FRENTE > 0.4:
            sprite, ancho = frente(skin), ANCHO
        elif hacia @ FRENTE < -0.4:
            sprite, ancho = espalda(skin), ANCHO
        else:
            sprite, ancho = perfil(skin, (hacia @ DERECHA) > 0), ANCHO / 2
        personas.append((x, 100.0, z, sprite, ALTO, ancho))
    personas.append((3000.0, 102.0, 12.0, frente(guardias["comandante"]), ALTO, ANCHO))
    for gx, gz in ((2989.5, 3.5), (3010.5, 3.5), (3010.5, 20.5)):
        personas.append((gx, 100.0, gz, frente(guardias["sargento"]), ALTO, ANCHO))
else:
    # buscando: un buscador viene por el pasillo entre las estanterías; otro, agachado en un hueco de los estantes
    personas.append((3017.5, 100.0, -17.3, con_espada(frente(skins[5])), ALTO, ANCHO))
    personas.append((3008.5, 100.0, -15.45, agachado(skins[30]), 1.5, ANCHO))

personas.sort(key=lambda p: -np.linalg.norm(L(p[0], p[1], p[2]) - POS))
for (x, y, z, sprite, alto, ancho) in personas:
    base = L(x, y, z)
    recorte(sprite, base, alto, ancho, luz_en(base + np.array([0.0, 1.0, 0.0])))

final = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).resize((W, H), Image.LANCZOS)
d = ImageDraw.Draw(final)
fuente = ImageFont.truetype(FUENTE, max(12, H // 50))
titulos = {"hall": "Las escondidas · las reglas en el hall de la escuela (imagen aproximada)",
           "biblioteca": "Las escondidas · un buscador en la biblioteca. ¿Ves al que está escondido en un hueco, a la derecha? (imagen aproximada)"}
d.text((12, H - H // 50 - 14), titulos[ESCENA], font=fuente, fill=(225, 225, 230))
final.save(salida)
print("guardado", salida)
