"""Lo que comparten las arenas nuevas (gen_asientos.py, gen_casilleros.py, gen_tejo.py y gen_estandartes.py): la
plantilla, la entrada (el podio del comandante y el portal de vuelta en la pared norte), las torres huecas, las
barandas, las luces invisibles y la escritura del .nbt y del .pkl para las imágenes de prueba (como en gen_puente.py).

Todas tienen la misma entrada: la pared norte en z = -16 (con el portal de vuelta en x OX+9..OX+13 y una barrera
detrás, en z = -17); el podio del comandante en x OX+27..OX+35, z -15..-12 (arriba, cuarzo liso, a y = 101); y la
llegada (donde aparece la gente) delante del podio, con el piso en y = 99. Las torres son altísimas (el suelo, en
y = 40): la plantilla empieza abajo, en (OX, 40, -17). La de Los estandartes es más ancha: su entrada va centrada en
x = 8000 (el parámetro centro de entrada).
"""
import gzip
import io
import pickle
import struct
from collections import Counter

DATA_VERSION = 3955
PISO = 99
LUZ = None                                   # se define abajo (necesita S)


def S(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    if not props:
        return name
    parts = []
    for k, v in sorted(props.items()):
        if isinstance(v, bool):
            v = "true" if v else "false"
        parts.append(f"{k}={v}")
    return f"{name}[{','.join(parts)}]"


LUZ = S("light", level=15, waterlogged=False)
NEGRO = S("polished_blackstone")


class Arena:
    def __init__(self, ox, oy, oz, sx, sy, sz):
        self.ox, self.oy, self.oz = ox, oy, oz
        self.sx, self.sy, self.sz = sx, sy, sz
        self.blocks = {}

    def put(self, wx, wy, wz, st):
        """Pone un bloque usando coordenadas del mundo."""
        self.blocks[(wx - self.ox, wy - self.oy, wz - self.oz)] = st

    def get(self, wx, wy, wz):
        return self.blocks.get((wx - self.ox, wy - self.oy, wz - self.oz))

    def quitar(self, wx, wy, wz):
        self.blocks.pop((wx - self.ox, wy - self.oy, wz - self.oz), None)

    def caja(self, x0, y0, z0, x1, y1, z1, st):
        for x in range(min(x0, x1), max(x0, x1) + 1):
            for y in range(min(y0, y1), max(y0, y1) + 1):
                for z in range(min(z0, z1), max(z0, z1) + 1):
                    self.put(x, y, z, st)

    def entrada(self, juego, cuarzo=S("smooth_quartz"), centro=None, piso=PISO):
        """El podio del comandante (arriba, y = 101), dos faroles y el portal de vuelta en la pared norte. El podio va
        centrado en x = centro (si no se dice, en OX + 31) y el portal, 20 bloques al oeste. Con piso, todo más alto
        (el piso del palco en y = piso, en vez de 99)."""
        ox = self.ox if centro is None else centro - 31
        PISO = piso
        for x in range(ox + 27, ox + 36):                       # podio del comandante (arriba: y = 101)
            for z in range(-15, -11):
                self.put(x, PISO + 1, z, NEGRO)
                self.put(x, PISO + 2, z, cuarzo)
        for x in (ox + 27, ox + 35):
            self.put(x, PISO + 3, -12, S("lantern", hanging=False, waterlogged=False))
        for x in range(ox + 8, ox + 15):                         # portal de vuelta, en la pared norte
            for y in range(PISO + 1, PISO + 7):
                marco = x in (ox + 8, ox + 14) or y == PISO + 6
                self.put(x, y, -16, NEGRO if marco else S("juegosdelpatio:portal_juego", juego=juego, regreso=True))
                if not marco:
                    self.put(x, y, -17, S("barrier"))           # que nadie caiga al vacío de atrás
        for x in range(ox + 9, ox + 14):
            self.put(x, PISO, -15, NEGRO)

    def baranda(self, celdas, y0, y1):
        """Rejas de hierro (de y0 a y1) en las celdas (x, z) dadas, unidas entre ellas como en el juego."""
        celdas = set(celdas)
        for (x, z) in celdas:
            lados = {"north": (x, z - 1) in celdas, "south": (x, z + 1) in celdas,
                     "west": (x - 1, z) in celdas, "east": (x + 1, z) in celdas}
            for y in range(y0, y1 + 1):
                self.put(x, y, z, S("iron_bars", waterlogged=False, **lados))

    def torre(self, x0, x1, z0, z1, y0, y1, pared, bandas=(), banda=None, ventanas=None, cada=6, alturas=()):
        """El cuerpo hueco de una torre (solo las paredes, de y0 a y1), con franjas de otro color a las alturas de
        bandas y, si hay ventanas, ventanas de luz cada tantos bloques a las alturas dadas."""
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                for z in range(z0, z1 + 1):
                    if x in (x0, x1) or z in (z0, z1):
                        st = banda if y in bandas and banda else pared
                        if ventanas and y in alturas:
                            borde_x = z in (z0, z1) and x0 < x < x1 and (x - x0) % cada == cada // 2
                            borde_z = x in (x0, x1) and z0 < z < z1 and (z - z0) % cada == cada // 2
                            if borde_x or borde_z:
                                st = ventanas
                        self.put(x, y, z, st)

    def luces(self, x0, x1, z0, z1, y=PISO + 2):
        """Luces invisibles a la altura de la cabeza, en damero (cada 6 bloques, una sí y una no) y junto a las paredes."""
        for x in range(x0, x1 + 1):
            for z in range(z0, z1 + 1):
                en_damero = x % 6 == 0 and z % 6 == 0 and (x // 6 + z // 6) % 2 == 0
                junto_a_la_pared = (x in (x0, x1) and z % 6 == 3) or (z in (z0, z1) and x % 6 == 3)
                if (en_damero or junto_a_la_pared) and self.get(x, y, z) is None:
                    self.put(x, y, z, LUZ)

    def guardar(self, out_nbt, out_pkl, nombre):
        for (x, y, z) in self.blocks:
            if not (0 <= x < self.sx and 0 <= y < self.sy and 0 <= z < self.sz):
                raise ValueError(f"fuera de la plantilla: {(x, y, z)}")
        raw, palette = self._nbt()
        with gzip.open(out_nbt, "wb", compresslevel=9) as f:
            f.write(raw)
        with open(out_pkl, "wb") as f:
            pickle.dump({"size": (self.sx, self.sy, self.sz), "blocks": self.blocks, "offset": 0,
                         "origen": (self.ox, self.oy, self.oz)}, f)
        print(f"{nombre}: {len(self.blocks)} bloques, paleta {len(palette)}, {len(raw) // 1024} KB sin comprimir")

    # ------------------------------------------------------------------ NBT
    def _nbt(self):
        freq = Counter(self.blocks.values())
        palette = sorted(freq, key=lambda s: (-freq[s], s))
        index = {s: i for i, s in enumerate(palette)}
        pal_tags = []
        for s in palette:
            name, props = _estado(s)
            c = {"Name": (_STRING, name)}
            if props:
                c["Properties"] = (_COMPOUND, {k: (_STRING, v) for k, v in sorted(props.items())})
            pal_tags.append(c)
        blk_tags = [{"pos": (_LIST, (_INT, [x, y, z])), "state": (_INT, index[self.blocks[(x, y, z)]])}
                    for (x, y, z) in sorted(self.blocks, key=lambda p: (p[1], p[0], p[2]))]
        root = {
            "DataVersion": (_INT, DATA_VERSION),
            "size": (_LIST, (_INT, [self.sx, self.sy, self.sz])),
            "palette": (_LIST, (_COMPOUND, pal_tags)),
            "blocks": (_LIST, (_COMPOUND, blk_tags)),
            "entities": (_LIST, (_COMPOUND, [])),
        }
        buf = io.BytesIO()
        buf.write(struct.pack(">b", _COMPOUND))
        _w_str(buf, "")
        _w_payload(buf, _COMPOUND, root)
        return buf.getvalue(), palette


_INT, _STRING, _LIST, _COMPOUND = 3, 8, 9, 10


def _w_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">H", len(b)))
    f.write(b)


def _w_payload(f, t, v):
    if t == _INT:
        f.write(struct.pack(">i", v))
    elif t == _STRING:
        _w_str(f, v)
    elif t == _LIST:
        et, items = v
        f.write(struct.pack(">b", et))
        f.write(struct.pack(">i", len(items)))
        for it in items:
            _w_payload(f, et, it)
    elif t == _COMPOUND:
        for name, (ct, cv) in v.items():
            f.write(struct.pack(">b", ct))
            _w_str(f, name)
            _w_payload(f, ct, cv)
        f.write(b"\x00")
    else:
        raise ValueError(t)


def _estado(s):
    if "[" in s:
        name, rest = s.split("[", 1)
        return name, dict(kv.split("=") for kv in rest[:-1].split(","))
    return s, {}


# los números de 3 x 5 (como los de la torre): X = bloque
DIGITOS = {
    0: ["XXX", "X.X", "X.X", "X.X", "XXX"],
    1: [".X.", "XX.", ".X.", ".X.", "XXX"],
    2: ["XXX", "..X", "XXX", "X..", "XXX"],
    3: ["XXX", "..X", "XXX", "..X", "XXX"],
    4: ["X.X", "X.X", "XXX", "..X", "..X"],
    5: ["XXX", "X..", "XXX", "..X", "XXX"],
    6: ["XXX", "X..", "XXX", "X.X", "XXX"],
    7: ["XXX", "..X", ".X.", ".X.", ".X."],
    8: ["XXX", "X.X", "XXX", "X.X", "XXX"],
    9: ["XXX", "X.X", "XXX", "..X", "XXX"],
}
