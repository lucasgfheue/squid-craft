#!/usr/bin/env python3
"""Imágenes de la Torre de los Juegos con render.py.
Uso: python3 torre_render.py <torre.pkl> <carpeta de salida> <ancho> <alto> <supermuestreo>"""
import os
import sys

entrada, carpeta = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
sys.argv = ["render.py", entrada]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
vistas = {
    # parado en el barrilete, mirando hacia arriba por el hueco de la escalera
    "torre_desde_abajo": ("p", (10.5, 1.8, 10.5), (10.6, 50.0, 10.0), 96),
    # subiendo: desde el descanso de la puerta 1 (esquina noroeste), mirando la puerta 3 y lo que falta subir
    "torre_subiendo": ("p", (2.6, 9.62, 2.6), (19.0, 30.0, 14.0), 72),
}
for nombre, (tipo, pos, objetivo, fov) in vistas.items():
    o, d = R.perspective(W2, H2, pos, objetivo, fov)
    R.save(R.render(R.FULL_GRID, o, d, W2, H2), os.path.join(carpeta, nombre + ".png"), SS)

# corte: sin la pared sur ni el techo, vista desde el sur y un poco desde arriba
g = R.build_grid(lambda x, y, z: z == 20 or x == 20 or y == 55)
o, d = R.ortho(W2, H2, (10.5, 27.5, 10.5), (-0.45, -0.32, -0.83), 66)
R.save(R.render(g, o, d, W2, H2, bg_top=(0.05, 0.06, 0.08), bg_bot=(0.02, 0.02, 0.03)),
       os.path.join(carpeta, "torre_corte.png"), SS)
