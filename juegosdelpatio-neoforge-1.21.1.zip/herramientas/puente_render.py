#!/usr/bin/env python3
"""Vistas previas del juego 4, "El puente de Londres", con render.py, los robots (cajas, como RobotRenderer.java) y
recortes (billboards) de las personas.

Uso: python3 puente_render.py <puente.pkl> <salida.png> <ancho> <alto> <supermuestreo> <escena>
  salon:     la plaza de Londres de noche desde arriba de la entrada, con la canción sonando: la fila da vueltas por la
             calle y pasa por debajo del puente que forman los dos robots con los brazos en alto
  empujon:   termina la canción: antes del puente, unos van despacio (agachados) y uno empuja al de adelante para que
             pase él por debajo
  atrapado:  los robots bajaron los brazos de golpe: el que pasaba quedó atrapado (y queda eliminado)
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
ESCENA = sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")
FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FUENTE_NEGRITA = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

datos = pickle.load(open(entrada, "rb"))
OX, OY, OZ = datos["origen"]
bloques = dict(datos["blocks"])
CX, CZ = 4000.5, 26.5
RADIO = 16.0
PUENTE = (4016.5, 26.5)
ROBOTS = [((4011.5, 100.0, 26.5), -90.0, "rojo"), ((4021.5, 100.0, 26.5), 90.0, "azul")]
ARRIBA, ABAJO = 25.0, -50.0                         # como Robot.ARRIBA y Robot.ABAJO


def L(wx, wy, wz):
    return np.array([wx - OX, wy - OY, wz - OZ], float)


tmp = os.path.join(tempfile.gettempdir(), "puente_escena.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": 0}, open(tmp, "wb"))
sys.argv = ["render.py", tmp]
sys.path.insert(0, AQUI)
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
if ESCENA == "empujon":
    POS, TGT, FOV = L(4022.9, 102.7, 16.6), L(4015.6, 104.3, 23.8), 74
elif ESCENA == "atrapado":
    POS, TGT, FOV = L(4024.0, 107.0, 11.0), L(4016.5, 102.6, 26.5), 58
else:
    POS, TGT, FOV = L(3998.5, 111.5, 0.5), L(4015.0, 101.0, 27.0), 70
O, D = R.perspective(W2, H2, POS, TGT, FOV)

golpe, t, n, celda, kid = R.trace(O, D, R.FULL_GRID)
img = np.zeros((len(O), 3))
img[:] = (0.03, 0.03, 0.04)
hi = np.nonzero(golpe)[0]
Pp = O[hi] + D[hi] * t[hi][:, None]
nn, cc, k = n[hi], celda[hi], kid[hi]
local = Pp - cc
eje = np.argmax(np.abs(nn), 1)
u = np.where(eje == 0, local[:, 2], local[:, 0])
v = np.where(eje == 1, local[:, 2], local[:, 1])
alb = R.shade_colors(k, u, v, local, cc, nn)
cara = np.select([nn[:, 1] > 0, nn[:, 1] < 0, eje == 2], [1.0, 0.5, 0.8], 0.6)
Lz, ao = R.smooth_light(Pp, nn, R.opaque_of[R.FULL_GRID])
col = alb * R.brightness(Lz) * (cara * ao)[:, None]
em = np.array([R.kinds[kk][0] in R.EMISSIVE and R.emit_of[kk] > 0 for kk in k])
col[em] = alb[em] * (0.92 + 0.08 * cara[em])[:, None]
img[hi] = col
img = np.clip(img, 0, 1).reshape(H2, W2, 3)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
arriba = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    d = np.asarray(p) - POS
    z = d @ f
    x = (d @ r) / z / (th * W2 / H2)
    y = (d @ arriba) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(p):
    cx, cz = int(math.floor(p[0])), int(math.floor(p[2]))
    niveles = [R.LIGHTF[cx + dx, yy, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1) for yy in (1, 2)
               if 0 <= cx + dx < R.LIGHTF.shape[0] and 0 <= cz + dz < R.LIGHTF.shape[2]]
    return R.brightness(np.array([max(niveles)]))[0] * 0.95


# ------------------------------------------------------------------ los robots: cajas (igual que RobotRenderer.java)
COLOR = {
    "rojo": (1.0, 0.16, 0.12), "azul": (0.25, 0.62, 1.0),              # las luces (el visor y la del pecho)
    "negro": (0.04, 0.05, 0.07), "gris": (0.21, 0.22, 0.24), "gris_claro": (0.49, 0.49, 0.45),
    "hierro": (0.85, 0.85, 0.86),
}
HOMBRO_X, HOMBRO_Y, HOMBRO_Z = 1.95, 7.0, 0.3       # como Robot.HOMBRO_*
AL_MEDIO = 5.0                                       # del centro del robot al medio de la calle (donde se dan la mano)
BRAZO, ANTEBRAZO, MANO = 3.9, 3.9, 0.9               # el antebrazo, con la mano


def rot_x(grados):
    a = math.radians(grados)
    return np.array([[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]])


def caja(centro, tam, color, brillo=False, giro=None):
    return (np.array(centro, float), np.array(tam, float) / 2.0, COLOR[color] if isinstance(color, str) else color,
            brillo, np.eye(3) if giro is None else giro)


def codo(angulo):
    """El brazo con codo (como en RobotRenderer.brazo): la mano llega justo al medio de la calle, a la altura que
    dice el ángulo; el codo, hacia arriba. Devuelve la inclinación del brazo, el codo (alto, adelante) y la del antebrazo."""
    d = AL_MEDIO - HOMBRO_Z
    th = math.radians(angulo)
    largo = d / math.cos(th)
    alfa = math.acos(max(-1.0, min(1.0, (BRAZO ** 2 + largo ** 2 - ANTEBRAZO ** 2) / (2 * BRAZO * largo))))
    brazo = th + alfa
    cy, cz = BRAZO * math.sin(brazo), BRAZO * math.cos(brazo)
    my, mz = largo * math.sin(th), largo * math.cos(th)
    return math.degrees(brazo), (cy, cz), math.degrees(math.atan2(my - cy, mz - cz))


def partes(luz, angulo):
    """Las cajas del robot, en sus coordenadas (x a los costados, y arriba, z adelante; el piso en y = 0)."""
    p = []
    brazo, (cy, cz), ante = codo(angulo)
    for s in (-1, 1):
        p.append(caja((0.7 * s, 0.225, 0.2), (1.0, 0.45, 1.5), "negro"))           # pies
        p.append(caja((0.7 * s, 1.55, 0.0), (0.75, 2.2, 0.75), "gris"))            # canillas
        p.append(caja((0.7 * s, 2.75, 0.08), (0.9, 0.4, 0.9), "negro"))            # rodillas
        p.append(caja((0.7 * s, 3.75, 0.0), (0.85, 1.6, 0.85), "gris"))            # muslos
        p.append(caja((1.9 * s, 7.25, 0.2), (1.15, 0.85, 1.4), "gris_claro"))      # hombreras
        p.append(caja((HOMBRO_X * s, HOMBRO_Y, HOMBRO_Z), (0.9, 0.9, 0.9), "negro"))   # hombro
        base = np.array([HOMBRO_X * s, HOMBRO_Y, HOMBRO_Z])
        g1 = rot_x(-brazo)
        p.append(caja(base + g1 @ np.array([0, 0, BRAZO / 2]), (0.75, 0.75, BRAZO), "gris", giro=g1))
        codo_p = base + np.array([0, cy, cz])
        p.append(caja(codo_p, (0.85, 0.85, 0.85), "negro"))                         # el codo
        g2 = rot_x(-ante)
        p.append(caja(codo_p + g2 @ np.array([0, 0, (ANTEBRAZO - MANO) / 2]), (0.7, 0.7, ANTEBRAZO - MANO), "gris", giro=g2))
        p.append(caja(codo_p + g2 @ np.array([0, 0, ANTEBRAZO - MANO / 2]), (0.9, 0.9, MANO), "negro", giro=g2))   # la mano
        p.append(caja(codo_p + g2 @ np.array([0, 0.36, (ANTEBRAZO - MANO) / 2]), (0.08, 0.06, ANTEBRAZO - MANO - 0.6),
                      luz, True, giro=g2))                                          # una línea de luz en el antebrazo
    p.append(caja((0, 4.7, 0), (2.2, 0.6, 1.2), "negro"))                           # cadera
    p.append(caja((0, 5.3, 0), (1.4, 0.6, 1.0), "gris"))                            # cintura
    p.append(caja((0, 6.45, 0), (3.1, 1.9, 1.7), "gris"))                           # el pecho
    p.append(caja((0, 6.6, 0.88), (2.3, 1.1, 0.12), "negro"))                       # la placa del pecho
    p.append(caja((0, 6.15, 0.95), (1.5, 0.16, 0.06), luz, True))                   # la luz del pecho
    p.append(caja((0, 6.4, -0.9), (1.6, 1.2, 0.15), "negro"))                       # la espalda
    p.append(caja((0, 7.6, 0), (0.6, 0.35, 0.6), "negro"))                          # el cuello
    p.append(caja((0, 8.25, 0.05), (1.3, 1.0, 1.3), "gris"))                        # la cabeza
    p.append(caja((0, 8.35, 0.71), (1.1, 0.2, 0.08), luz, True))                    # el visor
    p.append(caja((0, 8.85, -0.05), (0.22, 0.25, 1.2), "negro"))                    # la cresta
    return p


def a_mundo(pos, giro_y, partes_robot):
    a = math.radians(giro_y)
    ry = np.array([[math.cos(a), 0, -math.sin(a)], [0, 1, 0], [math.sin(a), 0, math.cos(a)]])   # columnas: x, y, z
    base = L(*pos)
    return [(base + ry @ c, h, colr, br, ry @ g) for c, h, colr, br, g in partes_robot]


def dibujar_cajas(cajas):
    for centro, medio, colr, brillo, ejes in cajas:
        esquinas = [centro + ejes @ (medio * np.array([sx, sy, sz])) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
        if any((e - POS) @ f <= 0.05 for e in esquinas):
            continue
        pts = [proyectar(e) for e in esquinas]
        i0 = max(int(min(q[0] for q in pts)) - 1, 0)
        i1 = min(int(max(q[0] for q in pts)) + 2, W2)
        j0 = max(int(min(q[1] for q in pts)) - 1, 0)
        j1 = min(int(max(q[1] for q in pts)) + 2, H2)
        if i0 >= i1 or j0 >= j1:
            continue
        dirs = DIRS[j0:j1, i0:i1].reshape(-1, 3)
        o_ = (POS - centro) @ ejes                                   # en el sistema de la caja
        d_ = dirs @ ejes
        with np.errstate(divide="ignore", invalid="ignore"):
            t1 = (-medio - o_) / d_
            t2 = (medio - o_) / d_
        tmin = np.minimum(t1, t2)
        tmax = np.maximum(t1, t2)
        entra = np.max(tmin, 1)
        sale = np.min(tmax, 1)
        cara_ = np.argmax(tmin, 1)
        ver = (sale >= entra) & (entra > 0)
        zona_p = prof[j0:j1, i0:i1].reshape(-1)
        ver &= entra < zona_p
        if not ver.any():
            continue
        signo = -np.sign(d_[np.arange(len(d_)), cara_])
        normal = ejes[:, cara_].T * signo[:, None]                   # en el mundo
        sombra_cara = np.where(normal[:, 1] > 0.6, 1.0, np.where(normal[:, 1] < -0.6, 0.5,
                               np.where(np.abs(normal[:, 2]) > np.abs(normal[:, 0]), 0.8, 0.6)))
        punto = POS + dirs * entra[:, None]
        luz = luz_en(punto[ver].mean(0)) if not brillo else 1.0
        c_ = np.array(colr)[None, :] * (np.ones((len(d_), 1)) if brillo else sombra_cara[:, None] * luz)
        zona_i = img[j0:j1, i0:i1].reshape(-1, 3)
        zona_i[ver] = c_[ver]
        zona_p[ver] = entra[ver]
        img[j0:j1, i0:i1] = zona_i.reshape(j1 - j0, i1 - i0, 3)
        prof[j0:j1, i0:i1] = zona_p.reshape(j1 - j0, i1 - i0)


# ------------------------------------------------------------------ la gente (como en sillas_render.py)
def recorte(sprite, base, alto, ancho, luz, adelante=0.0):
    base = np.asarray(base, float)
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    c = arr[py, px]
    efectivo = tt - adelante
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (c[..., 3] > 0) & (tt > 0) & (efectivo < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = c[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = efectivo[ver]


def sombra(base, ancho):
    cx, cy = proyectar(base)
    ex, _ = proyectar(np.asarray(base) + DERECHA * ancho * 0.6)
    rx = abs(ex - cx)
    ry = rx * 0.55
    if rx < 1:
        return
    j0, j1 = max(int(cy - ry) - 1, 0), min(int(cy + ry) + 2, H2)
    i0, i1 = max(int(cx - rx) - 1, 0), min(int(cx + rx) + 2, W2)
    if i0 >= i1 or j0 >= j1:
        return
    jj_, ii_ = np.ogrid[j0:j1, i0:i1]
    m = ((ii_ - cx) / rx) ** 2 + ((jj_ - cy) / max(ry, 1)) ** 2 <= 1
    img[j0:j1, i0:i1][m] *= 0.62


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


def perfil(skin, derecha):
    out = Image.new("RGBA", (8, 32), (0, 0, 0, 0))
    cara_ = (0, 8) if derecha else (16, 8)
    pegar(out, skin, cara_[0], cara_[1], 8, 8, 0, 0)
    pegar(out, skin, 16 if derecha else 28, 20, 4, 12, 2, 8)
    pegar(out, skin, 40 if derecha else 48, 20, 4, 12, 2, 8)
    pegar(out, skin, 0 if derecha else 8, 20, 4, 12, 2, 20)
    return out


ALTO, ANCHO = 1.85, 0.925
skins = [Image.open(os.path.join(TEX, f"entity/jugador/skin_{i}.png")).convert("RGBA") for i in range(48)]
guardias = {nm: Image.open(os.path.join(TEX, f"entity/guardia/{nm}.png")).convert("RGBA")
            for nm in ("sargento", "comandante")}
azar = random.Random(11)


def sprite_caminando(x, z, dx, dz, skin):
    hacia_camara = (dx * FRENTE[0] + dz * FRENTE[2])
    if hacia_camara > 0.4:
        return frente(skin), ANCHO
    if hacia_camara < -0.4:
        return espalda(skin), ANCHO
    return perfil(skin, (dx * DERECHA[0] + dz * DERECHA[2]) > 0), ANCHO / 2


def sin_brazo(skin, derecha):
    """De perfil, sin el brazo de este lado (para dibujarlo aparte)."""
    out = Image.new("RGBA", (8, 32), (0, 0, 0, 0))
    cara_ = (0, 8) if derecha else (16, 8)
    pegar(out, skin, cara_[0], cara_[1], 8, 8, 0, 0)
    pegar(out, skin, 16 if derecha else 28, 20, 4, 12, 2, 8)
    pegar(out, skin, 0 if derecha else 8, 20, 4, 12, 2, 20)
    return out


def empujando(skin, derecha):
    """De perfil, con el brazo estirado para adelante: está empujando al de adelante."""
    out = Image.new("RGBA", (24, 32), (0, 0, 0, 0))
    out.alpha_composite(sin_brazo(skin, derecha), (8, 0))
    brazo = skin.crop((40 if derecha else 48, 20, 44 if derecha else 52, 32)).rotate(90 if derecha else -90, expand=True)
    out.alpha_composite(brazo, (12 if derecha else 0, 9))
    return out


def agachado(sprite, derecha=None):
    """Agachado, como en el juego (1,5 de alto): la cabeza más abajo (y, de perfil, un poco adelante)."""
    w = sprite.size[0]
    out = Image.new("RGBA", (w + 2, 26), (0, 0, 0, 0))
    adelante = 0 if derecha is None else (1 if derecha else -1)
    out.alpha_composite(sprite.crop((0, 20, w, 32)).resize((w, 11), Image.NEAREST), (1, 15))
    out.alpha_composite(sprite.crop((0, 8, w, 20)).resize((w, 7), Image.NEAREST), (1 + adelante, 8))
    out.alpha_composite(sprite.crop((0, 0, w, 8)), (1 + 2 * adelante, 0))
    return out


def inclinado(sprite, grados):
    """Para adelante, como cuando te empujan (sale un poco del piso)."""
    return sprite.rotate(grados, expand=True, resample=Image.NEAREST)


personas = []                                          # (x, y, z, sprite, alto, ancho)
GENTE = 44
angulo_puente = math.atan2(PUENTE[1] - CZ, PUENTE[0] - CX)
atrapado = None
NOMBRES = {}                                           # quién es quién en los carteles


def en_la_calle(antes, rr=RADIO):
    """El lugar de la calle a 'antes' bloques del medio del puente (positivo: todavía no llegó)."""
    a = angulo_puente - antes / RADIO
    return CX + rr * math.cos(a), CZ + rr * math.sin(a), a


def agregar(x, z, sprite, alto, ancho, y=100.0):
    if np.linalg.norm(L(x, y + 1.6, z) - POS) > 3.0:
        personas.append((x, y, z, sprite, alto, ancho))


if ESCENA == "empujon":
    # antes del puente la fila se amontona: unos van agachados (despacio) y uno empuja al de adelante
    lugares = [(2.5, "empujado"), (4.0, "empuja"), (5.5, "agachado"), (6.9, "agachado"), (8.4, "agachado"),
               (10.2, "camina"), (-1.9, "camina"), (-4.2, "camina")]
    lugares += [(12.5 + 2.3 * k, "camina") for k in range(20)] + [(-6.5 - 2.3 * k, "camina") for k in range(14)]
    for antes, que in lugares:
        rr = RADIO + azar.uniform(-0.25, 0.25)
        x, z, a = en_la_calle(antes, rr)
        dx, dz = -math.sin(a), math.cos(a)
        skin = skins[azar.randrange(48)]
        derecha = (dx * DERECHA[0] + dz * DERECHA[2]) > 0
        sprite, ancho = sprite_caminando(x, z, dx, dz, skin)
        if que == "empuja":
            agregar(x, z, empujando(skins[17], derecha), ALTO, ANCHO * 1.5)
            NOMBRES["empuja"] = (x, z)
        elif que == "empujado":
            vuela = inclinado(perfil(skins[29], derecha), -14 if derecha else 14)
            agregar(x, z, vuela, ALTO * vuela.size[1] / 32, ANCHO / 2 * vuela.size[0] / 8, y=100.3)
            NOMBRES["empujado"] = (x, z)
        elif que == "agachado":
            chico = agachado(sprite, derecha if ancho < ANCHO else None)
            agregar(x, z, chico, ALTO * 26 / 32, ancho * chico.size[0] / sprite.size[0])
        else:
            agregar(x, z, sprite, ALTO, ancho)
else:
    for i in range(GENTE):
        a = angulo_puente - 0.02 + 2 * math.pi * i / GENTE + azar.uniform(-0.012, 0.012)
        if ESCENA == "atrapado":
            if i == 0:
                a = angulo_puente                          # el que quedó atrapado
            elif abs(math.remainder(a - angulo_puente, 2 * math.pi)) * RADIO < 3.4:
                a += math.copysign(2.9 / RADIO, math.remainder(a - angulo_puente, 2 * math.pi))   # quedaron afuera
        rr = RADIO + azar.uniform(-0.35, 0.35) if not (ESCENA == "atrapado" and i == 0) else RADIO
        x, z = CX + rr * math.cos(a), CZ + rr * math.sin(a)
        dx, dz = -math.sin(a), math.cos(a)             # para dónde camina (como las agujas del reloj)
        skin = skins[azar.randrange(48)]
        sprite, ancho = sprite_caminando(x, z, dx, dz, skin)
        if ESCENA == "atrapado" and i == 0:
            sprite, ancho = frente(skins[29]), ANCHO   # mira para la cámara: no tiene salida
            atrapado = (x, z)
        agregar(x, z, sprite, ALTO, ancho)
if ESCENA == "salon":
    personas.append((4000.5, 102.0, -13.5, espalda(guardias["comandante"]), ALTO, ANCHO))
    for gx, gz in ((3973.5, 6.5), (4027.5, 6.5), (3973.5, 46.5), (4027.5, 46.5)):
        personas.append((gx, 100.0, gz, frente(guardias["sargento"]), ALTO, ANCHO))

angulo = ABAJO if ESCENA == "atrapado" else ARRIBA - 4.0
cajas = []
for pos, giro, color in ROBOTS:
    cajas += a_mundo(pos, giro, partes(color, angulo))
dibujar_cajas(cajas)
for (rx, ry, rz), _, _ in ROBOTS:
    sombra(L(rx, ry, rz), 3.6)

personas.sort(key=lambda p: -np.linalg.norm(L(p[0], p[1], p[2]) - POS))
for x, y, z, sprite, alto, ancho in personas:
    sombra(L(x, y, z), ancho)
for x, y, z, sprite, alto, ancho in personas:
    base = L(x, y, z)
    recorte(sprite, base, alto, ancho, luz_en(base))

final = Image.fromarray((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8))
if SS > 1:
    final = final.resize((W, H), Image.LANCZOS)
dib = ImageDraw.Draw(final, "RGBA")


def texto_con_sombra(xy, texto, letra, color, desplazar):
    dib.text((xy[0] + desplazar, xy[1] + desplazar), texto, font=letra,
             fill=(int(color[0] * 0.25), int(color[1] * 0.25), int(color[2] * 0.25)))
    dib.text(xy, texto, font=letra, fill=color)


def cartel_nombre(p, texto, color):
    """Como el nombre sobre una entidad: letras con un fondo oscuro transparente."""
    x, y = proyectar(p)
    x, y = x / SS, y / SS
    d = np.linalg.norm(p - POS)
    letra = ImageFont.truetype(FUENTE, max(9, int(0.27 * H / (2 * d * th))))     # como en el juego: unos 0,25 bloques
    an = dib.textlength(texto, font=letra)
    dib.rectangle((x - an / 2 - 4, y - letra.size * 0.62, x + an / 2 + 4, y + letra.size * 0.62), fill=(0, 0, 0, 110))
    dib.text((x - an / 2, y - letra.size * 0.58), texto, font=letra, fill=color)


# ------------------------------------------------------------------ la barra de arriba y los carteles
if ESCENA == "atrapado":
    nombre_barra, progreso, color = "¡Se cayó el puente! · ronda 3 de 5 · 41 en la fila", 1.0, (232, 52, 52)
else:
    nombre_barra, progreso, color = "♪ El puente de Londres · ronda 3 de 5 · 41 en la fila", 1.0, (85, 200, 255)
letra_b = ImageFont.truetype(FUENTE, max(12, H // 46))
ancho_b = int(W * 0.30)
x0 = (W - ancho_b) // 2
y0 = int(H * 0.035)
an_t = dib.textlength(nombre_barra, font=letra_b)
texto_con_sombra(((W - an_t) / 2, y0), nombre_barra, letra_b, (255, 255, 255), max(1, H // 400))
yb = y0 + int(letra_b.size * 1.35)
alto_b = max(5, H // 110)
dib.rectangle((x0 - 1, yb - 1, x0 + ancho_b + 1, yb + alto_b + 1), fill=(0, 0, 0, 200))
dib.rectangle((x0, yb, x0 + ancho_b, yb + alto_b), fill=(int(color[0] * 0.35), int(color[1] * 0.35), int(color[2] * 0.35), 255))
dib.rectangle((x0, yb, x0 + int(ancho_b * progreso), yb + alto_b), fill=color + (255,))


def chat(lineas):
    """El chat, abajo a la izquierda (fondo oscuro transparente)."""
    letra_c = ImageFont.truetype(FUENTE, max(11, H // 50))
    alto_l = int(letra_c.size * 1.3)
    y_ = int(H * 0.93) - alto_l * len(lineas)
    for texto, color_c in lineas:
        an = dib.textlength(texto, font=letra_c)
        dib.rectangle((6, y_ - 2, 14 + an, y_ + alto_l - 2), fill=(0, 0, 0, 120))
        texto_con_sombra((10, y_), texto, letra_c, color_c, max(1, H // 400))
        y_ += alto_l


if ESCENA == "atrapado":
    letra_t = ImageFont.truetype(FUENTE_NEGRITA, max(28, H // 11))
    cartel = "¡SE CAYÓ EL PUENTE!"
    an_c = dib.textlength(cartel, font=letra_t)
    texto_con_sombra(((W - an_c) / 2, H * 0.66), cartel, letra_t, (255, 85, 85), max(2, H // 160))
    letra_s = ImageFont.truetype(FUENTE, max(14, H // 30))
    sub = "Quedó atrapado Bruno"
    an_s = dib.textlength(sub, font=letra_s)
    texto_con_sombra(((W - an_s) / 2, H * 0.66 + letra_t.size * 1.15), sub, letra_s, (200, 200, 200), max(1, H // 300))
    chat([("¡Joaco empujó a Bruno debajo del puente!", (255, 170, 0))])
else:
    if ESCENA == "empujon":
        cartel_nombre(L(NOMBRES["empuja"][0], 102.35, NOMBRES["empuja"][1]), "Joaco", (255, 255, 255))
        cartel_nombre(L(NOMBRES["empujado"][0], 102.65, NOMBRES["empujado"][1]), "Bruno", (255, 255, 255))
    letra = ImageFont.truetype(FUENTE, max(11, H // 52))
    linea = "♪ Camina en la fila: agachado (Shift) vas más despacio, pero no te pares ♪"
    an_l = dib.textlength(linea, font=letra)
    texto_con_sombra(((W - an_l) / 2, H * 0.86), linea, letra, (120, 220, 255), max(1, H // 400))
final.save(salida, optimize=True)
print("guardado", salida, final.size)
