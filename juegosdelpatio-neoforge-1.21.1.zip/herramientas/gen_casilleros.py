#!/usr/bin/env python3
"""Genera la arena del juego 2, "Sálvese quien pueda" (casilleros.nbt): una estación de trenes abandonada, de noche.

Una nave enorme de ladrillo, con un techo de arcos de hierro y vidrios rotos (por los huecos se ven las estrellas),
faroles colgando de cadenas y las vías en el medio. Por toda la estación hay filas de casilleros de metal: a lo largo
de las dos paredes largas y en dos islas en el medio (con casilleros de los dos lados). Cada casillero tiene una puerta
de hierro (que no se abre a mano: la abre el juego) y, arriba, una luz: verde si está abierto, roja si está cerrado. Al
sur, el taller del Cazador, el robot gigante que recorre la estación. Al norte, el vestíbulo (cerrado con rejas), con el
podio del comandante, el portal de vuelta y un reloj grande y parado en la pared.

Coordenadas del mundo: la plantilla empieza en (5955, 98, -18). El piso en y = 99 (se camina en y = 100).
  nave              paredes en x 5958 y 6042, z -18 y 114; el techo, de y 113 (junto a las paredes) a y 126 (en el medio)
  vestíbulo         x 5972..6028, z -16..1 (el podio en x 5996..6004, z -15..-12; rejas al sur, en z = 2)
  casilleros        (como Casilleros.java; cada uno: la puerta, el lugar de adentro y, arriba de la puerta, la luz)
                      pared oeste: puertas en x 5960 (adentro, x 5959), z 8, 10, ..., 98
                      pared este:  puertas en x 6040 (adentro, x 6041), z 8, 10, ..., 98
                      isla oeste (x 5984..5988): puertas en x 5984 y 5988 (adentro, 5985 y 5987), z 32, 34, ..., 86
                      isla este (x 6012..6016): puertas en x 6012 y 6016 (adentro, 6013 y 6015), z 32, 34, ..., 86
  pasillos          oeste x 5961..5983, el del medio (con las vías) x 5989..6011, este x 6017..6039
  taller            x 5990..6010, z 104..113 (el Cazador descansa en (6000, 100, 108))

Uso: python3 gen_casilleros.py <salida.nbt> <bloques.pkl>
"""
import math
import sys

from arenas_comun import PISO, Arena, S

OX, OY, OZ = 5955, 98, -18
SX, SY, SZ = 91, 30, 133                 # x 5955..6045, y 98..127, z -18..114
A = Arena(OX, OY, OZ, SX, SY, SZ)
CX = 6000
NAVE = (5958, 6042, -18, 114)
PALCO = (5972, 6028, -16, 1)
TALLER = (5990, 6010, 104, 113)
ALTO_PARED = 113
LADRILLO = S("bricks")
OSCURO = S("polished_blackstone_bricks")
NEGRO = S("polished_blackstone")
METAL = S("light_gray_concrete")
METAL_OSCURO = S("gray_concrete")
BALDOSA = S("polished_andesite")
FAROL = S("lantern", hanging=False, waterlogged=False)
COLGADO = S("lantern", hanging=True, waterlogged=False)
CADENA = S("chain", axis="y", waterlogged=False)
LUZ_ROJA = S("red_concrete")


def h01(*v):
    n = 0
    for k in v:
        n = (n * 1103515245 + k * 2654435761 + 12345) & 0xFFFFFFFF
    n ^= n >> 15
    n = (n * 2246822519) & 0xFFFFFFFF
    n ^= n >> 13
    return n / 0xFFFFFFFF


# los casilleros: (x de la puerta, x de adentro, z, para dónde mira la puerta)
CASILLEROS = []
for z in range(8, 99, 2):
    CASILLEROS.append((5960, 5959, z, "west"))
    CASILLEROS.append((6040, 6041, z, "east"))
for z in range(32, 87, 2):
    CASILLEROS += [(5984, 5985, z, "east"), (5988, 5987, z, "west"), (6012, 6013, z, "east"), (6016, 6015, z, "west")]
ISLAS = [(5984, 5988), (6012, 6016)]

# =================================================================== el piso (y uno abajo, macizo)
x0, x1, z0, z1 = NAVE
for x in range(x0, x1 + 1):
    for z in range(z0, z1 + 1):
        A.put(x, PISO - 1, z, S("deepslate", axis="y"))
        r = h01(x, z, 1)
        A.put(x, PISO, z, S("cracked_stone_bricks") if r < 0.12 else S("stone_bricks") if r < 0.55 else BALDOSA)
for z in range(3, 104):                                       # las vías, en el pasillo del medio
    for x in range(5995, 6006):
        A.put(x, PISO, z, S("gravel") if h01(x, z, 2) < 0.7 else S("tuff"))
    for x in (5997, 6003):
        A.put(x, PISO, z, S("polished_basalt", axis="z"))
    if z % 3 == 0:
        for x in range(5996, 6005):
            if x not in (5997, 6003):
                A.put(x, PISO, z, S("stripped_dark_oak_wood", axis="x"))   # los durmientes
x0, x1, z0, z1 = PALCO
for x in range(x0, x1 + 1):
    for z in range(z0, z1 + 1):
        A.put(x, PISO, z, OSCURO if x in (x0, x1) or z in (z0, z1) else S("polished_andesite"))

# =================================================================== las paredes de ladrillo, con pilastras y ventanas altas
x0, x1, z0, z1 = NAVE
for y in range(PISO + 1, ALTO_PARED + 1):
    for x in range(x0, x1 + 1):
        for z in (z0, z1):
            A.put(x, y, z, OSCURO if y in (PISO + 1, ALTO_PARED) else LADRILLO)
    for z in range(z0, z1 + 1):
        for x in (x0, x1):
            alta = PISO + 6 <= y <= PISO + 11 and z % 12 in (5, 6, 7)
            A.put(x, y, z, S("iron_bars", waterlogged=False, north=True, south=True, east=False, west=False) if alta
                  else OSCURO if y in (PISO + 1, ALTO_PARED) or z % 12 == 0 else LADRILLO)

# =================================================================== el techo: arcos de hierro y vidrios (algunos rotos)
def techo_y(x):
    t = (x - CX) / (NAVE[1] - CX)
    return ALTO_PARED + 13.0 * (1.0 - t * t)


for z in range(NAVE[2], NAVE[3] + 1):
    for x in range(NAVE[0], NAVE[1] + 1):
        y = int(round(techo_y(x)))
        arco = z % 12 == 0
        if arco:
            for yy in range(y - 1, y + 1):
                A.put(x, yy, z, S("polished_basalt", axis="y") if yy == y else NEGRO)
        elif h01(x, z, 7) < 0.72:
            A.put(x, y, z, S("gray_stained_glass") if h01(x, z, 8) < 0.8 else S("black_stained_glass"))
for z in range(NAVE[2], NAVE[3] + 1, 12):                    # faroles colgando de los arcos (a los costados de
    for x in (5966, 5978, 5994, 6006, 6022, 6034):             # por donde camina el Cazador)
        y = int(round(techo_y(x))) - 2
        for yy in range(PISO + 14, y + 1):
            A.put(x, yy, z, CADENA)
        A.put(x, PISO + 13, z, COLGADO)

# =================================================================== los casilleros
def puerta(x, z, mira, mitad):
    return S("iron_door", facing=mira, half=mitad, hinge="left", open=False, powered=False)


bancos = set()
for (px, ax, z, mira) in CASILLEROS:
    A.put(px, PISO + 1, z, puerta(px, z, mira, "lower"))
    A.put(px, PISO + 2, z, puerta(px, z, mira, "upper"))
    A.put(px, PISO + 3, z, LUZ_ROJA)                         # la luz de arriba (la cambia el juego)
    A.put(ax, PISO + 3, z, METAL)                            # el techo del casillero
    for x in (px, ax):
        bancos.add((x, z))
        for zz in (z - 1, z + 1):                            # los costados (entre casillero y casillero)
            for y in (PISO + 1, PISO + 2, PISO + 3):
                A.put(x, y, zz, METAL_OSCURO if y < PISO + 3 else METAL)
            bancos.add((x, zz))
for (ix0, ix1) in ISLAS:                                      # la pared del medio de cada isla, y las puntas
    for z in range(31, 88):
        for y in range(PISO + 1, PISO + 5):
            A.put((ix0 + ix1) // 2, y, z, METAL if y < PISO + 4 else OSCURO)
    for z in (31, 87):
        for x in range(ix0, ix1 + 1):
            for y in range(PISO + 1, PISO + 5):
                A.put(x, y, z, METAL_OSCURO if y < PISO + 4 else OSCURO)
    for z in range(31, 88):                                   # una cornisa oscura arriba de la isla
        for x in range(ix0, ix1 + 1):
            if A.get(x, PISO + 4, z) is None:
                A.put(x, PISO + 4, z, OSCURO)
    for z in (31, 87):                                        # faroles en las puntas de las islas
        A.put((ix0 + ix1) // 2, PISO + 5, z, FAROL)
for z in range(7, 100):                                       # arriba de los casilleros de las paredes, una cornisa
    for x in (5959, 5960, 6040, 6041):
        if A.get(x, PISO + 4, z) is None:
            A.put(x, PISO + 4, z, OSCURO)

# =================================================================== el taller del Cazador (al sur, en el medio)
tx0, tx1, tz0, tz1 = TALLER
for x in range(tx0, tx1 + 1):
    for z in range(tz0, tz1 + 1):
        A.put(x, PISO, z, S("black_concrete") if (x + z) % 2 else S("yellow_concrete") if z == tz0 else NEGRO)
for x in range(tx0, tx1 + 1):                                 # franja de peligro en la entrada del taller
    A.put(x, PISO, tz0, S("yellow_concrete") if (x // 2) % 2 else S("black_concrete"))
for z in range(tz0, tz1 + 1):                                 # las paredes del taller y el marco de la cortina
    for x in (tx0, tx1):
        for y in range(PISO + 1, PISO + 17):
            A.put(x, y, z, OSCURO if z == tz0 else LADRILLO)
for x in range(tx0, tx1 + 1):
    A.put(x, PISO + 17, tz0, OSCURO)
    for y in range(PISO + 15, PISO + 17):                     # la cortina de metal, levantada (el Cazador pasa abajo)
        A.put(x, y, tz0, S("iron_block") if y == PISO + 15 else METAL_OSCURO)
for x in range(tx0 + 2, tx1 - 1, 4):                          # cables y luces de taller (contra el fondo: el Cazador
    A.put(x, PISO + 11, tz1 - 1, S("redstone_lamp", lit=True))  # descansa en el medio)
for (x, z) in ((tx0 + 1, tz0 + 2), (tx1 - 1, tz0 + 2), (tx0 + 1, tz1 - 1), (tx1 - 1, tz1 - 1)):
    A.put(x, PISO + 1, z, S("anvil", facing="north"))

# =================================================================== bancos de la estación y el reloj parado
for (x, z) in ((5966, 40), (5966, 60), (5966, 80), (6034, 40), (6034, 60), (6034, 80), (5986, 24), (6014, 24),
               (5986, 92), (6014, 92)):                      # (fuera de por donde camina el Cazador)
    for dx in range(-1, 2):
        A.put(x + dx, PISO + 1, z, S("dark_oak_stairs", facing="north", half="bottom", shape="straight", waterlogged=False))
cy, cr = 108, 4.6                                             # el reloj, en la pared norte, sobre el vestíbulo
for x in range(CX - 6, CX + 7):
    for y in range(cy - 6, cy + 7):
        d = math.hypot(x - CX, y - cy)
        if d <= cr + 0.5:
            A.put(x, y, NAVE[2] + 1, OSCURO if d > cr - 0.6 else S("smooth_quartz"))
for k in range(1, 4):                                         # las agujas, paradas (a las diez y diez)
    A.put(CX - k, cy + (1 if k < 3 else 2), NAVE[2] + 2, S("black_concrete"))
    A.put(CX + k, cy + (1 if k < 3 else 2), NAVE[2] + 2, S("black_concrete"))
A.put(CX, cy, NAVE[2] + 2, S("black_concrete"))

# =================================================================== el vestíbulo: rejas, entrada y faroles
x0, x1, z0, z1 = PALCO
A.baranda([(x, 2) for x in range(NAVE[0] + 1, NAVE[1])], PISO + 1, PISO + 2)
borde = [(x, z0) for x in range(x0, x1 + 1)] + [(x, z) for z in range(z0, z1 + 1) for x in (x0, x1)]
borde = [(x, z) for (x, z) in borde if not (z == z0 and CX - 23 <= x <= CX - 17)]   # ahí va el portal de vuelta
A.baranda(borde, PISO + 1, PISO + 2)
A.entrada(2, centro=CX)
for (x, z) in ((x0 + 1, z1 - 1), (x1 - 1, z1 - 1), (x0 + 1, z0 + 1), (x1 - 1, z0 + 1)):
    A.put(x, PISO + 1, z, OSCURO)
    A.put(x, PISO + 2, z, FAROL)

# =================================================================== luces invisibles, tenues (es de noche)
for x in range(NAVE[0] + 1, NAVE[1]):
    for z in range(NAVE[2] + 1, NAVE[3]):
        if (x % 6, z % 6) == (3, 3) and A.get(x, PISO + 5, z) is None:
            A.put(x, PISO + 5, z, S("light", level=11, waterlogged=False))

if __name__ == "__main__":
    print(len(CASILLEROS), "casilleros")
    A.guardar(sys.argv[1], sys.argv[2], "casilleros")
