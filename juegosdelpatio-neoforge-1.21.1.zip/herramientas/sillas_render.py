#!/usr/bin/env python3
"""Vistas previas del juego 2, "Las sillas musicales", con render.py y recortes (billboards) de las personas.

Uso: python3 sillas_render.py <sillas.pkl> <salida.png> <ancho> <alto> <supermuestreo> <escena>
  salon:    el salón desde arriba de la entrada, en la ronda 1 con la música sonando: 86 caminan por la pista, cerca
            de las paredes, y en el centro esperan 83 sillas en anillos alrededor del gramófono
  sentarse: justo cuando para la música: todos corren desde la pista al centro y los primeros ya se sentaron
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
ESCENA = sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")
FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FUENTE_NEGRITA = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

datos = pickle.load(open(entrada, "rb"))
OX, OY, OZ = datos["origen"]
bloques = dict(datos["blocks"])
CENTRO_X, CENTRO_Z = 2000, 41
RADIOS = (7.0, 10.0, 13.0, 16.0, 19.0)
LLENO = 0.7
RADIO_PISTA = 33.0


def L(wx, wy, wz):
    return np.array([wx - OX, wy - OY, wz - OZ], float)


def poner(wx, wy, wz, st):
    bloques[(wx - OX, wy - OY, wz - OZ)] = st


# ------------------------------------------------------------------ 1) las sillas, como Sillas.anillos y Sillas.ponerSillas
def anillo(radio):
    hasta = int(math.ceil(radio)) + 1
    celdas = [(CENTRO_X + dx, CENTRO_Z + dz) for dx in range(-hasta, hasta + 1) for dz in range(-hasta, hasta + 1)
              if abs(math.sqrt(dx * dx + dz * dz) - radio) < 0.5]
    celdas.sort(key=lambda c: math.atan2(c[1] - CENTRO_Z, c[0] - CENTRO_X))
    sueltas = []
    for c in celdas:
        if not sueltas or abs(c[0] - sueltas[-1][0]) + abs(c[1] - sueltas[-1][1]) != 1:
            sueltas.append(c)
    if len(sueltas) > 1 and abs(sueltas[0][0] - sueltas[-1][0]) + abs(sueltas[0][1] - sueltas[-1][1]) == 1:
        sueltas.pop()
    return sueltas


ANILLOS = [anillo(r) for r in RADIOS]
azar = random.Random(7)


def poner_sillas(cantidad):
    usados, lugar = 0, 0
    while usados < len(ANILLOS) and lugar < cantidad:
        lugar += int(len(ANILLOS[usados]) * LLENO)
        usados += 1
    cap = [int(len(ANILLOS[i]) * LLENO) for i in range(usados)]
    puestas, sillas = 0, []
    for i in range(usados):
        aca = cantidad - puestas if i == usados - 1 else int(math.floor(cantidad * cap[i] / sum(cap) + 0.5))
        aca = max(0, min(aca, len(ANILLOS[i])))
        desfase = azar.random()
        for j in range(aca):
            sillas.append((ANILLOS[i][int((j + desfase) * len(ANILLOS[i]) / aca) % len(ANILLOS[i])], i))
        puestas += aca
    return sillas


GENTE = 86
SILLAS = poner_sillas(GENTE - 3) if ESCENA == "salon" else poner_sillas(GENTE - 3)
for (sx, sz), i in SILLAS:
    dx, dz = sx - CENTRO_X, sz - CENTRO_Z
    mira = ("east" if dx > 0 else "west") if abs(dx) > abs(dz) else ("south" if dz > 0 else "north")
    poner(sx, 100, sz, f"juegosdelpatio:silla[color={i % 4},facing={mira}]")

tmp = os.path.join(tempfile.gettempdir(), "sillas_escena.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": 0}, open(tmp, "wb"))
sys.argv = ["render.py", tmp]
sys.path.insert(0, AQUI)
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
if ESCENA == "sentarse":
    POS, TGT, FOV = L(2000.5, 106.0, 10.0), L(2000.5, 100.5, 31.0), 66
else:
    POS, TGT, FOV = L(2000.5, 114.5, -13.5), L(2000.5, 99.0, 40.0), 76
O, D = R.perspective(W2, H2, POS, TGT, FOV)

golpe, t, n, celda, kid = R.trace(O, D, R.FULL_GRID)
img = np.zeros((len(O), 3))
img[:] = (0.03, 0.03, 0.04)
hi = np.nonzero(golpe)[0]
Pp = O[hi] + D[hi] * t[hi][:, None]
nn, cc, k = n[hi], celda[hi], kid[hi]
local = Pp - cc
eje = np.argmax(np.abs(nn), 1)
u = np.where(eje == 0, local[:, 2], local[:, 0])
v = np.where(eje == 1, local[:, 2], local[:, 1])
alb = R.shade_colors(k, u, v, local, cc, nn)
cara = np.select([nn[:, 1] > 0, nn[:, 1] < 0, eje == 2], [1.0, 0.5, 0.8], 0.6)
Lz, ao = R.smooth_light(Pp, nn, R.opaque_of[R.FULL_GRID])
col = alb * R.brightness(Lz) * (cara * ao)[:, None]
em = np.array([R.kinds[kk][0] in R.EMISSIVE and R.emit_of[kk] > 0 for kk in k])
col[em] = alb[em] * (0.92 + 0.08 * cara[em])[:, None]
img[hi] = col
img = np.clip(img, 0, 1).reshape(H2, W2, 3)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
arriba = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    d = np.asarray(p) - POS
    z = d @ f
    x = (d @ r) / z / (th * W2 / H2)
    y = (d @ arriba) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(p):
    cx, cz = int(math.floor(p[0])), int(math.floor(p[2]))
    niveles = [R.LIGHTF[cx + dx, yy, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1) for yy in (1, 2)]
    return R.brightness(np.array([max(niveles)]))[0] * 0.95


def recorte(sprite, base, alto, ancho, luz, adelante=0.0):
    base = np.asarray(base, float)
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    c = arr[py, px]
    efectivo = tt - adelante
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (c[..., 3] > 0) & (tt > 0) & (efectivo < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = c[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = efectivo[ver]


def sombra(base, ancho):
    cx, cy = proyectar(base)
    ex, _ = proyectar(np.asarray(base) + DERECHA * ancho * 0.6)
    rx = abs(ex - cx)
    ry = rx * 0.55
    if rx < 1:
        return
    j0, j1 = max(int(cy - ry) - 1, 0), min(int(cy + ry) + 2, H2)
    i0, i1 = max(int(cx - rx) - 1, 0), min(int(cx + rx) + 2, W2)
    if i0 >= i1 or j0 >= j1:
        return
    jj_, ii_ = np.ogrid[j0:j1, i0:i1]
    m = ((ii_ - cx) / rx) ** 2 + ((jj_ - cy) / max(ry, 1)) ** 2 <= 1
    img[j0:j1, i0:i1][m] *= 0.62


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


def perfil(skin, derecha):
    """De costado (caminando): cabeza, torso y una pierna, para la gente que da vueltas."""
    out = Image.new("RGBA", (8, 32), (0, 0, 0, 0))
    cara = (0, 8) if derecha else (16, 8)
    pegar(out, skin, cara[0], cara[1], 8, 8, 0, 0)
    pegar(out, skin, 16 if derecha else 28, 20, 4, 12, 2, 8)
    pegar(out, skin, 40 if derecha else 48, 20, 4, 12, 2, 8)
    pegar(out, skin, 0 if derecha else 8, 20, 4, 12, 2, 20)
    return out


def sentado(skin):
    """De frente y sentado: cabeza y torso enteros, y las piernas (que van para adelante) bien cortitas."""
    parado = frente(skin)
    out = Image.new("RGBA", (16, 24), (0, 0, 0, 0))
    out.alpha_composite(parado.crop((0, 0, 16, 20)), (0, 0))
    out.alpha_composite(parado.crop((0, 20, 16, 32)).resize((16, 4)), (0, 20))
    return out


ALTO, ANCHO = 1.85, 0.925
skins = [Image.open(os.path.join(TEX, f"entity/jugador/skin_{i}.png")).convert("RGBA") for i in range(48)]
guardias = {nm: Image.open(os.path.join(TEX, f"entity/guardia/{nm}.png")).convert("RGBA")
            for nm in ("sargento", "comandante")}

personas = []                                          # (x, y, z, sprite, alto, ancho)
CX_, CZ_ = CENTRO_X + 0.5, CENTRO_Z + 0.5
if ESCENA == "salon":
    # todos caminando por la pista, cerca de las paredes (como las agujas del reloj), cada uno a su paso
    inicio = azar.random() * math.pi * 2
    for i in range(GENTE):
        a = inicio + 2 * math.pi * i / GENTE + azar.uniform(-0.02, 0.02)
        rr = RADIO_PISTA + azar.uniform(-0.3, 0.3)
        x, z = CX_ + rr * math.cos(a), CZ_ + rr * math.sin(a)
        dx, dz = -math.sin(a), math.cos(a)                     # para dónde camina
        de_frente = (dx * FRENTE[0] + dz * FRENTE[2]) > 0.4
        de_espaldas = (dx * FRENTE[0] + dz * FRENTE[2]) < -0.4
        skin = skins[azar.randrange(48)]
        if de_frente:
            sprite, ancho = frente(skin), ANCHO
        elif de_espaldas:
            sprite, ancho = espalda(skin), ANCHO
        else:
            sprite, ancho = perfil(skin, (dx * DERECHA[0] + dz * DERECHA[2]) > 0), ANCHO / 2
        personas.append((x, 100.0, z, sprite, ALTO, ancho))
    personas.append((2000.5, 102.0, -13.5, espalda(guardias["comandante"]), ALTO, ANCHO))
    for gx, gz in ((1963.5, 6.5), (2036.5, 6.5), (1963.5, 63.5), (2036.5, 63.5)):
        personas.append((gx, 100.0, gz, frente(guardias["sargento"]), ALTO, ANCHO))
else:
    # paró la música: casi todos corriendo al centro desde la pista; los primeros ya se sentaron afuera
    afuera = [s_ for s_ in SILLAS if s_[1] >= 3]
    for (sx, sz), i in afuera[:28]:
        dx, dz = sx - CENTRO_X, sz - CENTRO_Z
        largo = math.hypot(dx, dz)
        if (dx * FRENTE[0] + dz * FRENTE[2]) / largo > -0.2:
            personas.append((sx + 0.5 + dx / largo * 0.15, 100.0, sz + 0.5 + dz / largo * 0.15,
                             sentado(skins[azar.randrange(48)]), 1.42, ANCHO))
    for _ in range(60):
        a = azar.uniform(math.radians(215), math.radians(325))  # del lado de la cámara (al norte)
        rr = azar.uniform(20.5, 31.0)
        x, z = CX_ + rr * math.cos(a), CZ_ + rr * math.sin(a)
        if z < 13.0 or any((x - p_[0]) ** 2 + (z - p_[2]) ** 2 < 1.5 for p_ in personas):
            continue
        personas.append((x, 100.0, z, espalda(skins[azar.randrange(48)]), ALTO, ANCHO))   # corren hacia el centro

personas.sort(key=lambda p: -np.linalg.norm(L(p[0], p[1], p[2]) - POS))
for x, y, z, sprite, alto, ancho in personas:
    sombra(L(x, y, z), ancho)
for x, y, z, sprite, alto, ancho in personas:
    base = L(x, y, z)
    recorte(sprite, base, alto, ancho, luz_en(base))

final = Image.fromarray((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8))
if SS > 1:
    final = final.resize((W, H), Image.LANCZOS)
dib = ImageDraw.Draw(final, "RGBA")


def texto_con_sombra(xy, texto, letra, color, desplazar):
    dib.text((xy[0] + desplazar, xy[1] + desplazar), texto, font=letra,
             fill=(int(color[0] * 0.25), int(color[1] * 0.25), int(color[2] * 0.25)))
    dib.text(xy, texto, font=letra, fill=color)


# ------------------------------------------------------------------ la barra de arriba
if ESCENA == "salon":
    nombre_barra, progreso, color = "♪ Suena la música · ronda 1 de 3 · 86 jugadores · 83 sillas", 1.0, (180, 70, 230)
else:
    nombre_barra, progreso, color = "¡A sentarse! · ronda 1 de 3 · 86 jugadores · 83 sillas", 0.85, (232, 52, 52)
letra_b = ImageFont.truetype(FUENTE, max(12, H // 46))
ancho_b = int(W * 0.30)
x0 = (W - ancho_b) // 2
y0 = int(H * 0.035)
an_t = dib.textlength(nombre_barra, font=letra_b)
texto_con_sombra(((W - an_t) / 2, y0), nombre_barra, letra_b, (255, 255, 255), max(1, H // 400))
yb = y0 + int(letra_b.size * 1.35)
alto_b = max(5, H // 110)
dib.rectangle((x0 - 1, yb - 1, x0 + ancho_b + 1, yb + alto_b + 1), fill=(0, 0, 0, 200))
dib.rectangle((x0, yb, x0 + ancho_b, yb + alto_b), fill=(int(color[0] * 0.35), int(color[1] * 0.35), int(color[2] * 0.35), 255))
dib.rectangle((x0, yb, x0 + int(ancho_b * progreso), yb + alto_b), fill=color + (255,))

if ESCENA == "sentarse":
    letra_t = ImageFont.truetype(FUENTE_NEGRITA, max(28, H // 10))
    cartel = "¡A SENTARSE!"
    an_c = dib.textlength(cartel, font=letra_t)
    texto_con_sombra(((W - an_c) / 2, H * 0.56), cartel, letra_t, (255, 85, 85), max(2, H // 160))
    letra_s = ImageFont.truetype(FUENTE, max(14, H // 34))
    sub = "Corre al centro: clic derecho en una silla libre"
    an_s = dib.textlength(sub, font=letra_s)
    texto_con_sombra(((W - an_s) / 2, H * 0.56 + letra_t.size * 1.15), sub, letra_s, (190, 190, 190), max(1, H // 300))
else:
    letra = ImageFont.truetype(FUENTE, max(11, H // 52))
    linea = "♪ Camina por la pista, alrededor ♪"
    an_l = dib.textlength(linea, font=letra)
    texto_con_sombra(((W - an_l) / 2, H * 0.86), linea, letra, (255, 110, 255), max(1, H // 400))
final.save(salida, optimize=True)
print("guardado", salida, final.size)
