#!/usr/bin/env python3
"""Dibuja las skins de los guardias (una por rango), las armas y la bala.

Diseño propio: uniforme táctico azul marino, chaleco gris oscuro, máscara de gas con
visores redondos y filtro, casco del color del rango y una pieza de ajedrez como símbolo
del rango (en el pecho y la espalda), más un brazalete del mismo color.

  Vigilante  -> peón   (gris)
  Guardia    -> caballo (azul)
  Sargento   -> torre  (rojo)
  Comandante -> rey    (dorado)

Uso: python3 guardias.py <carpeta resources> <imagen de muestra>
"""
import os
import sys

from PIL import Image, ImageDraw, ImageFont

RES, MUESTRA = sys.argv[1], sys.argv[2]
sys.argv = [sys.argv[0], RES, "/tmp/_muestra_ignorada.png"]
from skins import Skin, frente  # noqa: E402  (reutiliza el pintor de skins)

MARINO = (30, 43, 69)
MARINO_OSC = (20, 29, 48)
CHALECO = (46, 50, 56)
CHALECO_OSC = (34, 37, 42)
CONTORNO = (18, 19, 22)
NEGRO = (22, 22, 24)
PLATA = (190, 192, 198)
ORO = (226, 186, 60)
ORO_OSC = (160, 124, 30)

# máscara de gas
GOMA = (52, 55, 60)
GOMA_OSC = (38, 40, 44)
CORREA = (26, 27, 30)
VISOR = (24, 34, 44)
VISOR_BRILLO = (128, 168, 190)
ARO = (96, 100, 108)
FILTRO = (118, 122, 130)
REJILLA = (40, 41, 46)

# nombre, color del casco/brazalete, color del símbolo, pieza
RANGOS = [
    ("vigilante", (130, 135, 145), (206, 210, 218), "peon"),
    ("guardia", (52, 102, 205), (88, 146, 245), "caballo"),
    ("sargento", (170, 36, 42), (228, 64, 64), "torre"),
    ("comandante", (205, 165, 45), (244, 204, 84), "rey"),
]

# piezas de ajedrez de 6 x 7 (X = símbolo)
PIEZAS = {
    "peon": ["......",
             "..XX..",
             ".XXXX.",
             "..XX..",
             "..XX..",
             ".XXXX.",
             "XXXXXX"],
    "torre": ["X.XX.X",
              "XXXXXX",
              ".XXXX.",
              ".XXXX.",
              ".XXXX.",
              ".XXXX.",
              "XXXXXX"],
    "caballo": ["...XX.",
                "..XXXX",
                ".XXXXX",
                "XXX.XX",
                "...XX.",
                ".XXXX.",
                "XXXXXX"],
    "rey": ["..XX..",
            ".XXXX.",
            "..XX..",
            "XXXXXX",
            ".XXXX.",
            ".XXXX.",
            "XXXXXX"],
}


def mezcla(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def simbolo_en(pieza, color, u, v, x0=1, y0=1):
    """Color del símbolo (con contorno oscuro) en la celda (u, v) de una cara, o None."""
    filas = PIEZAS[pieza]
    def lleno(x, y):
        return 0 <= y < len(filas) and 0 <= x < 6 and filas[y][x] == "X"
    x, y = u - x0, v - y0
    if lleno(x, y):
        if not lleno(x, y - 1) or not lleno(x - 1, y):
            return mezcla(color, 1.18)               # borde iluminado arriba/izquierda
        return color
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        if lleno(x + dx, y + dy):
            return CONTORNO
    return None


def hacer_guardia(nombre, color, color_simbolo, pieza):
    es_jefe = nombre == "comandante"
    s = Skin()

    # ---- máscara de gas (capa base de la cabeza: no se le ve la cara)
    def mascara(cara, u, v, w, h):
        if cara == "abajo":
            return GOMA_OSC
        if cara == "arriba":
            return GOMA
        if cara == "frente":
            if v in (3, 4) and u in (1, 2, 5, 6):
                if (v, u) in ((3, 1), (3, 5)):
                    return VISOR_BRILLO                  # reflejo del visor
                return VISOR
            if v in (3, 4) and u in (0, 7):
                return ARO
            if v == 2 and u in (1, 2, 5, 6):
                return ARO
            if v == 5 and u in (3, 4):
                return FILTRO
            if v == 6 and u in (2, 5):
                return FILTRO
            if v == 6 and u in (3, 4):
                return REJILLA                           # rejilla del filtro
            if v == 7 and u in (3, 4):
                return mezcla(FILTRO, 0.8)
            return GOMA if v < 6 else GOMA_OSC
        if v in (3, 4):
            return CORREA                                # correas a los costados y atrás
        if cara == "atras" and v == 5 and u in (3, 4):
            return PLATA                                 # hebilla
        return GOMA_OSC if v >= 6 else GOMA

    # ---- casco del color del rango (capa exterior de la cabeza)
    def casco(cara, u, v, w, h):
        borde = mezcla(color, 0.72)
        if cara == "arriba":
            if es_jefe and u in (3, 4):
                return ORO
            return mezcla(color, 1.08) if u in (3, 4) else color
        if cara == "abajo":
            return None
        if cara == "frente":
            if v <= 1:
                return color
            if v == 2 and u in (0, 3, 4, 7):
                return borde                             # visera
            return None
        if cara == "atras":
            return color if v <= 2 else (borde if v == 3 else None)
        return color if v <= 1 else (borde if v == 2 else None)

    def cuerpo(cara, u, v, w, h):
        if cara == "arriba":
            return MARINO
        if cara == "abajo":
            return MARINO_OSC
        if v == 9:
            return PLATA if (cara == "frente" and u in (3, 4)) else NEGRO   # cinturón
        return MARINO if v < 9 else MARINO_OSC

    # ---- chaleco con el símbolo del rango adelante y atrás
    def chaleco(cara, u, v, w, h):
        if cara in ("arriba", "abajo") or v == 0 or v >= 9:
            return None
        if cara in ("frente", "atras"):
            c = simbolo_en(pieza, color_simbolo, u, v, 1, 1)
            if c is not None:
                return c
            if v == 8 and cara == "frente" and u in (0, 7):
                return CHALECO_OSC
            return CHALECO if cara == "frente" else CHALECO_OSC if v in (8,) else CHALECO
        return CHALECO

    def brazo(cara, u, v, w, h):
        if cara == "arriba":
            return ORO if es_jefe else MARINO            # charreteras del comandante
        if cara == "abajo" or v >= 10:
            return NEGRO                                 # guantes
        if es_jefe and v == 0:
            return ORO
        if v in (2, 3):
            return color if v == 2 else mezcla(color, 0.8)   # brazalete del rango
        if v == 9:
            return ORO if es_jefe else MARINO_OSC
        return MARINO

    def pierna(cara, u, v, w, h):
        if cara == "arriba":
            return MARINO
        if cara == "abajo" or v == 11:
            return NEGRO
        if v >= 7:
            return (44, 44, 48) if v == 7 else NEGRO     # botas
        if v == 4 and cara == "frente":
            return MARINO_OSC                            # rodillera
        return MARINO

    s.caja(0, 0, 8, 8, 8, mascara)
    s.caja(32, 0, 8, 8, 8, casco)
    s.caja(16, 16, 8, 12, 4, cuerpo)
    s.caja(16, 32, 8, 12, 4, chaleco)
    s.caja(40, 16, 4, 12, 4, brazo)
    s.caja(32, 48, 4, 12, 4, brazo)
    s.caja(0, 16, 4, 12, 4, pierna)
    s.caja(16, 48, 4, 12, 4, pierna)
    return s.im


def espalda(skin, escala=6):
    """Vista de espaldas (16x32)."""
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))

    def pega(sx, sy, w, h, dx, dy):
        out.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))

    pega(24, 8, 8, 8, 4, 0)
    pega(56, 8, 8, 8, 4, 0)
    pega(32, 20, 8, 12, 4, 8)
    pega(32, 36, 8, 12, 4, 8)
    pega(52, 20, 4, 12, 12, 8)      # brazo derecho (se ve a la derecha desde atrás)
    pega(44, 52, 4, 12, 0, 8)       # brazo izquierdo
    pega(12, 20, 4, 12, 8, 20)      # pierna derecha
    pega(28, 52, 4, 12, 4, 20)      # pierna izquierda
    return out.resize((16 * escala, 32 * escala), Image.NEAREST)


# ------------------------------------------------------------------ armas (16x16, en diagonal como las herramientas)
def sprite(celdas, contorno=(18, 18, 20)):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for (x, y), c in celdas.items():
        im.putpixel((x, y), c + (255,))
    for (x, y) in list(celdas):
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < 16 and 0 <= ny < 16 and (nx, ny) not in celdas and im.getpixel((nx, ny))[3] == 0:
                im.putpixel((nx, ny), contorno + (255,))
    return im


def diagonal(x0, y0, largo, color, grosor=2, brillo=None):
    celdas = {}
    for t in range(largo):
        for g in range(grosor):
            celdas[(x0 + t + g, y0 - t)] = color
        if brillo:
            celdas[(x0 + t, y0 - t)] = brillo
    return celdas


METAL = (62, 64, 72)
METAL_CLA = (122, 126, 136)
MADERA = (120, 78, 42)
MADERA_OSC = (88, 56, 30)


def porra():
    c = diagonal(4, 11, 9, (36, 36, 40), brillo=(80, 80, 88))
    c.update({(3, 12): (110, 110, 118), (4, 12): (110, 110, 118), (2, 13): (110, 110, 118), (3, 13): (110, 110, 118)})
    c.update({(6, 11): (60, 60, 66), (7, 12): (60, 60, 66)})       # mango lateral
    return sprite(c)


def pistola():
    c = diagonal(6, 9, 7, METAL, brillo=METAL_CLA)
    for p in ((6, 10), (7, 10), (7, 11), (8, 11), (8, 12)):
        c[p] = (40, 34, 30)                                          # empuñadura
    c[(9, 10)] = METAL
    return sprite(c)


def rifle():
    c = diagonal(5, 10, 10, METAL, brillo=METAL_CLA)
    for p in ((2, 13), (3, 13), (3, 12), (4, 12), (4, 11), (2, 12), (1, 13), (3, 14), (2, 14)):
        c[p] = MADERA                                                # culata
    c[(1, 14)] = MADERA_OSC
    for p in ((9, 8), (10, 9), (10, 8)):
        c[p] = (40, 40, 46)                                          # cargador
    c[(12, 3)] = (40, 40, 46)                                        # mira
    return sprite(c)


def escopeta():
    c = diagonal(5, 10, 9, METAL, grosor=3, brillo=METAL_CLA)
    for p in ((2, 13), (3, 13), (3, 12), (4, 12), (4, 11), (2, 12), (1, 13), (2, 14), (3, 14)):
        c[p] = MADERA
    for p in ((8, 8), (9, 7), (9, 8), (10, 7)):
        c[p] = MADERA_OSC                                            # guardamano
    for p in ((6, 9), (7, 9)):
        c[p] = ORO                                                   # detalles dorados
    return sprite(c)


def bala():
    """Cartucho (vaina de latón y punta de cobre), en diagonal."""
    c = {}
    for t in range(5):
        c[(4 + t, 11 - t)] = (226, 184, 84)
        c[(5 + t, 11 - t)] = (184, 140, 52)
    c[(3, 12)] = (150, 110, 40)                                      # culote
    c[(4, 12)] = (150, 110, 40)
    c[(9, 6)] = (196, 116, 64)                                       # punta
    c[(10, 6)] = (160, 90, 48)
    c[(10, 5)] = (196, 116, 64)
    return sprite(c, contorno=(60, 44, 20))


if __name__ == "__main__":
    carpeta = os.path.join(RES, "assets/juegosdelpatio/textures/entity/guardia")
    os.makedirs(carpeta, exist_ok=True)
    skins = []
    for nombre, color, color_simbolo, pieza in RANGOS:
        im = hacer_guardia(nombre, color, color_simbolo, pieza)
        im.save(os.path.join(carpeta, f"{nombre}.png"))
        skins.append(im)
    items = os.path.join(RES, "assets/juegosdelpatio/textures/item")
    armas = {"porra": porra(), "pistola": pistola(), "rifle": rifle(), "escopeta": escopeta(), "bala": bala()}
    for n, im in armas.items():
        im.save(os.path.join(items, f"{n}.png"))

    # muestra: cada rango de frente y de espaldas, con su arma y su nombre
    esc = 7
    ancho_col = 2 * 16 * esc + 20 + 100 + 40
    hoja = Image.new("RGBA", (4 * ancho_col + 20, 32 * esc + 120), (22, 24, 30, 255))
    dib = ImageDraw.Draw(hoja)
    try:
        letra = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 30)
    except OSError:
        letra = ImageFont.load_default()
    glifos = {"peon": "♟", "caballo": "♞", "torre": "♜", "rey": "♚"}
    titulos = ["Vigilante", "Guardia", "Sargento", "Comandante"]
    orden = ["porra", "pistola", "rifle", "escopeta"]
    for i, im in enumerate(skins):
        x = 30 + i * ancho_col
        hoja.alpha_composite(frente(im, esc), (x, 70))
        hoja.alpha_composite(espalda(im, esc), (x + 16 * esc + 20, 70))
        hoja.alpha_composite(armas[orden[i]].resize((96, 96), Image.NEAREST), (x + 2 * 16 * esc + 30, 70 + 12 * esc))
        _, _, color_simbolo, pieza = RANGOS[i]
        dib.text((x, 18), f"{glifos[pieza]} {titulos[i]}", font=letra, fill=color_simbolo)
    hoja.convert("RGB").save(MUESTRA)
    print("guardias y armas listos")
