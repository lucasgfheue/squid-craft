#!/usr/bin/env python3
"""Vista previa de la ceremonia de bienvenida: el portón abierto, el comandante con los cuatro sargentos
frente a la sala y los bots escuchando. La sala se dibuja con render.py; las personas son "recortes"
(billboards) hechos con sus skins, con su luz y tapados por lo que tengan delante.

Uso: python3 ceremonia_render.py <bloques.pkl> <salida.png> <ancho> <alto> <supermuestreo>
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")

# ------------------------------------------------------------------ 1) la sala con el portón abierto
datos = pickle.load(open(entrada, "rb"))
OFF = datos["offset"]
bloques = dict(datos["blocks"])
ZP = OFF - 1                                         # la puerta está en z = -1 del salón
for x in range(28, 37):
    filas = [bloques.pop((x, y, ZP)) for y in range(1, 10)]
    for i, st in enumerate(filas):
        bloques[(x, 10 + i, ZP)] = st                # sube al hueco del muro
tmp = os.path.join(tempfile.gettempdir(), "bloques_porton_abierto.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": OFF}, open(tmp, "wb"))

sys.argv = ["render.py", tmp]
sys.path.insert(0, AQUI)
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
POS = np.array([32.5, 3.9, OFF + 25.0])
TGT = np.array([32.5, 2.7, OFF + 4.0])
FOV = 48
O, D = R.perspective(W2, H2, POS, TGT, FOV)
img = R.render(R.FULL_GRID, O, D, W2, H2).copy()
golpe, t, _, _, _ = R.trace(O, D, R.FULL_GRID)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
u = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))       # los recortes miran a la cámara
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    d = np.asarray(p) - POS
    z = d @ f
    x = (d @ r) / z / (th * W2 / H2)
    y = (d @ u) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(x, z):
    cx, cz = int(math.floor(x)), int(math.floor(z))
    niveles = [R.LIGHTF[cx + dx, 2, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1)]
    return R.brightness(np.array([max(niveles)]))[0] * 0.92


def recorte(sprite, base, alto, ancho, luz, adelante=0.0, desvio=0.0):
    """Dibuja un sprite vertical de pie en 'base' (centro de los pies), tapado por lo que haya delante."""
    base = np.asarray(base, float) + DERECHA * desvio
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    col = arr[py, px]
    efectivo = tt - adelante
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (col[..., 3] > 0) & (tt > 0) & (efectivo < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = col[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = efectivo[ver]


def sombra(base, ancho):
    cx, cy = proyectar(base)
    ex, _ = proyectar(np.asarray(base) + DERECHA * ancho * 0.6)
    rx = abs(ex - cx)
    ry = rx * 0.28
    jj, ii = np.ogrid[:H2, :W2]
    m = ((ii - cx) / max(rx, 1)) ** 2 + ((jj - cy) / max(ry, 1)) ** 2 <= 1
    img[m] *= 0.62


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


ALTO, ANCHO = 1.85, 0.925
guardias = {n: Image.open(os.path.join(TEX, f"entity/guardia/{n}.png")).convert("RGBA")
            for n in ("vigilante", "guardia", "sargento", "comandante")}
armas = {n: Image.open(os.path.join(TEX, f"item/{n}.png")).convert("RGBA").rotate(45, expand=True)
         for n in ("porra", "pistola", "rifle", "escopeta")}

figuras = []                                          # (x, z, sprite, arma)
# el comandante en el escenario (0.5, 65, 8.5) y dos sargentos de cada lado, un paso atrás
figuras.append((32.5, 41.5, frente(guardias["comandante"]), "escopeta"))
for dx in (-1.6, -3.2, 1.6, 3.2):
    figuras.append((32.5 + dx, 40.5, frente(guardias["sargento"]), "rifle"))
# guardias de la sala, quietos junto al portón
figuras.append((25.5, 31.5, frente(guardias["vigilante"]), "porra"))
figuras.append((39.5, 31.5, frente(guardias["guardia"]), "pistola"))

# el público: bots de espaldas mirando al comandante
azar = random.Random(7)
publico = []
while len(publico) < 22:
    x = azar.uniform(21.5, 43.5)
    z = azar.uniform(44.5, 49.5)
    if abs(x - 32.5) < 2.6:
        continue                                      # que se vea el comandante
    if all((x - a) ** 2 + (z - b) ** 2 > 0.95 for a, b, _ in publico):
        publico.append((x, z, azar.randrange(48)))

for x, z, _, _ in figuras:
    sombra((x, 1.0, z), ANCHO)
for x, z, _ in publico:
    sombra((x, 1.0, z), ANCHO)
for x, z, sprite, arma in figuras:
    luz = luz_en(x, z)
    recorte(sprite, (x, 1.0, z), ALTO, ANCHO, luz)
    recorte(armas[arma], (x, 0.35, z), 1.25, 1.25, luz, adelante=0.3, desvio=-0.42)
for x, z, s in publico:
    skin = Image.open(os.path.join(TEX, f"entity/jugador/skin_{s}.png")).convert("RGBA")
    recorte(espalda(skin), (x, 1.0, z), ALTO, ANCHO, luz_en(x, z))

final = Image.fromarray((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8))
if SS > 1:
    final = final.resize((W, H), Image.LANCZOS)

# ------------------------------------------------------------------ chat, como se vería en el juego
dib = ImageDraw.Draw(final, "RGBA")
letra = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", max(12, H // 52))
nombre = "<♚ Comandante> "
frases = ["Son 5 juegos en total: uno por día.",
          "El premio es de 1000 diamantes.",
          "Nadie está obligado a quedarse: si la mayoría vota por salir, los juegos se terminan.",
          "Y pase lo que pase, el premio se reparte entre todos los jugadores."]
alto_linea = int(letra.size * 1.45)
ancho_max = int(W * 0.56)
lineas = []
for frase in frases:
    palabras, actual, primera = frase.split(), "", True
    for p in palabras:
        prueba = (actual + " " + p).strip()
        extra = dib.textlength(nombre, font=letra) if primera else 0
        if dib.textlength(prueba, font=letra) + extra > ancho_max and actual:
            lineas.append((primera, actual))
            actual, primera = p, False
        else:
            actual = prueba
    lineas.append((primera, actual))
y = H - 14 - alto_linea * len(lineas)
for primera, texto in lineas:
    dib.rectangle((8, y, 8 + ancho_max + 16, y + alto_linea), fill=(0, 0, 0, 120))
    x = 14
    if primera:
        dib.text((x, y + 2), "<", font=letra, fill=(255, 255, 255))
        x += dib.textlength("<", font=letra)
        dib.text((x, y + 2), "♚ Comandante", font=letra, fill=(255, 170, 0))
        x += dib.textlength("♚ Comandante", font=letra)
        dib.text((x, y + 2), "> ", font=letra, fill=(255, 255, 255))
        x += dib.textlength("> ", font=letra)
    dib.text((x, y + 2), texto, font=letra, fill=(255, 255, 85))
    y += alto_linea
cx, cy = proyectar((32.5, 1.0 + ALTO + 0.45, 41.5))
cx, cy = cx / SS, cy / SS
etiqueta = "\u265A Comandante"
letra2 = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", max(11, H // 58))
an = dib.textlength(etiqueta, font=letra2)
dib.rectangle((cx - an / 2 - 3, cy - letra2.size * 0.7, cx + an / 2 + 3, cy + letra2.size * 0.75), fill=(0, 0, 0, 90))
dib.text((cx - an / 2, cy - letra2.size * 0.62), etiqueta, font=letra2, fill=(255, 170, 0))
final.save(salida, optimize=True)
print("guardado", salida, final.size)
