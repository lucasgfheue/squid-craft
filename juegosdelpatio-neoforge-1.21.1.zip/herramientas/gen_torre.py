#!/usr/bin/env python3
"""Genera la Torre de los Juegos (torre.nbt): detrás del portón y del pasillo de los guardias.

Una torre cuadrada de 21 x 21 con una escalera que sube en espiral pegada a las paredes. Cada tramo sube
8 bloques y termina en un descanso con una puerta numerada (1 a 5), una por juego, con el número hecho de
lámparas. En el medio queda un hueco abierto de 13 x 13, con faroles colgando del techo y el barrilete
del complejo dibujado en el piso.

Coordenadas locales: x, z de 0 a 20 (paredes en 0 y 20), y de 0 (piso) a 55 (techo).
En el mundo: x = -10 + x, y = 64 + y, z = -54 + z (la pared sur toca el fondo del pasillo).

Uso: python3 gen_torre.py <salida.nbt> <bloques.pkl>
"""
import gzip
import io
import pickle
import struct
import sys
from collections import Counter

N = 21                          # ancho y largo (paredes incluidas)
H = 56                          # alto: piso en 0, techo en 55
DATA_VERSION = 3955             # Minecraft 1.21.1

blocks = {}


def S(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    if not props:
        return name
    parts = []
    for k, v in sorted(props.items()):
        if isinstance(v, bool):
            v = "true" if v else "false"
        parts.append(f"{k}={v}")
    return f"{name}[{','.join(parts)}]"


def put(x, y, z, st):
    blocks[(x, y, z)] = st


def clear(x, y, z):
    blocks.pop((x, y, z), None)


BULB = S("waxed_copper_bulb", lit=True, powered=False)
DEEP = S("polished_deepslate")
TILES = S("deepslate_tiles")
BLACK = S("polished_blackstone")
SEA = S("sea_lantern")
BARS = "@iron_bars"
CHAIN = S("chain", axis="y", waterlogged=False)
LANTERN = S("lantern", hanging=True, waterlogged=False)
OPUESTO = {"north": "south", "south": "north", "east": "west", "west": "east"}


def escalon(facing, half="bottom"):
    return S("deepslate_tile_stairs", facing=facing, half=half, shape="straight", waterlogged=False)


def wall_state(y):
    if y in (1, H - 2):
        return S("polished_tuff")
    if y % 8 == 0:
        return S("chiseled_tuff_bricks")
    return S("tuff_bricks")


# =================================================================== piso, paredes y techo
for x in range(N):
    for z in range(N):
        put(x, 0, z, TILES)
        put(x, H - 1, z, TILES)
for y in range(1, H - 1):
    for i in range(N):
        put(i, y, 0, wall_state(y))
        put(i, y, N - 1, wall_state(y))
        put(0, y, i, wall_state(y))
        put(N - 1, y, i, wall_state(y))

# piso del hueco central: andesita con el barrilete del complejo y un borde oscuro
for x in range(4, 17):
    for z in range(4, 17):
        put(x, 0, z, DEEP if x in (4, 16) or z in (4, 16) else S("polished_andesite"))
for x, z in ((4, 4), (16, 4), (4, 16), (16, 16)):
    put(x, 0, z, SEA)
for dx in range(-5, 6):
    for dz in range(-5, 6):
        if abs(dx) + abs(dz) > 5:
            continue
        if dx == 0 or dz == 0:
            c = "black"                              # varillas del barrilete
        else:
            c = {(-1, -1): "red", (1, -1): "yellow", (-1, 1): "blue", (1, 1): "lime"}[(1 if dx > 0 else -1, 1 if dz > 0 else -1)]
        put(10 + dx, 0, 10 + dz, S(f"{c}_concrete"))
for (x, z), c in {(10, 16): "black", (10, 17): "black", (9, 18): "red", (11, 18): "blue", (10, 19): "black"}.items():
    put(x, 0, z, S(f"{c}_concrete"))                 # la cola, hacia la entrada

# techo: faroles de mar en cruz
for i in range(4, 17, 3):
    put(i, H - 1, 10, SEA)
    put(10, H - 1, i, SEA)

# =================================================================== entrada (pared sur, a nivel del piso)
for x in range(8, 13):
    for y in range(1, 6):
        clear(x, y, N - 1)
for y in range(1, 7):
    put(7, y, N - 1, DEEP)
    put(13, y, N - 1, DEEP)
for x in range(7, 14):
    put(x, 6, N - 1, DEEP)
put(7, 7, N - 1, BULB)
put(13, 7, N - 1, BULB)

# =================================================================== escalera en espiral
# Cada lado del anillo (3 de ancho) tiene un tramo de 8 escalones y un descanso plano con una puerta.
# Orden: oeste (sube al norte), norte (sube al este), este (sube al sur), sur (sube al oeste), y otra vez oeste.
LADOS = {
    #        columnas del anillo, celdas del tramo (en orden),            celdas del descanso, sube hacia
    "oeste": ((1, 2, 3), [16 - i for i in range(8)], [8, 7, 6, 5, 4], "north"),
    "norte": ((1, 2, 3), [4 + i for i in range(8)], [12, 13, 14, 15, 16], "east"),
    "este": ((17, 18, 19), [4 + i for i in range(8)], [12, 13, 14, 15, 16], "south"),
    "sur": ((17, 18, 19), [16 - i for i in range(8)], [8, 7, 6, 5, 4], "west"),
}
INTERIOR = {"oeste": 3, "norte": 3, "este": 17, "sur": 17}       # columna que da al hueco (baranda)
ESQUINAS = {"noroeste": (1, 1), "noreste": (17, 1), "sureste": (17, 17), "suroeste": (1, 17)}
RECORRIDO = [("oeste", 0, "noroeste"), ("norte", 8, "noreste"), ("este", 16, "sureste"),
             ("sur", 24, "suroeste"), ("oeste", 32, "noroeste")]


def celda(lado, a, b):
    """a = columna del anillo (x para oeste/este, z para norte/sur), b = posición a lo largo del lado."""
    return (a, b) if lado in ("oeste", "este") else (b, a)


puertas = []
for numero, (lado, base, esquina) in enumerate(RECORRIDO, start=1):
    cols, tramo, descanso, sube = LADOS[lado]
    nivel = base + 8
    for i, b in enumerate(tramo):
        for a in cols:
            x, z = celda(lado, a, b)
            put(x, base + 1 + i, z, escalon(sube))
            if base + i > 0:
                put(x, base + i, z, escalon(OPUESTO[sube], "top"))   # parte de abajo, en serrucho
            if a == INTERIOR[lado]:
                put(x, base + 2 + i, z, BARS)                         # barrotes de la baranda
    for b in descanso:
        for a in cols:
            x, z = celda(lado, a, b)
            put(x, nivel, z, DEEP)
            if a == INTERIOR[lado]:
                put(x, nivel + 1, z, BARS)
    ex, ez = ESQUINAS[esquina]
    for x in range(ex, ex + 3):
        for z in range(ez, ez + 3):
            put(x, nivel, z, DEEP)
    puertas.append((numero, lado, descanso[2], nivel))

# =================================================================== puertas numeradas
DIGITOS = {
    1: [".X.", "XX.", ".X.", ".X.", "XXX"],
    2: ["XXX", "..X", "XXX", "X..", "XXX"],
    3: ["XXX", "..X", "XXX", "..X", "XXX"],
    4: ["X.X", "X.X", "XXX", "..X", "..X"],
    5: ["XXX", "X..", "XXX", "..X", "XXX"],
}


def en_pared(lado, centro, k):
    """Posición (x, z) sobre la pared del lado, corrida k lugares hacia la derecha de quien la mira desde adentro."""
    if lado == "oeste":
        return 0, centro - k
    if lado == "norte":
        return centro + k, 0
    if lado == "este":
        return N - 1, centro + k
    return centro - k, N - 1


for numero, lado, centro, nivel in puertas:
    for k in range(-2, 3):
        for y in range(nivel + 1, nivel + 6):
            x, z = en_pared(lado, centro, k)
            if abs(k) == 2 or y == nivel + 5:
                put(x, y, z, BLACK)                                   # marco
            else:
                put(x, y, z, BLACK if y in (nivel + 1, nivel + 4) else S("iron_block"))   # la puerta, cerrada
        for y in range(nivel + 6, nivel + 13):
            x, z = en_pared(lado, centro, k)
            put(x, y, z, BLACK)                                       # placa del número
    for fila, texto in enumerate(DIGITOS[numero]):
        for col, c in enumerate(texto):
            if c == "X":
                x, z = en_pared(lado, centro, col - 1)
                put(x, nivel + 11 - fila, z, BULB)

# =================================================================== luces
for y in range(4, H - 2, 8):                                          # lámparas en las paredes
    for lado in ("oeste", "norte", "este", "sur"):
        for centro in (2, 10, 18):
            x, z = en_pared(lado, centro, 0)
            actual = blocks.get((x, y, z), "")
            if "polished_blackstone" in actual or "iron_block" in actual or "waxed_copper_bulb" in actual:
                continue
            if lado == "sur" and y < 8 and 7 <= x <= 13:
                continue                                              # la entrada
            put(x, y, z, BULB)
for (x, z), largo in {(10, 10): 26, (6, 6): 18, (14, 6): 32, (6, 14): 34, (14, 14): 20}.items():
    for y in range(H - 2, H - 2 - largo, -1):                         # faroles colgando en el hueco
        put(x, y, z, CHAIN)
    put(x, H - 2 - largo, z, LANTERN)

# =================================================================== conexiones de los barrotes
SOLIDO = ("tuff_bricks", "polished_tuff", "chiseled_tuff_bricks", "polished_deepslate", "waxed_copper_bulb",
          "iron_block", "polished_blackstone", "deepslate_tiles", "sea_lantern")


def conecta(st):
    if st is None:
        return False
    if st.startswith("@"):
        return True
    return st.split(":")[1].split("[")[0] in SOLIDO


resueltos = {}
for (x, y, z), st in blocks.items():
    if st.startswith("@"):
        resueltos[(x, y, z)] = S(st[1:],
                                 north=conecta(blocks.get((x, y, z - 1))), south=conecta(blocks.get((x, y, z + 1))),
                                 east=conecta(blocks.get((x + 1, y, z))), west=conecta(blocks.get((x - 1, y, z))),
                                 waterlogged=False)
blocks.update(resueltos)
for (x, y, z) in blocks:
    if not (0 <= x < N and 0 <= y < H and 0 <= z < N):
        raise ValueError(f"fuera de la plantilla: {(x, y, z)}")


# =================================================================== escritura NBT
class NBT:
    END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTE_ARRAY, STRING, LIST, COMPOUND, INT_ARRAY = range(12)


def w_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">H", len(b)))
    f.write(b)


def w_payload(f, t, v):
    if t == NBT.INT:
        f.write(struct.pack(">i", v))
    elif t == NBT.STRING:
        w_str(f, v)
    elif t == NBT.LIST:
        et, items = v
        f.write(struct.pack(">b", et))
        f.write(struct.pack(">i", len(items)))
        for it in items:
            w_payload(f, et, it)
    elif t == NBT.COMPOUND:
        for name, (ct, cv) in v.items():
            f.write(struct.pack(">b", ct))
            w_str(f, name)
            w_payload(f, ct, cv)
        f.write(b"\x00")
    else:
        raise ValueError(t)


def parse_state(s):
    if "[" in s:
        name, rest = s.split("[", 1)
        return name, dict(kv.split("=") for kv in rest[:-1].split(","))
    return s, {}


def build_nbt():
    freq = Counter(blocks.values())
    palette = sorted(freq, key=lambda s: (-freq[s], s))
    index = {s: i for i, s in enumerate(palette)}
    pal_tags = []
    for s in palette:
        name, props = parse_state(s)
        c = {"Name": (NBT.STRING, name)}
        if props:
            c["Properties"] = (NBT.COMPOUND, {k: (NBT.STRING, v) for k, v in sorted(props.items())})
        pal_tags.append(c)
    blk_tags = [{"pos": (NBT.LIST, (NBT.INT, [x, y, z])), "state": (NBT.INT, index[blocks[(x, y, z)]])}
                for (x, y, z) in sorted(blocks, key=lambda p: (p[1], p[0], p[2]))]
    root = {
        "DataVersion": (NBT.INT, DATA_VERSION),
        "size": (NBT.LIST, (NBT.INT, [N, H, N])),
        "palette": (NBT.LIST, (NBT.COMPOUND, pal_tags)),
        "blocks": (NBT.LIST, (NBT.COMPOUND, blk_tags)),
        "entities": (NBT.LIST, (NBT.COMPOUND, [])),
    }
    buf = io.BytesIO()
    buf.write(struct.pack(">b", NBT.COMPOUND))
    w_str(buf, "")
    w_payload(buf, NBT.COMPOUND, root)
    return buf.getvalue(), palette


if __name__ == "__main__":
    out_nbt, out_pkl = sys.argv[1], sys.argv[2]
    raw, palette = build_nbt()
    with gzip.open(out_nbt, "wb", compresslevel=9) as f:
        f.write(raw)
    with open(out_pkl, "wb") as f:
        pickle.dump({"size": (N, H, N), "blocks": blocks, "offset": 0, "puertas": puertas}, f)
    print(f"torre: {len(blocks)} bloques, paleta {len(palette)}, puertas {[(p[0], p[1], p[3]) for p in puertas]}")
