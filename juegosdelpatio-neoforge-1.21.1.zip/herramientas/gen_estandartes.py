#!/usr/bin/env python3
"""Genera la arena del juego 7, "Los estandartes" (estandartes.nbt): un campo largo de noche, partido por una grieta.

Un campo de pasto (bloques de pasto, sin plantas) con colinas suaves, bajo la noche estrellada del complejo. Una grieta
enorme (33 bloques de ancho) de norte a sur lo parte en dos lados: el oeste es de los rojos y el este de los azules. La
grieta es honda (el fondo está 59 bloques más abajo: el que se cae, se mata) y se cruza saltando por torres de piedra
con pasto arriba: tres caminos (al norte, en el medio y al sur), de 3 o 4 torres, con saltos de 2 y de 3. En cada
lado, al fondo, el fortín del equipo, con su estandarte parado sobre oro; y por el campo, ruinas (muros rotos, una
capilla, un arco, columnas, una torre caída, rocas). Al norte, más alto y separado del campo por el vacío, el palco
del comandante, con el podio y el portal de vuelta.

Todo es igual de los dos lados (para que sea parejo): lo del este es el reflejo de lo del oeste (x -> 16000 - x), con
los colores cambiados. La altura del pasto nunca cambia más de un bloque de un lugar al de al lado (se camina por todo).

Coordenadas del mundo: la plantilla empieza en (7895, 40, -20).
  campo           x 7900..8100, z 6..86 (con una barrera invisible en el borde); el pasto en lo llano, en y = 100
  grieta          x 7984..8016 (a veces un bloque más ancha, lejos de los caminos), en todo el largo; el fondo en y = 41
  torres          arriba, pasto en y = 100 (se camina en y = 101):
                    norte  z 18..24: x 7986..7992, 7996..8004, 8008..8014
                    medio  z 44..48: x 7986..7990, 7994..7998, 8002..8006, 8010..8014
                    sur    z 68..74: igual que el norte
  estandartes     el rojo en (7912, 101, 46) y el azul en (8088, 101, 46), sobre oro, en el medio del fortín
  palco           x 7975..8025, z -16..-2, el piso en y = 111 (podio en x 7996..8004, z -15..-12)

Uso: python3 gen_estandartes.py <salida.nbt> <bloques.pkl>
"""
import math
import sys

from arenas_comun import Arena, S

OX, OY, OZ = 7895, 40, -20
SX, SY, SZ = 211, 96, 111                  # x 7895..8105, y 40..135, z -20..90
A = Arena(OX, OY, OZ, SX, SY, SZ)
CX, CZ = 8000, 46
X0, X1, Z0, Z1 = 7900, 8100, 6, 86          # el borde del campo (ahí va la barrera)
LLANO = 100
FONDO = 41
GRIETA = 16                                  # la mitad del ancho de la grieta: x 7984..8016
CAMINOS = [((18, 24), [(7986, 7992), (7996, 8004), (8008, 8014)]),
           ((44, 48), [(7986, 7990), (7994, 7998), (8002, 8006), (8010, 8014)]),
           ((68, 74), [(7986, 7992), (7996, 8004), (8008, 8014)])]
ESTANDARTE = (7912, 46)                      # el rojo (el azul es el reflejo)
PALCO = (7975, 8025, -16, -2)
PALCO_PISO = 111

PASTO = S("grass_block", snowy=False)
TIERRA = S("dirt")
PIEDRA = S("stone")
LADRILLO = S("stone_bricks")
MUSGO = S("mossy_stone_bricks")
RAJADO = S("cracked_stone_bricks")
CINCELADO = S("chiseled_stone_bricks")
ADOQUIN = S("cobblestone")
ADOQUIN_MUSGO = S("mossy_cobblestone")
ANDESITA = S("andesite")
ORO = S("gold_block")
FAROL = S("lantern", hanging=False, waterlogged=False)
BARRERA = S("barrier")


def h01(*v):
    """Un número entre 0 y 1 que depende solo de los enteros dados (siempre el mismo)."""
    n = 0
    for k in v:
        n = (n * 1103515245 + k * 2654435761 + 12345) & 0xFFFFFFFF
    n ^= n >> 15
    n = (n * 2246822519) & 0xFFFFFFFF
    n ^= n >> 13
    return n / 0xFFFFFFFF


def ancho_grieta(z):
    """La mitad del ancho de la grieta: 16 junto a los caminos de torres; lejos, a veces 17 (el borde, irregular)."""
    if any(z0 - 3 <= z <= z1 + 3 for (z0, z1), _ in CAMINOS):
        return GRIETA
    return GRIETA + (1 if h01(z // 3, 7) < 0.45 else 0)


def en_grieta(x, z):
    return abs(x - CX) <= ancho_grieta(z)


# =================================================================== la altura del pasto
COLINAS = [(36, 14, 5, 6), (42, 72, 6, 7), (58, 32, 4, 5), (54, 60, 3, 5), (72, 16, 5, 6), (74, 76, 5, 6),
           (48, 46, 2, 4), (64, 46, 3, 5), (86, 28, 4, 5), (86, 64, 4, 5)]   # (distancia al medio, z, alto, radio)


def altura_cruda(x, z):
    d = abs(x - CX)
    h = LLANO + 1.1 * math.sin(d / 6.3 + 0.6) * math.cos((z - CZ) / 8.7)
    for (dc, zc, alto, radio) in COLINAS:
        h += alto * math.exp(-((d - dc) ** 2 + (z - zc) ** 2) / (2.0 * radio ** 2))
    borde = min(abs(x - X0) if x < CX else abs(X1 - x), z - Z0, Z1 - z)
    if borde < 7:
        h += (7 - borde) * 1.0                 # el campo se levanta en los bordes, como un valle
    cerca = abs(x - CX) - GRIETA - 1
    if cerca < 10:                              # junto a la grieta, llano (de ahí se salta a las torres)
        t = max(0.0, cerca) / 10.0
        h = h * t + LLANO * (1 - t)
    bx, bz = ESTANDARTE
    db = math.hypot(d - (CX - bx), z - bz)
    if db < 12:                                 # el fortín, llano
        t = max(0.0, db - 8) / 4.0
        h = h * t + LLANO * (1 - t)
    return h


ALTO = {}
for x in range(X0, CX + 1):
    for z in range(Z0, Z1 + 1):
        ALTO[(x, z)] = int(round(altura_cruda(x, z)))
cambio = True
while cambio:                                   # nunca más de un bloque entre vecinos (se camina por todo)
    cambio = False
    for (x, z), h in list(ALTO.items()):
        vecinos = [ALTO[v] for v in ((x + 1, z), (x - 1, z), (x, z + 1), (x, z - 1)) if v in ALTO]
        tope = min(vecinos) + 1
        if h > tope:
            ALTO[(x, z)] = tope
            cambio = True


def alto(x, z):
    return ALTO[(x if x <= CX else 2 * CX - x, z)]


# =================================================================== el lado oeste (después se refleja)
for x in range(X0, CX):
    for z in range(Z0, Z1 + 1):
        if en_grieta(x, z):
            continue
        h = alto(x, z)
        borde_campo = x == X0 or z in (Z0, Z1)
        borde_grieta = en_grieta(x + 1, z) or en_grieta(x, z - 1) or en_grieta(x, z + 1)
        A.put(x, h, z, PASTO)
        for y in range(h - 3, h):
            A.put(x, y, z, TIERRA)
        if borde_grieta:                        # la pared de la grieta: piedra hasta el fondo
            for y in range(FONDO + 1, h - 3):
                r = h01(x, y, z)
                A.put(x, y, z, ANDESITA if r < 0.2 else S("tuff") if r < 0.3 else S("deepslate", axis="y") if y < 66 else PIEDRA)
        elif borde_campo:                       # el borde del campo: un acantilado
            for y in range(70, h - 3):
                A.put(x, y, z, ANDESITA if h01(x, y, z) < 0.25 else PIEDRA)
        else:
            A.put(x, h - 4, z, PIEDRA)
        if borde_campo:
            for y in range(h + 1, h + 7):
                A.put(x, y, z, BARRERA)         # que nadie se caiga del campo
for z in (Z0, Z1):                              # las dos puntas de la grieta, cerradas (con la barrera arriba)
    for x in range(CX - ancho_grieta(z), CX):
        h = alto(x, z)
        for y in range(FONDO + 1, h + 1):
            A.put(x, y, z, PIEDRA if h01(x, y, z) < 0.7 else ANDESITA)
        for y in range(h + 1, h + 7):
            A.put(x, y, z, BARRERA)
for z in range(Z0, Z1 + 1):                     # el fondo de la grieta
    for x in range(CX - ancho_grieta(z), CX):
        r = h01(x, 1, z)
        A.put(x, FONDO, z, S("magma_block") if r < 0.06 else S("gravel") if r < 0.4 else S("deepslate", axis="y"))


def suelo(x, z, bloque):
    """Cambia el pasto de arriba por otro bloque (un piso de piedra, un camino)."""
    A.put(x, alto(x, z), z, bloque)


def pilar(x, z, alto_, bloques=(LADRILLO, MUSGO, RAJADO), arriba=None):
    """Una columna de ruina, de pie sobre el pasto."""
    h = alto(x, z)
    for k in range(1, alto_ + 1):
        A.put(x, h + k, z, bloques[int(h01(x, h + k, z) * len(bloques)) % len(bloques)])
    if arriba:
        A.put(x, h + alto_ + 1, z, arriba)


def muro(celdas, alto_, roto=0.0, bloques=(LADRILLO, MUSGO, RAJADO, ADOQUIN)):
    """Un muro de ruina sobre las celdas dadas: de alto_ bloques, con la parte de arriba rota (roto: cuánto)."""
    for (x, z) in celdas:
        tope = alto_ - (int(h01(x, z, 3) * (alto_ + 1) * roto) if roto else 0)
        pilar(x, z, max(1, tope), bloques)


# --- las torres de la grieta: piedra, con pasto arriba (se salta de una a otra)
for (z0, z1), torres in CAMINOS:
    for (x0, x1) in torres:
        if x0 >= CX:
            continue                            # (las del este salen del reflejo; la del medio, entera acá)
        for x in range(x0, min(x1, CX) + 1):
            for z in range(z0, z1 + 1):
                A.put(x, LLANO, z, PASTO)
                A.put(x, LLANO - 1, z, TIERRA)
                if x in (x0, x1) or z in (z0, z1):
                    for y in range(FONDO + 1, LLANO - 1):
                        r = h01(x, y, z)
                        A.put(x, y, z, ANDESITA if r < 0.22 else ADOQUIN_MUSGO if r < 0.3 and y > 80 else
                              S("tuff") if r < 0.38 else S("deepslate", axis="y") if y < 64 else PIEDRA)
        for x in range(x0, min(x1, CX) + 1):    # luces arriba (invisibles), y en la grieta para ver la hondura
            for z in range(z0, z1 + 1):
                if (x - x0) % 3 == 1 and (z - z0) % 3 == 1:
                    A.put(x, LLANO + 3, z, S("light", level=13, waterlogged=False))

# --- el fortín, con el estandarte (abierto hacia la grieta)
bx, bz = ESTANDARTE
for x in range(bx - 6, bx + 7):
    for z in range(bz - 6, bz + 7):
        r = math.hypot(x - bx, z - bz)
        if r <= 6.5:
            suelo(x, z, ADOQUIN_MUSGO if h01(x, z, 21) < 0.25 else ADOQUIN if r > 4.5 else LADRILLO)
for x in range(bx - 1, bx + 2):
    for z in range(bz - 1, bz + 2):
        suelo(x, z, CINCELADO)
suelo(bx, bz, ORO)
A.put(bx, alto(bx, bz) + 1, bz, S("red_banner", rotation=12))   # mirando al campo (al este)
muro([(bx - 7, z) for z in range(bz - 7, bz + 8)], 3, 0.5)
muro([(x, bz - 7) for x in range(bx - 7, bx + 4)] + [(x, bz + 7) for x in range(bx - 7, bx + 4)], 2, 0.6)
for (x, z) in ((bx + 4, bz - 7), (bx + 4, bz + 7)):
    pilar(x, z, 3, (LADRILLO, CINCELADO), FAROL)
for z in (bz - 4, bz + 4):                       # banderas en el muro del fondo (ahí, el muro entero)
    pilar(bx - 7, z, 3, (LADRILLO,))
    A.put(bx - 6, alto(bx - 7, z) + 2, z, S("red_wall_banner", facing="east"))

# --- ruinas
muro([(x, 30) for x in range(7966, 7974)] + [(7966, z) for z in range(31, 34)], 3, 0.5)    # junto a la grieta
muro([(x, 62) for x in range(7966, 7974)] + [(7966, z) for z in range(59, 62)], 3, 0.5)
capilla = [(x, 22) for x in range(7935, 7946)] + [(7935, z) for z in range(22, 32)] + [(7945, z) for z in range(22, 29)]
capilla += [(x, 31) for x in range(7935, 7940)]
capilla = [(x, z) for (x, z) in capilla if not ((x == 7940 and z == 22) or (z == 26 and x == 7945))]   # puerta y hueco
muro(capilla, 4, 0.35)
for x in range(7936, 7945):
    for z in range(23, 31):
        if h01(x, z, 31) < 0.55:
            suelo(x, z, ADOQUIN if h01(x, z, 32) < 0.6 else ADOQUIN_MUSGO)
for k, x in enumerate(range(7930, 7946, 3)):     # columnas (algunas rotas) y una caída
    pilar(x, 66, (4, 2, 5, 3, 1, 4)[k % 6], (LADRILLO, MUSGO, CINCELADO))
for x in range(7933, 7938):
    A.put(x, alto(x, 68) + 1, 68, MUSGO if x % 2 else LADRILLO)
for z in (40, 46):                               # un arco suelto
    pilar(7955, z, 4, (LADRILLO, MUSGO))
for z in range(40, 47):
    A.put(7955, max(alto(7955, 40), alto(7955, 46)) + 5, z, LADRILLO if z in (40, 46) or h01(z, 4) < 0.7 else MUSGO)
torre = [(x, z) for x in range(7950, 7955) for z in (70, 74)] + [(x, z) for z in range(71, 74) for x in (7950, 7954)]
torre = [(x, z) for (x, z) in torre if (x, z) != (7954, 72)]                                   # la puerta
muro(torre, 6, 0.4)
muro([(7962, z) for z in range(50, 56)], 2, 0.6)
muro([(x, 14) for x in range(7956, 7962)], 2, 0.5)
for (x, z, n) in ((7925, 16, 3), (7960, 24, 2), (7948, 56, 2), (7922, 78, 3), (7938, 50, 2), (7972, 12, 2),
                  (7974, 80, 2), (7944, 40, 2), (7918, 30, 3), (7958, 84, 2), (7930, 58, 2)):          # rocas
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            if h01(x + dx, z + dz, 41) < 0.65 or (dx, dz) == (0, 0):
                pilar(x + dx, z + dz, 1 + int(h01(x, z, dx, dz) * n), (ANDESITA, ADOQUIN, ADOQUIN_MUSGO, PIEDRA))

# --- luces: invisibles, a la altura de la cabeza, en todo el campo (como luna); y faroles en las ruinas
for x in range(X0 + 1, CX):
    for z in range(Z0 + 1, Z1):
        if en_grieta(x, z) or (x % 6, z % 6) != (2, 4):
            continue
        y = alto(x, z) + 3
        if A.get(x, y, z) is None and A.get(x, y - 1, z) is None:
            A.put(x, y, z, S("light", level=14, waterlogged=False))
for (x, z) in ((7940, 27), (7952, 72), (7970, 34), (7970, 58)):
    pilar(x, z, 1, (LADRILLO,), FAROL)
for (z0, z1), _ in CAMINOS:                      # faroles donde se empieza a saltar
    for z in (z0 - 1, z1 + 1):
        pilar(CX - GRIETA - 2, z, 1, (LADRILLO,), FAROL)


# =================================================================== el reflejo: el lado este, igual (con los colores al revés)
def reflejar(estado):
    nombre, _, props = estado.partition("[")
    nombre = nombre.replace("red_", "blue_")
    if not props:
        return nombre
    p = dict(kv.split("=") for kv in props.rstrip("]").split(","))
    if "rotation" in p:
        p["rotation"] = str((16 - int(p["rotation"])) % 16)
    if "facing" in p:
        p["facing"] = {"east": "west", "west": "east"}.get(p["facing"], p["facing"])
    if "east" in p and "west" in p:
        p["east"], p["west"] = p["west"], p["east"]
    return nombre + "[" + ",".join(f"{k}={v}" for k, v in sorted(p.items())) + "]"


for (lx, y, lz), estado in list(A.blocks.items()):
    x = lx + OX
    if x < CX:
        A.put(2 * CX - x, y + OY, lz + OZ, reflejar(estado))
for z in range(Z0, Z1 + 1):                      # el medio del fondo de la grieta (y de las puntas)
    A.put(CX, FONDO, z, S("gravel") if h01(CX, z) < 0.5 else S("deepslate", axis="y"))
    if z in (Z0, Z1):
        for y in range(FONDO + 1, alto(CX, z) + 1):
            A.put(CX, y, z, PIEDRA)
        for y in range(alto(CX, z) + 1, alto(CX, z) + 7):
            A.put(CX, y, z, BARRERA)

# =================================================================== el palco del comandante (al norte, separado)
px0, px1, pz0, pz1 = PALCO
for x in range(px0, px1 + 1):
    for z in range(pz0, pz1 + 1):
        borde = x in (px0, px1) or z in (pz0, pz1)
        A.put(x, PALCO_PISO, z, LADRILLO if borde else S("polished_andesite"))
        if borde:
            for y in range(76, PALCO_PISO):
                A.put(x, y, z, ANDESITA if h01(x, y, z) < 0.3 else PIEDRA)
borde = [(x, z) for x in range(px0, px1 + 1) for z in (pz0, pz1)] + [(x, z) for z in range(pz0, pz1 + 1) for x in (px0, px1)]
borde = [(x, z) for (x, z) in borde if not (z == pz0 and CX - 23 <= x <= CX - 17)]   # el portal de vuelta
A.baranda(borde, PALCO_PISO + 1, PALCO_PISO + 2)
A.entrada(7, centro=CX, piso=PALCO_PISO)
for (x, z) in ((px0 + 1, pz1 - 1), (px1 - 1, pz1 - 1), (px0 + 1, pz0 + 1), (px1 - 1, pz0 + 1)):
    A.put(x, PALCO_PISO + 1, z, LADRILLO)
    A.put(x, PALCO_PISO + 2, z, FAROL)
for x in range(px0 + 1, px1, 6):
    for z in (pz0 + 4, pz1 - 3):
        if A.get(x, PALCO_PISO + 2, z) is None:
            A.put(x, PALCO_PISO + 2, z, S("light", level=15, waterlogged=False))

if __name__ == "__main__":
    A.guardar(sys.argv[1], sys.argv[2], "estandartes")
