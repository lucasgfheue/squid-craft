#!/usr/bin/env python3
"""Genera la arena del juego 7, "Los estandartes" (estandartes.nbt): un campo de torres altísimas entre dos bastiones.

Cada equipo tiene su bastión en una punta: el rojo al oeste y el azul al este, cada uno con su estandarte parado en el
medio (sobre oro) y una muralla atrás con banderas de su color. Entre los dos bastiones, tres caminos de torres sobre
el vacío (el suelo está 59 bloques más abajo): el del medio, con saltos de 2 (y uno de 3) y la plaza en el centro; y
dos por los costados, de torres más chicas y saltos de 3, que en el juego se van derrumbando. Al norte, el palco (con
el podio del comandante y el portal de vuelta), separado del campo por un vacío que nadie salta.

Todo es igual de los dos lados (para que sea parejo): lo del este es el reflejo de lo del oeste (x -> 16000 - x).

Coordenadas del mundo: la plantilla empieza en (7955, 40, -17). El suelo en y = 40; arriba de las torres, en y = 99.
  palco             x 7975..8025, z -16..2   (podio en x 7996..8004, z -15..-12; portal en x 7977..7983)
  bastión rojo      x 7957..7967, z 10..36   (muralla en x = 7957; estandarte en (7962, 23))
  bastión azul      x 8033..8043, z 10..36   (muralla en x = 8043; estandarte en (8038, 23))
  camino del medio  z 21..25: x 7970..7975, 7979..7984, 7987..7992 | plaza x 7995..8005, z 18..28 | y al revés
  costado norte     z 10..14: x 7971..7975, 7979..7983, 7987..7991, 7995..8005 (el del medio), y al revés
  costado sur       z 32..36: igual que el norte

Uso: python3 gen_estandartes.py <salida.nbt> <bloques.pkl>
"""
import math
import sys

from arenas_comun import PISO, Arena, S

OX, OY, OZ = 7955, 40, -17
SX, SY, SZ = 91, 78, 58                  # x 7955..8045, y 40..117, z -17..40
A = Arena(OX, OY, OZ, SX, SY, SZ)
SUELO = 40
CENTRO_X, CENTRO_Z = 8000, 23
PALCO = (7975, 8025, -16, 2)
BASTION = (7957, 7967, 10, 36)           # el rojo (el azul es el reflejo)
PEDESTAL = (7962, 23)
MEDIO = [(7970, 7975, 21, 25), (7979, 7984, 21, 25), (7987, 7992, 21, 25)]
PLAZA = (7995, 8005, 18, 28)
COSTADO = [(7971, 7975), (7979, 7983), (7987, 7991)]
COSTADO_MEDIO = (7995, 8005)
NORTE, SUR = (10, 14), (32, 36)
NEGRO = S("polished_blackstone")
LADRILLO = S("polished_blackstone_bricks")
CINCELADO = S("chiseled_polished_blackstone")
BALDOSA = S("deepslate_tiles")
ORO = S("gold_block")
CALIDA = S("shroomlight")
FRIA = S("sea_lantern")
FAROL = S("lantern", hanging=False, waterlogged=False)


def espejo(x):
    return 2 * CENTRO_X - x


def caja_espejo(c):
    x0, x1, z0, z1 = c
    return (espejo(x1), espejo(x0), z0, z1)


EQUIPOS = {
    "rojo": dict(bastion=BASTION, x=lambda x: x, trim=S("red_nether_bricks"), banda=S("nether_bricks"), luz=CALIDA,
                 estandarte=S("red_banner", rotation=12), bandera=lambda f: S("red_wall_banner", facing=f),
                 adentro="east", afuera="west"),
    "azul": dict(bastion=caja_espejo(BASTION), x=espejo, trim=S("lapis_block"), banda=S("lapis_block"), luz=FRIA,
                 estandarte=S("blue_banner", rotation=4), bandera=lambda f: S("blue_wall_banner", facing=f),
                 adentro="west", afuera="east"),
}
TORRES_MEDIO = MEDIO + [caja_espejo(c) for c in MEDIO]
TORRES_COSTADO = []
for (z0, z1) in (NORTE, SUR):
    for (x0, x1) in COSTADO:
        TORRES_COSTADO += [(x0, x1, z0, z1), (espejo(x1), espejo(x0), z0, z1)]
    TORRES_COSTADO.append((COSTADO_MEDIO[0], COSTADO_MEDIO[1], z0, z1))

# =================================================================== el suelo, allá abajo
for x in range(OX, OX + SX):
    for z in range(OZ, OZ + SZ):
        A.put(x, SUELO, z, CALIDA if x % 8 == 4 and z % 8 == 4 else BALDOSA)

# =================================================================== los cuerpos de las torres (huecos)
A.torre(*PALCO[:2], *PALCO[2:], SUELO + 1, PISO - 1, BALDOSA, bandas=(60, 80), banda=S("polished_deepslate"),
        ventanas=CALIDA, cada=6, alturas=(52, 72, 92))
for nombre, eq in EQUIPOS.items():
    A.torre(*eq["bastion"][:2], *eq["bastion"][2:], SUELO + 1, PISO - 1, LADRILLO, bandas=(56, 57, 76, 77, 96),
            banda=eq["banda"], ventanas=eq["luz"], cada=4, alturas=(48, 66, 86))
A.torre(*PLAZA[:2], *PLAZA[2:], SUELO + 1, PISO - 1, BALDOSA, bandas=(58, 78, 97), banda=S("polished_deepslate"),
        ventanas=CALIDA, cada=5, alturas=(50, 70, 90))
for k, (x0, x1, z0, z1) in enumerate(TORRES_MEDIO):
    A.torre(x0, x1, z0, z1, SUELO + 1, PISO - 1, S("polished_deepslate"), bandas=(54, 55, 74, 75, 97),
            banda=S("chiseled_deepslate"), ventanas=CALIDA, cada=3, alturas=(60 + 2 * k, 82 + 2 * k))
for k, (x0, x1, z0, z1) in enumerate(TORRES_COSTADO):
    A.torre(x0, x1, z0, z1, SUELO + 1, PISO - 1, S("polished_deepslate"), bandas=(62, 63, 85, 97),
            banda=BALDOSA, ventanas=CALIDA, cada=3, alturas=(52 + 3 * (k % 4), 76 + 3 * (k % 4)))


# =================================================================== arriba de las torres
def techo(c, borde, adentro):
    x0, x1, z0, z1 = c
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            A.put(x, PISO, z, borde if x in (x0, x1) or z in (z0, z1) else adentro)


for c in TORRES_MEDIO + TORRES_COSTADO:
    techo(c, LADRILLO, BALDOSA)
techo(PALCO, LADRILLO, S("polished_andesite"))
# la plaza: piedra negra, un anillo de oro y faroles en las cuatro esquinas
techo(PLAZA, LADRILLO, NEGRO)
for x in range(PLAZA[0] + 1, PLAZA[1]):
    for z in range(PLAZA[2] + 1, PLAZA[3]):
        if round(math.hypot(x - CENTRO_X, z - CENTRO_Z)) == 3:
            A.put(x, PISO, z, ORO)
A.put(CENTRO_X, PISO, CENTRO_Z, CINCELADO)
for (x, z) in ((PLAZA[0], PLAZA[2]), (PLAZA[1], PLAZA[2]), (PLAZA[0], PLAZA[3]), (PLAZA[1], PLAZA[3])):
    A.put(x, PISO + 1, z, LADRILLO)
    A.put(x, PISO + 2, z, FAROL)

# =================================================================== los bastiones (el azul, reflejado)
for nombre, eq in EQUIPOS.items():
    X = eq["x"]
    x0, x1, z0, z1 = BASTION                                       # en coordenadas del rojo (X las da vuelta)
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            A.put(X(x), PISO, z, eq["trim"] if z in (z0, z1) or x == x1 else LADRILLO)
    for z in range(z0 + 1, z1):                                    # la alfombra del medio, hasta el estandarte
        if z == CENTRO_Z:
            for x in range(x0 + 1, x1):
                A.put(X(x), PISO, z, eq["trim"])
    px, pz = PEDESTAL
    for x in range(px - 1, px + 2):                                # el pedestal: piedra cincelada y oro
        for z in range(pz - 1, pz + 2):
            A.put(X(x), PISO, z, CINCELADO)
    A.put(X(px), PISO, pz, ORO)
    A.put(X(px), PISO + 1, pz, eq["estandarte"])                   # el estandarte del equipo
    for z in range(z0, z1 + 1):                                    # la muralla de atrás, con almenas
        for y in range(PISO + 1, PISO + 7):
            A.put(X(x0), y, z, eq["luz"] if y == PISO + 3 and z % 4 == 1 else LADRILLO)
        if z % 2 == 0:
            A.put(X(x0), PISO + 7, z, LADRILLO)
    for z in (z0 + 3, z0 + 7, z0 + 11, z1 - 11, z1 - 7, z1 - 3):    # banderas colgadas en la muralla
        A.put(X(x0 + 1), PISO + 5, z, eq["bandera"](eq["adentro"]))
    for z in range(z0 + 6, z0 + 11):                               # y afuera, colgando sobre el vacío
        A.put(X(x1 + 1), PISO - 2, z, eq["bandera"](eq["adentro"]))
    for z in range(z1 - 10, z1 - 5):
        A.put(X(x1 + 1), PISO - 2, z, eq["bandera"](eq["adentro"]))
    for z in (z0 + 8, z1 - 8):                                     # dos braseros a los lados del estandarte
        A.put(X(px), PISO + 1, z, LADRILLO)
        A.put(X(px), PISO + 2, z, eq["luz"])
    baranda = [(X(x), z) for x in range(x0 + 1, x1 + 1) for z in (z0, z1)]
    baranda += [(X(x1), z) for z in list(range(z0 + 5, z0 + 11)) + list(range(z1 - 10, z1 - 4))]
    A.baranda(baranda, PISO + 1, PISO + 2)

# =================================================================== el palco: baranda, entrada y faroles
x0, x1, z0, z1 = PALCO
borde = [(x, z) for x in range(x0, x1 + 1) for z in (z0, z1)] + [(x, z) for z in range(z0, z1 + 1) for x in (x0, x1)]
borde = [(x, z) for (x, z) in borde if not (z == z0 and CENTRO_X - 23 <= x <= CENTRO_X - 17)]   # el portal de vuelta
A.baranda(borde, PISO + 1, PISO + 2)
A.entrada(7, centro=CENTRO_X)
for (x, z) in ((x0 + 1, z1 - 1), (x1 - 1, z1 - 1), (x0 + 1, z0 + 1), (x1 - 1, z0 + 1)):
    A.put(x, PISO + 1, z, LADRILLO)
    A.put(x, PISO + 2, z, FAROL)

# =================================================================== luces: arriba, invisibles; y en el vacío
A.luces(x0 + 1, x1 - 1, z0 + 1, z1 - 1)
for eq in EQUIPOS.values():
    bx0, bx1, bz0, bz1 = eq["bastion"]
    A.luces(bx0 + 1, bx1, bz0 + 1, bz1 - 1)
for c in TORRES_MEDIO + TORRES_COSTADO + [PLAZA]:
    A.luces(*c)
for x in range(7969, 8032, 9):
    for z in (6, 17, 29, 39):
        for y in (52, 68, 84):
            if A.get(x, y, z) is None:
                A.put(x, y, z, S("light", level=10, waterlogged=False))

if __name__ == "__main__":
    A.guardar(sys.argv[1], sys.argv[2], "estandartes")
