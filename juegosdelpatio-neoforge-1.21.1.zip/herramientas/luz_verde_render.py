#!/usr/bin/env python3
"""Vistas previas del juego 1, "Luz verde, luz roja", con render.py y recortes (billboards) de las personas.

Uso: python3 luz_verde_render.py <luz_verde.pkl> <salida.png> <ancho> <alto> <supermuestreo> <escena>
  roja:  cerca de la meta, con la luz roja: el Vigía se dio vuelta y mira, todos quietos, y a uno lo acaba de ver
  verde: la misma vista con la luz verde: el Vigía de espaldas y la gente avanzando
  arena: el patio entero desde arriba de la salida, con la luz verde y el juego en marcha
  reglas: la salida vista desde el campo: todos detrás de la línea y el comandante en su podio explicando las reglas
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
ESCENA = sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")
FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FUENTE_NEGRITA = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

datos = pickle.load(open(entrada, "rb"))
OX, OY, OZ = datos["origen"]
bloques = dict(datos["blocks"])
VERDE = ESCENA in ("arena", "verde")


def L(wx, wy, wz):
    """Del mundo a la plantilla."""
    return np.array([wx - OX, wy - OY, wz - OZ], float)


def poner(wx, wy, wz, st):
    bloques[(wx - OX, wy - OY, wz - OZ)] = st


# ------------------------------------------------------------------ 1) la cabeza del Vigía y las luces, como en el juego
def leer_cabeza():
    for rel in ("../src/main/java/com/juegosdelpatio/Vigia.java", "../juegosdelpatio/src/main/java/com/juegosdelpatio/Vigia.java"):
        ruta = os.path.join(AQUI, rel)
        if os.path.exists(ruta):
            texto = open(ruta, encoding="utf-8").read()
            tabla = texto[texto.index("CABEZA = {"):]
            filas = __import__("re").findall(r'"([IGLKR]{8})"', tabla[:tabla.index("};")])
            return [filas[8 * y:8 * y + 8] for y in range(8)]
    raise FileNotFoundError("no encuentro Vigia.java")


MATERIAL = {"I": "minecraft:iron_block", "G": "minecraft:gray_concrete", "L": "minecraft:light_gray_concrete",
            "K": "minecraft:black_concrete", "R": "minecraft:red_concrete"}
CABEZA = leer_cabeza()
giro = 2 if VERDE else 0                              # de espaldas con la verde; mirando con la roja (Vigia.poner)
for y in range(8):
    for z in range(8):
        for x in range(8):
            dx, dz = (x, z) if giro == 0 else (7 - z, x) if giro == 1 else (7 - x, 7 - z)
            poner(996 + dx, 127 + y, 298 + dz, MATERIAL[CABEZA[y][z][x]])
for x in (949, 1050):                                 # las luces de las paredes (Juego.ponerLuces)
    for zc in (35, 85, 135, 185, 235, 285):
        for z in range(zc - 1, zc + 2):
            for y in range(104, 108):
                poner(x, y, z, "minecraft:lime_concrete" if VERDE else "minecraft:red_concrete")
if ESCENA in ("arena", "verde", "roja"):
    for x in range(950, 1050):                       # el juego empezó: ya no está la barrera de la salida
        for y in range(100, 104):
            bloques.pop((x - OX, y - OY, 10 - OZ), None)
tmp = os.path.join(tempfile.gettempdir(), "luz_verde_escena.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": 0}, open(tmp, "wb"))

sys.argv = ["render.py", tmp]
sys.path.insert(0, AQUI)
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
if ESCENA in ("roja", "verde"):
    POS, TGT, FOV = L(1000.6, 102.1, 236.0), L(1000.0, 107.0, 300.0), 66
elif ESCENA == "reglas":
    POS, TGT, FOV = L(1022.5, 104.4, 27.5), L(1022.5, 101.9, 5.0), 62
else:
    POS, TGT, FOV = L(1041.0, 158.0, -52.0), L(997.0, 99.0, 122.0), 64
O, D = R.perspective(W2, H2, POS, TGT, FOV)

# lo mismo que R.render, pero guardando la profundidad para tapar bien a las personas
golpe, t, n, celda, kid = R.trace(O, D, R.FULL_GRID)
img = np.zeros((len(O), 3))
jj = np.repeat(np.arange(H2), W2) / max(H2 - 1, 1)
img[:] = np.array((0.035, 0.045, 0.085))[None, :] * (1 - jj)[:, None] + np.array((0.012, 0.012, 0.02))[None, :] * jj[:, None]
cielo = np.nonzero(~golpe)[0]
azar_cielo = np.random.default_rng(3)
estrellas = cielo[azar_cielo.random(len(cielo)) < 0.0009 / SS]
img[estrellas] = np.clip(0.5 + 0.5 * azar_cielo.random((len(estrellas), 1)), 0, 1) * np.array([0.85, 0.88, 1.0])
hi = np.nonzero(golpe)[0]
Pp = O[hi] + D[hi] * t[hi][:, None]
nn, cc, k = n[hi], celda[hi], kid[hi]
local = Pp - cc
eje = np.argmax(np.abs(nn), 1)
u = np.where(eje == 0, local[:, 2], local[:, 0])
v = np.where(eje == 1, local[:, 2], local[:, 1])
alb = R.shade_colors(k, u, v, local, cc, nn)
cara = np.select([nn[:, 1] > 0, nn[:, 1] < 0, eje == 2], [1.0, 0.5, 0.8], 0.6)
Lz, ao = R.smooth_light(Pp, nn, R.opaque_of[R.FULL_GRID])
col = alb * R.brightness(Lz) * (cara * ao)[:, None]
em = np.array([R.kinds[kk][0] in R.EMISSIVE and R.emit_of[kk] > 0 for kk in k])
col[em] = alb[em] * (0.92 + 0.08 * cara[em])[:, None]
img[hi] = col
img = np.clip(img, 0, 1).reshape(H2, W2, 3)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
arriba = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    d = np.asarray(p) - POS
    z = d @ f
    x = (d @ r) / z / (th * W2 / H2)
    y = (d @ arriba) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(p):
    cx, cz = int(math.floor(p[0])), int(math.floor(p[2]))
    niveles = [R.LIGHTF[cx + dx, yy, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1) for yy in (1, 2)]
    return R.brightness(np.array([max(niveles)]))[0] * 0.95


def recorte(sprite, base, alto, ancho, luz, adelante=0.0, desvio=0.0):
    base = np.asarray(base, float) + DERECHA * desvio
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    c = arr[py, px]
    efectivo = tt - adelante
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (c[..., 3] > 0) & (tt > 0) & (efectivo < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = c[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = efectivo[ver]


def sombra(base, ancho):
    cx, cy = proyectar(base)
    ex, _ = proyectar(np.asarray(base) + DERECHA * ancho * 0.6)
    rx = abs(ex - cx)
    ry = rx * 0.28 if ESCENA in ("roja", "verde") else rx * 0.6
    if rx < 1:
        return
    j0, j1 = max(int(cy - ry) - 1, 0), min(int(cy + ry) + 2, H2)
    i0, i1 = max(int(cx - rx) - 1, 0), min(int(cx + rx) + 2, W2)
    if i0 >= i1 or j0 >= j1:
        return
    jj_, ii_ = np.ogrid[j0:j1, i0:i1]
    m = ((ii_ - cx) / rx) ** 2 + ((jj_ - cy) / max(ry, 1)) ** 2 <= 1
    img[j0:j1, i0:i1][m] *= 0.62


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


ALTO, ANCHO = 1.85, 0.925
skins = [Image.open(os.path.join(TEX, f"entity/jugador/skin_{i}.png")).convert("RGBA") for i in range(48)]
guardias = {nm: Image.open(os.path.join(TEX, f"entity/guardia/{nm}.png")).convert("RGBA")
            for nm in ("sargento", "comandante")}
armas = {nm: Image.open(os.path.join(TEX, f"item/{nm}.png")).convert("RGBA").rotate(45, expand=True)
         for nm in ("rifle", "escopeta")}

azar = random.Random(11)
personas = []                                         # (x, z mundo, sprite)
ELIMINADO = (1009.5, 268.0)                           # al que el Vigía acaba de ver moverse (escena roja)
if ESCENA in ("roja", "verde"):
    # la gente entre z 250 y 288, de espaldas a la cámara; con la verde, más desparramada (van avanzando)
    z0 = 249.0 if ESCENA == "verde" else 251.0
    while len(personas) < 46:
        x, z = azar.uniform(976.0, 1025.0), azar.uniform(z0, 288.5)
        if (x - 1000.6) ** 2 + (z - 244.0) ** 2 < 40:
            continue
        if all((x - a) ** 2 + (z - b) ** 2 > (2.2 if ESCENA == "verde" else 1.5) for a, b, _ in personas):
            personas.append((x, z, espalda(skins[azar.randrange(48)])))
    if ESCENA == "roja":
        personas.append((ELIMINADO[0], ELIMINADO[1], espalda(skins[5])))
    # algunos ya pasaron la meta (de frente: festejan y miran a los que vienen)
    for _ in range(9):
        x, z = azar.uniform(976.0, 1024.0), azar.uniform(294.0, 297.5)
        if not (989.0 < x < 1010.0 and z > 297.0):
            personas.append((x, z, frente(skins[azar.randrange(48)])))
elif ESCENA == "reglas":
    # todos esperando detrás de la línea de salida (z 1..8), menos donde está el podio
    while len(personas) < 115:
        x, z = azar.uniform(952.0, 1036.5), azar.uniform(1.2, 8.6)
        if all((x - a) ** 2 + (z - b) ** 2 > 1.4 for a, b, _ in personas):
            personas.append((x, z, frente(skins[azar.randrange(48)])))      # miran al semáforo (hacia acá)
    personas.append((1042.5, 4.5, frente(guardias["comandante"])))
    for gx, gz in ((952.5, 75.5), (1047.5, 75.5), (952.5, 175.5), (1047.5, 175.5)):
        personas.append((gx, gz, frente(guardias["sargento"])))
else:
    # el juego en marcha: la gente desparramada por los primeros 150 bloques, más apretada atrás
    while len(personas) < 120:
        x = azar.uniform(952.0, 1047.0)
        z = 11.0 + 150.0 * azar.random() ** 1.6
        if all((x - a) ** 2 + (z - b) ** 2 > 2.0 for a, b, _ in personas):
            personas.append((x, z, espalda(skins[azar.randrange(48)])))
    personas.append((1042.5, 4.5, frente(guardias["comandante"])))     # en su podio (piso en y=103)
    for gx, gz in ((952.5, 75.5), (1047.5, 75.5), (952.5, 175.5), (1047.5, 175.5)):
        personas.append((gx, gz, frente(guardias["sargento"])))

personas.sort(key=lambda p: -np.linalg.norm(L(p[0], 100.0, p[1]) - POS))
for x, z, sprite in personas:
    y = 103.0 if (x, z) == (1042.5, 4.5) else 100.0
    base = L(x, y, z)
    sombra(base, ANCHO)
for x, z, sprite in personas:
    y = 103.0 if (x, z) == (1042.5, 4.5) else 100.0
    base = L(x, y, z)
    luz = luz_en(base)
    recorte(sprite, base, ALTO, ANCHO, luz)
    if ESCENA in ("arena", "reglas") and (x, z) in ((1042.5, 4.5), (952.5, 75.5), (1047.5, 75.5), (952.5, 175.5), (1047.5, 175.5)):
        arma = armas["escopeta" if (x, z) == (1042.5, 4.5) else "rifle"]
        recorte(arma, base + np.array([0, -0.65, 0]), 1.25, 1.25, luz, adelante=0.3, desvio=-0.42)

final = Image.fromarray((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8))
if SS > 1:
    final = final.resize((W, H), Image.LANCZOS)
dib = ImageDraw.Draw(final, "RGBA")

# ------------------------------------------------------------------ el rayo del Vigía (puntos rojos, como en el juego)
if ESCENA == "roja":
    visor = L(1000.0, 130.5, 297.6)
    hasta = L(ELIMINADO[0], 101.0, ELIMINADO[1])
    pasos_r = int(np.linalg.norm(hasta - visor) / 1.5)
    for i in range(pasos_r + 1):
        p_ = visor + (hasta - visor) * (i / pasos_r)
        dist = float(np.linalg.norm(p_ - POS))
        if (p_ - POS) @ f <= 0.5:
            continue
        cx, cy = proyectar(p_)
        r_ = max(1.5, 2.2 * H2 / (2 * th) / dist * 0.12) / SS
        cx, cy = cx / SS, cy / SS
        dib.rectangle((cx - r_, cy - r_, cx + r_, cy + r_), fill=(255, 40, 30, 235))


def texto_con_sombra(xy, texto, letra, color, desplazar):
    dib.text((xy[0] + desplazar, xy[1] + desplazar), texto, font=letra, fill=(int(color[0] * 0.25), int(color[1] * 0.25), int(color[2] * 0.25)))
    dib.text(xy, texto, font=letra, fill=color)


# ------------------------------------------------------------------ la barra de arriba (como la de los jefes)
if ESCENA == "roja":
    nombre_barra, progreso, color = "Luz verde, luz roja · 1:12 · faltan llegar 31", 0.40, (232, 52, 52)
elif ESCENA == "verde":
    nombre_barra, progreso, color = "Luz verde, luz roja · 1:16 · faltan llegar 33", 0.42, (88, 214, 64)
elif ESCENA == "reglas":
    nombre_barra, progreso, color = "Luz verde, luz roja", 1.0, (236, 236, 236)
else:
    nombre_barra, progreso, color = "Luz verde, luz roja · 2:21 · faltan llegar 124", 0.78, (88, 214, 64)
letra_b = ImageFont.truetype(FUENTE, max(12, H // 46))
ancho_b = int(W * 0.30)
x0 = (W - ancho_b) // 2
y0 = int(H * 0.035)
an_t = dib.textlength(nombre_barra, font=letra_b)
texto_con_sombra(((W - an_t) / 2, y0), nombre_barra, letra_b, (255, 255, 255), max(1, H // 400))
yb = y0 + int(letra_b.size * 1.35)
alto_b = max(5, H // 110)
dib.rectangle((x0 - 1, yb - 1, x0 + ancho_b + 1, yb + alto_b + 1), fill=(0, 0, 0, 200))
dib.rectangle((x0, yb, x0 + ancho_b, yb + alto_b), fill=(int(color[0] * 0.35), int(color[1] * 0.35), int(color[2] * 0.35), 255))
dib.rectangle((x0, yb, x0 + int(ancho_b * progreso), yb + alto_b), fill=color + (255,))

# ------------------------------------------------------------------ el cartel del centro
if ESCENA in ("roja", "verde"):
    letra_t = ImageFont.truetype(FUENTE_NEGRITA, max(28, H // 9))
    cartel = "LUZ ROJA" if ESCENA == "roja" else "LUZ VERDE"
    an_c = dib.textlength(cartel, font=letra_t)
    texto_con_sombra(((W - an_c) / 2, H * 0.60), cartel, letra_t, (255, 85, 85) if ESCENA == "roja" else (85, 255, 85),
                     max(2, H // 160))
# ------------------------------------------------------------------ el chat, como se vería en el juego
if ESCENA == "reglas":
    letra = ImageFont.truetype(FUENTE, max(11, H // 56))
    frases = ["Al fondo está el Vigía. Mientras esté de espaldas, la luz está en verde: pueden avanzar hacia la meta.",
              "Cuando se dé vuelta, la luz se pone en rojo: tienen que quedarse completamente quietos.",
              "Si el Vigía los ve moverse con la luz roja, quedarán eliminados.",
              "Y tengan cuidado: nadie dijo que no se pudiera empujar."]
    alto_linea = int(letra.size * 1.45)
    nombre = "♚ Comandante"
    ancho_max = int(W * 0.50)
    lineas = []
    for frase in frases:
        actual, primera = "", True
        for palabra in frase.split():
            prueba = (actual + " " + palabra).strip()
            extra = dib.textlength("<" + nombre + "> ", font=letra) if primera else 0
            if dib.textlength(prueba, font=letra) + extra > ancho_max and actual:
                lineas.append((primera, actual))
                actual, primera = palabra, False
            else:
                actual = prueba
        lineas.append((primera, actual))
    y = H - 14 - alto_linea * len(lineas)
    for primera, texto in lineas:
        dib.rectangle((8, y, 8 + ancho_max + 16, y + alto_linea), fill=(0, 0, 0, 120))
        x = 14
        if primera:
            for parte, color_p in (("<", (255, 255, 255)), (nombre, (255, 170, 0)), ("> ", (255, 255, 255))):
                dib.text((x, y + 2), parte, font=letra, fill=color_p)
                x += dib.textlength(parte, font=letra)
        dib.text((x, y + 2), texto, font=letra, fill=(255, 255, 85))
        y += alto_linea
    cx, cy = proyectar(L(1042.5, 103.0 + ALTO + 0.5, 4.5))
    cx, cy = cx / SS, cy / SS
    letra2 = ImageFont.truetype(FUENTE, max(11, H // 58))
    an = dib.textlength(nombre, font=letra2)
    dib.rectangle((cx - an / 2 - 3, cy - letra2.size * 0.7, cx + an / 2 + 3, cy + letra2.size * 0.75), fill=(0, 0, 0, 90))
    dib.text((cx - an / 2, cy - letra2.size * 0.62), nombre, font=letra2, fill=(255, 170, 0))
final.save(salida, optimize=True)
print("guardado", salida, final.size)
