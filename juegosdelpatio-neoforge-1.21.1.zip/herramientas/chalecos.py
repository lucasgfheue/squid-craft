#!/usr/bin/env python3
"""Los chalecos de Las escondidas: el amarillo con franjas negras de los que buscan (con un ojo en la espalda) y el
violeta con franjas lilas de los que se esconden (con una luna). Y los de Fuego cruzado y La batalla: el rojo oscuro
(con un círculo atrás) y el azul oscuro (con un triángulo), los dos con franjas negras. Genera las texturas de la armadura (capa 1, solo el
torso: no tienen mangas) y los íconos.

Uso: python3 chalecos.py <carpeta assets/juegosdelpatio/textures>
"""
import os
import sys

from PIL import Image

CHALECOS = {
    "chaleco_buscador": {"base": (240, 196, 34), "sombra": (206, 160, 20), "franja": (28, 26, 30),
                         "simbolo": (28, 26, 30), "fondo_simbolo": None,
                         "forma": ["..XXXX..",
                                   ".X.XX.X.",
                                   "..XXXX.."]},                      # un ojo
    "chaleco_escondido": {"base": (118, 58, 168), "sombra": (92, 42, 136), "franja": (204, 176, 238),
                          "simbolo": (244, 242, 250), "fondo_simbolo": None,
                          "forma": ["...XX...",
                                    "..X.....",
                                    "..X.....",
                                    "...XX..."]},                     # una luna
    # El quemado y La batalla: los dos equipos
    "chaleco_rojo": {"base": (142, 26, 24), "sombra": (104, 16, 16), "franja": (38, 34, 38),
                     "simbolo": (38, 34, 38), "fondo_simbolo": None,
                     "forma": ["..XXXX..",
                               ".X....X.",
                               ".X....X.",
                               "..XXXX.."]},                          # un círculo
    "chaleco_azul": {"base": (34, 58, 140), "sombra": (22, 40, 104), "franja": (38, 34, 38),
                     "simbolo": (38, 34, 38), "fondo_simbolo": None,
                     "forma": ["...XX...",
                               "..X..X..",
                               ".X....X.",
                               ".XXXXXX."]},                          # un triángulo
}
FRANJAS = (5, 8)                     # filas de las franjas (de 12)


def pintar_cara(img, x0, y0, ancho, alto, c, frente=False, espalda=False):
    for dy in range(alto):
        for dx in range(ancho):
            color = c["sombra"] if dy == alto - 1 or dx in (0, ancho - 1) and ancho > 4 else c["base"]
            if dy in FRANJAS:
                color = c["franja"]
            img.putpixel((x0 + dx, y0 + dy), color + (255,))
    if frente:                                                    # escote en V y el cierre
        for (dx, dy) in ((3, 0), (4, 0)):
            img.putpixel((x0 + dx, y0 + dy), (0, 0, 0, 0))
        for dy in range(1, alto - 1):
            if dy not in FRANJAS:
                img.putpixel((x0 + 3, y0 + dy), c["sombra"] + (255,))
    if espalda:
        for fy, fila in enumerate(c["forma"]):
            for fx, ch in enumerate(fila):
                if ch == "X":
                    img.putpixel((x0 + fx, y0 + 1 + fy), c["simbolo"] + (255,))


def capa(c):
    img = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    pintar_cara(img, 20, 20, 8, 12, c, frente=True)               # frente
    pintar_cara(img, 32, 20, 8, 12, c, espalda=True)              # espalda
    pintar_cara(img, 16, 20, 4, 12, c)                            # costado derecho
    pintar_cara(img, 28, 20, 4, 12, c)                            # costado izquierdo
    for dx in range(8):                                           # arriba (hombros) y abajo
        for dy in range(4):
            img.putpixel((20 + dx, 16 + dy), c["base"] + (255,))
            img.putpixel((28 + dx, 16 + dy), c["sombra"] + (255,))
    return img


ICONO = ["................",
         "....XX....XX....",
         "...XXXO..OXXX...",
         "...XXXXOOXXXX...",
         "..XXXXXXXXXXXX..",
         "..XXXXXXXXXXXX..",
         "..XXXXXXXXXXXX..",
         "..SSSSSSSSSSSS..",
         "..XXXXXXXXXXXX..",
         "..XXXXXXXXXXXX..",
         "..SSSSSSSSSSSS..",
         "..XXXXXXXXXXXX..",
         "..XXXXXXXXXXXX..",
         "..XXXXXXXXXXXX..",
         "...XXXXXXXXXX...",
         "................"]


def icono(c):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, fila in enumerate(ICONO):
        for x, ch in enumerate(fila):
            if ch == "X":
                img.putpixel((x, y), (c["sombra"] if x in (2, 13) or y == 14 else c["base"]) + (255,))
            elif ch == "S":
                img.putpixel((x, y), c["franja"] + (255,))
            elif ch == "O":
                img.putpixel((x, y), (40, 36, 44, 255))
    borde = img.copy()                                            # un contorno oscuro
    for y in range(16):
        for x in range(16):
            if img.getpixel((x, y))[3] == 0 and any(0 <= x + dx < 16 and 0 <= y + dy < 16 and img.getpixel((x + dx, y + dy))[3]
                                                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                borde.putpixel((x, y), (22, 20, 26, 255))
    return borde


if __name__ == "__main__":
    texturas = sys.argv[1]
    for nombre, c in CHALECOS.items():
        capa(c).save(os.path.join(texturas, "models/armor", f"{nombre}_layer_1.png"))
        icono(c).save(os.path.join(texturas, "item", f"{nombre}.png"))
        print("listo", nombre)
