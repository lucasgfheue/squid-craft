#!/usr/bin/env python3
"""Render aproximado (estilo Minecraft) de la plantilla del dormitorio.

Trazado de rayos por vóxeles con numpy, luz de bloques propagada como en el juego,
iluminación suave con oclusión ambiental y texturas procedurales simples.

Uso: python3 render.py <bloques.pkl> <vista> <salida.png> <ancho> <alto> <supermuestreo>
Vistas: corte, puertas, banos, comedor, entrada, alto, literas
"""
import math
import pickle
import sys
from collections import deque

import numpy as np
from PIL import Image

data = pickle.load(open(sys.argv[1], "rb"))
SX, SY, SZ = data["size"]
OFF = data.get("offset", 0)
BLOCKS = data["blocks"]
DIMS = np.array([SX, SY, SZ])

# ------------------------------------------------------------------ geometría de cada bloque
EMIT = {"sea_lantern": 15, "waxed_copper_bulb": 15, "lantern": 15, "soul_lantern": 10, "portal_juego": 12}


def parse(s):
    name = s.split(":", 1)[1]
    props = {}
    if "[" in name:
        name, rest = name.split("[", 1)
        props = dict(kv.split("=") for kv in rest[:-1].split(","))
    return name, props


def P(v):
    return v / 16.0


def boxes_for(name, p):
    """Lista de cajas (min, max, patrón) en coordenadas locales; None = bloque completo; [] = invisible."""
    if name == "white_bed":
        return [((0, 0, 0), (1, P(9), 1), None)]
    if name in ("iron_bars",) or name.endswith("glass_pane"):
        pat = "bars" if name == "iron_bars" else "pane"
        n, s, e, w = (p.get(k) == "true" for k in ("north", "south", "east", "west"))
        out = []
        if n or s:
            out.append(((P(7), 0, 0 if n else P(7)), (P(9), 1, 1 if s else P(9)), pat))
        if e or w:
            out.append(((0 if w else P(7), 0, P(7)), (1 if e else P(9), 1, P(9)), pat))
        if not out:
            out.append(((P(7), 0, P(7)), (P(9), 1, P(9)), None))
        return out
    if name == "chain":
        return [((P(6.5), 0, P(6.5)), (P(9.5), 1, P(9.5)), None)]
    if name in ("barrier", "light"):
        return []
    if name in ("lantern", "soul_lantern"):
        if p.get("hanging") == "true":
            return [((P(5), P(1), P(5)), (P(11), P(10), P(11)), None)]
        return [((P(5), 0, P(5)), (P(11), P(9), P(11)), None)]
    if name.endswith("_slab"):
        t = p.get("type")
        if t == "top":
            return [((0, 0.5, 0), (1, 1, 1), None)]
        if t == "bottom":
            return [((0, 0, 0), (1, 0.5, 1), None)]
        return None
    if name.endswith("_stairs"):
        f = p.get("facing")
        arriba = p.get("half") == "top"                 # escalón dado vuelta
        y0, y1 = (0, 0.5) if arriba else (0.5, 1)
        back = {"west": ((0, y0, 0), (0.5, y1, 1)), "east": ((0.5, y0, 0), (1, y1, 1)),
                "north": ((0, y0, 0), (1, y1, 0.5)), "south": ((0, y0, 0.5), (1, y1, 1))}[f]
        losa = ((0, 0.5, 0), (1, 1, 1)) if arriba else ((0, 0, 0), (1, 0.5, 1))
        return [(losa[0], losa[1], None), (back[0], back[1], None)]
    if name.endswith("_trapdoor"):
        if p.get("open") == "true":
            f = p.get("facing")
            return [{"east": ((0, 0, 0), (P(3), 1, 1)), "west": ((P(13), 0, 0), (1, 1, 1)),
                     "south": ((0, 0, 0), (1, 1, P(3))), "north": ((0, 0, P(13)), (1, 1, 1))}[f] + (None,)]
        return [((0, 0, 0), (1, P(3), 1), None)] if p.get("half") == "bottom" else [((0, P(13), 0), (1, 1, 1), None)]
    if name.endswith("_door"):
        f = p.get("facing")
        return [{"east": ((0, 0, 0), (P(3), 1, 1)), "west": ((P(13), 0, 0), (1, 1, 1)),
                 "south": ((0, 0, 0), (1, 1, P(3))), "north": ((0, 0, P(13)), (1, 1, 1))}[f] + (None,)]
    if name == "lever":
        return []
    if name == "silla":                                  # como SillaBlock / models/block/silla.json (hasta 16 px de alto)
        f = p.get("facing", "north")

        def girar(x0, y0, z0, x1, y1, z1):
            y1 = min(y1, 16)
            if f == "east":
                a, b = (16 - z1, y0, x0), (16 - z0, y1, x1)
            elif f == "south":
                a, b = (16 - x1, y0, 16 - z1), (16 - x0, y1, 16 - z0)
            elif f == "west":
                a, b = (z0, y0, 16 - x1), (z1, y1, 16 - x0)
            else:
                a, b = (x0, y0, z0), (x1, y1, z1)
            return (tuple(P(v) for v in a), tuple(P(v) for v in b), None)
        partes = [(2, 0, 2, 4, 7, 4), (12, 0, 2, 14, 7, 4), (2, 0, 12, 4, 7, 14), (12, 0, 12, 14, 7, 14),
                  (1, 7, 1, 15, 9, 15), (2, 9, 13, 4, 16, 15), (12, 9, 13, 14, 16, 15), (4, 11, 13.5, 12, 16, 14.5)]
        return [girar(*q) for q in partes]
    if name == "lightning_rod":
        f = p.get("facing")
        if f in ("north", "south"):
            return [((P(6), P(6), 0), (P(10), P(10), 1), None)]
        if f in ("east", "west"):
            return [((0, P(6), P(6)), (1, P(10), P(10)), None)]
        return [((P(6), 0, P(6)), (P(10), 1, P(10)), None)]
    if name.endswith("_candle"):
        return [((P(5), 0, P(5)), (P(11), P(6), P(11)), None)]
    if name == "cake":
        return [((P(1), 0, P(1)), (P(15), P(8), P(15)), None)]
    if name.endswith("_wall_sign"):
        f = p.get("facing")
        y0, y1 = P(4.5), P(12.5)
        return [{"south": ((0, y0, 0), (1, y1, P(2))), "north": ((0, y0, P(14)), (1, y1, 1)),
                 "east": ((0, y0, 0), (P(2), y1, 1)), "west": ((P(14), y0, 0), (1, y1, 1))}[f] + (None,)]
    return None


kinds = [("air", {}, [])]
kind_index = {}


def kind_of(state):
    if state not in kind_index:
        name, props = parse(state)
        kind_index[state] = len(kinds)
        kinds.append((name, props, boxes_for(name, props)))
    return kind_index[state]


def build_grid(cut=None):
    g = np.zeros((SX, SY, SZ), np.int16)
    for (x, y, z), st in BLOCKS.items():
        if cut and cut(x, y, z):
            continue
        g[x, y, z] = kind_of(st)
    return g


FULL_GRID = build_grid()
NK = len(kinds)
is_full = np.array([k[2] is None for k in kinds])
has_boxes = np.array([bool(k[2]) for k in kinds])
TRANSPARENT_FULL = {"light_gray_stained_glass", "glass"}
opaque_of = np.array([k[2] is None and k[0] not in TRANSPARENT_FULL for k in kinds])


def emit_level(name, props):
    if name.endswith("_candle") and props.get("lit") == "true":
        return 3 * int(props.get("candles", 1))
    if name == "waxed_copper_bulb" and props.get("lit") != "true":
        return 0
    if name == "light":
        return int(props.get("level", 15))
    return EMIT.get(name, 0)


emit_of = np.array([emit_level(k[0], k[1]) for k in kinds])

# ------------------------------------------------------------------ luz de bloques (BFS)
light = np.zeros((SX, SY, SZ), np.int8)
q = deque()
for (x, y, z), st in BLOCKS.items():
    e = emit_of[kind_index[st]]
    if e:
        light[x, y, z] = e
        q.append((x, y, z))
opaque_full = opaque_of[FULL_GRID]
while q:
    x, y, z = q.popleft()
    l = light[x, y, z] - 1
    if l <= 0:
        continue
    for nx, ny, nz in ((x + 1, y, z), (x - 1, y, z), (x, y + 1, z), (x, y - 1, z), (x, y, z + 1), (x, y, z - 1)):
        if 0 <= nx < SX and 0 <= ny < SY and 0 <= nz < SZ and not opaque_full[nx, ny, nz] and light[nx, ny, nz] < l:
            light[nx, ny, nz] = l
            q.append((nx, ny, nz))
LIGHTF = light.astype(np.float32)


def norm(v):
    v = np.asarray(v, np.float64)
    return v / np.linalg.norm(v, axis=-1, keepdims=True)


def h32(*arrs):
    h = np.full(arrs[0].shape, 2166136261, np.int64)
    for a in arrs:
        h = ((h ^ (a.astype(np.int64) & 0xFFFFFFFF)) * 16777619) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * 1274126177) & 0xFFFFFFFF
    h ^= h >> 16
    return (h & 0xFFFF) / 65535.0


def brightness(level, ambient=0.1, gamma=0.6):
    f = level / 15.0
    b = f / (4.0 - 3.0 * f)
    b = ambient + (1.0 - ambient) * b
    out = np.stack([b, b * ((b * 0.6 + 0.4) * 0.6 + 0.4), b * (b * b * 0.6 + 0.4)], -1)
    out = out * 0.96 + 0.03
    ng = 1.0 - (1.0 - np.clip(out, 0, 1)) ** 4
    return np.clip(out + gamma * (ng - out), 0, 1)


# ------------------------------------------------------------------ trazado
def trace(O, D, grid):
    N = len(O)
    D = np.where(np.abs(D) < 1e-9, 1e-9, D)
    inv = 1.0 / D
    t1 = (0.0 - O) * inv
    t2 = (DIMS - O) * inv
    tmin_ax = np.minimum(t1, t2)
    tmin = np.max(tmin_ax, 1)
    tmax = np.min(np.maximum(t1, t2), 1)
    entry_axis = np.argmax(tmin_ax, 1)
    inside0 = tmin < 0
    tmin = np.maximum(tmin, 0.0)
    valid = tmax > tmin

    hit = np.zeros(N, bool)
    ht = np.full(N, np.inf)
    hn = np.zeros((N, 3), np.int64)
    hcell = np.zeros((N, 3), np.int64)
    hkind = np.zeros(N, np.int64)

    idx = np.nonzero(valid)[0]
    o, d, iv = O[idx], D[idx], inv[idx]
    tc = tmin[idx] + 1e-7
    Pt = o + d * tc[:, None]
    cell = np.clip(np.floor(Pt).astype(np.int64), 0, DIMS - 1)
    step = np.where(d > 0, 1, -1)
    tdel = np.abs(iv)
    tmx = tc[:, None] + ((cell + (step > 0)) - Pt) * iv
    last = np.where(inside0[idx], -1, entry_axis[idx])

    for _ in range(500):
        if len(idx) == 0:
            break
        rows = np.arange(len(idx))
        k = grid[cell[:, 0], cell[:, 1], cell[:, 2]].astype(np.int64)
        done = np.zeros(len(idx), bool)

        m = is_full[k] & (k != 0) & (last >= 0)
        if m.any():
            ax = last[m]
            gi = idx[m]
            hit[gi] = True
            ht[gi] = tc[m]
            nn = np.zeros((len(gi), 3), np.int64)
            nn[np.arange(len(gi)), ax] = -step[m, ax]
            hn[gi] = nn
            hcell[gi] = cell[m]
            hkind[gi] = k[m]
            done |= m

        pm = has_boxes[k]
        if pm.any():
            for kk in np.unique(k[pm]):
                sel = np.nonzero(k == kk)[0]
                c = cell[sel].astype(np.float64)
                om, dm, ivm = o[sel], d[sel], iv[sel]
                best = np.full(len(sel), np.inf)
                bax = np.zeros(len(sel), np.int64)
                for lo, hi, pat in kinds[kk][2]:
                    a1 = (c + np.array(lo) - om) * ivm
                    a2 = (c + np.array(hi) - om) * ivm
                    amin = np.minimum(a1, a2)
                    tn = np.max(amin, 1)
                    tf = np.min(np.maximum(a1, a2), 1)
                    ok = (tn <= tf) & (tf > 0)
                    axn = np.argmax(amin, 1)
                    if pat:
                        ph = om + dm * tn[:, None] - c
                        thin = 0 if (hi[0] - lo[0]) < 0.2 else 2
                        u = (ph[:, 2] if thin == 0 else ph[:, 0]) * 16
                        v = ph[:, 1] * 16
                        if pat == "bars":
                            solid = (np.mod(u, 4.0) < 1.7) | (v < 1.2) | (v > 14.8)
                        else:
                            solid = (u < 0.8) | (u > 15.2) | (v < 0.8) | (v > 15.2)
                        ok &= solid | (axn != thin)
                    better = ok & (tn < best)
                    best[better] = tn[better]
                    bax[better] = axn[better]
                got = np.isfinite(best)
                if got.any():
                    s2 = sel[got]
                    gi = idx[s2]
                    hit[gi] = True
                    ht[gi] = best[got]
                    nn = np.zeros((len(gi), 3), np.int64)
                    nn[np.arange(len(gi)), bax[got]] = -step[s2, bax[got]]
                    hn[gi] = nn
                    hcell[gi] = cell[s2]
                    hkind[gi] = kk
                    done[s2] = True

        ax = np.argmin(tmx, 1)
        tc = tmx[rows, ax]
        cell[rows, ax] += step[rows, ax]
        tmx[rows, ax] += tdel[rows, ax]
        last = ax
        inb = np.all((cell >= 0) & (cell < DIMS), 1)
        keep = ~done & inb
        idx, o, d, iv, tc, cell, step, tdel, tmx, last = (
            idx[keep], o[keep], d[keep], iv[keep], tc[keep], cell[keep], step[keep], tdel[keep], tmx[keep], last[keep])
    return hit, ht, hn, hcell, hkind


# ------------------------------------------------------------------ materiales
BASE = {
    "smooth_stone": (0.62, 0.62, 0.62), "polished_andesite": (0.53, 0.55, 0.55),
    "polished_deepslate": (0.29, 0.29, 0.31), "deepslate_tiles": (0.21, 0.21, 0.23),
    "tuff_bricks": (0.40, 0.42, 0.37), "polished_tuff": (0.38, 0.41, 0.38),
    "chiseled_tuff_bricks": (0.37, 0.39, 0.34), "iron_block": (0.85, 0.85, 0.86),
    "polished_blackstone": (0.21, 0.19, 0.23), "sea_lantern": (0.78, 0.89, 0.85),
    "waxed_copper_bulb": (0.80, 0.47, 0.30), "waxed_copper_grate": (0.70, 0.41, 0.26),
    "white_bed": (0.90, 0.91, 0.91), "iron_bars": (0.43, 0.43, 0.45), "chain": (0.22, 0.24, 0.28),
    "lantern": (1.0, 0.80, 0.42),
    "white_concrete": (0.81, 0.83, 0.84), "black_concrete": (0.04, 0.05, 0.07),
    "red_concrete": (0.56, 0.13, 0.13), "orange_concrete": (0.88, 0.38, 0.02),
    "yellow_concrete": (0.94, 0.69, 0.08), "lime_concrete": (0.37, 0.66, 0.09),
    "green_concrete": (0.29, 0.36, 0.14), "cyan_concrete": (0.08, 0.47, 0.54),
    "blue_concrete": (0.17, 0.18, 0.56), "purple_concrete": (0.39, 0.12, 0.61),
    "light_blue_concrete": (0.14, 0.54, 0.78), "light_gray_concrete": (0.49, 0.49, 0.45),
    "quartz_stairs": (0.92, 0.90, 0.86), "smooth_quartz": (0.92, 0.90, 0.86),
    "smooth_quartz_slab": (0.92, 0.90, 0.86), "quartz_bricks": (0.91, 0.89, 0.85),
    "light_blue_terracotta": (0.45, 0.44, 0.55), "iron_trapdoor": (0.80, 0.80, 0.81),
    "birch_door": (0.86, 0.79, 0.60), "water_cauldron": (0.25, 0.25, 0.27),
    "light_gray_stained_glass": (0.55, 0.60, 0.66), "lightning_rod": (0.80, 0.48, 0.33),
    "white_stained_glass_pane": (0.95, 0.96, 0.97), "spruce_planks": (0.45, 0.33, 0.20),
    "spruce_slab": (0.45, 0.33, 0.20), "dark_oak_planks": (0.26, 0.17, 0.08), "dark_oak_slab": (0.26, 0.17, 0.08),
    "white_candle": (0.95, 0.93, 0.85), "smoker": (0.36, 0.34, 0.31), "barrel": (0.49, 0.36, 0.21),
    "cake": (0.93, 0.91, 0.88), "spruce_wall_sign": (0.42, 0.31, 0.19),
    "deepslate_tile_stairs": (0.21, 0.21, 0.23),
    "soul_lantern": (0.45, 0.86, 0.96), "portal_juego": (0.40, 0.88, 0.88),
    "prismarine_bricks": (0.36, 0.60, 0.54),
    "green_terracotta": (0.30, 0.33, 0.17), "red_terracotta": (0.56, 0.24, 0.18),
    "gray_concrete": (0.21, 0.22, 0.24), "gold_block": (0.96, 0.80, 0.24),
    "pink_concrete": (0.84, 0.40, 0.56), "magenta_concrete": (0.66, 0.19, 0.62), "quartz_pillar": (0.92, 0.89, 0.84),
    "silla": (0.30, 0.21, 0.14),
}
EMISSIVE = {"sea_lantern", "waxed_copper_bulb", "lantern", "white_candle", "soul_lantern", "portal_juego"}


def shade_colors(kid, u, v, local, cell, n):
    N = len(kid)
    col = np.zeros((N, 3))
    tu = np.clip(np.floor(u * 16), 0, 15).astype(np.int64)
    tv = np.clip(np.floor(v * 16), 0, 15).astype(np.int64)
    face = np.argmax(np.abs(n), 1) * 2 + (n.sum(1) > 0)
    noise = h32(cell[:, 0], cell[:, 1], cell[:, 2], face, tu, tv) - 0.5
    for kidx in np.unique(kid):
        name, props, _ = kinds[kidx]
        m = kid == kidx
        c = np.tile(np.array(BASE.get(name, (1, 0, 1)), np.float64), (m.sum(), 1))
        a, b, nz = tu[m], tv[m], noise[m]
        nm = n[m]
        top = nm[:, 1] > 0
        border = (a == 0) | (a == 15) | (b == 0) | (b == 15)
        amp = 0.05
        if name == "smooth_stone":
            c[border] *= 0.83
            amp = 0.03
        elif name in ("polished_andesite", "polished_tuff", "polished_deepslate", "polished_blackstone"):
            c[border] *= 1.12
            amp = 0.06
        elif name in ("deepslate_tiles", "deepslate_tile_stairs"):
            c[(a % 8 == 0) | (b % 8 == 0)] *= 0.6
            amp = 0.08
        elif name in ("tuff_bricks", "quartz_bricks"):
            row = b // 4
            joint = ((a + (row % 2) * 4) % 8 == 0) | (b % 4 == 0)
            c[joint] *= 0.78 if name == "tuff_bricks" else 0.9
            amp = 0.07 if name == "tuff_bricks" else 0.02
        elif name == "chiseled_tuff_bricks":
            ring = ((a >= 3) & (a <= 12) & ((b == 3) | (b == 12))) | ((b >= 3) & (b <= 12) & ((a == 3) | (a == 12)))
            c[border | ring] *= 0.75
        elif name == "iron_block":
            c[border] *= 0.86
            c[b == 8] *= 0.9
            amp = 0.02
        elif name == "sea_lantern":
            c[(a % 5 == 0) | (b % 5 == 0)] *= 0.82
            amp = 0.04
        elif name == "waxed_copper_bulb":
            center = (a >= 4) & (a <= 11) & (b >= 4) & (b <= 11)
            if props.get("lit") == "false":
                c *= 0.55
                c[center] = (0.30, 0.20, 0.14)               # apagada
            else:
                c[center] = (1.0, 0.86, 0.58)
        elif name == "portal_juego":
            ola = np.sin((a + 2 * b) * 0.39 + cell[m][:, 1] * 2.5) * 0.5 + 0.5
            c = c * (0.75 + 0.4 * ola)[:, None]
            amp = 0.10
        elif name == "waxed_copper_grate":
            hole = ((a % 4) >= 1) & ((a % 4) <= 2) & ((b % 4) >= 1) & ((b % 4) <= 2)
            c[hole] = (0.10, 0.07, 0.06)
        elif name in ("spruce_planks", "spruce_slab", "dark_oak_planks", "dark_oak_slab"):
            c[(b % 4 == 0)] *= 0.8
            amp = 0.08
        elif name in ("smooth_quartz", "smooth_quartz_slab", "quartz_stairs"):
            c[border] *= 0.95
            amp = 0.015
        elif name == "water_cauldron":
            inner = top & (a >= 2) & (a <= 13) & (b >= 2) & (b <= 13)
            c[inner] = (0.20, 0.36, 0.78)
        elif name == "iron_trapdoor":
            c[((a % 5) == 2) & ((b % 5) == 2)] *= 0.5
        elif name == "birch_door":
            c[(a == 3) | (a == 12)] *= 0.85
        elif name == "light_gray_stained_glass":
            c[border] *= 0.75
            amp = 0.01
        elif name == "smoker":
            front = (nm[:, 2] > 0) & (a >= 4) & (a <= 11) & (b >= 3) & (b <= 7)
            c[front] = (0.12, 0.10, 0.09)
        elif name == "barrel":
            c[(b == 3) | (b == 12)] *= 0.7
            c[top & (a >= 5) & (a <= 10) & (b >= 5) & (b <= 10)] *= 0.75
        elif name == "cake":
            dots = top & ((a + b * 3) % 7 == 0)
            c[dots] = (0.75, 0.10, 0.10)
            c[~top] = (0.86, 0.70, 0.52)
        elif name == "spruce_wall_sign":
            text = (np.abs(nm[:, 2]) + np.abs(nm[:, 0]) > 0) & (b >= 7) & (b <= 9) & (a >= 3) & (a <= 12)
            c[text] = (0.98, 0.98, 0.95)
        elif name == "white_candle":
            c[top & (a >= 6) & (a <= 9) & (b >= 6) & (b <= 9)] = (1.0, 0.75, 0.3)
        elif name == "white_bed":
            ly = local[m, 1]
            side = nm[:, 1] == 0
            c[side & (ly < 3 / 16)] = (0.62, 0.46, 0.28)
            facing = props.get("facing")
            lz, lx = local[m, 2], local[m, 0]
            along = {"south": lz, "north": 1 - lz, "east": lx, "west": 1 - lx}[facing]
            across = lx if facing in ("south", "north") else lz
            if props.get("part") == "head":
                pillow = top & (along > 0.6) & (across > 2 / 16) & (across < 14 / 16)
                c[pillow] = (0.98, 0.98, 0.98)
                edge = pillow & ((along < 0.64) | (across < 3 / 16) | (across > 13 / 16))
                c[edge] = (0.78, 0.79, 0.80)
            else:
                c[top & (along < 0.12)] *= 0.92
            amp = 0.025
        elif name == "silla":                            # asiento y respaldo de color; patas y parantes de madera
            ly = local[m, 1]
            colores = {"0": (0.62, 0.12, 0.12), "1": (0.95, 0.70, 0.10), "2": (0.38, 0.68, 0.10), "3": (0.16, 0.56, 0.80)}
            c[:] = colores.get(props.get("color", "0"), (0.62, 0.12, 0.12))
            lx, lz = local[m, 0], local[m, 2]
            f = props.get("facing", "north")
            atras = {"north": lz > 12.5 / 16, "south": lz < 3.5 / 16, "east": lx < 3.5 / 16, "west": lx > 12.5 / 16}[f]
            costado = {"north": (lx < 4 / 16) | (lx > 12 / 16), "south": (lx < 4 / 16) | (lx > 12 / 16),
                       "east": (lz < 4 / 16) | (lz > 12 / 16), "west": (lz < 4 / 16) | (lz > 12 / 16)}[f]
            madera = (ly < 7 / 16) | (atras & costado & (ly > 9 / 16))
            c[madera] = (0.30, 0.21, 0.14)
            amp = 0.03
        elif name.endswith("concrete"):
            amp = 0.015
        c *= (1 + amp * 2 * nz)[:, None]
        col[m] = c
    return np.clip(col, 0, 1)


def smooth_light(Pp, n, grid_opaque):
    N = len(Pp)
    A = np.floor(Pp + n * 0.02).astype(np.int64)
    axis = np.argmax(np.abs(n), 1)
    a1 = (axis + 1) % 3
    a2 = (axis + 2) % 3
    loc = Pp - A
    s1 = np.clip(loc[np.arange(N), a1], 0, 1)
    s2 = np.clip(loc[np.arange(N), a2], 0, 1)
    e = np.eye(3, dtype=np.int64)
    E1, E2 = e[a1], e[a2]

    def sample(c):
        inb = np.all((c >= 0) & (c < DIMS), 1)
        cc = np.clip(c, 0, DIMS - 1)
        L = np.where(inb, LIGHTF[cc[:, 0], cc[:, 1], cc[:, 2]], 0.0)
        op = np.where(inb, grid_opaque[cc[:, 0], cc[:, 1], cc[:, 2]], False)
        return L, op

    L0, _ = sample(A)
    acc_l = np.zeros(N)
    acc_ao = np.zeros(N)
    for d1 in (0, 1):
        for d2 in (0, 1):
            o1 = E1 * (2 * d1 - 1)
            o2 = E2 * (2 * d2 - 1)
            La, oa = sample(A + o1)
            Lb, ob = sample(A + o2)
            Lc, oc = sample(A + o1 + o2)
            oc = oc | (oa & ob)
            num = L0 + np.where(oa, 0, La) + np.where(ob, 0, Lb) + np.where(oc, 0, Lc)
            den = 1 + (~oa).astype(int) + (~ob).astype(int) + (~oc).astype(int)
            occ = oa.astype(int) + ob.astype(int) + oc.astype(int)
            w = (s1 if d1 else 1 - s1) * (s2 if d2 else 1 - s2)
            acc_l += w * num / den
            acc_ao += w * (1.0 - 0.17 * occ)
    return acc_l, acc_ao


def render(grid, O, D, W, H, bg_top=(0.07, 0.08, 0.11), bg_bot=(0.02, 0.02, 0.03)):
    hit, t, n, cell, kid = trace(O, D, grid)
    img = np.zeros((len(O), 3))
    jj = np.repeat(np.arange(H), W) / max(H - 1, 1)
    img[:] = np.array(bg_top)[None, :] * (1 - jj)[:, None] + np.array(bg_bot)[None, :] * jj[:, None]
    hi = np.nonzero(hit)[0]
    if len(hi):
        Pp = O[hi] + D[hi] * t[hi][:, None]
        nn = n[hi]
        cc = cell[hi]
        local = Pp - cc
        axis = np.argmax(np.abs(nn), 1)
        u = np.where(axis == 0, local[:, 2], local[:, 0])
        v = np.where(axis == 1, local[:, 2], local[:, 1])
        k = kid[hi]
        alb = shade_colors(k, u, v, local, cc, nn)
        face_shade = np.select([nn[:, 1] > 0, nn[:, 1] < 0, axis == 2], [1.0, 0.5, 0.8], 0.6)
        L, ao = smooth_light(Pp, nn, opaque_of[grid])
        col = alb * brightness(L) * (face_shade * ao)[:, None]
        em = np.array([kinds[kk][0] in EMISSIVE and emit_of[kk] > 0 for kk in k])
        col[em] = alb[em] * (0.92 + 0.08 * face_shade[em])[:, None]
        img[hi] = col
    return np.clip(img, 0, 1).reshape(H, W, 3)


def perspective(W, H, pos, target, vfov):
    pos = np.array(pos, np.float64)
    f = norm(np.array(target) - pos)
    r = norm(np.cross(f, [0, 1, 0]))
    up = np.cross(r, f)
    th = math.tan(math.radians(vfov) / 2)
    i, j = np.meshgrid(np.arange(W) + 0.5, np.arange(H) + 0.5)
    px = (2 * i / W - 1) * th * W / H
    py = (1 - 2 * j / H) * th
    d = f[None, None, :] + px[..., None] * r + py[..., None] * up
    return np.tile(pos, (W * H, 1)), norm(d).reshape(-1, 3)


def ortho(W, H, center, fwd, width):
    f = norm(fwd)
    r = norm(np.cross(f, [0, 1, 0]))
    up = np.cross(r, f)
    i, j = np.meshgrid(np.arange(W) + 0.5, np.arange(H) + 0.5)
    px = (i / W - 0.5) * width
    py = (0.5 - j / H) * width * H / W
    o = np.array(center)[None, None, :] - f * 300 + px[..., None] * r + py[..., None] * up
    return o.reshape(-1, 3), np.tile(f, (W * H, 1))


def save(img, path, ss):
    im = Image.fromarray((img * 255 + 0.5).astype(np.uint8))
    if ss > 1:
        im = im.resize((im.width // ss, im.height // ss), Image.LANCZOS)
    im.save(path, optimize=True)
    print("guardado", path, im.size)


if __name__ == "__main__":
    which, out = sys.argv[2], sys.argv[3]
    W, H, ss = int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6])
    W2, H2 = W * ss, H * ss
    Z = OFF                                            # z donde empieza el salón
    if which == "corte":
        def cut(x, y, z):
            if y >= 20:                                # techo del salón
                return True
            if 1 <= x <= 63 and Z + 1 <= z <= Z + 71 and y >= 12:
                return True
            if z < Z and (y >= 6 and x <= 24 or y >= 7 and x >= 40):
                return True                            # techos de baños y comedor
            if z == Z and y >= 3:                      # pared del portón
                return True
            if (x >= 64 or z == 0) and y >= 3:        # paredes cercanas a la cámara
                return True
            return False
        g = build_grid(cut)
        o, d = ortho(W2, H2, (SX / 2, 4, SZ / 2 - 4), (-0.36, -0.62, 0.70), 150)
        save(render(g, o, d, W2, H2), out, ss)
    else:
        views = {
            "puertas": ((32.5, 4.0, Z + 24.0), (32.5, 3.5, Z + 0.0), 70),
            "banos": ((17.5, 3.2, Z - 1.5), (8.0, 0.8, Z - 22.0), 74),
            "comedor": ((52.5, 4.4, Z - 1.5), (52.5, 0.3, Z - 22.0), 74),
            "entrada": ((32.5, 6.0, Z + 2.6), (32.5, 0.0, Z + 38.0), 70),
            "alto": ((61.5, 11.0, Z + 70.5), (20.0, 0.0, Z + 20.0), 72),
            "literas": ((4.5, 2.62, Z + 2.5), (4.5, 1.9, Z + 40.0), 72),
            "plaza": ((32.5, 7.5, Z + 67.0), (32.5, 1.5, Z + 22.0), 72),
        }
        pos, tgt, fov = views[which]
        o, d = perspective(W2, H2, pos, tgt, fov)
        save(render(FULL_GRID, o, d, W2, H2), out, ss)
