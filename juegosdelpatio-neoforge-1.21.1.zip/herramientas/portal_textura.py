#!/usr/bin/env python3
"""Textura animada del portal de los juegos: cortina de luz turquesa con destellos que suben.
Uso: python3 portal_textura.py <carpeta resources>"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image

RES = sys.argv[1]
N = 32                                                 # cuadros de la animación
rng = np.random.default_rng(5)
chispas = [(rng.uniform(0, 16), rng.uniform(0, 16), rng.uniform(0.5, 1.2), rng.uniform(0.6, 1.0)) for _ in range(9)]
hoja = np.zeros((16 * N, 16, 4), np.uint8)
yy, xx = np.mgrid[0:16, 0:16].astype(float)
for f in range(N):
    t = f / N
    fase = 2 * math.pi * t
    # ondas que se repiten cada 16 píxeles (así varios bloques juntos forman una sola cortina, sin costuras)
    k = 2 * math.pi / 16
    v = (0.45 + 0.22 * np.sin(k * (xx + 2 * yy) - 2 * fase) + 0.18 * np.sin(k * (2 * xx - yy) + fase)
         + 0.12 * np.sin(k * 3 * yy + 3 * fase))
    # destellos que suben y dan la vuelta (distancias "envueltas" para que tampoco haya costuras)
    for (cx, cy, vel, brillo) in chispas:
        py = (cy - t * 16 * vel) % 16
        dx = (xx - cx + 8) % 16 - 8
        dy = (yy - py + 8) % 16 - 8
        v += brillo * np.exp(-(dx * dx + dy * dy) / 1.4)
    v = np.clip(v, 0, 1.5) / 1.5
    oscuro = np.array([26, 128, 140], float)
    claro = np.array([214, 255, 250], float)
    rgb = oscuro[None, None, :] * (1 - v[..., None]) + claro[None, None, :] * v[..., None]
    alfa = 150 + 95 * v
    hoja[16 * f:16 * (f + 1), :, :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    hoja[16 * f:16 * (f + 1), :, 3] = np.clip(alfa, 0, 255).astype(np.uint8)
carpeta = os.path.join(RES, "assets/juegosdelpatio/textures/block")
os.makedirs(carpeta, exist_ok=True)
Image.fromarray(hoja, "RGBA").save(os.path.join(carpeta, "portal_juego.png"))
with open(os.path.join(carpeta, "portal_juego.png.mcmeta"), "w") as f:
    json.dump({"animation": {"frametime": 2, "interpolate": True}}, f, indent=2)
    f.write("\n")
# vista previa: 8 cuadros grandes
prev = Image.new("RGBA", (8 * 128 + 70, 140), (22, 24, 30, 255))
for i in range(8):
    cuadro = Image.fromarray(hoja[16 * i * 4:16 * (i * 4 + 1)], "RGBA").resize((128, 128), Image.NEAREST)
    prev.alpha_composite(cuadro, (10 + i * 138, 6))
prev.convert("RGB").save("/home/claude/trabajo/portal_textura.png")
print("textura del portal:", hoja.shape)
