#!/usr/bin/env python3
"""Genera la arena del juego 3, "Fuego cruzado" (fuego.nbt): dos torres altísimas, frente a frente.

Cada equipo juega arriba de su torre: la de los rojos (ladrillo del Nether, al norte) y la de los azules (prismarina
oscura, al sur), separadas por un abismo de 8 bloques que nadie puede saltar. Arriba no hay baranda, y el piso es de
ladrillo de piedra negra: las bolas de fuego lo queman (se vuelve magma) y, si vuelven a pegar ahí, lo rompen. El que
se cae por un agujero o por el borde se mata contra el suelo (59 bloques más abajo). Al norte, la entrada (el palco,
con baranda), con el podio del comandante y el portal de vuelta.

Coordenadas del mundo: la plantilla empieza en (5969, 40, -17). El suelo en y = 40; arriba de las torres, en y = 99.
  palco (la entrada)    x 5972..6028, z -16..1   (el podio en x 5996..6004, z -15..-12)
  torre roja            x 5986..6014, z 8..24
  el abismo del medio   z 25..32
  torre azul            x 5986..6014, z 33..49

Uso: python3 gen_fuego.py <salida.nbt> <bloques.pkl>
"""
import sys

from arenas_comun import PISO, Arena, S

OX, OY, OZ = 5969, 40, -17
SX, SY, SZ = 63, 78, 70                  # x 5969..6031, y 40..117, z -17..52
A = Arena(OX, OY, OZ, SX, SY, SZ)
SUELO = 40
PALCO = (5972, 6028, -16, 1)
TORRE_ROJA = (5986, 6014, 8, 24)
TORRE_AZUL = (5986, 6014, 33, 49)
PIEDRA = S("polished_blackstone_bricks")
CALIDA = S("shroomlight")
FRIA = S("sea_lantern")

# =================================================================== el suelo, allá abajo: piedra negra y brasas
for x in range(OX, OX + SX):
    for z in range(OZ, OZ + SZ):
        brasa = (x * 7 + z * 13) % 23 == 0
        A.put(x, SUELO, z, S("magma_block") if brasa else CALIDA if x % 8 == 4 and z % 8 == 4 else S("blackstone"))

# =================================================================== las torres (huecas: solo las paredes)
A.torre(*PALCO[:2], *PALCO[2:], SUELO + 1, PISO - 1, S("deepslate_tiles"), bandas=(60, 80),
        banda=S("polished_deepslate"), ventanas=CALIDA, cada=6, alturas=(52, 72, 92))
A.torre(*TORRE_ROJA[:2], *TORRE_ROJA[2:], SUELO + 1, PISO - 1, S("red_nether_bricks"), bandas=(58, 59, 78, 79, 96),
        banda=S("nether_bricks"), ventanas=CALIDA, cada=4, alturas=(50, 68, 88))
A.torre(*TORRE_AZUL[:2], *TORRE_AZUL[2:], SUELO + 1, PISO - 1, S("dark_prismarine"), bandas=(58, 59, 78, 79, 96),
        banda=S("polished_deepslate"), ventanas=FRIA, cada=4, alturas=(50, 68, 88))


def techo(caja, borde, adentro):
    """Arriba de una torre: el borde del color del equipo y el piso de adentro."""
    x0, x1, z0, z1 = caja
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            A.put(x, PISO, z, borde if x in (x0, x1) or z in (z0, z1) else adentro)


techo(TORRE_ROJA, S("red_nether_bricks"), PIEDRA)
techo(TORRE_AZUL, S("dark_prismarine"), PIEDRA)
techo(PALCO, PIEDRA, S("polished_andesite"))

# =================================================================== el palco: baranda, entrada y faroles
x0, x1, z0, z1 = PALCO
borde = [(x, z) for x in range(x0, x1 + 1) for z in (z0, z1)] + [(x, z) for z in range(z0, z1 + 1) for x in (x0, x1)]
borde = [(x, z) for (x, z) in borde if not (z == z0 and OX + 8 <= x <= OX + 14)]   # ahí va el portal de vuelta
A.baranda(borde, PISO + 1, PISO + 2)
A.entrada(3)
for (x, z) in ((x0 + 1, z1 - 1), (x1 - 1, z1 - 1), (x0 + 1, z0 + 1), (x1 - 1, z0 + 1)):
    A.put(x, PISO + 1, z, PIEDRA)
    A.put(x, PISO + 2, z, S("lantern", hanging=False, waterlogged=False))

# =================================================================== luces (invisibles) arriba de todo y en el vacío
A.luces(x0 + 1, x1 - 1, z0 + 1, z1 - 1)
for caja in (TORRE_ROJA, TORRE_AZUL):
    A.luces(*caja)
for z in range(OZ + 2, OZ + SZ - 2, 7):
    for y in (56, 72, 88):
        for x in (5983, 6017):
            A.put(x, y, z, S("light", level=12, waterlogged=False))

if __name__ == "__main__":
    A.guardar(sys.argv[1], sys.argv[2], "fuego")
