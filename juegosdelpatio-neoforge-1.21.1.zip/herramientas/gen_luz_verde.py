#!/usr/bin/env python3
"""Genera la arena del juego 1, "Luz verde, luz roja" (luz_verde.nbt).

Un patio gigante al aire libre (de noche, bajo las estrellas del complejo): 100 bloques de ancho y 280 de largo
entre la línea de salida y la meta. Carriles pintados, una franja amarilla cada 50 bloques, meta a cuadros,
el Vigía al fondo (un gigante mecánico de 32 bloques que gira la cabeza para mirar) y luces en las paredes de
los costados (cada 50 bloques) que se ponen verdes o rojas, para que siempre haya una a la vista. Iluminado con
luces invisibles. En la salida: barrera invisible (se saca cuando empieza el juego), podio del comandante y un
portal de vuelta a la sala.

Coordenadas del mundo: la plantilla empieza en (949, 99, -1). Adentro: x 950..1049, z 0..305, piso en y=99.
  salida   z 0..9      línea de salida z=10 (barrera)
  campo    z 11..289   meta z 290..292 (a cuadros)   llegada z 293..305

La cabeza del Vigía se lee de src/main/java/com/juegosdelpatio/Vigia.java (la misma que gira en el juego).

Uso: python3 gen_luz_verde.py <salida.nbt> <bloques.pkl>
"""
import gzip
import io
import os
import pickle
import re
import struct
import sys
from collections import Counter

OX, OY, OZ = 949, 99, -1        # esquina de la plantilla en el mundo
SX, SY, SZ = 102, 38, 308       # tamaño: x 949..1050, y 99..136, z -1..306
DATA_VERSION = 3955

blocks = {}


def S(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    if not props:
        return name
    parts = []
    for k, v in sorted(props.items()):
        if isinstance(v, bool):
            v = "true" if v else "false"
        parts.append(f"{k}={v}")
    return f"{name}[{','.join(parts)}]"


def put(wx, wy, wz, st):
    """Pone un bloque usando coordenadas del mundo."""
    blocks[(wx - OX, wy - OY, wz - OZ)] = st


X0, X1 = 950, 1049              # adentro
Z0, Z1 = 0, 305
PISO = 99
SALIDA_Z, META_Z = 10, 290
LUZ = S("light", level=15, waterlogged=False)
BARRERA = S("barrier")
NEGRO = S("polished_blackstone")


def wall_state(y):
    h = y - PISO
    if h in (1, 12):
        return S("polished_tuff")
    if h == 8:
        return S("chiseled_tuff_bricks")
    return S("tuff_bricks")


# =================================================================== piso
for x in range(OX, OX + SX):
    for z in range(OZ, OZ + SZ):
        if z < SALIDA_Z or z > META_Z + 2:
            st = S("polished_deepslate")                     # salida y llegada
        elif z == SALIDA_Z:
            st = S("white_concrete")                         # línea de salida
        elif META_Z <= z <= META_Z + 2:
            st = S("black_concrete") if (x + z) % 2 else S("white_concrete")   # meta a cuadros
        elif (z - SALIDA_Z) % 50 == 0:
            st = S("yellow_concrete")                        # una franja cada 50 bloques
        elif (x - X0) % 10 == 0 and x != X0:
            st = S("white_concrete")                         # carriles
        else:
            st = S("smooth_stone")
        put(x, PISO, z, st)

# =================================================================== paredes (12 de alto) con pilares y reflectores
for y in range(PISO + 1, PISO + 13):
    for x in range(OX, OX + SX):
        put(x, y, OZ, wall_state(y))
        put(x, y, OZ + SZ - 1, wall_state(y))
    for z in range(OZ, OZ + SZ):
        put(OX, y, z, wall_state(y))
        put(OX + SX - 1, y, z, wall_state(y))
for z in range(OZ, OZ + SZ, 25):
    for x in (OX, OX + SX - 1):
        for y in range(PISO + 1, PISO + 13):
            put(x, y, z, S("polished_deepslate"))
        put(x, PISO + 13, z, S("sea_lantern"))                # reflector arriba de cada pilar
for x in range(OX, OX + SX, 25):
    for z in (OZ, OZ + SZ - 1):
        for y in range(PISO + 1, PISO + 13):
            put(x, y, z, S("polished_deepslate"))
        put(x, PISO + 13, z, S("sea_lantern"))


# =================================================================== el Vigía: gigante mecánico al fondo, de espaldas a la gente
def leer_cabeza():
    aqui = os.path.dirname(os.path.abspath(__file__))
    for rel in ("../src/main/java/com/juegosdelpatio/Vigia.java", "../juegosdelpatio/src/main/java/com/juegosdelpatio/Vigia.java"):
        ruta = os.path.join(aqui, rel)
        if os.path.exists(ruta):
            texto = open(ruta, encoding="utf-8").read()
            tabla = texto[texto.index("CABEZA = {"):]
            tabla = tabla[:tabla.index("};")]
            filas = re.findall(r'"([IGLKR]{8})"', tabla)
            assert len(filas) == 64, len(filas)
            return [filas[8 * y:8 * y + 8] for y in range(8)]
    raise FileNotFoundError("no encuentro Vigia.java")


MATERIAL = {"I": S("iron_block"), "G": S("gray_concrete"), "L": S("light_gray_concrete"), "K": S("black_concrete"),
            "R": S("red_concrete"), "O": S("gold_block")}
CABEZA = leer_cabeza()
CAB_X0, CAB_Y0, CAB_Z0 = 996, 127, 298                          # como Vigia.X0 / Y0 / Z0

for x in range(991, 1009):                                       # pedestal
    for z in range(299, 305):
        for y in range(PISO + 1, PISO + 4):
            put(x, y, z, NEGRO)
for x in range(996, 1004):                                       # piernas (con una raya gris entre las dos)
    for z in range(300, 304):
        for y in range(103, 115):
            if x in (999, 1000) and y <= 111:
                m = "G"
            elif y <= 104 or y == 108:
                m = "K"                                          # pies y rodillas
            elif y >= 113:
                m = "G"                                          # cadera
            else:
                m = "I"
            put(x, y, z, MATERIAL[m])
CORONA = {123: "O.OO.O", 122: "OOOOOO", 121: "OOOOOO", 120: ".OOOO."}   # en la espalda, que mira a la gente
for x in range(996, 1004):                                       # torso
    for z in range(300, 304):
        for y in range(115, 127):
            m = "K" if y <= 116 else "G" if y == 126 else "I"
            if z == 300 and y in CORONA and 997 <= x <= 1002 and CORONA[y][x - 997] == "O":
                m = "O"
            put(x, y, z, MATERIAL[m])
for x0 in (992, 1004):                                           # brazos
    for x in range(x0, x0 + 4):
        for z in range(300, 304):
            for y in range(115, 127):
                m = "G" if y >= 124 else "K" if y == 119 or y <= 116 else "I"
                put(x, y, z, MATERIAL[m])
for y in range(8):                                               # la cabeza, de espaldas (como DE_ESPALDAS)
    for z in range(8):
        for x in range(8):
            put(CAB_X0 + 7 - x, CAB_Y0 + y, CAB_Z0 + 7 - z, MATERIAL[CABEZA[y][z][x]])
for x in (993, 1000, 1006):                                      # luces delante del cuerpo y de la cara
    for y in (106, 114, 122):
        put(x, y, 298, LUZ)
for x in (997, 1002):
    for y in (129, 133):
        put(x, y, 296, LUZ)
for x in (992, 998, 1004, 1009):                                 # el pedestal tapa luces del piso: van alrededor
    put(x, PISO + 2, 297, LUZ)
for z in (300, 304):
    put(989, PISO + 2, z, LUZ)
    put(1010, PISO + 2, z, LUZ)

# =================================================================== luces en las paredes de los costados (verde o roja)
LADOS_X = (OX, OX + SX - 1)
LADOS_Z = (35, 85, 135, 185, 235, 285)
for x in LADOS_X:
    adentro = x + 2 if x == OX else x - 2
    for zc in LADOS_Z:
        for z in range(zc - 2, zc + 3):
            for y in range(PISO + 3, PISO + 11):
                put(x, y, z, NEGRO)                              # marco
        for z in range(zc - 1, zc + 2):
            for y in range(PISO + 5, PISO + 9):
                put(x, y, z, S("gray_concrete"))                 # la luz, apagada
        put(adentro, PISO + 6, zc, LUZ)

# =================================================================== salida: barrera, podio y portal de vuelta
for x in range(X0, X1 + 1):
    for y in range(PISO + 1, PISO + 5):
        put(x, y, SALIDA_Z, BARRERA)                             # se saca cuando empieza el juego
for x in range(1040, 1045):                                       # podio del comandante
    for z in range(2, 7):
        for y in range(PISO + 1, PISO + 4):
            put(x, y, z, NEGRO)
for x in range(998, 1003):                                        # portal de vuelta, en la pared de atrás
    for y in range(PISO + 1, PISO + 6):
        marco = x in (998, 1002) or y == PISO + 5
        put(x, y, OZ, NEGRO if marco else S("juegosdelpatio:portal_juego", juego=1, regreso=True))

# =================================================================== luces invisibles
# A la altura de la cabeza (no chocan con nada) y en damero: cada 6 bloques, una sí y una no. Así ningún
# lugar del piso queda a más de 6 pasos de una luz, y en todo el patio hay por lo menos nivel 8 de luz.
LUZ_Y = PISO + 2
for x in range(X0, X1 + 1):
    for z in range(Z0, Z1 + 1):
        en_damero = x % 6 == 0 and z % 6 == 0 and (x // 6 + z // 6) % 2 == 0
        junto_a_la_pared = (x in (X0, X1) and z % 6 == 3) or (z in (Z0, Z1) and x % 6 == 3)
        if (en_damero or junto_a_la_pared) and (x - OX, LUZ_Y - OY, z - OZ) not in blocks:
            put(x, LUZ_Y, z, LUZ)

for (x, y, z) in blocks:
    if not (0 <= x < SX and 0 <= y < SY and 0 <= z < SZ):
        raise ValueError(f"fuera de la plantilla: {(x, y, z)}")


# =================================================================== escritura NBT
class NBT:
    END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTE_ARRAY, STRING, LIST, COMPOUND, INT_ARRAY = range(12)


def w_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">H", len(b)))
    f.write(b)


def w_payload(f, t, v):
    if t == NBT.INT:
        f.write(struct.pack(">i", v))
    elif t == NBT.STRING:
        w_str(f, v)
    elif t == NBT.LIST:
        et, items = v
        f.write(struct.pack(">b", et))
        f.write(struct.pack(">i", len(items)))
        for it in items:
            w_payload(f, et, it)
    elif t == NBT.COMPOUND:
        for name, (ct, cv) in v.items():
            f.write(struct.pack(">b", ct))
            w_str(f, name)
            w_payload(f, ct, cv)
        f.write(b"\x00")
    else:
        raise ValueError(t)


def parse_state(s):
    if "[" in s:
        name, rest = s.split("[", 1)
        return name, dict(kv.split("=") for kv in rest[:-1].split(","))
    return s, {}


def build_nbt():
    freq = Counter(blocks.values())
    palette = sorted(freq, key=lambda s: (-freq[s], s))
    index = {s: i for i, s in enumerate(palette)}
    pal_tags = []
    for s in palette:
        name, props = parse_state(s)
        c = {"Name": (NBT.STRING, name)}
        if props:
            c["Properties"] = (NBT.COMPOUND, {k: (NBT.STRING, v) for k, v in sorted(props.items())})
        pal_tags.append(c)
    blk_tags = [{"pos": (NBT.LIST, (NBT.INT, [x, y, z])), "state": (NBT.INT, index[blocks[(x, y, z)]])}
                for (x, y, z) in sorted(blocks, key=lambda p: (p[1], p[0], p[2]))]
    root = {
        "DataVersion": (NBT.INT, DATA_VERSION),
        "size": (NBT.LIST, (NBT.INT, [SX, SY, SZ])),
        "palette": (NBT.LIST, (NBT.COMPOUND, pal_tags)),
        "blocks": (NBT.LIST, (NBT.COMPOUND, blk_tags)),
        "entities": (NBT.LIST, (NBT.COMPOUND, [])),
    }
    buf = io.BytesIO()
    buf.write(struct.pack(">b", NBT.COMPOUND))
    w_str(buf, "")
    w_payload(buf, NBT.COMPOUND, root)
    return buf.getvalue(), palette


if __name__ == "__main__":
    out_nbt, out_pkl = sys.argv[1], sys.argv[2]
    raw, palette = build_nbt()
    with gzip.open(out_nbt, "wb", compresslevel=9) as f:
        f.write(raw)
    with open(out_pkl, "wb") as f:
        pickle.dump({"size": (SX, SY, SZ), "blocks": blocks, "offset": 0, "origen": (OX, OY, OZ)}, f)
    print(f"arena: {len(blocks)} bloques, paleta {len(palette)}, {len(raw) // 1024} KB sin comprimir")
