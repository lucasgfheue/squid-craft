#!/usr/bin/env python3
"""Vistas previas de la noche del pastel (después del tercer juego), en la sala. La sala se dibuja con render.py; las
personas son recortes (billboards) hechos con sus skins; los que duermen o están muertos, acostados sobre la cama o
el piso.

Uso: python3 masacre_render.py <bloques.pkl> <salida.png> <ancho> <alto> <supermuestreo> <escena>
  pelea:    dos bots se pelean frente al escenario y todos los demás miran en ronda (luces prendidas)
  acecho:   de noche (luces apagadas): el que ganó la pelea va agachado con la espada hasta uno que duerme
  masacre:  las luces parpadean: unos atacan con la espada, otros huyen, y hay cuerpos tirados
  guardias: entran los guardias apuntando; el comandante habla (con el chat)
"""
import math
import os
import pickle
import random
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

entrada, salida = sys.argv[1], sys.argv[2]
W, H, SS = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
ESCENA = sys.argv[6]
AQUI = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(AQUI, "../juegosdelpatio/src/main/resources/assets/juegosdelpatio/textures")
FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FUENTE_NEGRITA = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

# coordenadas del dibujo: x = x del mundo + 32, y = y del mundo - 64, z = z del mundo + 33
datos = pickle.load(open(entrada, "rb"))
OFF = datos["offset"]
bloques = dict(datos["blocks"])
ZP = 28                                               # el portón (z = -5 del mundo)
if ESCENA == "guardias":
    for x in range(28, 37):                           # el portón abierto (sube al hueco del muro)
        filas = [bloques.pop((x, y, ZP)) for y in range(1, 10) if (x, y, ZP) in bloques]
        for i, st in enumerate(filas):
            bloques[(x, 10 + i, ZP)] = st
if ESCENA == "acecho":                                # de noche: las luces apagadas (como Noche.cambiarLuces)
    noche = {}
    for (x, y, z), st in bloques.items():
        pasillo = 27 <= x <= 37 and z <= OFF - 1
        if not pasillo:
            if "waxed_copper_bulb" in st:
                st = st.replace("lit=true", "lit=false")
            elif st.startswith("minecraft:lantern") and "hanging=false" in st:
                continue
            elif st.startswith("minecraft:lantern"):
                st = st.replace("minecraft:lantern", "minecraft:soul_lantern")
            elif st == "minecraft:sea_lantern":
                st = "minecraft:prismarine_bricks"
        noche[(x, y, z)] = st
    bloques = noche
tmp = os.path.join(tempfile.gettempdir(), "masacre_escena.pkl")
pickle.dump({"size": datos["size"], "blocks": bloques, "offset": OFF}, open(tmp, "wb"))
sys.argv = ["render.py", tmp]
sys.path.insert(0, AQUI)
import render as R  # noqa: E402

W2, H2 = W * SS, H * SS
CAMARAS = {
    "pelea": ((33.2, 2.75, 60.2), (32.5, 1.35, 54.4), 62),
    "acecho": ((52.3, 2.25, 66.4), (55.4, 1.05, 70.6), 60),
    "masacre": ((25.8, 2.5, 61.8), (31.0, 1.4, 54.0), 64),
    "guardias": ((32.5, 3.1, 55.0), (32.5, 2.3, 38.0), 58),
}
POS, TGT, FOV = (np.array(v, float) if i < 2 else v for i, v in enumerate(CAMARAS[ESCENA]))
O, D = R.perspective(W2, H2, POS, TGT, FOV)
img = R.render(R.FULL_GRID, O, D, W2, H2).copy()
golpe, t, _, _, _ = R.trace(O, D, R.FULL_GRID)
prof = np.where(golpe, t, 1e9).reshape(H2, W2)
DIRS = D.reshape(H2, W2, 3)

f = R.norm(TGT - POS)
r = R.norm(np.cross(f, [0, 1, 0]))
u = np.cross(r, f)
th = math.tan(math.radians(FOV) / 2)
FRENTE = R.norm(np.array([-f[0], 0.0, -f[2]]))
DERECHA = R.norm(np.array([r[0], 0.0, r[2]]))


def proyectar(p):
    d = np.asarray(p) - POS
    z = d @ f
    x = (d @ r) / z / (th * W2 / H2)
    y = (d @ u) / z / th
    return (x + 1) * W2 / 2, (1 - y) * H2 / 2


def luz_en(x, z, y=2):
    cx, cz = int(math.floor(x)), int(math.floor(z))
    niveles = [R.LIGHTF[cx + dx, y, cz + dz] for dx in (-1, 0, 1) for dz in (-1, 0, 1)]
    return R.brightness(np.array([max(niveles)]))[0] * 0.92


def recorte(sprite, base, alto, ancho, luz, adelante=0.0, desvio=0.0):
    base = np.asarray(base, float) + DERECHA * desvio
    esquinas = [proyectar(base + DERECHA * (s * ancho / 2) + np.array([0, h, 0])) for s in (-1, 1) for h in (0, alto)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    tt = ((base - POS) @ FRENTE) / (dirs @ FRENTE)
    punto = POS + dirs * tt[..., None]
    uu = ((punto - base) @ DERECHA) / ancho + 0.5
    vv = (punto[..., 1] - base[1]) / alto
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    px = np.clip((uu * sw).astype(int), 0, sw - 1)
    py = np.clip(((1 - vv) * sh).astype(int), 0, sh - 1)
    col = arr[py, px]
    efectivo = tt - adelante
    ver = (uu >= 0) & (uu < 1) & (vv >= 0) & (vv < 1) & (col[..., 3] > 0) & (tt > 0) & (efectivo < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = col[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = efectivo[ver]


def acostado_en(sprite, base, direccion, altura, luz, largo=1.85, ancho=0.925):
    """Un cuerpo boca arriba: el sprite de frente, acostado a lo largo de direccion (la cabeza adelante)."""
    base = np.asarray(base, float)
    dn = R.norm(np.array([direccion[0], 0.0, direccion[2]]))
    pp = np.array([-dn[2], 0.0, dn[0]])
    h = base[1] + altura
    esquinas = [proyectar(base + dn * (a * largo / 2) + pp * (b * ancho / 2) + np.array([0, altura, 0]))
                for a in (-1, 1) for b in (-1, 1)]
    i0 = max(int(min(e[0] for e in esquinas)) - 2, 0)
    i1 = min(int(max(e[0] for e in esquinas)) + 3, W2)
    j0 = max(int(min(e[1] for e in esquinas)) - 2, 0)
    j1 = min(int(max(e[1] for e in esquinas)) + 3, H2)
    if i0 >= i1 or j0 >= j1:
        return
    dirs = DIRS[j0:j1, i0:i1]
    with np.errstate(divide="ignore", invalid="ignore"):
        tt = (h - POS[1]) / dirs[..., 1]
    punto = POS + dirs * tt[..., None]
    aa = ((punto - base) @ dn) / largo + 0.5
    bb = ((punto - base) @ pp) / ancho + 0.5
    arr = np.asarray(sprite.convert("RGBA"))
    sh, sw = arr.shape[:2]
    py = np.clip(((1 - aa) * sh).astype(int), 0, sh - 1)
    px = np.clip((bb * sw).astype(int), 0, sw - 1)
    c = arr[py, px]
    ver = (aa >= 0) & (aa < 1) & (bb >= 0) & (bb < 1) & (c[..., 3] > 0) & (tt > 0) & (tt < prof[j0:j1, i0:i1])
    zona = img[j0:j1, i0:i1]
    zona[ver] = c[..., :3][ver] / 255.0 * luz
    prof[j0:j1, i0:i1][ver] = tt[ver]


def pegar(destino, skin, sx, sy, w, h, dx, dy):
    destino.alpha_composite(skin.crop((sx, sy, sx + w, sy + h)), (dx, dy))


def frente(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((8, 8, 8, 8, 4, 0), (40, 8, 8, 8, 4, 0), (20, 20, 8, 12, 4, 8), (20, 36, 8, 12, 4, 8),
                 (44, 20, 4, 12, 0, 8), (44, 36, 4, 12, 0, 8), (36, 52, 4, 12, 12, 8), (52, 52, 4, 12, 12, 8),
                 (4, 20, 4, 12, 4, 20), (4, 36, 4, 12, 4, 20), (20, 52, 4, 12, 8, 20), (4, 52, 4, 12, 8, 20)):
        pegar(out, skin, *args)
    return out


def espalda(skin):
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    for args in ((24, 8, 8, 8, 4, 0), (56, 8, 8, 8, 4, 0), (32, 20, 8, 12, 4, 8), (32, 36, 8, 12, 4, 8),
                 (52, 20, 4, 12, 12, 8), (52, 36, 4, 12, 12, 8), (44, 52, 4, 12, 0, 8), (60, 52, 4, 12, 0, 8),
                 (12, 20, 4, 12, 8, 20), (12, 36, 4, 12, 8, 20), (28, 52, 4, 12, 4, 20), (12, 52, 4, 12, 4, 20)):
        pegar(out, skin, *args)
    return out


def perfil(skin, derecha, puno=False, espada=False, corriendo=False):
    """De costado (mirando a la derecha si derecha): con el brazo adelante (piña o espada) o corriendo."""
    out = Image.new("RGBA", (16, 32), (0, 0, 0, 0))
    cara = (0, 8) if derecha else (16, 8)
    pegar(out, skin, cara[0], cara[1], 8, 8, 4, 0)
    pegar(out, skin, 16 if derecha else 28, 20, 4, 12, 6, 8)
    if corriendo:                                         # las piernas abiertas
        pierna = skin.crop((0, 20, 4, 32))
        out.alpha_composite(pierna.rotate(25 if derecha else -25, expand=True).crop((0, 0, 8, 12)), (3, 20))
        out.alpha_composite(pierna.rotate(-25 if derecha else 25, expand=True).crop((0, 0, 8, 12)), (6, 20))
    else:
        pegar(out, skin, 0 if derecha else 8, 20, 4, 12, 6, 20)
    brazo = skin.crop((40, 20, 44, 32))
    if puno or espada:
        horizontal = brazo.rotate(90 if derecha else -90, expand=True)
        out.alpha_composite(horizontal, (8, 9) if derecha else (-4 + 4, 9))
        if espada:
            dd = ImageDraw.Draw(out)
            x0 = 15 if derecha else 0
            for i in range(8):
                dd.point((x0 - (i // 4 if derecha else -(i // 4)), 9 - i), fill=(200, 200, 205, 255) if i > 1 else (120, 120, 125, 255))
    else:
        pegar(out, skin, 40, 20, 4, 12, 6, 8)
    if not derecha:
        out = out.transpose(Image.FLIP_LEFT_RIGHT).transpose(Image.FLIP_LEFT_RIGHT)
    return out


def agachado(skin, espada=False):
    """De costado, agachado (cabeza y torso más abajo e inclinados), con la espada adelante."""
    parado = perfil(skin, True, espada=espada)
    out = Image.new("RGBA", (16, 27), (0, 0, 0, 0))
    torso = parado.crop((0, 0, 16, 20)).rotate(-14, resample=Image.NEAREST, center=(8, 20))
    out.alpha_composite(torso, (1, 0))
    out.alpha_composite(parado.crop((0, 20, 16, 32)).resize((16, 7)), (0, 20))
    return out


def con_espada(sprite):
    out = sprite.copy()
    dd = ImageDraw.Draw(out)
    for i in range(9):
        x, y = 1 - i // 3, 18 - i
        if 0 <= x < out.width and y >= 0:
            dd.point((x, y), fill=(200, 200, 205, 255) if i > 2 else (120, 120, 125, 255))
    dd.point((1, 19), fill=(90, 70, 50, 255))
    return out


ALTO, ANCHO = 1.85, 0.925
skins = [Image.open(os.path.join(TEX, f"entity/jugador/skin_{i}.png")).convert("RGBA") for i in range(48)]
guardias = {n: Image.open(os.path.join(TEX, f"entity/guardia/{n}.png")).convert("RGBA")
            for n in ("vigilante", "guardia", "sargento", "comandante")}
armas = {n: Image.open(os.path.join(TEX, f"item/{n}.png")).convert("RGBA") for n in ("pistola", "rifle", "escopeta")}
azar = random.Random(5)

parados = []                                              # (x, z, sprite, alto, ancho)
acostados = []                                            # (x, y, z, sprite, direccion, altura)
if ESCENA == "pelea":
    cx, cz = 32.5, 54.5                                    # Masacre.RING (0.5, 65, 21.5)
    parados.append((cx - 1.1, cz, perfil(skins[9], True, puno=True), ALTO, ANCHO))
    parados.append((cx + 1.1, cz, perfil(skins[23], False), ALTO, ANCHO))
    n = 0
    while n < 28:
        a = azar.random() * math.pi * 2
        rr = 4.5 + azar.random() * 2.0
        x, z = cx + rr * math.cos(a), cz + rr * math.sin(a)
        if z > cz + 2.0 and abs(x - cx) < 4.2 or z > cz + 4.6:
            continue                                       # que se vea la pelea (los de este lado, a los costados)
        if any((x - p[0]) ** 2 + (z - p[1]) ** 2 < 0.8 for p in parados):
            continue
        skin = skins[azar.randrange(48)]
        parados.append((x, z, espalda(skin) if z > cz else frente(skin), ALTO, ANCHO))
        n += 1
elif ESCENA == "acecho":
    acostados.append((55.5, 1.0, 70.5, frente(skins[31]), (1.0, 0, 0), 0.62))   # en la cama (cabeza en x = 56)
    acostados.append((55.5, 1.0, 68.5, frente(skins[14]), (1.0, 0, 0), 0.62))
    acostados.append((55.5, 1.0, 74.5, frente(skins[40]), (1.0, 0, 0), 0.62))
    parados.append((53.9, 70.6, agachado(skins[9], espada=True), 1.5, ANCHO))
elif ESCENA == "masacre":
    for (x, z, s, d) in ((27.0, 58.5, 31, (1, 0, 0.3)), (30.5, 61.0, 14, (-0.4, 0, 1)), (36.0, 56.5, 40, (1, 0, -0.6)),
                         (24.5, 54.0, 5, (0.2, 0, 1))):
        acostados.append((x, 1.0, z, frente(skins[s]), d, 0.3))
    parados.append((29.0, 56.0, perfil(skins[9], True, espada=True), ALTO, ANCHO))     # ataca
    parados.append((31.2, 55.6, perfil(skins[2], True, corriendo=True), ALTO, ANCHO))  # huye
    parados.append((37.5, 51.5, con_espada(frente(skins[17])), ALTO, ANCHO))
    parados.append((25.5, 50.0, perfil(skins[33], False, corriendo=True), ALTO, ANCHO))
    parados.append((40.5, 49.0, perfil(skins[11], True, corriendo=True), ALTO, ANCHO))
    parados.append((34.0, 47.5, con_espada(frente(skins[26])), ALTO, ANCHO))
    parados.append((21.5, 47.0, perfil(skins[44], False, espada=True), ALTO, ANCHO))
elif ESCENA == "guardias":
    for (x, z, s, d) in ((27.5, 55.0, 31, (1, 0, 0.3)), (38.0, 57.0, 14, (-0.4, 0, 1)), (24.0, 50.5, 40, (1, 0, -0.6))):
        acostados.append((x, 1.0, z, frente(skins[s]), d, 0.3))
    figuras = [(32.5, 41.5, "comandante", "escopeta")]
    for dx, dz in ((-1.6, -1), (-3.2, -1), (1.6, -1), (3.2, -1)):
        figuras.append((32.5 + dx, 41.5 + dz, "sargento", "rifle"))
    for dx, dz in ((-4.8, -2), (4.8, -2), (-2.4, -2.6), (2.4, -2.6)):
        figuras.append((32.5 + dx, 41.5 + dz, "guardia", "pistola"))
    for x, z, rango, arma in figuras:
        parados.append((x, z, frente(guardias[rango]), ALTO, ANCHO, arma))
    n = 0
    while n < 16:
        x, z = azar.uniform(22.5, 42.5), azar.uniform(46.0, 52.0)
        if abs(x - 32.5) < 2.4 or any((x - p[0]) ** 2 + (z - p[1]) ** 2 < 1.4 for p in parados):
            continue
        parados.append((x, z, espalda(skins[azar.randrange(48)]), ALTO, ANCHO))
        n += 1

REALCE = 2.2 if ESCENA == "acecho" else 1.0                   # de noche, la luz azul de los faroles alcanza a verlos
for (x, y, z, sprite, d, altura) in acostados:
    acostado_en(sprite, (x, y, z), d, altura, np.minimum(1.0, luz_en(x, z) * REALCE))
parados.sort(key=lambda p: -np.linalg.norm(np.array([p[0], 1.0, p[1]]) - POS))
for p in parados:
    x, z, sprite, alto, ancho = p[:5]
    luz = np.minimum(1.0, luz_en(x, z) * REALCE)
    recorte(sprite, (x, 1.0, z), alto, ancho, luz)
    if len(p) > 5:                                         # el arma, apuntando (horizontal, a la altura del pecho)
        recorte(armas[p[5]], (x, 1.0 + 0.95, z), 0.55, 0.55, luz, adelante=0.35, desvio=-0.3)

final_arr = np.clip(img, 0, 1)
if ESCENA == "masacre":                                    # un apagón del parpadeo: casi todo negro
    yy = np.linspace(-1, 1, H2)[:, None]
    xx = np.linspace(-1, 1, W2)[None, :]
    oscuro = 0.15 + 0.55 * np.clip(xx * 1.2 - 0.1, 0, 1)    # el costado derecho, a oscuras (la luz que falla)
    final_arr = final_arr * (1.0 - oscuro[..., None] * (0.6 + 0.4 * (yy[..., None] ** 2 < 2)))
final = Image.fromarray((final_arr * 255 + 0.5).astype(np.uint8))
if SS > 1:
    final = final.resize((W, H), Image.LANCZOS)
dib = ImageDraw.Draw(final, "RGBA")
letra = ImageFont.truetype(FUENTE, max(12, H // 46))


def chat(lineas):
    alto_linea = int(letra.size * 1.45)
    y = H - 34 - alto_linea * len(lineas)
    ancho_max = int(W * 0.66)
    for partes in lineas:
        dib.rectangle((8, y, 8 + ancho_max, y + alto_linea), fill=(0, 0, 0, 120))
        x = 14
        for texto, color in partes:
            dib.text((x + 1, y + 3), texto, font=letra, fill=(30, 30, 30))
            dib.text((x, y + 2), texto, font=letra, fill=color)
            x += dib.textlength(texto, font=letra)
        y += alto_linea


def titulo(grande, chico, color):
    lg = ImageFont.truetype(FUENTE_NEGRITA, H // 9)
    lc = ImageFont.truetype(FUENTE, H // 30)
    wg = dib.textlength(grande, font=lg)
    wc = dib.textlength(chico, font=lc)
    dib.text(((W - wg) / 2 + 4, H * 0.30 + 4), grande, font=lg, fill=(20, 0, 0))
    dib.text(((W - wg) / 2, H * 0.30), grande, font=lg, fill=color)
    dib.text(((W - wc) / 2 + 2, H * 0.30 + lg.size * 1.25 + 2), chico, font=lc, fill=(20, 20, 20))
    dib.text(((W - wc) / 2, H * 0.30 + lg.size * 1.25), chico, font=lc, fill=(205, 205, 210))


COMANDANTE = [("<", (255, 255, 255)), ("♚ Comandante", (255, 170, 0)), ("> ", (255, 255, 255))]
if ESCENA == "pelea":
    chat([[("¡Mateo y Lucía se están peleando!", (255, 170, 0))]])
    leyenda = "La noche del pastel · dos se pelean frente al escenario y todos miran (imagen aproximada)"
elif ESCENA == "acecho":
    chat([[("Mateo mató a Lucía en la pelea.", (170, 0, 0))]])
    leyenda = "La noche del pastel · con las luces apagadas, Mateo se levanta y va agachado hasta uno que duerme (imagen aproximada)"
elif ESCENA == "masacre":
    titulo("¡MASACRE!", "Mateo mató a Bruno mientras dormía. ¡Aguanta 2 minutos!", (190, 20, 20))
    chat([[("Mateo mató a Bruno mientras dormía.", (170, 0, 0))], [("Sofía mató a Tomás.", (170, 0, 0))],
          [("Valen murió.", (170, 0, 0))]])
    leyenda = "La noche del pastel · las luces parpadean 2 minutos: unos atacan con la espada y otros huyen (imagen aproximada)"
else:
    chat([COMANDANTE + [("¡Basta! ¡Todos quietos! Suelten las espadas.", (255, 255, 85))],
          COMANDANTE + [("Esta noche murieron 14. El premio ya es de 2650 diamantes.", (255, 255, 85))],
          COMANDANTE + [("Descansen: el cuarto juego está a punto de comenzar.", (255, 255, 85))]])
    leyenda = "La noche del pastel · entran los guardias apuntando, les quitan las espadas y habla el comandante (imagen aproximada)"
dib.text((12, H - 24), leyenda, font=ImageFont.truetype(FUENTE, max(11, H // 52)), fill=(225, 225, 230))
final.save(salida, optimize=True)
print("guardado", salida, final.size)
