#!/usr/bin/env python3
"""Genera la arena del juego 2, "Las sillas musicales" (sillas.nbt).

Un salón de fiestas techado: piso de parqué, paredes blancas con franjas de colores y notas musicales dibujadas,
arañas de faroles colgando del techo. Se juega en una sola ronda enorme: en el centro, sobre un disco negro como un
disco de vinilo gigante, van las sillas (en anillos alrededor de un gramófono gigante con una bocina dorada, de
donde sale la música), y lejos, cerca de las paredes, está la pista blanca por donde camina la gente. Las sillas no
están en la plantilla: las pone el juego.

Coordenadas del mundo: la plantilla empieza en (1960, 99, -17). Adentro: x 1961..2039, z -15..78, piso en y=99.
  entrada   z -15..4   (llegada, podio del comandante y portal de vuelta en la pared norte)
  ronda     centro en el bloque (2000, 41): gramófono r<=5,5 · vinilo hasta r 19,5 (las sillas, en anillos de radio
            7, 10, 13, 16 y 19) · pista blanca de r 31,4 a 34,6

Uso: python3 gen_sillas.py <salida.nbt> <bloques.pkl>
"""
import gzip
import io
import math
import pickle
import struct
import sys
from collections import Counter

OX, OY, OZ = 1960, 99, -17      # esquina de la plantilla en el mundo
SX, SY, SZ = 81, 18, 97         # x 1960..2040, y 99..116, z -17..79
DATA_VERSION = 3955

blocks = {}


def S(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    if not props:
        return name
    parts = []
    for k, v in sorted(props.items()):
        if isinstance(v, bool):
            v = "true" if v else "false"
        parts.append(f"{k}={v}")
    return f"{name}[{','.join(parts)}]"


def put(wx, wy, wz, st):
    """Pone un bloque usando coordenadas del mundo."""
    blocks[(wx - OX, wy - OY, wz - OZ)] = st


def get(wx, wy, wz):
    return blocks.get((wx - OX, wy - OY, wz - OZ))


X0, X1 = 1961, 2039             # adentro
Z0, Z1 = -15, 78
PARED_N, PARED_S, PARED_O, PARED_E = -16, 79, 1960, 2040
PISO = 99
TECHO = 116
LUZ = S("light", level=15, waterlogged=False)
NEGRO = S("polished_blackstone")
DEEP = S("polished_deepslate")
MADERA = S("dark_oak_planks")
ORO = S("gold_block")
CADENA = S("chain", axis="y", waterlogged=False)
FAROL = S("lantern", hanging=True, waterlogged=False)
FAROL_PISO = S("lantern", hanging=False, waterlogged=False)

# =================================================================== piso
for x in range(OX, OX + SX):
    for z in range(PARED_N, PARED_S + 1):
        if z <= 4:
            st = DEEP                                              # entrada
        elif z == 5:
            st = S("white_concrete")                               # línea
        else:
            st = S("spruce_planks") if (x // 2 + z // 2) % 2 == 0 else MADERA   # parqué de madera
        put(x, PISO, z, st)

# la ronda: el disco de vinilo con las ranuras (entre los anillos de sillas), la etiqueta roja debajo del gramófono,
# un borde celeste, la pista blanca y un borde magenta
CENTRO_X, CENTRO_Z = 2000, 41
RADIOS_SILLAS = (7.0, 10.0, 13.0, 16.0, 19.0)
for dx in range(-36, 37):
    for dz in range(-36, 37):
        r = math.hypot(dx, dz)
        if r > 35.4:
            continue
        if r <= 6.5:
            st = S("red_concrete")                                   # la etiqueta del disco
        elif r <= 19.5:
            surco = any(abs(r - (a + b) / 2) <= 0.35 for a, b in zip(RADIOS_SILLAS, RADIOS_SILLAS[1:]))
            st = S("gray_concrete") if surco or r > 19.0 else S("black_concrete")
        elif r <= 30.5:
            continue                                                 # parqué: por acá se corre a las sillas
        elif r <= 31.4:
            st = S("light_blue_concrete")
        elif r <= 34.6:
            st = S("white_concrete")                                 # la pista para caminar
        else:
            st = S("magenta_concrete")
        put(CENTRO_X + dx, PISO, CENTRO_Z + dz, st)

# =================================================================== paredes: zócalo, blanco con franjas y notas, pilares
def pared(y):
    h = y - PISO
    if h == 1:
        return MADERA                                             # zócalo
    if h == 4:
        return S("pink_concrete")
    if h == 5:
        return S("light_blue_concrete")
    if h == 15:
        return ORO                                                # moldura de arriba
    if h == 16:
        return DEEP
    return S("white_concrete")


for y in range(PISO + 1, TECHO):
    for x in range(OX, OX + SX):
        put(x, y, PARED_N, pared(y))
        put(x, y, PARED_S, pared(y))
    for z in range(PARED_N, PARED_S + 1):
        put(PARED_O, y, z, pared(y))
        put(PARED_E, y, z, pared(y))
# pilares de cuarzo con un farol de mar arriba, cada 10 bloques
PILAR = S("quartz_pillar", axis="y")
for x in range(OX, OX + SX, 10):
    for z in (PARED_N, PARED_S):
        for y in range(PISO + 1, TECHO - 1):
            put(x, y, z, PILAR)
        put(x, TECHO - 3, z, S("sea_lantern"))
for z in range(PARED_N + 4, PARED_S, 10):
    for x in (PARED_O, PARED_E):
        for y in range(PISO + 1, TECHO - 1):
            put(x, y, z, PILAR)
        put(x, TECHO - 3, z, S("sea_lantern"))

# notas musicales dibujadas en las paredes (de negro), entre pilar y pilar
CORCHEA = [".X..", ".XX.", ".X.X", ".X..", "XX..", "XX.."]           # ♪ (de arriba abajo)
DOBLE = [".XXXXX", ".X...X", ".X...X", ".X...X", "XX..XX", "XX..XX"]  # ♫
NOTA_Y = PISO + 12                                                    # la fila de arriba de la nota


def dibujar_nota(patron, a0, plano):
    """plano(a, y) -> posición del mundo; a0 = primera columna."""
    for fila, texto in enumerate(patron):
        for col, c in enumerate(texto):
            if c == "X":
                put(*plano(a0 + col, NOTA_Y - fila), S("black_concrete"))


k = 0
for x0 in range(OX + 3, OX + SX - 8, 10):
    patron = CORCHEA if k % 2 == 0 else DOBLE
    for z, espejo in ((PARED_N, False), (PARED_S, True)):
        ancho = len(patron[0])
        inicio = x0 + (10 - ancho) // 2 - 1
        dibujar_nota([t[::-1] for t in patron] if espejo else patron, inicio, lambda a, y, z=z: (a, y, z))
    k += 1
k = 0
for z0 in range(PARED_N + 4, PARED_S - 8, 10):
    patron = DOBLE if k % 2 == 0 else CORCHEA
    for x, espejo in ((PARED_O, True), (PARED_E, False)):
        ancho = len(patron[0])
        inicio = z0 + (10 - ancho) // 2 + 1
        dibujar_nota([t[::-1] for t in patron] if espejo else patron, inicio, lambda a, y, x=x: (x, y, a))
    k += 1

# =================================================================== techo, con arañas de faroles sobre cada círculo
for x in range(OX, OX + SX):
    for z in range(PARED_N, PARED_S + 1):
        put(x, TECHO, z, MADERA)
for x in range(OX + 5, OX + SX, 10):
    for z in range(OZ + 6, OZ + SZ, 10):
        put(x, TECHO, z, S("sea_lantern"))
ARANAS = [(33.0, 12, 15.0), (12.25, 6, 0.0), (24.0, 8, 22.5)]   # (radio, cuántas, desfase en grados)
for radio_a, cuantas, desfase in ARANAS:
    for k in range(cuantas):
        a_ = math.radians(desfase + 360.0 * k / cuantas)
        cx, cz = round(CENTRO_X + radio_a * math.cos(a_)), round(CENTRO_Z + radio_a * math.sin(a_))
        for y in range(PISO + 9, TECHO):
            put(cx, y, cz, CADENA)
        put(cx, PISO + 8, cz, FAROL)
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):            # cuatro faroles alrededor
            for y in range(PISO + 10, TECHO):
                put(cx + dx, y, cz + dz, CADENA)
            put(cx + dx, PISO + 9, cz + dz, FAROL)

# =================================================================== entrada: podio, portal de vuelta y faroles
for x in range(1996, 2005):                                     # podio del comandante (arriba: y=102)
    for z in range(-15, -11):
        for y in range(PISO + 1, PISO + 3):
            put(x, y, z, NEGRO if y == PISO + 1 else S("smooth_quartz"))
for x in (1996, 2004):
    put(x, PISO + 3, -12, FAROL_PISO)
for x in range(1977, 1984):                                     # portal de vuelta, en la pared norte
    for y in range(PISO + 1, PISO + 7):
        marco = x in (1977, 1983) or y == PISO + 6
        put(x, y, PARED_N, NEGRO if marco else S("juegosdelpatio:portal_juego", juego=2, regreso=True))
        if not marco:
            put(x, y, PARED_N - 1, S("barrier"))                # que nadie caiga al vacío de atrás
for x in range(1978, 1983):
    put(x, PISO, -15, NEGRO)

# =================================================================== el gramófono gigante, en el centro de la ronda
for dx in range(-6, 7):                                         # tarima redonda
    for dz in range(-6, 7):
        r = math.hypot(dx, dz)
        if r <= 5.5:
            put(CENTRO_X + dx, PISO + 1, CENTRO_Z + dz, ORO if r > 4.8 else MADERA)
for k in range(8):                                              # faroles en el borde de la tarima
    a_ = math.radians(22.5 + 45.0 * k)
    put(round(CENTRO_X + 4.6 * math.cos(a_)), PISO + 2, round(CENTRO_Z + 4.6 * math.sin(a_)), FAROL_PISO)
for dx in range(-3, 4):                                         # el mueble
    for dz in range(-3, 4):
        for y in range(PISO + 2, PISO + 5):
            borde = abs(dx) == 3 and abs(dz) == 3
            put(CENTRO_X + dx, y, CENTRO_Z + dz, ORO if borde else MADERA)
for dx in range(-2, 3):                                         # el disco y el eje
    for dz in range(-2, 3):
        if dx * dx + dz * dz <= 5:
            put(CENTRO_X + dx, PISO + 5, CENTRO_Z + dz, S("black_concrete"))
put(CENTRO_X, PISO + 6, CENTRO_Z, S("lightning_rod", facing="up", powered=False, waterlogged=False))
# la bocina: aros dorados, cada vez más anchos, que se abren hacia arriba
AROS = [(0.5, PISO + 7), (0.9, PISO + 8), (1.4, PISO + 9), (2.0, PISO + 10), (2.7, PISO + 11), (3.5, PISO + 12),
        (4.3, PISO + 13), (5.0, PISO + 14)]
BOCA_Z = CENTRO_Z + 2                                           # un poco corrida hacia atrás del disco
for radio, yc in AROS:
    for dx in range(-6, 7):
        for dz in range(-6, 7):
            r = math.hypot(dx, dz)
            if radio - 0.55 <= r <= radio + 0.45 or (radio < 1.0 and r <= radio):
                put(CENTRO_X + dx, yc, BOCA_Z + dz, ORO)
for y in range(PISO + 5, PISO + 7):
    put(CENTRO_X, y, BOCA_Z, ORO)                               # el cuello, que baja al mueble

# =================================================================== luces invisibles
# A la altura de la cabeza (no chocan con nada) y en damero: cada 6 bloques, una sí y una no.
LUZ_Y = PISO + 2
for x in range(X0, X1 + 1):
    for z in range(Z0, Z1 + 1):
        en_damero = x % 6 == 0 and z % 6 == 0 and (x // 6 + z // 6) % 2 == 0
        junto_a_la_pared = (x in (X0, X1) and z % 6 == 3) or (z in (Z0, Z1) and x % 6 == 3)
        if (en_damero or junto_a_la_pared) and get(x, LUZ_Y, z) is None:
            put(x, LUZ_Y, z, LUZ)

for (x, y, z) in blocks:
    if not (0 <= x < SX and 0 <= y < SY and 0 <= z < SZ):
        raise ValueError(f"fuera de la plantilla: {(x, y, z)}")


# =================================================================== escritura NBT
class NBT:
    END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTE_ARRAY, STRING, LIST, COMPOUND, INT_ARRAY = range(12)


def w_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">H", len(b)))
    f.write(b)


def w_payload(f, t, v):
    if t == NBT.INT:
        f.write(struct.pack(">i", v))
    elif t == NBT.STRING:
        w_str(f, v)
    elif t == NBT.LIST:
        et, items = v
        f.write(struct.pack(">b", et))
        f.write(struct.pack(">i", len(items)))
        for it in items:
            w_payload(f, et, it)
    elif t == NBT.COMPOUND:
        for name, (ct, cv) in v.items():
            f.write(struct.pack(">b", ct))
            w_str(f, name)
            w_payload(f, ct, cv)
        f.write(b"\x00")
    else:
        raise ValueError(t)


def parse_state(s):
    if "[" in s:
        name, rest = s.split("[", 1)
        return name, dict(kv.split("=") for kv in rest[:-1].split(","))
    return s, {}


def build_nbt():
    freq = Counter(blocks.values())
    palette = sorted(freq, key=lambda s: (-freq[s], s))
    index = {s: i for i, s in enumerate(palette)}
    pal_tags = []
    for s in palette:
        name, props = parse_state(s)
        c = {"Name": (NBT.STRING, name)}
        if props:
            c["Properties"] = (NBT.COMPOUND, {k: (NBT.STRING, v) for k, v in sorted(props.items())})
        pal_tags.append(c)
    blk_tags = [{"pos": (NBT.LIST, (NBT.INT, [x, y, z])), "state": (NBT.INT, index[blocks[(x, y, z)]])}
                for (x, y, z) in sorted(blocks, key=lambda p: (p[1], p[0], p[2]))]
    root = {
        "DataVersion": (NBT.INT, DATA_VERSION),
        "size": (NBT.LIST, (NBT.INT, [SX, SY, SZ])),
        "palette": (NBT.LIST, (NBT.COMPOUND, pal_tags)),
        "blocks": (NBT.LIST, (NBT.COMPOUND, blk_tags)),
        "entities": (NBT.LIST, (NBT.COMPOUND, [])),
    }
    buf = io.BytesIO()
    buf.write(struct.pack(">b", NBT.COMPOUND))
    w_str(buf, "")
    w_payload(buf, NBT.COMPOUND, root)
    return buf.getvalue(), palette


if __name__ == "__main__":
    out_nbt, out_pkl = sys.argv[1], sys.argv[2]
    raw, palette = build_nbt()
    with gzip.open(out_nbt, "wb", compresslevel=9) as f:
        f.write(raw)
    with open(out_pkl, "wb") as f:
        pickle.dump({"size": (SX, SY, SZ), "blocks": blocks, "offset": 0, "origen": (OX, OY, OZ)}, f)
    print(f"arena: {len(blocks)} bloques, paleta {len(palette)}, {len(raw) // 1024} KB sin comprimir")
