package com.juegosdelpatio;

import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Uno de los dos robots gigantes de El puente de Londres (juego 4): un robot de metal oscuro de más de 9 bloques de alto,
 * con un visor de luz en la cabeza (rojo o azul) y una luz igual en el pecho y en los antebrazos. Se paran uno a cada
 * lado de la calle, mirándose, y se dan las dos manos por encima: los brazos forman el puente. El juego le dice cuánto
 * levantar los brazos ({@link #ponerBrazos}); el dibujo ({@link RobotRenderer}) los mueve suave entre tick y tick, con
 * el codo doblado para que las manos queden siempre en el medio de la calle, agarradas a las del otro robot. Mientras
 * suena la canción, gira la cabeza de a poco, mirando la fila.
 *
 * No se lo puede lastimar, empujar ni tocar (los clics lo atraviesan: se puede empujar a alguien que está detrás), no
 * choca con nada y no se guarda en el mundo: el juego lo pone al empezar y lo saca al terminar.
 */
public class Robot extends Entity {
    static final int ROJO = 0;
    static final int AZUL = 1;
    /** Ángulo de los brazos, en grados: arriba (forman el puente) y bajados de golpe (encierran al que pasa). */
    static final float ARRIBA = 25.0F;
    static final float ABAJO = -50.0F;
    /** El hombro, desde el pie del robot (en bloques): al costado, de alto y hacia adelante. */
    static final float HOMBRO_X = 1.95F;
    static final float HOMBRO_Y = 7.0F;
    static final float HOMBRO_Z = 0.3F;
    /** Del centro del robot al medio de la calle (ahí se dan la mano con el otro robot). */
    static final float AL_MEDIO = 5.0F;
    /** El brazo y el antebrazo (con la mano), en bloques. Juntos llegan al medio de la calle aunque estén bajados. */
    static final float BRAZO = 3.9F;
    static final float ANTEBRAZO = 3.9F;

    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(Robot.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> BRAZOS = SynchedEntityData.defineId(Robot.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> CANTA = SynchedEntityData.defineId(Robot.class, EntityDataSerializers.BOOLEAN);

    /** En el cliente: los brazos en el tick anterior y en este (se dibujan en el medio). */
    float brazosAntes = ARRIBA;
    float brazosAhora = ARRIBA;

    public Robot(EntityType<? extends Robot> tipo, Level nivel) {
        super(tipo, nivel);
        this.noPhysics = true;
    }

    /** Pone un robot parado en {@code lugar}, mirando para {@code giro} (grados), con los brazos arriba. */
    @Nullable
    static Robot poner(ServerLevel nivel, Vec3 lugar, float giro, int color) {
        Robot robot = Registro.ROBOT.get().create(nivel);
        if (robot == null) {
            return null;
        }
        robot.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
        robot.setYHeadRot(giro);
        robot.entityData.set(COLOR, color);
        robot.entityData.set(BRAZOS, ARRIBA);
        nivel.addFreshEntity(robot);
        return robot;
    }

    int color() {
        return entityData.get(COLOR);
    }

    float brazos() {
        return entityData.get(BRAZOS);
    }

    /** Cuánto levanta los brazos (grados, entre {@link #ABAJO} y {@link #ARRIBA}). */
    void ponerBrazos(float angulo) {
        float limitado = Math.max(ABAJO, Math.min(ARRIBA, angulo));
        if (limitado != entityData.get(BRAZOS)) {
            entityData.set(BRAZOS, limitado);
        }
    }

    /** Mientras suena la canción, el robot gira la cabeza de a poco, mirando la fila. */
    void cantar(boolean canta) {
        if (canta != entityData.get(CANTA)) {
            entityData.set(CANTA, canta);
        }
    }

    boolean canta() {
        return entityData.get(CANTA);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) {
            brazosAntes = brazosAhora;
            brazosAhora = entityData.get(BRAZOS);
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        datos.define(COLOR, ROJO);
        datos.define(BRAZOS, ARRIBA);
        datos.define(CANTA, false);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag datos) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag datos) {
    }

    /** No le pasa nada. */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return false;
    }

    /** Los clics lo atraviesan (así se puede empujar a alguien que está al lado del robot). */
    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    /** Los brazos salen bastante del cuerpo: que no deje de dibujarse cuando el cuerpo queda fuera de la pantalla. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return getBoundingBox().inflate(7.0, 1.0, 7.0);
    }
}
