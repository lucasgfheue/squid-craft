package com.juegosdelpatio;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import org.slf4j.Logger;

/**
 * Clase principal del mod "Juegos del Patio".
 *
 * Agrega la dimensión del complejo, el dormitorio con baños y comedor, la invitación
 * para entrar y salir, el uniforme, los bots que viven en el dormitorio, los guardias con sus armas y la
 * ceremonia de bienvenida (el portón se abre al atardecer del día de entrada).
 */
@Mod(JuegosDelPatio.MODID)
public final class JuegosDelPatio {
    public static final String MODID = "juegosdelpatio";
    public static final Logger LOGGER = LogUtils.getLogger();

    public JuegosDelPatio(IEventBus busDelMod, ModContainer contenedor) {
        Registro.registrar(busDelMod);
        busDelMod.addListener(JuegosDelPatio::crearAtributos);
        NeoForge.EVENT_BUS.addListener(Comandos::registrar);
        NeoForge.EVENT_BUS.addListener(Guardia::alRecibirDanio);
        NeoForge.EVENT_BUS.addListener(Ceremonia::alTick);
        NeoForge.EVENT_BUS.addListener(Ceremonia::alParar);
    }

    private static void crearAtributos(EntityAttributeCreationEvent evento) {
        evento.put(Registro.JUGADOR_BOT.get(), JugadorBot.crearAtributos().build());
        evento.put(Registro.GUARDIA.get(), Guardia.crearAtributos().build());
    }
}
