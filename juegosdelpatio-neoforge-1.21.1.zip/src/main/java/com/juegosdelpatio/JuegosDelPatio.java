package com.juegosdelpatio;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

/**
 * Clase principal del mod "Juegos del Patio".
 *
 * Esta primera versión agrega la dimensión del complejo, el dormitorio gigante
 * y la invitación que sirve para entrar y salir.
 */
@Mod(JuegosDelPatio.MODID)
public final class JuegosDelPatio {
    public static final String MODID = "juegosdelpatio";
    public static final Logger LOGGER = LogUtils.getLogger();

    public JuegosDelPatio(IEventBus busDelMod, ModContainer contenedor) {
        Registro.registrar(busDelMod);
        NeoForge.EVENT_BUS.addListener(Comandos::registrar);
    }
}
