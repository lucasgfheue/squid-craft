package com.juegosdelpatio;

import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * El Cazador, el robot gigante de Sálvese quien pueda (juego 2): un robot de metal oscuro de 12 bloques de alto, con un
 * visor rojo en la cabeza y una luz igual en el pecho y en los antebrazos. Recorre la estación caminando (el juego lo
 * mueve con {@link #caminarHacia}); con la alarma se le prenden los ojos y gira la cabeza de un lado al otro, buscando
 * (el juego le dice cuánto, con {@link #ponerCabeza}). El dibujo ({@link CazadorRenderer}) mueve las piernas y los brazos
 * según lo que camina.
 *
 * No se lo puede lastimar, empujar ni tocar, no choca con nada y no se guarda en el mundo: el juego lo pone al empezar y
 * lo saca al terminar.
 */
public class Cazador extends Entity {
    /** A qué altura (desde el pie) está el visor. */
    static final double ALTO_VISOR = 11.2;

    private static final EntityDataAccessor<Boolean> OJOS = SynchedEntityData.defineId(Cazador.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> CABEZA = SynchedEntityData.defineId(Cazador.class, EntityDataSerializers.FLOAT);

    /** En el cliente: cuánto caminó (para mover las piernas) y el giro de la cabeza, en el tick anterior y en este. */
    float pasoAntes;
    float pasoAhora;
    float cabezaAntes;
    float cabezaAhora;
    /** En el cliente: adónde va (lo que mandó el servidor) y en cuántos ticks llega, para que se mueva suave. */
    private int pasos;
    private double haciaX;
    private double haciaY;
    private double haciaZ;
    private float haciaGiro;

    public Cazador(EntityType<? extends Cazador> tipo, Level nivel) {
        super(tipo, nivel);
        this.noPhysics = true;
    }

    /** Pone al Cazador parado en {@code lugar}, mirando para {@code giro} (grados), con los ojos apagados. */
    @Nullable
    static Cazador poner(ServerLevel nivel, Vec3 lugar, float giro) {
        Cazador cazador = Registro.CAZADOR.get().create(nivel);
        if (cazador == null) {
            return null;
        }
        cazador.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
        nivel.addFreshEntity(cazador);
        return cazador;
    }

    boolean ojos() {
        return entityData.get(OJOS);
    }

    void ponerOjos(boolean prendidos) {
        if (prendidos != entityData.get(OJOS)) {
            entityData.set(OJOS, prendidos);
        }
    }

    /** El giro de la cabeza, en grados, respecto del cuerpo (positivo: para su derecha). */
    float cabeza() {
        return entityData.get(CABEZA);
    }

    void ponerCabeza(float grados) {
        if (grados != entityData.get(CABEZA)) {
            entityData.set(CABEZA, grados);
        }
    }

    /**
     * Un paso hacia {@code destino}, a {@code velocidad} bloques por tick, girando de a poco para ese lado (si está
     * muy torcido, primero gira sin avanzar). true si ya llegó.
     */
    boolean caminarHacia(Vec3 destino, double velocidad) {
        double dx = destino.x - getX();
        double dz = destino.z - getZ();
        double distancia = Math.sqrt(dx * dx + dz * dz);
        if (distancia <= velocidad) {
            setPos(destino.x, getY(), destino.z);
            return true;
        }
        float quiere = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90.0F;
        float giro = Mth.approachDegrees(getYRot(), quiere, 6.0F);
        setYRot(giro);
        if (Math.abs(Mth.wrapDegrees(quiere - giro)) < 45.0F) {
            setPos(getX() + dx / distancia * velocidad, getY(), getZ() + dz / distancia * velocidad);
        }
        return false;
    }

    /** Para dónde mira el visor (en el plano): el giro del cuerpo más el de la cabeza. */
    Vec3 mirada() {
        float angulo = (getYRot() + cabeza()) * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(angulo), 0.0, Mth.cos(angulo));
    }

    /** Dónde está el visor. */
    Vec3 visor() {
        return position().add(0.0, ALTO_VISOR, 0.0);
    }

    /** Mientras va hacia donde dijo el servidor, los paquetes que no traen posición (o giro) siguen hacia ahí. */
    @Override
    public double lerpTargetX() {
        return pasos > 0 ? haciaX : getX();
    }

    @Override
    public double lerpTargetY() {
        return pasos > 0 ? haciaY : getY();
    }

    @Override
    public double lerpTargetZ() {
        return pasos > 0 ? haciaZ : getZ();
    }

    @Override
    public float lerpTargetYRot() {
        return pasos > 0 ? haciaGiro : getYRot();
    }

    @Override
    public void lerpTo(double x, double y, double z, float giro, float inclinacion, int ticks) {
        haciaX = x;
        haciaY = y;
        haciaZ = z;
        haciaGiro = giro;
        pasos = 3;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) {
            if (pasos > 0) {                                         // hacia donde dijo el servidor, en 3 ticks
                setPos(getX() + (haciaX - getX()) / pasos, getY() + (haciaY - getY()) / pasos, getZ() + (haciaZ - getZ()) / pasos);
                setYRot(getYRot() + Mth.wrapDegrees(haciaGiro - getYRot()) / pasos);
                pasos--;
            }
            pasoAntes = pasoAhora;
            double dx = getX() - xo;
            double dz = getZ() - zo;
            pasoAhora += (float) Math.sqrt(dx * dx + dz * dz);
            cabezaAntes = cabezaAhora;
            cabezaAhora = entityData.get(CABEZA);
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        datos.define(OJOS, false);
        datos.define(CABEZA, 0.0F);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag datos) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag datos) {
    }

    /** No le pasa nada. */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return false;
    }

    /** Los clics lo atraviesan. */
    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    /** Los brazos salen del cuerpo: que no deje de dibujarse cuando el cuerpo queda fuera de la pantalla. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return getBoundingBox().inflate(4.0, 1.0, 4.0);
    }
}
