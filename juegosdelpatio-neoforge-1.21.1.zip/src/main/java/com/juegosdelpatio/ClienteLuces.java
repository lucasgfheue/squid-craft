package com.juegosdelpatio;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * En el cliente: el parpadeo de las luces cuando para la música (ver {@link Parpadeo}). Es una capa de pantalla, arriba
 * del mundo y debajo del HUD: casi negra con las luces apagadas, y un destello suave cuando vuelven. Si en Accesibilidad
 * está activado "Ocultar destellos de rayos", no parpadea: solo se oscurece un poco mientras dura.
 */
final class ClienteLuces {
    /** Luces apagadas: casi todo negro (todavía se ve un poco por dónde se va). */
    private static final int APAGADAS = 0xC8000000;
    /** El primer tick con la luz de vuelta: un blanco cálido muy suave. */
    private static final int DESTELLO = 0x30FFF2D8;
    /** Para quien ocultó los destellos: un poco más oscuro, sin parpadear. */
    private static final int TENUE = 0x60000000;

    private ClienteLuces() {
    }

    /** Cada tick del cliente: avanza el parpadeo (en pausa, no). */
    static void tick(Minecraft minecraft) {
        if (Parpadeo.tiempoCliente < 0) {
            return;
        }
        if (minecraft.level == null) {
            Parpadeo.tiempoCliente = -1;                     // se fue del mundo: se corta
            return;
        }
        if (minecraft.isPaused()) {
            return;
        }
        Parpadeo.tiempoCliente++;
        if (Parpadeo.tiempoCliente >= Parpadeo.largoCliente) {
            Parpadeo.tiempoCliente = -1;
        }
    }

    /** La capa de pantalla (registrada en Cliente, arriba de los efectos de cámara). */
    static void dibujar(GuiGraphics grafico, DeltaTracker delta) {
        int t = Parpadeo.tiempoCliente;
        if (t < 0) {
            return;
        }
        int color;
        if (Minecraft.getInstance().options.hideLightningFlash().get()) {
            color = TENUE;
        } else if (Parpadeo.apagadas(t, Parpadeo.tipoCliente)) {
            color = APAGADAS;
        } else if (t > 0 && Parpadeo.apagadas(t - 1, Parpadeo.tipoCliente)) {
            color = DESTELLO;                                // la luz vuelve de golpe
        } else {
            return;
        }
        grafico.fill(0, 0, grafico.guiWidth(), grafico.guiHeight(), color);
    }
}
