package com.juegosdelpatio;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Lo que no se ve de una silla: el que se sienta "monta" este asiento invisible, que está en la silla. Cuando se
 * levanta (o sacan la silla), el asiento desaparece. No se guarda en el mundo.
 */
public class Asiento extends Entity {
    /**
     * A qué altura quedan los pies del que se sienta, respecto del piso de la silla: un poco más abajo, así queda
     * sentado sobre el asiento (que está a 9 píxeles) con las piernas para adelante.
     */
    private static final double ALTURA_PIES = -0.25;

    public Asiento(EntityType<? extends Asiento> tipo, Level nivel) {
        super(tipo, nivel);
        this.noPhysics = true;
    }

    /** Pone un asiento en la silla y sienta ahí a alguien, mirando para adelante. null si no se pudo. */
    @Nullable
    static Asiento sentar(ServerLevel nivel, BlockPos silla, Direction mira, LivingEntity quien) {
        Asiento asiento = Registro.ASIENTO.get().create(nivel);
        if (asiento == null) {
            return null;
        }
        float giro = mira.toYRot();
        asiento.moveTo(silla.getX() + 0.5, silla.getY(), silla.getZ() + 0.5, giro, 0.0F);
        nivel.addFreshEntity(asiento);
        if (!quien.startRiding(asiento, true)) {
            asiento.discard();
            return null;
        }
        asiento.positionRider(quien);                    // ya mismo encima del asiento (no recién en el tick siguiente)
        quien.setYRot(giro);
        quien.setYHeadRot(giro);
        quien.setYBodyRot(giro);
        return asiento;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag datos) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag datos) {
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) {
            return;
        }
        boolean sinNadie = getPassengers().isEmpty() && this.tickCount > 2;
        boolean sinSilla = !(level().getBlockState(blockPosition()).getBlock() instanceof SillaBlock);
        if (sinNadie || sinSilla) {
            discard();                                   // se levantó, o sacaron la silla
        }
    }

    @Override
    protected Vec3 getPassengerAttachmentPoint(Entity pasajero, EntityDimensions dimensiones, float escala) {
        // a los jugadores Minecraft les resta su "punto de vehículo" (0,6): se suma para que todos queden igual
        return new Vec3(0.0, ALTURA_PIES + pasajero.getVehicleAttachmentPoint(this).y, 0.0);
    }

    @Override
    protected boolean canAddPassenger(Entity pasajero) {
        return getPassengers().isEmpty();
    }

    @Override
    protected void positionRider(Entity pasajero, Entity.MoveFunction mover) {
        super.positionRider(pasajero, mover);
        mirarAdelante(pasajero);
    }

    @Override
    public void onPassengerTurned(Entity pasajero) {
        mirarAdelante(pasajero);
    }

    /** El cuerpo queda mirando para adelante; la cabeza puede girar, pero no tanto como para darse vuelta. */
    private void mirarAdelante(Entity pasajero) {
        pasajero.setYBodyRot(getYRot());
        float giro = Mth.wrapDegrees(pasajero.getYRot() - getYRot());
        float limitado = Mth.clamp(giro, -100.0F, 100.0F);
        pasajero.yRotO += limitado - giro;
        pasajero.setYRot(pasajero.getYRot() + limitado - giro);
        pasajero.setYHeadRot(pasajero.getYRot());
    }

    /** Al levantarse queda parado delante de la silla (del lado de la pista). */
    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity pasajero) {
        Direction mira = Direction.fromYRot(getYRot());
        return new Vec3(getX() + mira.getStepX() * 1.2, getY(), getZ() + mira.getStepZ() * 1.2);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return false;
    }
}
