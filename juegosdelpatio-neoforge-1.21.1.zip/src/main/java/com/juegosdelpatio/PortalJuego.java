package com.juegosdelpatio;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Portal de luz que aparece cuando se abre una puerta de la Torre de los Juegos: lleva al juego de ese número.
 * Con {@code regreso} es el portal de vuelta, que está en cada juego y lleva de nuevo a la sala.
 */
public class PortalJuego extends Block {
    public static final IntegerProperty JUEGO = IntegerProperty.create("juego", 1, 5);
    public static final BooleanProperty REGRESO = BooleanProperty.create("regreso");

    public PortalJuego(Properties propiedades) {
        super(propiedades);
        registerDefaultState(this.stateDefinition.any().setValue(JUEGO, 1).setValue(REGRESO, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> constructor) {
        constructor.add(JUEGO, REGRESO);
    }

    @Override
    protected void entityInside(BlockState estado, Level nivel, BlockPos pos, Entity entidad) {
        if (nivel.isClientSide()) {
            return;
        }
        if (entidad instanceof ServerPlayer jugador) {
            Portales.usar(jugador, estado.getValue(JUEGO), estado.getValue(REGRESO));
        } else if ((entidad instanceof JugadorBot || entidad instanceof Guardia) && !estado.getValue(REGRESO)) {
            Juego.entraAlPortal(entidad, estado.getValue(JUEGO));   // los bots y el comandante también van al juego
        }
    }

    /** Entre dos bloques de portal no se dibuja la cara del medio (se ve como una sola cortina de luz). */
    @Override
    protected boolean skipRendering(BlockState estado, BlockState vecino, Direction lado) {
        return vecino.is(this) || super.skipRendering(estado, vecino, lado);
    }

    @Override
    public void animateTick(BlockState estado, Level nivel, BlockPos pos, RandomSource azar) {
        if (azar.nextInt(3) == 0) {
            nivel.addParticle(ParticleTypes.END_ROD, pos.getX() + azar.nextDouble(), pos.getY() + azar.nextDouble(),
                    pos.getZ() + azar.nextDouble(), 0.0, 0.02, 0.0);
        }
    }
}
