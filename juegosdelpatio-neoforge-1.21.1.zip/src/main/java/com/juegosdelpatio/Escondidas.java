package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * El juego 3, "Las escondidas" (el día 3 del ciclo), en una escuela gigante de noche (ver gen_escondidas.py).
 *
 * <ol>
 *   <li>Después de las reglas, en el hall, se reparten dos equipos al azar: la mitad busca y la otra mitad se
 *       esconde (si son impares, se esconde uno más).</li>
 *   <li>Los buscadores esperan en la sala de profesores (con rejas en las puertas) con los ojos cerrados: 1 minuto.
 *       Mientras, los demás se esconden por toda la escuela.</li>
 *   <li>Se abren las rejas: los buscadores salen con una espada de netherite con filo V. Tienen 5 minutos para
 *       encontrar y matar a los escondidos. Los buscadores no se pueden matar entre ellos, y los escondidos no
 *       pueden pelear (sí empujar).</li>
 *   <li>En ese momento también se abre una de las seis salidas al patio, al azar: nadie sabe cuál. El escondido que
 *       la encuentra y la cruza, pasa (espera en el patio). Los buscadores no pueden salir.</li>
 *   <li>Cuando se termina el tiempo, todos los que siguen vivos pasan.</li>
 * </ol>
 */
public final class Escondidas {
    // ------------------------------------------------------------------ la arena (igual que gen_escondidas.py)
    public static final ResourceLocation ARENA = Complejo.id("escuela");
    /** Esquina de la plantilla escuela.nbt (150 x 9 x 132). */
    public static final BlockPos ORIGEN = new BlockPos(2925, 98, -60);
    static final int VERSION_ARENA = 1;
    /** Lo que ocupa la arena (la escuela y el patio), para mantenerla cargada mientras se juega. */
    static final int X0 = 2925;
    static final int X1 = 3074;
    static final int Z0 = -60;
    static final int Z1 = 71;
    /**
     * La escuela sola (sin el patio): ahí abajo, en y=98, una esponja marca cada escondite y una esponja mojada,
     * cada lugar por donde pasan los bots que buscan (el medio de cada sala y puntos del pasillo).
     */
    private static final int ESCUELA_Z0 = -48;
    private static final int MARCA_Y = 98;
    /** Donde se para la gente. */
    static final int PISO = 100;
    /** El podio del comandante, en el medio del hall, y los cuatro sargentos en las esquinas del hall. */
    static final Vec3 PODIO = new Vec3(3000.0, 102.0, 12.0);
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(2989.5, 100.0, 3.5), new Vec3(3010.5, 100.0, 3.5),
            new Vec3(2989.5, 100.0, 20.5), new Vec3(3010.5, 100.0, 20.5),
    };
    static final float[] GIROS_SARGENTOS = {-45.0F, 45.0F, -135.0F, 135.0F};
    /** La sala de profesores (adentro): ahí esperan los buscadores. */
    private static final int PROF_X0 = 2988;
    private static final int PROF_X1 = 2996;
    private static final int PROF_Z0 = -9;
    private static final int PROF_Z1 = 0;
    /** Las dos puertas de la sala de profesores, con rejas (x0, z0, x1, z1; de y 100 a 102). */
    static final int[][] REJAS_PROFESORES = {{2991, 1, 2993, 1}, {2997, -6, 2997, -4}};
    /** El patio, donde esperan los que salieron (y lejos de los faroles y los árboles). */
    private static final int PATIO_X0 = 2967;
    private static final int PATIO_X1 = 3033;
    private static final int PATIO_Z0 = -58;
    private static final int PATIO_Z1 = -51;

    /** Una salida al patio: el vestíbulo (pisarlo es salir), las rejas que lo cierran (de y 100 a 105) y el frente. */
    private record Salida(String nombre, int vx0, int vz0, int vx1, int vz1, int rx0, int rz0, int rx1, int rz1,
                          Vec3 frente) {
        boolean adentro(LivingEntity quien) {
            return quien.getX() >= vx0 && quien.getX() < vx1 + 1 && quien.getZ() >= vz0 && quien.getZ() < vz1 + 1
                    && quien.getY() < PISO + 3;
        }

        Vec3 centro() {
            return new Vec3((vx0 + vx1 + 1) / 2.0, PISO, (vz0 + vz1 + 1) / 2.0);
        }
    }

    static final Salida[] SALIDAS = {
            new Salida("oeste_norte", 2926, -32, 2928, -29, 2929, -32, 2929, -29, new Vec3(2931.5, 100.0, -29.5)),
            new Salida("este_norte", 3071, -32, 3073, -29, 3070, -32, 3070, -29, new Vec3(3068.5, 100.0, -29.5)),
            new Salida("oeste_sur", 2926, 52, 2928, 55, 2929, 52, 2929, 55, new Vec3(2931.5, 100.0, 54.5)),
            new Salida("este_sur", 3071, 52, 3073, 55, 3070, 52, 3070, 55, new Vec3(3068.5, 100.0, 54.5)),
            new Salida("norte", 2998, -47, 3001, -45, 2998, -44, 3001, -44, new Vec3(3000.5, 100.0, -41.5)),
            new Salida("sur", 2998, 68, 3001, 70, 2998, 67, 3001, 67, new Vec3(3000.5, 100.0, 65.5)),
    };

    // ------------------------------------------------------------------ reglas
    /** Para esconderse: 1 minuto (los buscadores, con los ojos cerrados). */
    static final int TIEMPO_ESCONDERSE = 60 * 20;
    /** Para buscar: 5 minutos. */
    static final int TIEMPO_BUSCAR = 5 * 60 * 20;
    /**
     * Hasta dónde ve un bot que busca, según la luz donde está el escondido (de 10 para arriba, de 7, de 4, o menos):
     * 56 bloques con mucha luz, 44 con luz media, 32 con poca y 14 a oscuras. Agachado, menos (0,6); corriendo, más (1,3).
     */
    private static final double[] VISTA = {14.0, 32.0, 44.0, 56.0};
    private static final double AGACHADO = 0.6;
    private static final double CORRIENDO = 1.3;
    /** Ve casi todo lo que tiene adelante y a los costados (más de 90 grados para cada lado de donde mira). */
    private static final double CAMPO_VISUAL = -0.1;
    /** Más cerca que esto, te nota aunque no te esté mirando (te oye): si corres, desde más lejos; agachado, casi no. */
    private static final double OIDO = 6.0;
    private static final double OIDO_CORRIENDO = 10.0;
    private static final double OIDO_AGACHADO = 2.5;
    /** Cuando un bot que busca ve a alguien, avisa: los otros que están a menos de esto van a ese lugar. */
    private static final double AVISO = 32.0;
    /**
     * De cada 100 rondas, en cuántas un bot que busca "oye algo" y va a mirar algún escondite de la zona donde hay un
     * jugador escondido (a menos de 12 bloques; 20 si está agachado, que hace menos ruido): no va derecho a él.
     */
    private static final int OLFATO = 15;
    /** Un jugador que busca y mira derecho a un bot escondido (a menos de esto, y si lo podría ver) lo hace correr. */
    private static final double MIRADA_JUGADOR = 16.0;
    /** Para que los bots encuentren caminos largos en la escuela: durante el juego ven más lejos. */
    private static final ResourceLocation MAS_ALCANCE = Complejo.id("escondidas_alcance");

    private enum Estado { NINGUNO, ESCONDERSE, BUSCAR, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int salidaAbierta = -1;
    private static int pasaron;
    private static final Set<UUID> BUSCADORES = new HashSet<>();
    private static final Set<UUID> ESCONDIDOS = new HashSet<>();
    /** Los escondidos que encontraron la salida (esperan en el patio). */
    private static final Set<UUID> SALIERON = new HashSet<>();
    private static final Map<UUID, JugadorBot> BOTS = new HashMap<>();
    /** Los escondites de la escuela (donde se para uno), y cuál tomó cada bot. */
    private static final List<BlockPos> ESCONDITES = new ArrayList<>();
    /** Por donde pasan los bots que buscan: el medio de cada sala y puntos del pasillo. */
    private static final List<BlockPos> RONDA = new ArrayList<>();
    /** De cada 100 veces, cuántas un bot que busca va derecho a un escondite (las demás, a mirar una sala). */
    private static final int VA_A_ESCONDITE = 40;
    private static final Map<BlockPos, UUID> OCUPADO = new HashMap<>();
    private static final Map<UUID, BlockPos> ESCONDITE_DE = new HashMap<>();
    /** Cuándo revisó un buscador cada escondite (para no volver enseguida al mismo), y adónde va cada uno. */
    private static final Map<BlockPos, Integer> REVISADO = new HashMap<>();
    private static final Map<UUID, BlockPos> REVISANDO = new HashMap<>();
    /** A qué bot escondido le pegaron (o vio a un buscador encima): sale corriendo. */
    private static final Map<UUID, UUID> ASUSTADO = new HashMap<>();
    /** A quién vio un buscador (y cuándo, y quién): el escondido que lo sabe sale corriendo. */
    private static final Map<UUID, Integer> VISTO = new HashMap<>();
    private static final Map<UUID, UUID> VISTO_POR = new HashMap<>();
    /** Cuándo se le avisó a cada jugador que lo vieron (para no llenarle la pantalla). */
    private static final Map<UUID, Integer> AVISADO = new HashMap<>();
    private static final List<LivingEntity> ESCONDIDOS_AHORA = new ArrayList<>();
    private static int escondidosDelTick = -1;
    /** Los avisos de los buscadores ("¡lo vi acá!"): dónde y cuándo. */
    private static final List<Pista> PISTAS = new ArrayList<>();

    private record Pista(Vec3 donde, int cuando) {
    }
    /** Ticks del juego entero (para REVISADO). */
    private static int reloj;

    private Escondidas() {
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean escondiendose() {
        return estado == Estado.ESCONDERSE;
    }

    static boolean buscando() {
        return estado == Estado.BUSCAR;
    }

    static int pasaron() {
        return pasaron;
    }

    static boolean esBuscador(LivingEntity quien) {
        return BUSCADORES.contains(quien.getUUID());
    }

    /** Se está escondiendo todavía (no lo encontraron ni salió). */
    static boolean esEscondido(LivingEntity quien) {
        return ESCONDIDOS.contains(quien.getUUID()) && !SALIERON.contains(quien.getUUID()) && quien.isAlive();
    }

    static boolean salio(LivingEntity quien) {
        return SALIERON.contains(quien.getUUID());
    }

    static int salidaAbierta() {
        return salidaAbierta;
    }

    static int cantidadSalidas() {
        return SALIDAS.length;
    }

    static Vec3 frenteSalida(int salida) {
        return SALIDAS[salida].frente();
    }

    static Vec3 centroSalida(int salida) {
        return SALIDAS[salida].centro();
    }

    public static boolean estaEnLaEscuela(LivingEntity quien) {
        return quien.getX() >= X0 && quien.getX() < X1 + 1 && quien.getZ() >= Z0 && quien.getZ() < Z1 + 1;
    }

    // ------------------------------------------------------------------ empezar
    /** Termina de hablar el comandante: se reparten los equipos, los buscadores a la sala de profesores. */
    static void empezar(ServerLevel complejo, List<LivingEntity> gente) {
        olvidar();
        buscarEscondites(complejo);
        ponerRejas(complejo);
        RandomSource azar = complejo.getRandom();
        List<LivingEntity> mezcla = new ArrayList<>(gente);
        for (int i = mezcla.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            LivingEntity cambio = mezcla.get(i);
            mezcla.set(i, mezcla.get(j));
            mezcla.set(j, cambio);
        }
        int buscan = mezcla.size() / 2;                                  // mitad y mitad (impares: uno más se esconde)
        List<BlockPos> sala = lugaresProfesores(complejo);
        for (int i = 0; i < mezcla.size(); i++) {
            LivingEntity quien = mezcla.get(i);
            boolean busca = i < buscan;
            (busca ? BUSCADORES : ESCONDIDOS).add(quien.getUUID());
            if (quien instanceof JugadorBot bot) {
                BOTS.put(bot.getUUID(), bot);
                bot.getNavigation().stop();
                bot.setCustomNameVisible(busca);                         // al que se esconde no se le ve el nombre
                AttributeInstance alcance = bot.getAttribute(Attributes.FOLLOW_RANGE);
                if (alcance != null) {
                    alcance.addOrUpdateTransientModifier(new AttributeModifier(MAS_ALCANCE, 64.0,
                            AttributeModifier.Operation.ADD_VALUE));
                }
            }
            if (busca) {
                BlockPos lugar = sala.isEmpty() ? BlockPos.containing(PODIO) : sala.get(i % sala.size());
                float giro = azar.nextFloat() * 360.0F;
                if (quien instanceof ServerPlayer jugador) {
                    jugador.teleportTo(complejo, lugar.getX() + 0.5, lugar.getY(), lugar.getZ() + 0.5, giro, 0.0F);
                } else {
                    quien.moveTo(lugar.getX() + 0.5, lugar.getY(), lugar.getZ() + 0.5, giro, 0.0F);
                }
                quien.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, TIEMPO_ESCONDERSE + 40, 0, false, false));
            }
            if (quien instanceof ServerPlayer jugador) {
                Juego.titulo(jugador, Component.translatable(busca ? "titulo.juegosdelpatio.buscas"
                                : "titulo.juegosdelpatio.te_escondes").withStyle(busca ? ChatFormatting.RED : ChatFormatting.AQUA),
                        Component.translatable(busca ? "titulo.juegosdelpatio.buscas_detalle"
                                : "titulo.juegosdelpatio.te_escondes_detalle", TIEMPO_ESCONDERSE / 20)
                                .withStyle(ChatFormatting.GRAY), 5, 70, 15);
                jugador.sendSystemMessage(Component.translatable(busca ? "mensaje.juegosdelpatio.como_buscar"
                        : "mensaje.juegosdelpatio.como_esconderse").withStyle(ChatFormatting.GRAY));
                jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, busca ? 0.7F : 1.3F);
            }
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.escondidas_equipos", buscan,
                mezcla.size() - buscan, TIEMPO_ESCONDERSE / 20));
        estado = Estado.ESCONDERSE;
        tiempo = 0;
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    /** Avanza el juego. true cuando se terminó. */
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        reloj++;
        switch (estado) {
            case ESCONDERSE -> {
                int faltan = TIEMPO_ESCONDERSE - tiempo;
                if (faltan > 0 && faltan <= 100 && faltan % 20 == 0) {
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 1.0F, 1.0F);
                        if (esBuscador(jugador)) {
                            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.cuenta",
                                    faltan / 20).withStyle(ChatFormatting.RED), true);
                        }
                    }
                }
                if (tiempo % 10 == 1) {
                    Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.escondidas_esconderse",
                                    reloj(Math.max(0, faltan)), contarEscondidos(complejo), BUSCADORES.size()),
                            BossEvent.BossBarColor.BLUE, Math.max(0, faltan) / (float) TIEMPO_ESCONDERSE);
                }
                if (faltan <= 0) {
                    soltarBuscadores(complejo);
                }
            }
            case BUSCAR -> {
                if (tiempo % 2 == 0) {
                    revisarSalidas(complejo);
                }
                if (tiempo % 40 == 0) {
                    ASUSTADO.keySet().removeIf(id -> !BOTS.containsKey(id));
                }
                int quedan = contarEscondidos(complejo);
                if (tiempo % 10 == 1) {
                    Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.escondidas_buscar",
                                    reloj(Math.max(0, TIEMPO_BUSCAR - tiempo)), quedan, SALIERON.size()),
                            BossEvent.BossBarColor.RED, Math.max(0, TIEMPO_BUSCAR - tiempo) / (float) TIEMPO_BUSCAR);
                }
                if (tiempo >= TIEMPO_BUSCAR || quedan == 0) {
                    terminarJuego(complejo, quedan == 0);
                }
            }
            default -> {
            }
        }
        return estado == Estado.TERMINADO;
    }

    /** Se terminó el minuto: se abren las rejas, una salida al azar, y los buscadores salen con su espada. */
    private static void soltarBuscadores(ServerLevel complejo) {
        estado = Estado.BUSCAR;
        tiempo = 0;
        sacarRejas(complejo, true);
        salidaAbierta = complejo.getRandom().nextInt(SALIDAS.length);
        Salida salida = SALIDAS[salidaAbierta];
        for (int x = salida.rx0(); x <= salida.rx1(); x++) {
            for (int z = salida.rz0(); z <= salida.rz1(); z++) {
                for (int y = PISO; y < PISO + 6; y++) {
                    complejo.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                }
            }
        }
        complejo.playSound(null, salida.centro().x, PISO + 1, salida.centro().z, SoundEvents.IRON_DOOR_OPEN,
                SoundSource.BLOCKS, 2.0F, 0.7F);
        ItemStack espada = espadaDelBuscador(complejo);
        for (LivingEntity quien : enJuego(complejo)) {
            boolean busca = esBuscador(quien);
            if (busca) {
                quien.removeEffect(MobEffects.BLINDNESS);
                if (quien instanceof ServerPlayer jugador) {
                    if (jugador.getMainHandItem().isEmpty()) {
                        jugador.setItemInHand(InteractionHand.MAIN_HAND, espada.copy());
                    } else if (!jugador.getInventory().add(espada.copy())) {
                        jugador.drop(espada.copy(), false);
                    }
                } else if (quien instanceof JugadorBot bot) {
                    bot.setItemSlot(EquipmentSlot.MAINHAND, espada.copy());
                    bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
                }
            }
            if (quien instanceof ServerPlayer jugador) {
                Juego.titulo(jugador, Component.translatable(busca ? "titulo.juegosdelpatio.a_buscar"
                                : "titulo.juegosdelpatio.ya_salen").withStyle(busca ? ChatFormatting.RED : ChatFormatting.GOLD),
                        Component.translatable(busca ? "titulo.juegosdelpatio.a_buscar_detalle"
                                : "titulo.juegosdelpatio.ya_salen_detalle").withStyle(ChatFormatting.GRAY), 5, 50, 15);
                jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, busca ? 0.8F : 1.2F);
            }
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.escondidas_salen", TIEMPO_BUSCAR / 1200));
    }

    /** El que se esconde y pisa el vestíbulo de la salida abierta, pasa; el buscador vuelve para adentro. */
    private static void revisarSalidas(ServerLevel complejo) {
        if (salidaAbierta < 0) {
            return;
        }
        Salida salida = SALIDAS[salidaAbierta];
        for (LivingEntity quien : enJuego(complejo)) {
            if (!salida.adentro(quien)) {
                continue;
            }
            if (esBuscador(quien)) {
                Vec3 frente = salida.frente();
                if (quien instanceof ServerPlayer jugador) {
                    jugador.teleportTo(complejo, frente.x, frente.y, frente.z, jugador.getYRot(), jugador.getXRot());
                    jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.buscador_no_sale")
                            .withStyle(ChatFormatting.RED), true);
                } else {
                    quien.moveTo(frente.x, frente.y, frente.z, quien.getYRot(), 0.0F);
                }
                continue;
            }
            SALIERON.add(quien.getUUID());
            soltarEscondite(quien.getUUID());
            Vec3 patio = lugarEnElPatio(complejo.getRandom());
            if (quien instanceof ServerPlayer jugador) {
                jugador.teleportTo(complejo, patio.x, patio.y, patio.z, 180.0F, 0.0F);
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.saliste").withStyle(ChatFormatting.GREEN),
                        Component.translatable("titulo.juegosdelpatio.saliste_detalle").withStyle(ChatFormatting.GRAY),
                        5, 60, 15);
                jugador.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
            } else if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                pararse(bot);
                bot.moveTo(patio.x, patio.y, patio.z, 180.0F, 0.0F);
            }
            String nombre = quien instanceof JugadorBot bot ? bot.nombre() : quien.getName().getString();
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio.alguien_salio", nombre)
                        .withStyle(ChatFormatting.GREEN));
            }
        }
    }

    /** Se terminó el tiempo (o no queda nadie escondido): todos los que siguen vivos pasan. */
    private static void terminarJuego(ServerLevel complejo, boolean nadieQueda) {
        estado = Estado.TERMINADO;
        pasaron = enJuego(complejo).size();
        Juego.decir(complejo, Component.translatable(nadieQueda ? "juego.juegosdelpatio.escondidas_nadie"
                : "juego.juegosdelpatio.escondidas_tiempo"));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.6F);
        }
    }

    // ------------------------------------------------------------------ golpes y muertes
    /**
     * En las escondidas solo vale que un buscador lastime a un escondido (mientras se busca). Entre buscadores está
     * prohibido, y los escondidos no pueden pelear: esos golpes no hacen nada (y se le avisa al que pegó).
     */
    static void alRecibirGolpe(LivingIncomingDamageEvent evento) {
        LivingEntity victima = evento.getEntity();
        Entity fuente = evento.getSource().getEntity();
        if (!(fuente instanceof LivingEntity atacante) || atacante == victima
                || !(victima instanceof Player || victima instanceof JugadorBot)
                || !(atacante instanceof Player || atacante instanceof JugadorBot)) {
            return;                                                      // caídas, guardias...: lo de siempre
        }
        if (estado == Estado.BUSCAR && esBuscador(atacante) && esEscondido(victima)) {
            if (victima instanceof JugadorBot bot) {
                ASUSTADO.put(bot.getUUID(), atacante.getUUID());          // le pegaron: sale corriendo
            }
            return;                                                      // ¡lo encontró!
        }
        evento.setCanceled(true);
        if (estado == Estado.BUSCAR && atacante instanceof ServerPlayer jugador) {
            String aviso = esBuscador(atacante) && esBuscador(victima) ? "no_entre_buscadores"
                    : ESCONDIDOS.contains(atacante.getUUID()) ? "no_pelear_escondido" : null;
            if (aviso != null) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio." + aviso)
                        .withStyle(ChatFormatting.RED), true);
            }
        }
    }

    /** Murió uno de los que se escondían (lo encontraron): queda eliminado. */
    static void alMorir(LivingDeathEvent evento) {
        LivingEntity muerto = evento.getEntity();
        if (estado == Estado.NINGUNO || muerto.level().isClientSide() || !(muerto.level() instanceof ServerLevel complejo)
                || !(ESCONDIDOS.contains(muerto.getUUID()) || BUSCADORES.contains(muerto.getUUID()))) {
            return;
        }
        soltarEscondite(muerto.getUUID());
        BOTS.remove(muerto.getUUID());
        String quien = muerto instanceof JugadorBot bot ? bot.nombre() : muerto.getName().getString();
        Juego.anotarEliminado(complejo, muerto, "te_encontraron");
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (jugador != muerto) {
                jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio.encontraron_a", quien)
                        .withStyle(ChatFormatting.DARK_RED));
            }
        }
    }

    // ------------------------------------------------------------------ para los bots
    /**
     * Un escondite libre para el bot: al azar entre los libres, mejor lejos de {@code lejosDe} (si hay de quién
     * alejarse) y no tan lejos de él. null si no queda ninguno.
     */
    @Nullable
    static BlockPos reservarEscondite(JugadorBot bot, @Nullable Vec3 lejosDe) {
        soltarEscondite(bot.getUUID());
        RandomSource azar = bot.getRandom();
        BlockPos mejor = null;
        double mejorPuntaje = -Double.MAX_VALUE;
        for (int intento = 0; intento < 24 && !ESCONDITES.isEmpty(); intento++) {
            BlockPos lugar = ESCONDITES.get(azar.nextInt(ESCONDITES.size()));
            if (OCUPADO.containsKey(lugar)) {
                continue;
            }
            double distancia = Math.sqrt(bot.distanceToSqr(lugar.getX() + 0.5, lugar.getY(), lugar.getZ() + 0.5));
            double puntaje = -Math.abs(distancia - 45.0) + azar.nextDouble() * 20.0;       // ni muy cerca ni muy lejos
            if (lejosDe != null) {
                // lejos del buscador, y para el otro lado: no pasar al lado de él
                Vec3 hacia = new Vec3(lugar.getX() + 0.5 - bot.getX(), 0.0, lugar.getZ() + 0.5 - bot.getZ()).normalize();
                Vec3 peligro = new Vec3(lejosDe.x - bot.getX(), 0.0, lejosDe.z - bot.getZ()).normalize();
                puntaje = Math.sqrt(lejosDe.distanceToSqr(lugar.getX() + 0.5, lugar.getY(), lugar.getZ() + 0.5))
                        - distancia * 0.5 - Math.max(0.0, hacia.dot(peligro)) * 40.0 + azar.nextDouble() * 6.0;
            }
            if (puntaje > mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = lugar;
            }
        }
        if (mejor != null) {
            OCUPADO.put(mejor, bot.getUUID());
            ESCONDITE_DE.put(bot.getUUID(), mejor);
        }
        return mejor;
    }

    static void soltarEscondite(UUID quien) {
        BlockPos antes = ESCONDITE_DE.remove(quien);
        if (antes != null) {
            OCUPADO.remove(antes);
        }
    }

    /**
     * Adónde va a mirar un buscador: casi siempre el medio de una sala o un punto del pasillo (y a veces derecho a un
     * escondite), uno cercano que nadie haya revisado hace poco.
     */
    @Nullable
    static BlockPos paraRevisar(JugadorBot buscador) {
        RandomSource azar = buscador.getRandom();
        if (azar.nextInt(100) < OLFATO && buscador.level() instanceof ServerLevel complejo) {
            List<ServerPlayer> escondidos = new ArrayList<>();
            for (ServerPlayer jugador : complejo.players()) {
                if (esEscondido(jugador) && !jugador.isSpectator()) {
                    escondidos.add(jugador);
                }
            }
            if (!escondidos.isEmpty()) {                                 // "oyó algo": va a mirar por esa zona
                ServerPlayer jugador = escondidos.get(azar.nextInt(escondidos.size()));
                BlockPos cerca = esconditeCerca(buscador, jugador.position(), jugador.isShiftKeyDown() ? 20.0 : 12.0, true);
                if (cerca != null) {
                    return cerca;
                }
            }
        }
        List<BlockPos> lugares = RONDA.isEmpty() || azar.nextInt(100) < VA_A_ESCONDITE ? ESCONDITES : RONDA;
        BlockPos mejor = null;
        double mejorPuntaje = Double.MAX_VALUE;
        for (BlockPos lugar : lugares) {
            Integer cuando = REVISADO.get(lugar);
            if (cuando != null && reloj - cuando < 90 * 20 || REVISANDO.containsValue(lugar)) {
                continue;
            }
            double puntaje = Math.sqrt(buscador.distanceToSqr(lugar.getX() + 0.5, lugar.getY(), lugar.getZ() + 0.5))
                    + azar.nextDouble() * 25.0;
            if (puntaje < mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = lugar;
            }
        }
        if (mejor == null && !lugares.isEmpty()) {
            mejor = lugares.get(azar.nextInt(lugares.size()));
        }
        if (mejor != null) {
            REVISANDO.put(buscador.getUUID(), mejor);
        }
        return mejor;
    }

    static void revisado(JugadorBot buscador, BlockPos lugar) {
        REVISADO.put(lugar, reloj);
        REVISANDO.remove(buscador.getUUID());
    }

    /** Ya no va a ese lugar (lo llamaron de otro lado): que lo pueda revisar otro. */
    static void dejarDeRevisar(JugadorBot buscador) {
        REVISANDO.remove(buscador.getUUID());
    }

    /**
     * Un escondite a menos de {@code radio} de {@code punto} que nadie revisó hace poco: el más cercano (para revisar
     * alrededor de donde se le perdió alguien) o uno cualquiera de la zona (cuando "oyó algo"). null si no hay.
     */
    @Nullable
    static BlockPos esconditeCerca(JugadorBot buscador, Vec3 punto, double radio, boolean cualquiera) {
        BlockPos mejor = null;
        double mejorPuntaje = Double.MAX_VALUE;
        RandomSource azar = buscador.getRandom();
        for (BlockPos lugar : ESCONDITES) {
            Integer cuando = REVISADO.get(lugar);
            double d = punto.distanceToSqr(lugar.getX() + 0.5, lugar.getY(), lugar.getZ() + 0.5);
            if (d > radio * radio || cuando != null && reloj - cuando < 20 * 20 || REVISANDO.containsValue(lugar)) {
                continue;
            }
            double puntaje = cualquiera ? azar.nextDouble() : d + azar.nextDouble() * 9.0;
            if (puntaje < mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = lugar;
            }
        }
        if (mejor != null) {
            REVISANDO.put(buscador.getUUID(), mejor);
        }
        return mejor;
    }

    /**
     * El buscador vio a alguien: avisa a los otros (dónde) y el escondido se entera de que lo vieron (un bot sale
     * corriendo; a un jugador se le avisa en la pantalla, como mucho cada 3 segundos).
     */
    static void loVi(JugadorBot buscador, LivingEntity escondido) {
        VISTO.put(escondido.getUUID(), reloj);
        VISTO_POR.put(escondido.getUUID(), buscador.getUUID());
        PISTAS.removeIf(pista -> reloj - pista.cuando() > 160 || pista.donde().distanceToSqr(escondido.position()) < 36.0);
        PISTAS.add(new Pista(escondido.position(), reloj));
        Integer antes = AVISADO.get(escondido.getUUID());
        if (escondido instanceof ServerPlayer jugador && (antes == null || reloj - antes > 60)) {
            AVISADO.put(jugador.getUUID(), reloj);
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.te_vio", buscador.nombre())
                    .withStyle(ChatFormatting.RED), true);
        }
    }

    /** Un aviso reciente (de los últimos 8 segundos) a menos de 32 bloques, para ir a ayudar. null si no hay. */
    @Nullable
    static Vec3 pistaCerca(JugadorBot buscador) {
        Vec3 mejor = null;
        double cerca = AVISO * AVISO;
        for (Pista pista : PISTAS) {
            double d = buscador.distanceToSqr(pista.donde());
            if (reloj - pista.cuando() <= 160 && d < cerca && d > 9.0) {
                cerca = d;
                mejor = pista.donde();
            }
        }
        return mejor;
    }

    /** Si a este bot escondido lo vio un buscador hace muy poco: ese buscador (para escaparse), o null. */
    @Nullable
    static LivingEntity loVieron(JugadorBot bot) {
        Integer cuando = VISTO.get(bot.getUUID());
        if (cuando == null || reloj - cuando > 20 || !(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        UUID quien = VISTO_POR.get(bot.getUUID());
        Entity buscador = quien == null ? null : complejo.getEntity(quien);
        return buscador instanceof LivingEntity vivo && vivo.isAlive() ? vivo : null;
    }

    /** El escondido más cercano que el bot buscador ve (o que oye, si está cerca). */
    @Nullable
    static LivingEntity aQuienVe(JugadorBot buscador) {
        if (!(buscador.level() instanceof ServerLevel complejo)) {
            return null;
        }
        double lejos = VISTA[VISTA.length - 1] * CORRIENDO;
        double cerca = lejos * lejos;
        LivingEntity mejor = null;
        for (LivingEntity otro : escondidosAhora(complejo)) {
            double d2 = buscador.distanceToSqr(otro);
            if (d2 < cerca && otro != buscador && esEscondido(otro) && Math.abs(otro.getY() - buscador.getY()) < 4.0
                    && ve(buscador, otro)) {
                cerca = d2;                                              // el más cercano que ve
                mejor = otro;
            }
        }
        return mejor;
    }

    /** Los que siguen escondidos (se busca una sola vez por tick, para todos los buscadores). */
    private static List<LivingEntity> escondidosAhora(ServerLevel complejo) {
        if (escondidosDelTick != reloj) {
            escondidosDelTick = reloj;
            ESCONDIDOS_AHORA.clear();
            for (UUID id : ESCONDIDOS) {
                if (complejo.getEntity(id) instanceof LivingEntity vivo && esEscondido(vivo)) {
                    ESCONDIDOS_AHORA.add(vivo);
                }
            }
        }
        return ESCONDIDOS_AHORA;
    }

    /**
     * ¿El buscador ve al escondido? Depende de la luz donde está el escondido, de si está agachado o corriendo, de para
     * dónde mira el buscador (ve casi todo lo de adelante y los costados) y de que no haya nada en el medio (alcanza
     * con verle la cabeza o el cuerpo; a través de vidrios y rejas, también). Cerca, lo oye aunque no lo mire.
     */
    static boolean ve(LivingEntity buscador, LivingEntity escondido) {
        double d2 = buscador.distanceToSqr(escondido);
        double alcance = alcanceVista(buscador.level(), escondido);
        if (d2 > alcance * alcance) {
            return false;
        }
        double oido = escondido.isCrouching() || escondido.isShiftKeyDown() ? OIDO_AGACHADO
                : escondido.isSprinting() ? OIDO_CORRIENDO : OIDO;
        if (d2 > oido * oido) {
            Vec3 mira = mirada(buscador);                                // para donde mira la cabeza
            Vec3 hacia = escondido.getEyePosition().subtract(buscador.getEyePosition()).normalize();
            if (mira.dot(hacia) < CAMPO_VISUAL) {
                return false;                                            // lo tiene a la espalda
            }
        }
        return hayVista(buscador, escondido);
    }

    /** Se ven: no hay nada entre los ojos de uno y la cabeza o el cuerpo del otro (los vidrios y las rejas no tapan). */
    static boolean hayVista(LivingEntity desde, LivingEntity otro) {
        return seVe(desde, otro.getEyePosition()) || seVe(desde, otro.position().add(0.0, otro.getBbHeight() * 0.45, 0.0));
    }

    private static boolean seVe(LivingEntity desde, Vec3 punto) {
        Vec3 ojos = desde.getEyePosition();
        if (ojos.distanceToSqr(punto) > 128.0 * 128.0) {
            return false;
        }
        return desde.level().clip(new ClipContext(ojos, punto, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, desde))
                .getType() == HitResult.Type.MISS;
    }

    private static double alcanceVista(Level nivel, LivingEntity escondido) {
        int luz = nivel.getBrightness(LightLayer.BLOCK, BlockPos.containing(escondido.getEyePosition()));
        double alcance = VISTA[luz >= 10 ? 3 : luz >= 7 ? 2 : luz >= 4 ? 1 : 0];
        if (escondido.isCrouching() || escondido.isShiftKeyDown()) {
            alcance *= AGACHADO;
        } else if (escondido.isSprinting()) {
            alcance *= CORRIENDO;
        }
        return alcance;
    }

    /**
     * De quién tiene que escaparse un bot escondido, o null: de un buscador que lo vio recién, de uno que está cerca
     * (a menos de {@code radio}, y lo ve), o de un jugador que busca y lo está mirando.
     */
    @Nullable
    static LivingEntity peligro(JugadorBot escondido, double radio) {
        if (!(escondido.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity vio = loVieron(escondido);
        if (vio != null) {
            return vio;
        }
        double alcanceMirada = Math.min(MIRADA_JUGADOR, alcanceVista(complejo, escondido));
        double lejos = Math.max(radio, alcanceMirada);
        for (LivingEntity otro : complejo.getEntitiesOfClass(LivingEntity.class, escondido.getBoundingBox().inflate(lejos, 3.0, lejos),
                otro -> otro.isAlive() && esBuscador(otro))) {
            double d2 = escondido.distanceToSqr(otro);
            boolean cerca = d2 < radio * radio;
            boolean loMira = otro instanceof Player && d2 < alcanceMirada * alcanceMirada
                    && mirada(otro).dot(escondido.getEyePosition().subtract(otro.getEyePosition()).normalize()) > 0.9;
            if ((cerca || loMira) && hayVista(escondido, otro)) {
                return otro;
            }
        }
        return null;
    }

    /** Para dónde mira: la cabeza de un bot (que puede mirar para un costado mientras camina); la cámara de un jugador. */
    private static Vec3 mirada(LivingEntity quien) {
        double giro = Math.toRadians(-(quien instanceof Player ? quien.getYRot() : quien.getYHeadRot()));
        double cabeceo = Math.toRadians(quien.getXRot());
        return new Vec3(Math.sin(giro) * Math.cos(cabeceo), -Math.sin(cabeceo), Math.cos(giro) * Math.cos(cabeceo));
    }

    /** Si al bot escondido le pegaron hace poco: de quién escaparse (y se le pasa el susto). */
    @Nullable
    static LivingEntity susto(JugadorBot bot) {
        UUID de = ASUSTADO.remove(bot.getUUID());
        if (de == null || !(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        Entity quien = complejo.getEntity(de);
        return quien instanceof LivingEntity vivo && vivo.isAlive() ? vivo : null;
    }

    /** Agacharse (escondido) o pararse. */
    static void agacharse(JugadorBot bot) {
        bot.setShiftKeyDown(true);
        bot.setPose(Pose.CROUCHING);
    }

    static void pararse(JugadorBot bot) {
        if (bot.isShiftKeyDown() || bot.getPose() == Pose.CROUCHING) {
            bot.setShiftKeyDown(false);
            bot.setPose(Pose.STANDING);
        }
    }

    // ------------------------------------------------------------------ fin
    /** Al terminar (o cortarse) el juego: rejas en su lugar, sin espadas, sin ojos cerrados, y se olvida todo. */
    static void limpiar(ServerLevel complejo) {
        if (EstadoComplejo.de(complejo.getServer()).versionEscuela() == VERSION_ARENA) {
            ponerRejas(complejo);
        }
        for (ServerPlayer jugador : complejo.players()) {
            sacarEspadas(jugador.getInventory());
            if (BUSCADORES.contains(jugador.getUUID())) {
                jugador.removeEffect(MobEffects.BLINDNESS);
            }
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> BOTS.containsKey(bot.getUUID()))) {
            if (esEspada(bot.getMainHandItem())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
            bot.removeEffect(MobEffects.BLINDNESS);
            bot.setCustomNameVisible(true);
            pararse(bot);
            AttributeInstance alcance = bot.getAttribute(Attributes.FOLLOW_RANGE);
            if (alcance != null) {
                alcance.removeModifier(MAS_ALCANCE);
            }
        }
        for (ItemEntity tirada : complejo.getEntitiesOfClass(ItemEntity.class, new AABB(X0, PISO - 2, Z0, X1 + 1, PISO + 8, Z1 + 1),
                tirada -> esEspada(tirada.getItem()))) {
            tirada.discard();
        }
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        salidaAbierta = -1;
        BUSCADORES.clear();
        ESCONDIDOS.clear();
        SALIERON.clear();
        BOTS.clear();
        OCUPADO.clear();
        ESCONDITE_DE.clear();
        REVISADO.clear();
        REVISANDO.clear();
        ASUSTADO.clear();
        VISTO.clear();
        VISTO_POR.clear();
        AVISADO.clear();
        PISTAS.clear();
        ESCONDIDOS_AHORA.clear();
        escondidosDelTick = -1;
    }

    // ------------------------------------------------------------------ la arena
    /** Dónde aparece quien llega (por el portal o llevado): en el hall, alrededor del podio. */
    static Vec3 lugarDeSalida(RandomSource azar) {
        double angulo = azar.nextDouble() * Math.PI * 2.0;
        double radio = 4.0 + azar.nextDouble() * 4.0;
        return new Vec3(Math.floor(PODIO.x + radio * Math.cos(angulo)) + 0.5, PISO,
                Math.floor(PODIO.z + radio * Math.sin(angulo)) + 0.5);
    }

    private static Vec3 lugarEnElPatio(RandomSource azar) {
        return new Vec3(PATIO_X0 + azar.nextInt(PATIO_X1 - PATIO_X0 + 1) + 0.5, PISO,
                PATIO_Z0 + azar.nextInt(PATIO_Z1 - PATIO_Z0 + 1) + 0.5);
    }

    /**
     * Construye la escuela la primera vez (o si cambió de versión). Antes saca la plataforma provisoria del juego 3
     * (la que aparece si alguien entra al portal 3 antes de que el juego exista). false si falta la estructura.
     */
    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estado = EstadoComplejo.de(complejo.getServer());
        if (estado.versionEscuela() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        int cx = Portales.SEPARACION_JUEGOS * 3;
        for (BlockPos pos : BlockPos.betweenClosed(cx - 14, Portales.ALTURA_JUEGOS - 1, -14, cx + 14, Portales.ALTURA_JUEGOS + 6, 14)) {
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estado.setVersionEscuela(VERSION_ARENA);
        ESCONDITES.clear();                                              // se vuelven a buscar
        RONDA.clear();
        return true;
    }

    /** Busca las esponjas de debajo del piso: escondites y lugares de la ronda (donde se para uno, arriba). */
    private static void buscarEscondites(ServerLevel complejo) {
        if (!ESCONDITES.isEmpty()) {
            return;
        }
        RONDA.clear();
        for (int x = X0; x <= X1; x++) {
            for (int z = ESCUELA_Z0; z <= Z1; z++) {
                BlockState marca = complejo.getBlockState(new BlockPos(x, MARCA_Y, z));
                boolean escondite = marca.is(Blocks.SPONGE);
                if (!escondite && !marca.is(Blocks.WET_SPONGE)) {
                    continue;
                }
                for (int y = PISO; y <= PISO + 3; y++) {
                    BlockPos lugar = new BlockPos(x, y, z);
                    if (sePuedeParar(complejo, lugar)) {
                        (escondite ? ESCONDITES : RONDA).add(lugar);
                        break;
                    }
                }
            }
        }
    }

    private static boolean sePuedeParar(ServerLevel complejo, BlockPos lugar) {
        BlockPos abajo = lugar.below();
        return !complejo.getBlockState(abajo).getCollisionShape(complejo, abajo).isEmpty()
                && complejo.getBlockState(lugar).getCollisionShape(complejo, lugar).isEmpty()
                && complejo.getBlockState(lugar.above()).getCollisionShape(complejo, lugar.above()).isEmpty();
    }

    /** Los lugares libres de la sala de profesores (para repartir a los buscadores). */
    private static List<BlockPos> lugaresProfesores(ServerLevel complejo) {
        List<BlockPos> lugares = new ArrayList<>();
        for (int x = PROF_X0; x <= PROF_X1; x++) {
            for (int z = PROF_Z0; z <= PROF_Z1; z++) {
                BlockPos lugar = new BlockPos(x, PISO, z);
                if (sePuedeParar(complejo, lugar)) {
                    lugares.add(lugar);
                }
            }
        }
        return lugares;
    }

    /** Rejas en las dos puertas de la sala de profesores y en las seis salidas (como en la plantilla). */
    private static void ponerRejas(ServerLevel complejo) {
        sacarRejas(complejo, false);
        for (Salida salida : SALIDAS) {
            for (int x = salida.rx0(); x <= salida.rx1(); x++) {
                for (int z = salida.rz0(); z <= salida.rz1(); z++) {
                    for (int y = PISO; y < PISO + 6; y++) {
                        BlockPos pos = new BlockPos(x, y, z);
                        if (!complejo.getBlockState(pos).is(Blocks.IRON_BARS)) {
                            complejo.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), Block.UPDATE_ALL);
                        }
                    }
                }
            }
        }
    }

    /** Saca (o pone, con {@code sacar} en false) las rejas de la sala de profesores. */
    private static void sacarRejas(ServerLevel complejo, boolean sacar) {
        for (int[] puerta : REJAS_PROFESORES) {
            for (int x = puerta[0]; x <= puerta[2]; x++) {
                for (int z = puerta[1]; z <= puerta[3]; z++) {
                    for (int y = PISO; y < PISO + 3; y++) {
                        BlockPos pos = new BlockPos(x, y, z);
                        boolean hay = complejo.getBlockState(pos).is(Blocks.IRON_BARS);
                        if (sacar && hay) {
                            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                        } else if (!sacar && !hay) {
                            complejo.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), Block.UPDATE_ALL);
                        }
                    }
                }
            }
        }
        if (sacar) {
            complejo.playSound(null, PROF_X1 + 0.5, PISO + 1, (PROF_Z0 + PROF_Z1) / 2.0, SoundEvents.IRON_DOOR_OPEN,
                    SoundSource.BLOCKS, 2.0F, 0.6F);
        }
    }

    // ------------------------------------------------------------------ la espada
    /** Espada de netherite con filo V, irrompible, con su nombre (y una marca para sacarla al final). */
    private static ItemStack espadaDelBuscador(ServerLevel complejo) {
        ItemStack espada = new ItemStack(Items.NETHERITE_SWORD);
        Holder<Enchantment> filo = complejo.registryAccess().registryOrThrow(Registries.ENCHANTMENT)
                .getHolderOrThrow(Enchantments.SHARPNESS);
        espada.enchant(filo, 5);
        espada.set(DataComponents.UNBREAKABLE, new Unbreakable(true));
        espada.set(DataComponents.ITEM_NAME, Component.translatable("item.juegosdelpatio.espada_buscador"));
        CompoundTag marca = new CompoundTag();
        marca.putBoolean("EspadaBuscador", true);
        espada.set(DataComponents.CUSTOM_DATA, CustomData.of(marca));
        return espada;
    }

    static boolean esEspada(ItemStack cosa) {
        CustomData datos = cosa.get(DataComponents.CUSTOM_DATA);
        return datos != null && cosa.is(Items.NETHERITE_SWORD) && datos.copyTag().getBoolean("EspadaBuscador");
    }

    private static void sacarEspadas(Inventory inventario) {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            if (esEspada(inventario.getItem(i))) {
                inventario.setItem(i, ItemStack.EMPTY);
            }
        }
    }

    // ------------------------------------------------------------------ ayudas
    /** Los que siguen jugando (los que salieron al patio también: siguen vivos y pasan). */
    private static List<LivingEntity> enJuego(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : Juego.participantes(complejo)) {
            if (BUSCADORES.contains(quien.getUUID()) || ESCONDIDOS.contains(quien.getUUID())) {
                lista.add(quien);
            }
        }
        return lista;
    }

    /** Cuántos siguen escondidos en la escuela (vivos y sin haber salido). */
    private static int contarEscondidos(ServerLevel complejo) {
        int quedan = 0;
        for (LivingEntity quien : enJuego(complejo)) {
            if (esEscondido(quien)) {
                quedan++;
            }
        }
        return quedan;
    }

    private static String reloj(int ticks) {
        int segundos = (ticks + 19) / 20;
        return segundos / 60 + ":" + (segundos % 60 < 10 ? "0" : "") + segundos % 60;
    }
}
