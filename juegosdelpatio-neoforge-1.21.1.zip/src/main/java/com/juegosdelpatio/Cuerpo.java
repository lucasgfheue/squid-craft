package com.juegosdelpatio;

import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * En Las escondidas, el que encontraron queda tirado en el piso: esto es lo que queda (el muerto desaparece y en su
 * lugar se pone el cuerpo, boca arriba, con su skin y su chaleco). No se puede tocar ni empujar, no choca con nada y
 * no se guarda en el mundo: se saca cuando termina el juego.
 */
public class Cuerpo extends Entity {
    /** La skin: la de un bot (0 a 47) o, si es -1, la del jugador {@link #JUGADOR}. */
    private static final EntityDataAccessor<Integer> SKIN = SynchedEntityData.defineId(Cuerpo.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Optional<UUID>> JUGADOR =
            SynchedEntityData.defineId(Cuerpo.class, EntityDataSerializers.OPTIONAL_UUID);
    /** El chaleco que tenía puesto: 0 ninguno, 1 el de buscador, 2 el de escondido. */
    private static final EntityDataAccessor<Integer> CHALECO = SynchedEntityData.defineId(Cuerpo.class, EntityDataSerializers.INT);
    /**
     * Si es de mentira (uno que se hace el muerto): el número de entidad del que está tirado ahí, que mientras tanto no
     * se dibuja (así el de mentira y los de verdad se ven iguales). -1 si es un cuerpo de verdad.
     */
    private static final EntityDataAccessor<Integer> DUENO = SynchedEntityData.defineId(Cuerpo.class, EntityDataSerializers.INT);

    public Cuerpo(EntityType<? extends Cuerpo> tipo, Level nivel) {
        super(tipo, nivel);
        this.noPhysics = true;
    }

    /** Deja el cuerpo de {@code muerto} donde cayó, mirando para donde miraba. */
    @Nullable
    static Cuerpo dejar(ServerLevel nivel, LivingEntity muerto, int chaleco) {
        return poner(nivel, muerto, chaleco, -1);
    }

    /** El cuerpo de mentira del que se hace el muerto (igual a uno de verdad): mientras está, a él no se lo dibuja. */
    @Nullable
    static Cuerpo fingido(ServerLevel nivel, LivingEntity vivo, int chaleco) {
        return poner(nivel, vivo, chaleco, vivo.getId());
    }

    @Nullable
    private static Cuerpo poner(ServerLevel nivel, LivingEntity quien, int chaleco, int dueno) {
        Cuerpo cuerpo = Registro.CUERPO.get().create(nivel);
        if (cuerpo == null) {
            return null;
        }
        double y = quien.onGround() ? quien.getY() : Math.floor(quien.getY() + 0.01);   // si saltaba, cae al piso
        cuerpo.moveTo(quien.getX(), y, quien.getZ(), quien.getYRot(), 0.0F);
        if (quien instanceof JugadorBot bot) {
            cuerpo.entityData.set(SKIN, bot.getSkin());
        } else {
            cuerpo.entityData.set(SKIN, -1);
            cuerpo.entityData.set(JUGADOR, Optional.of(quien.getUUID()));
        }
        cuerpo.entityData.set(CHALECO, chaleco);
        cuerpo.entityData.set(DUENO, dueno);
        nivel.addFreshEntity(cuerpo);
        return cuerpo;
    }

    int skin() {
        return entityData.get(SKIN);
    }

    @Nullable
    UUID jugador() {
        return entityData.get(JUGADOR).orElse(null);
    }

    int chaleco() {
        return entityData.get(CHALECO);
    }

    /** El número de entidad del que se hace el muerto acá, o -1 si es un cuerpo de verdad. */
    int dueno() {
        return entityData.get(DUENO);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        datos.define(SKIN, 0);
        datos.define(JUGADOR, Optional.empty());
        datos.define(CHALECO, 0);
        datos.define(DUENO, -1);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag datos) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag datos) {
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return false;
    }
}
