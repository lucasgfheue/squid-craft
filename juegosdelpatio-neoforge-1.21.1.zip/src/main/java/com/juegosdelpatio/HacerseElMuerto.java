package com.juegosdelpatio;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Del cliente al servidor: el jugador apretó la tecla de hacerse el muerto (la G). En Las escondidas, el que se
 * esconde se tira al piso un rato (o se levanta, si ya estaba tirado). Ver {@link Escondidas#hacerseElMuerto}.
 */
public record HacerseElMuerto() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<HacerseElMuerto> TIPO =
            new CustomPacketPayload.Type<>(Complejo.id("hacerse_el_muerto"));
    public static final StreamCodec<ByteBuf, HacerseElMuerto> CODEC = StreamCodec.unit(new HacerseElMuerto());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TIPO;
    }

    static void registrar(RegisterPayloadHandlersEvent evento) {
        PayloadRegistrar registro = evento.registrar("1");
        registro.playToServer(TIPO, CODEC, HacerseElMuerto::recibir);
    }

    private static void recibir(HacerseElMuerto paquete, IPayloadContext contexto) {
        contexto.enqueueWork(() -> {
            if (contexto.player() instanceof ServerPlayer jugador) {
                Escondidas.hacerseElMuerto(jugador);
            }
        });
    }
}
