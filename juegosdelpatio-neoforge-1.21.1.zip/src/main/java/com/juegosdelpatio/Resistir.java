package com.juegosdelpatio;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * El aviso que manda el cliente cada vez que el jugador aprieta la Z estando sentado: en las sillas musicales, así
 * aguanta para que no lo saquen de la silla (ver {@link Sillas#resistir}).
 */
public record Resistir() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<Resistir> TIPO = new CustomPacketPayload.Type<>(Complejo.id("resistir"));
    public static final StreamCodec<ByteBuf, Resistir> CODEC = StreamCodec.unit(new Resistir());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TIPO;
    }

    /** Se anota el paquete (del cliente al servidor). */
    static void registrar(RegisterPayloadHandlersEvent evento) {
        PayloadRegistrar registro = evento.registrar("1");
        registro.playToServer(TIPO, CODEC, Resistir::recibir);
    }

    private static void recibir(Resistir paquete, IPayloadContext contexto) {
        contexto.enqueueWork(() -> {
            if (contexto.player() instanceof ServerPlayer jugador) {
                Sillas.resistir(jugador);
            }
        });
    }
}
