package com.juegosdelpatio;

import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Comandos para operadores (con trucos activados):
 * /juegosdelpatio entrar | salir | reconstruir
 */
public final class Comandos {

    private Comandos() {
    }

    static void registrar(RegisterCommandsEvent evento) {
        evento.getDispatcher().register(Commands.literal("juegosdelpatio")
                .requires(fuente -> fuente.hasPermission(2))
                .then(Commands.literal("entrar").executes(ctx -> {
                    Complejo.entrar(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("salir").executes(ctx -> {
                    Complejo.salir(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("reconstruir").executes(ctx -> {
                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                    if (complejo == null || !Complejo.construirSiFalta(complejo, true)) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_sala"));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.reconstruida"), true);
                    return 1;
                })));
    }
}
