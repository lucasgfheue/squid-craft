package com.juegosdelpatio;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Comandos para operadores (con trucos activados):
 * /juegosdelpatio entrar | salir | reconstruir | bots <0-150> | guardias <0-2>
 *                 | invocar <vigilante|guardia|sargento|comandante> | ceremonia | porton <abrir|cerrar>
 */
public final class Comandos {

    private Comandos() {
    }

    static void registrar(RegisterCommandsEvent evento) {
        // /juegosdelpatio invocar <rango>: un guardia fijo donde estás parado
        LiteralArgumentBuilder<CommandSourceStack> invocar = Commands.literal("invocar");
        for (Rango rango : Rango.values()) {
            invocar.then(Commands.literal(rango.id).executes(ctx -> {
                CommandSourceStack fuente = ctx.getSource();
                Complejo.invocarGuardia(fuente.getLevel(), fuente.getPosition(), fuente.getRotation().y, rango, -1);
                fuente.sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.invocado", rango.nombre()), true);
                return 1;
            }));
        }

        evento.getDispatcher().register(Commands.literal("juegosdelpatio")
                .requires(fuente -> fuente.hasPermission(2))
                .then(Commands.literal("entrar").executes(ctx -> {
                    Complejo.entrar(ctx.getSource().getPlayerOrException(), true);   // los operadores entran cualquier día
                    return 1;
                }))
                .then(Commands.literal("salir").executes(ctx -> {
                    Complejo.salir(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("reconstruir").executes(ctx -> {
                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                    if (complejo == null || !Complejo.prepararComplejo(complejo, true)) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_sala"));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.reconstruida"), true);
                    return 1;
                }))
                .then(Commands.literal("bots")
                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(0, Complejo.MAX_BOTS))
                                .executes(ctx -> {
                                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                                    if (complejo == null) {
                                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
                                        return 0;
                                    }
                                    int total = Complejo.generarBots(complejo, IntegerArgumentType.getInteger(ctx, "cantidad"));
                                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.bots", total), true);
                                    return total;
                                })))
                .then(Commands.literal("guardias")
                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(0, Complejo.MAX_GUARDIAS))
                                .executes(ctx -> {
                                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                                    if (complejo == null) {
                                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
                                        return 0;
                                    }
                                    int total = Complejo.generarGuardias(complejo, IntegerArgumentType.getInteger(ctx, "cantidad"));
                                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.guardias", total), true);
                                    return total;
                                })))
                .then(invocar)
                .then(Commands.literal("porton")
                        .then(Commands.literal("abrir").executes(ctx -> porton(ctx.getSource(), true)))
                        .then(Commands.literal("cerrar").executes(ctx -> porton(ctx.getSource(), false))))
                .then(Commands.literal("ceremonia").executes(ctx -> {
                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                    if (complejo == null) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
                        return 0;
                    }
                    if (!Ceremonia.empezar(complejo)) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.ceremonia_en_curso"));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.ceremonia"), true);
                    return 1;
                })));
    }

    /** Abre o cierra el portón (y con él, el camino a la Torre de los Juegos). */
    private static int porton(CommandSourceStack fuente, boolean abrir) {
        ServerLevel complejo = fuente.getServer().getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            fuente.sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
            return 0;
        }
        boolean hecho = abrir ? Ceremonia.abrirPorton(complejo) : Ceremonia.cerrarPorton(complejo);
        if (!hecho) {
            fuente.sendFailure(Component.translatable("mensaje.juegosdelpatio.porton_ocupado"));
            return 0;
        }
        fuente.sendSuccess(() -> Component.translatable(abrir ? "mensaje.juegosdelpatio.porton_abierto"
                : "mensaje.juegosdelpatio.porton_cerrado"), true);
        return 1;
    }
}
