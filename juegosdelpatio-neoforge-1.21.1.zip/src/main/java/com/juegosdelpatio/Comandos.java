package com.juegosdelpatio;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Comandos para operadores (con trucos activados):
 * /juegosdelpatio entrar | salir | reconstruir | bots <0-150>
 */
public final class Comandos {

    private Comandos() {
    }

    static void registrar(RegisterCommandsEvent evento) {
        evento.getDispatcher().register(Commands.literal("juegosdelpatio")
                .requires(fuente -> fuente.hasPermission(2))
                .then(Commands.literal("entrar").executes(ctx -> {
                    Complejo.entrar(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("salir").executes(ctx -> {
                    Complejo.salir(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("reconstruir").executes(ctx -> {
                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                    if (complejo == null || !Complejo.prepararComplejo(complejo, true)) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_sala"));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.reconstruida"), true);
                    return 1;
                }))
                .then(Commands.literal("bots")
                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(0, Complejo.MAX_BOTS))
                                .executes(ctx -> {
                                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                                    if (complejo == null) {
                                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
                                        return 0;
                                    }
                                    int total = Complejo.generarBots(complejo, IntegerArgumentType.getInteger(ctx, "cantidad"));
                                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.bots", total), true);
                                    return total;
                                }))));
    }
}
