package com.juegosdelpatio;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Comandos para operadores (con trucos activados):
 * /juegosdelpatio entrar | salir | reconstruir | bots <0-150> | guardias <0-2>
 *                 | invocar <vigilante|guardia|sargento|comandante> | ceremonia | porton <abrir|cerrar>
 *                 | puerta <1-5> <abrir|cerrar> | primerjuego | segundojuego | tercerjuego | resultados
 *                 | juego <llamar|empezar|parar> | comida
 * Para todos: /votar <seguir|irse>
 */
public final class Comandos {

    private Comandos() {
    }

    static void registrar(RegisterCommandsEvent evento) {
        // /juegosdelpatio invocar <rango>: un guardia fijo donde estás parado
        LiteralArgumentBuilder<CommandSourceStack> invocar = Commands.literal("invocar");
        for (Rango rango : Rango.values()) {
            invocar.then(Commands.literal(rango.id).executes(ctx -> {
                CommandSourceStack fuente = ctx.getSource();
                Complejo.invocarGuardia(fuente.getLevel(), fuente.getPosition(), fuente.getRotation().y, rango, -1);
                fuente.sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.invocado", rango.nombre()), true);
                return 1;
            }));
        }

        evento.getDispatcher().register(Commands.literal("votar")
                .then(Commands.literal("seguir").executes(ctx -> votar(ctx.getSource(), true)))
                .then(Commands.literal("irse").executes(ctx -> votar(ctx.getSource(), false))));

        evento.getDispatcher().register(Commands.literal("juegosdelpatio")
                .requires(fuente -> fuente.hasPermission(2))
                .then(Commands.literal("entrar").executes(ctx -> {
                    Complejo.entrar(ctx.getSource().getPlayerOrException(), true);   // los operadores entran cualquier día
                    return 1;
                }))
                .then(Commands.literal("salir").executes(ctx -> {
                    Complejo.salir(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("reconstruir").executes(ctx -> {
                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                    if (complejo == null || !Complejo.prepararComplejo(complejo, true)) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_sala"));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.reconstruida"), true);
                    return 1;
                }))
                .then(Commands.literal("bots")
                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(0, Complejo.MAX_BOTS))
                                .executes(ctx -> {
                                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                                    if (complejo == null) {
                                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
                                        return 0;
                                    }
                                    int total = Complejo.generarBots(complejo, IntegerArgumentType.getInteger(ctx, "cantidad"));
                                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.bots", total), true);
                                    return total;
                                })))
                .then(Commands.literal("guardias")
                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(0, Complejo.MAX_GUARDIAS))
                                .executes(ctx -> {
                                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                                    if (complejo == null) {
                                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
                                        return 0;
                                    }
                                    int total = Complejo.generarGuardias(complejo, IntegerArgumentType.getInteger(ctx, "cantidad"));
                                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.guardias", total), true);
                                    return total;
                                })))
                .then(invocar)
                .then(Commands.literal("porton")
                        .then(Commands.literal("abrir").executes(ctx -> porton(ctx.getSource(), true)))
                        .then(Commands.literal("cerrar").executes(ctx -> porton(ctx.getSource(), false))))
                .then(Commands.literal("puerta")
                        .then(Commands.argument("numero", IntegerArgumentType.integer(1, Portales.CANTIDAD))
                                .then(Commands.literal("abrir").executes(ctx ->
                                        puerta(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "numero"), true)))
                                .then(Commands.literal("cerrar").executes(ctx ->
                                        puerta(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "numero"), false)))))
                .then(Commands.literal("primerjuego").executes(ctx -> juego(ctx.getSource(), "llamar", 1)))
                .then(Commands.literal("segundojuego").executes(ctx -> juego(ctx.getSource(), "llamar", 2)))
                .then(Commands.literal("tercerjuego").executes(ctx -> juego(ctx.getSource(), "llamar", 3)))
                .then(Commands.literal("resultados").executes(ctx -> juego(ctx.getSource(), "resultados", 1)))
                .then(Commands.literal("comida").executes(ctx -> juego(ctx.getSource(), "comida", 1)))
                .then(Commands.literal("juego")
                        .then(Commands.literal("llamar").executes(ctx -> juego(ctx.getSource(), "llamar", 1))
                                .then(Commands.argument("numero", IntegerArgumentType.integer(1, Juego.JUEGOS_HECHOS))
                                        .executes(ctx -> juego(ctx.getSource(), "llamar",
                                                IntegerArgumentType.getInteger(ctx, "numero")))))
                        .then(Commands.literal("empezar").executes(ctx -> juego(ctx.getSource(), "empezar", 1))
                                .then(Commands.argument("numero", IntegerArgumentType.integer(1, Juego.JUEGOS_HECHOS))
                                        .executes(ctx -> juego(ctx.getSource(), "empezar",
                                                IntegerArgumentType.getInteger(ctx, "numero")))))
                        .then(Commands.literal("parar").executes(ctx -> juego(ctx.getSource(), "parar", 1))))
                .then(Commands.literal("ceremonia").executes(ctx -> {
                    ServerLevel complejo = ctx.getSource().getServer().getLevel(Complejo.DIMENSION);
                    if (complejo == null) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
                        return 0;
                    }
                    if (!Ceremonia.empezar(complejo)) {
                        ctx.getSource().sendFailure(Component.translatable("mensaje.juegosdelpatio.ceremonia_en_curso"));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("mensaje.juegosdelpatio.ceremonia"), true);
                    return 1;
                })));
    }

    /** Abre o cierra el portón (y con él, el camino a la Torre de los Juegos). */
    private static int porton(CommandSourceStack fuente, boolean abrir) {
        ServerLevel complejo = fuente.getServer().getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            fuente.sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
            return 0;
        }
        boolean hecho = abrir ? Ceremonia.abrirPorton(complejo) : Ceremonia.cerrarPorton(complejo);
        if (!hecho) {
            fuente.sendFailure(Component.translatable("mensaje.juegosdelpatio.porton_ocupado"));
            return 0;
        }
        fuente.sendSuccess(() -> Component.translatable(abrir ? "mensaje.juegosdelpatio.porton_abierto"
                : "mensaje.juegosdelpatio.porton_cerrado"), true);
        return 1;
    }

    /** Abre o cierra una puerta de la torre: abierta, en su lugar hay un portal al juego. */
    private static int puerta(CommandSourceStack fuente, int numero, boolean abrir) {
        ServerLevel complejo = fuente.getServer().getLevel(Complejo.DIMENSION);
        if (complejo == null || !Complejo.prepararComplejo(complejo, false)) {
            fuente.sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
            return 0;
        }
        if (abrir) {
            Portales.abrirPuerta(complejo, numero);
        } else {
            Portales.cerrarPuerta(complejo, numero);
        }
        fuente.sendSuccess(() -> Component.translatable(abrir ? "mensaje.juegosdelpatio.puerta_abierta"
                : "mensaje.juegosdelpatio.puerta_cerrada", numero), true);
        return 1;
    }

    /**
     * llamar: todo el día del juego {@code numero} desde el llamado; empezar: directo a su arena; parar: todos vuelven
     * a la sala.
     */
    private static int juego(CommandSourceStack fuente, String accion, int numero) {
        ServerLevel complejo = fuente.getServer().getLevel(Complejo.DIMENSION);
        if (complejo == null || !Complejo.prepararComplejo(complejo, false)) {
            fuente.sendFailure(Component.translatable("mensaje.juegosdelpatio.sin_dimension"));
            return 0;
        }
        boolean hecho = switch (accion) {
            case "llamar" -> Juego.llamar(complejo, numero);
            case "resultados" -> Juego.empezarResultados(complejo);
            case "comida" -> !Juego.enCurso() && !Ceremonia.enCurso() && Comida.empezar(complejo, Juego.ultimoNumero());
            case "empezar" -> Juego.empezarYa(complejo, numero);
            default -> Juego.parar(complejo);
        };
        if (!hecho) {
            fuente.sendFailure(Component.translatable(accion.equals("parar")
                    ? "mensaje.juegosdelpatio.sin_juego" : "mensaje.juegosdelpatio.juego_ocupado"));
            return 0;
        }
        fuente.sendSuccess(() -> Component.translatable(accion.equals("parar") ? "mensaje.juegosdelpatio.juego_parado"
                : accion.equals("comida") ? "mensaje.juegosdelpatio.comida_empezada"
                : "mensaje.juegosdelpatio.juego_empezado"), true);
        return 1;
    }

    /** /votar seguir o /votar irse: para cualquier jugador que siga en el complejo, una sola vez por votación. */
    private static int votar(CommandSourceStack fuente, boolean seguir) throws CommandSyntaxException {
        ServerPlayer jugador = fuente.getPlayerOrException();
        int resultado = Votacion.votar(jugador, seguir);
        if (resultado == 0) {
            fuente.sendSuccess(() -> Component.translatable(seguir ? "voto.juegosdelpatio.votaste_seguir"
                    : "voto.juegosdelpatio.votaste_irse"), false);
            return 1;
        }
        fuente.sendFailure(Component.translatable(resultado == 1 ? "voto.juegosdelpatio.no_hay"
                : resultado == 2 ? "voto.juegosdelpatio.ya_votaste" : "voto.juegosdelpatio.no_podes"));
        return 0;
    }
}
