package com.juegosdelpatio;

import com.mojang.serialization.MapCodec;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * La silla de Asientos al vacío: cuatro patas, el asiento y el respaldo de color. Mira hacia {@code facing} (el
 * que se sienta queda mirando para ahí; el respaldo está del otro lado). Clic derecho para sentarse: en el juego,
 * solo cuando para la música y en una silla libre de tu círculo. No se puede romper (la pone y la saca el juego).
 */
public class SillaBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<SillaBlock> CODEC = simpleCodec(SillaBlock::new);
    /** El color del asiento y del respaldo: 0 rojo, 1 amarillo, 2 verde, 3 celeste. */
    public static final IntegerProperty COLOR = IntegerProperty.create("color", 0, 3);
    public static final int COLORES = 4;
    private static final Map<Direction, VoxelShape> FORMAS = new EnumMap<>(Direction.class);

    static {
        for (Direction lado : new Direction[] {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST}) {
            FORMAS.put(lado, Shapes.or(caja(lado, 1, 0, 1, 15, 9, 15), caja(lado, 1, 9, 13, 15, 21, 15)));
        }
    }

    public SillaBlock(Properties propiedades) {
        super(propiedades);
        registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(COLOR, 0));
    }

    /**
     * Una caja en píxeles, medida en la silla que mira al norte (respaldo al sur), girada para que mire hacia
     * {@code lado} igual que el modelo (y = 90 lleva el norte al este).
     */
    private static VoxelShape caja(Direction lado, double x0, double y0, double z0, double x1, double y1, double z1) {
        return switch (lado) {
            case EAST -> Block.box(16 - z1, y0, x0, 16 - z0, y1, x1);
            case SOUTH -> Block.box(16 - x1, y0, 16 - z1, 16 - x0, y1, 16 - z0);
            case WEST -> Block.box(z0, y0, 16 - x1, z1, y1, 16 - x0);
            default -> Block.box(x0, y0, z0, x1, y1, z1);
        };
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> constructor) {
        constructor.add(FACING, COLOR);
    }

    @Override
    protected VoxelShape getShape(BlockState estado, BlockGetter nivel, BlockPos pos, CollisionContext contexto) {
        return FORMAS.get(estado.getValue(FACING));
    }

    /** Los bots no se suben por arriba de las sillas: las esquivan y pasan por los huecos. */
    @Override
    protected boolean isPathfindable(BlockState estado, PathComputationType tipo) {
        return false;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState estado, Level nivel, BlockPos pos, Player jugador,
                                               BlockHitResult golpe) {
        if (nivel.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (jugador instanceof ServerPlayer servidor) {
            Sillas.alUsarSilla(servidor, pos.immutable());
        }
        return InteractionResult.CONSUME;
    }
}
