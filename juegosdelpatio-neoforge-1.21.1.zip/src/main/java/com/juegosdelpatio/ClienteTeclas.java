package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLivingEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * En el cliente, cada tick: cada vez que se aprieta la tecla de aguantar (la Z), se le avisa al servidor (en las sillas
 * y en los forcejeos); la G, para hacerse el muerto; y avanza el parpadeo de las luces. Además, los que se hacen los
 * muertos no se dibujan: en su lugar está su cuerpo de mentira.
 */
@EventBusSubscriber(modid = JuegosDelPatio.MODID, value = Dist.CLIENT)
public final class ClienteTeclas {
    /** Mantener apretada la Z no vale (la tecla se repite sola): solo cuenta apretarla, y hasta este tiempo apretada. */
    private static final int Z_SOSTENIDA = 5;
    private static int zSostenida;
    /** Los números de entidad de los que se hacen los muertos (no se dibujan), y dónde están los cuerpos de verdad. */
    private static final Set<Integer> OCULTOS = new HashSet<>();
    private static final List<Vec3> CUERPOS = new ArrayList<>();

    private ClienteTeclas() {
    }

    @SubscribeEvent
    public static void alTick(ClientTickEvent.Post evento) {
        Minecraft minecraft = Minecraft.getInstance();
        int apretones = 0;
        while (Cliente.AGUANTAR.consumeClick()) {
            apretones++;
        }
        zSostenida = Cliente.AGUANTAR.isDown() ? zSostenida + 1 : 0;
        if (apretones > 0 && zSostenida <= Z_SOSTENIDA && minecraft.player != null && minecraft.getConnection() != null) {
            PacketDistributor.sendToServer(new Resistir());          // uno por tick como mucho
        }
        while (Cliente.HACERSE_EL_MUERTO.consumeClick()) {
            if (minecraft.player != null && minecraft.getConnection() != null) {
                PacketDistributor.sendToServer(new HacerseElMuerto());
            }
        }
        if (minecraft.player == null) {
            MuertoFingido.enCliente = false;
        } else if (MuertoFingido.enCliente) {
            minecraft.player.setPose(Pose.SLEEPING);                  // la vista, a ras del piso
            minecraft.player.setDeltaMovement(0.0, Math.min(0.0, minecraft.player.getDeltaMovement().y), 0.0);
        }
        OCULTOS.clear();
        CUERPOS.clear();
        if (minecraft.level != null) {
            for (Entity cosa : minecraft.level.entitiesForRendering()) {
                if (cosa instanceof Cuerpo cuerpo) {
                    if (cuerpo.dueno() >= 0) {
                        OCULTOS.add(cuerpo.dueno());
                    } else {
                        CUERPOS.add(cuerpo.position());
                    }
                }
            }
        }
        ClienteLuces.tick(minecraft);
    }

    /**
     * El que se hace el muerto no se dibuja (ni su ropa, ni su nombre): se ve solo su cuerpo de mentira. Y el que
     * acaba de morir en Las escondidas tampoco (ya está su cuerpo tirado en el piso).
     */
    @SubscribeEvent
    public static void alDibujar(RenderLivingEvent.Pre<?, ?> evento) {
        LivingEntity quien = evento.getEntity();
        if (!OCULTOS.isEmpty() && OCULTOS.contains(quien.getId())) {
            evento.setCanceled(true);
            return;
        }
        if (!CUERPOS.isEmpty() && quien.isDeadOrDying() && (quien instanceof Player || quien instanceof JugadorBot)) {
            for (Vec3 cuerpo : CUERPOS) {
                if (cuerpo.distanceToSqr(quien.position()) < 1.5 * 1.5) {
                    evento.setCanceled(true);
                    return;
                }
            }
        }
    }
}
