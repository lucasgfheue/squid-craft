package com.juegosdelpatio;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** En el cliente: cada vez que se aprieta la tecla de aguantar (la Z) estando sentado, se le avisa al servidor. */
@EventBusSubscriber(modid = JuegosDelPatio.MODID, value = Dist.CLIENT)
public final class ClienteTeclas {
    private ClienteTeclas() {
    }

    @SubscribeEvent
    public static void alTick(ClientTickEvent.Post evento) {
        Minecraft minecraft = Minecraft.getInstance();
        while (Cliente.AGUANTAR.consumeClick()) {
            if (minecraft.player != null && minecraft.player.isPassenger() && minecraft.getConnection() != null) {
                PacketDistributor.sendToServer(new Resistir());
            }
        }
    }
}
