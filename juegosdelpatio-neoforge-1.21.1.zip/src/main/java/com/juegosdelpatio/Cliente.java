package com.juegosdelpatio;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

/** Registros que solo existen en el cliente (cómo se dibujan las entidades, y la tecla para aguantar en la silla). */
@EventBusSubscriber(modid = JuegosDelPatio.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class Cliente {
    /** La Z: apretarla rápido, sentado, para que no te saquen de la silla (se puede cambiar en Controles). */
    public static final KeyMapping AGUANTAR = new KeyMapping("key.juegosdelpatio.aguantar", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_Z, "key.categories.juegosdelpatio");

    private Cliente() {
    }

    @SubscribeEvent
    public static void registrarTeclas(RegisterKeyMappingsEvent evento) {
        evento.register(AGUANTAR);
    }

    @SubscribeEvent
    public static void registrarRenderers(EntityRenderersEvent.RegisterRenderers evento) {
        evento.registerEntityRenderer(Registro.JUGADOR_BOT.get(), JugadorBotRenderer::new);
        evento.registerEntityRenderer(Registro.GUARDIA.get(), GuardiaRenderer::new);
        evento.registerEntityRenderer(Registro.BALA.get(), contexto -> new ThrownItemRenderer<>(contexto, 0.5F, true));
        evento.registerEntityRenderer(Registro.ASIENTO.get(), NoopRenderer::new);    // el asiento no se ve
    }
}
