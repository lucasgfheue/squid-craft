package com.juegosdelpatio;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Registros que solo existen en el cliente (cómo se dibujan las entidades). */
@EventBusSubscriber(modid = JuegosDelPatio.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class Cliente {
    private Cliente() {
    }

    @SubscribeEvent
    public static void registrarRenderers(EntityRenderersEvent.RegisterRenderers evento) {
        evento.registerEntityRenderer(Registro.JUGADOR_BOT.get(), JugadorBotRenderer::new);
        evento.registerEntityRenderer(Registro.GUARDIA.get(), GuardiaRenderer::new);
        evento.registerEntityRenderer(Registro.BALA.get(), contexto -> new ThrownItemRenderer<>(contexto, 0.5F, true));
    }
}
