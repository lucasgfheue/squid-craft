package com.juegosdelpatio;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import org.lwjgl.glfw.GLFW;

/**
 * Registros que solo existen en el cliente: cómo se dibujan las entidades, la tecla para aguantar en la silla y la
 * capa de pantalla del parpadeo de las luces.
 */
@EventBusSubscriber(modid = JuegosDelPatio.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class Cliente {
    /** La Z: apretarla rápido, en Las escondidas, para que no te quiten la espada (se puede cambiar en Controles). */
    public static final KeyMapping AGUANTAR = new KeyMapping("key.juegosdelpatio.aguantar", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_Z, "key.categories.juegosdelpatio");
    /** La G: en Las escondidas, el que se esconde se hace el muerto (y se levanta, si la vuelve a apretar). */
    public static final KeyMapping HACERSE_EL_MUERTO = new KeyMapping("key.juegosdelpatio.hacerse_el_muerto",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.juegosdelpatio");

    private Cliente() {
    }

    @SubscribeEvent
    public static void registrarTeclas(RegisterKeyMappingsEvent evento) {
        evento.register(AGUANTAR);
        evento.register(HACERSE_EL_MUERTO);
    }

    /** Las luces que parpadean cuando para la música: arriba del mundo, debajo de la mira y del HUD. */
    @SubscribeEvent
    public static void registrarCapas(RegisterGuiLayersEvent evento) {
        evento.registerAbove(VanillaGuiLayers.CAMERA_OVERLAYS, Complejo.id("luces"), ClienteLuces::dibujar);
    }

    @SubscribeEvent
    public static void registrarRenderers(EntityRenderersEvent.RegisterRenderers evento) {
        evento.registerEntityRenderer(Registro.JUGADOR_BOT.get(), JugadorBotRenderer::new);
        evento.registerEntityRenderer(Registro.GUARDIA.get(), GuardiaRenderer::new);
        evento.registerEntityRenderer(Registro.BALA.get(), contexto -> new ThrownItemRenderer<>(contexto, 0.5F, true));
        evento.registerEntityRenderer(Registro.ASIENTO.get(), NoopRenderer::new);    // el asiento no se ve
        evento.registerEntityRenderer(Registro.CUERPO.get(), CuerpoRenderer::new);
        evento.registerEntityRenderer(Registro.ROBOT.get(), RobotRenderer::new);   // los robots del puente
    }
}
