package com.juegosdelpatio;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * El Vigía: el gigante mecánico (32 bloques de alto) que está al fondo de la arena de Luz verde, luz roja.
 * Está parado de espaldas a la gente. Con la luz roja gira la cabeza para mirarlos (visor rojo) y con la verde
 * la vuelve a girar. El cuerpo está en luz_verde.nbt; la cabeza la pone este código, y gen_luz_verde.py lee el
 * dibujo de la cabeza de acá (no hay que cambiarlo en dos lugares).
 */
final class Vigia {
    /** Esquina de la cabeza (8 x 8 x 8): x 996..1003, y 127..134, z 298..305. */
    static final int X0 = 996;
    static final int Y0 = 127;
    static final int Z0 = 298;
    /** Hacia dónde mira la cabeza: a la gente (norte), de costado (este) o de espaldas (sur). */
    static final int MIRANDO = 0;
    static final int DE_COSTADO = 1;
    static final int DE_ESPALDAS = 2;
    private static final int TICKS_POR_PASO = 3;

    /**
     * La cabeza mirando a la gente. Capas de abajo (y = 0) hacia arriba; en cada capa, filas desde la cara
     * (norte) hasta la nuca (sur); en cada fila, de oeste a este.
     * I = hierro, G = gris, L = gris claro, K = negro, R = visor rojo.
     */
    private static final String[][] CABEZA = {
            {"GGIKKIGG", "GGGGGGGG", "GGGGGGGG", "GGGGGGGG", "GGGGGGGG", "GGGGGGGG", "GGGGGGGG", "GGGGGGGG"},   // y = 0
            {"GIIKKIIG", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "GIIIIIIG"},   // y = 1
            {"GKKKKKKG", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "GIKKKKIG"},   // y = 2
            {"GRRRRRRG", "IGGGGGGI", "IGGGGGGI", "KGGGGGGK", "KGGGGGGK", "IGGGGGGI", "IGGGGGGI", "GIIIIIIG"},   // y = 3
            {"GRRRRRRG", "IGGGGGGI", "IGGGGGGI", "KGGGGGGK", "KGGGGGGK", "IGGGGGGI", "IGGGGGGI", "GIKKKKIG"},   // y = 4
            {"GKKKKKKG", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "GIIIIIIG"},   // y = 5
            {"GIIIIIIG", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "IGGGGGGI", "GIIIIIIG"},   // y = 6
            {"GGGGGGGG", "GLLLLLLG", "GLLLLLLG", "GLLLLLLG", "GLLLLLLG", "GLLLLLLG", "GLLLLLLG", "GGGGGGGG"},   // y = 7
    };

    private static int actual = DE_ESPALDAS;
    private static int objetivo = DE_ESPALDAS;
    private static int espera;

    private Vigia() {
    }

    /** Que gire la cabeza hacia la gente (luz roja) o de espaldas (luz verde). */
    static void mirar(boolean aLaGente) {
        int nuevo = aLaGente ? MIRANDO : DE_ESPALDAS;
        if (nuevo != objetivo) {
            objetivo = nuevo;
            espera = TICKS_POR_PASO - 1;                       // empieza a girar enseguida
        }
    }

    static boolean mirando() {
        return actual == MIRANDO;
    }

    /** Un paso del giro cada 3 ticks: de espaldas, de costado, mirando (o al revés). */
    static void tick(ServerLevel nivel) {
        if (actual == objetivo || ++espera < TICKS_POR_PASO) {
            return;
        }
        espera = 0;
        actual += objetivo > actual ? 1 : -1;
        poner(nivel, actual);
    }

    /** Pone la cabeza de una vez (sin girar), por ejemplo al empezar o al terminar el juego. */
    static void reiniciar(ServerLevel nivel, int giro) {
        actual = giro;
        objetivo = giro;
        espera = 0;
        poner(nivel, giro);
    }

    /** Al cerrar el servidor: la próxima vez se vuelve a poner la cabeza entera. */
    static void olvidar() {
        actual = DE_ESPALDAS;
        objetivo = DE_ESPALDAS;
        espera = 0;
    }

    /** Coloca los 512 bloques de la cabeza girada (los que no cambian no mandan nada a los clientes). */
    static void poner(ServerLevel nivel, int giro) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int y = 0; y < 8; y++) {
            for (int z = 0; z < 8; z++) {
                for (int x = 0; x < 8; x++) {
                    int dx;
                    int dz;
                    if (giro == MIRANDO) {
                        dx = x;
                        dz = z;
                    } else if (giro == DE_COSTADO) {
                        dx = 7 - z;                            // la cara queda mirando al este
                        dz = x;
                    } else {
                        dx = 7 - x;                            // la cara queda mirando al sur (a la pared)
                        dz = 7 - z;
                    }
                    pos.set(X0 + dx, Y0 + y, Z0 + dz);
                    nivel.setBlock(pos, bloque(CABEZA[y][z].charAt(x)), Block.UPDATE_CLIENTS);
                }
            }
        }
    }

    private static BlockState bloque(char letra) {
        return switch (letra) {
            case 'I' -> Blocks.IRON_BLOCK.defaultBlockState();
            case 'L' -> Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
            case 'K' -> Blocks.BLACK_CONCRETE.defaultBlockState();
            case 'R' -> Blocks.RED_CONCRETE.defaultBlockState();
            default -> Blocks.GRAY_CONCRETE.defaultBlockState();
        };
    }
}
