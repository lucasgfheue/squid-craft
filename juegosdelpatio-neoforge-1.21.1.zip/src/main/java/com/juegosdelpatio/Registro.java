package com.juegosdelpatio;

import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Todo lo que el mod registra en el juego. */
public final class Registro {
    public static final DeferredRegister.Items OBJETOS = DeferredRegister.createItems(JuegosDelPatio.MODID);
    public static final DeferredRegister<CreativeModeTab> PESTANAS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JuegosDelPatio.MODID);
    public static final DeferredRegister<AttachmentType<?>> DATOS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, JuegosDelPatio.MODID);

    /** La invitación: clic derecho para entrar o salir del complejo. */
    public static final DeferredItem<InvitacionItem> INVITACION = OBJETOS.register("invitacion",
            () -> new InvitacionItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    /** Dónde estaba cada jugador antes de entrar, para devolverlo al salir. */
    public static final Supplier<AttachmentType<PosicionRetorno>> RETORNO = DATOS.register("retorno",
            () -> AttachmentType.builder(() -> PosicionRetorno.NINGUNA)
                    .serialize(PosicionRetorno.CODEC)
                    .copyOnDeath()
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> PESTANA = PESTANAS.register("juegos",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.juegosdelpatio"))
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .icon(() -> INVITACION.get().getDefaultInstance())
                    .displayItems((parametros, salida) -> salida.accept(INVITACION.get()))
                    .build());

    private Registro() {
    }

    static void registrar(IEventBus bus) {
        OBJETOS.register(bus);
        PESTANAS.register(bus);
        DATOS.register(bus);
    }
}
