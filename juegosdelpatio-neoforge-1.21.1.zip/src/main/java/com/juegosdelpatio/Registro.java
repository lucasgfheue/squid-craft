package com.juegosdelpatio;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Todo lo que el mod registra en el juego. */
public final class Registro {
    public static final DeferredRegister.Items OBJETOS = DeferredRegister.createItems(JuegosDelPatio.MODID);
    public static final DeferredRegister<CreativeModeTab> PESTANAS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JuegosDelPatio.MODID);
    public static final DeferredRegister<AttachmentType<?>> DATOS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, JuegosDelPatio.MODID);
    public static final DeferredRegister<EntityType<?>> ENTIDADES =
            DeferredRegister.create(Registries.ENTITY_TYPE, JuegosDelPatio.MODID);
    public static final DeferredRegister<ArmorMaterial> MATERIALES =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, JuegosDelPatio.MODID);

    // ------------------------------------------------------------------ entidades
    public static final DeferredHolder<EntityType<?>, EntityType<JugadorBot>> JUGADOR_BOT = ENTIDADES.register("jugador",
            () -> EntityType.Builder.of(JugadorBot::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("jugador"));

    public static final DeferredHolder<EntityType<?>, EntityType<Guardia>> GUARDIA = ENTIDADES.register("guardia",
            () -> EntityType.Builder.of(Guardia::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("guardia"));

    public static final DeferredHolder<EntityType<?>, EntityType<Bala>> BALA = ENTIDADES.register("bala",
            () -> EntityType.Builder.<Bala>of(Bala::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build("bala"));

    // ------------------------------------------------------------------ uniforme (armadura de tela)
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> MATERIAL_UNIFORME = MATERIALES.register("uniforme",
            () -> new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), defensa -> {
                        defensa.put(ArmorItem.Type.BOOTS, 1);
                        defensa.put(ArmorItem.Type.LEGGINGS, 1);
                        defensa.put(ArmorItem.Type.CHESTPLATE, 2);
                        defensa.put(ArmorItem.Type.HELMET, 1);
                        defensa.put(ArmorItem.Type.BODY, 2);
                    }),
                    10,
                    SoundEvents.ARMOR_EQUIP_LEATHER,
                    () -> Ingredient.of(Items.BLACK_WOOL),
                    List.of(new ArmorMaterial.Layer(Complejo.id("uniforme"))),
                    0.0F,
                    0.0F));

    public static final DeferredItem<ArmorItem> UNIFORME_CAMISA = OBJETOS.register("uniforme_camisa",
            () -> new ArmorItem(MATERIAL_UNIFORME, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final DeferredItem<ArmorItem> UNIFORME_PANTALON = OBJETOS.register("uniforme_pantalon",
            () -> new ArmorItem(MATERIAL_UNIFORME, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final DeferredItem<ArmorItem> UNIFORME_ZAPATILLAS = OBJETOS.register("uniforme_zapatillas",
            () -> new ArmorItem(MATERIAL_UNIFORME, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));

    // ------------------------------------------------------------------ objetos
    /** La invitación: clic derecho para entrar o salir del complejo. */
    public static final DeferredItem<InvitacionItem> INVITACION = OBJETOS.register("invitacion",
            () -> new InvitacionItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static final DeferredItem<DeferredSpawnEggItem> HUEVO_JUGADOR = OBJETOS.register("huevo_jugador",
            () -> new DeferredSpawnEggItem(JUGADOR_BOT, 0x222226, 0x96969E, new Item.Properties()));

    // ------------------------------------------------------------------ armas de los guardias
    /** Vigilante: porra (cuerpo a cuerpo, un poco más rápida que una espada). */
    public static final DeferredItem<SwordItem> PORRA = OBJETOS.register("porra",
            () -> new SwordItem(Tiers.IRON, new Item.Properties()
                    .attributes(SwordItem.createAttributes(Tiers.IRON, 1, -2.0F))));

    // daño, recarga (ticks), velocidad, imprecisión, perdigones, tono del disparo, intervalo y alcance del guardia
    /** Guardia: pistola, rápida y de poco daño. */
    public static final DeferredItem<ArmaDeFuego> PISTOLA = OBJETOS.register("pistola",
            () -> new ArmaDeFuego(new Item.Properties().stacksTo(1), 4.0F, 8, 3.0F, 1.0F, 1, 1.6F, 20, 16.0F));
    /** Sargento: rifle, lento pero preciso y de largo alcance. */
    public static final DeferredItem<ArmaDeFuego> RIFLE = OBJETOS.register("rifle",
            () -> new ArmaDeFuego(new Item.Properties().stacksTo(1), 8.0F, 25, 4.0F, 0.3F, 1, 1.1F, 40, 24.0F));
    /** Comandante: escopeta, cinco perdigones de corto alcance. */
    public static final DeferredItem<ArmaDeFuego> ESCOPETA = OBJETOS.register("escopeta",
            () -> new ArmaDeFuego(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON),
                    3.0F, 20, 2.5F, 6.0F, 5, 0.7F, 35, 10.0F));
    /** Munición de las armas de fuego (también es lo que se ve volar). */
    public static final DeferredItem<Item> BALA_ITEM = OBJETOS.registerSimpleItem("bala");

    public static final DeferredItem<DeferredSpawnEggItem> HUEVO_GUARDIA = OBJETOS.register("huevo_guardia",
            () -> new DeferredSpawnEggItem(GUARDIA, 0x1E2B45, 0xE2BA3C, new Item.Properties()));

    /** Dónde estaba cada jugador antes de entrar, para devolverlo al salir. */
    public static final Supplier<AttachmentType<PosicionRetorno>> RETORNO = DATOS.register("retorno",
            () -> AttachmentType.builder(() -> PosicionRetorno.NINGUNA)
                    .serialize(PosicionRetorno.CODEC)
                    .copyOnDeath()
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> PESTANA = PESTANAS.register("juegos",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.juegosdelpatio"))
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .icon(() -> INVITACION.get().getDefaultInstance())
                    .displayItems((parametros, salida) -> {
                        salida.accept(INVITACION.get());
                        salida.accept(UNIFORME_CAMISA.get());
                        salida.accept(UNIFORME_PANTALON.get());
                        salida.accept(UNIFORME_ZAPATILLAS.get());
                        salida.accept(HUEVO_JUGADOR.get());
                        salida.accept(HUEVO_GUARDIA.get());
                        salida.accept(PORRA.get());
                        salida.accept(PISTOLA.get());
                        salida.accept(RIFLE.get());
                        salida.accept(ESCOPETA.get());
                        salida.accept(BALA_ITEM.get());
                    })
                    .build());

    private Registro() {
    }

    static void registrar(IEventBus bus) {
        ENTIDADES.register(bus);
        MATERIALES.register(bus);
        OBJETOS.register(bus);
        PESTANAS.register(bus);
        DATOS.register(bus);
    }
}
