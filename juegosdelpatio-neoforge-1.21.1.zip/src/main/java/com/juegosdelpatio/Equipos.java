package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/**
 * Los dos equipos de Fuego cruzado y de Los estandartes: los rojos y los azules, cada uno con su chaleco (al jugador se le
 * guarda la camisa del uniforme y se le devuelve al final). Los dos juegos nunca se juegan a la vez.
 */
final class Equipos {
    /** Lo que los jugadores tenían puesto antes del chaleco (la camisa del uniforme), para devolvérselo. */
    private static final Map<UUID, ItemStack> CAMISAS = new HashMap<>();

    private Equipos() {
    }

    /** Mezcla a la gente y la parte en dos: la primera lista son los rojos (si son impares, hay un rojo más). */
    static List<List<LivingEntity>> repartir(List<LivingEntity> gente, RandomSource azar) {
        List<LivingEntity> mezcla = new ArrayList<>(gente);
        for (int i = mezcla.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            LivingEntity cambio = mezcla.get(i);
            mezcla.set(i, mezcla.get(j));
            mezcla.set(j, cambio);
        }
        int rojos = (mezcla.size() + 1) / 2;
        return List.of(new ArrayList<>(mezcla.subList(0, rojos)), new ArrayList<>(mezcla.subList(rojos, mezcla.size())));
    }

    static void ponerChaleco(LivingEntity quien, boolean rojo) {
        ItemStack antes = quien.getItemBySlot(EquipmentSlot.CHEST);
        if (quien instanceof ServerPlayer && !esChaleco(antes) && !CAMISAS.containsKey(quien.getUUID())) {
            CAMISAS.put(quien.getUUID(), antes.copy());
        }
        quien.setItemSlot(EquipmentSlot.CHEST, new ItemStack(rojo ? Registro.CHALECO_ROJO.get() : Registro.CHALECO_AZUL.get()));
        if (quien instanceof JugadorBot bot) {
            bot.setDropChance(EquipmentSlot.CHEST, 0.0F);
        }
    }

    static boolean esChaleco(ItemStack cosa) {
        return cosa.is(Registro.CHALECO_ROJO.get()) || cosa.is(Registro.CHALECO_AZUL.get());
    }

    /** Se saca el chaleco (y el jugador vuelve a tener su camisa); también los que tenga guardados. */
    static void sacarChaleco(LivingEntity quien) {
        ItemStack camisa = CAMISAS.remove(quien.getUUID());
        if (esChaleco(quien.getItemBySlot(EquipmentSlot.CHEST))) {
            quien.setItemSlot(EquipmentSlot.CHEST, camisa != null ? camisa : ItemStack.EMPTY);
        }
        if (quien instanceof ServerPlayer jugador) {
            Inventory inventario = jugador.getInventory();
            for (int i = 0; i < inventario.getContainerSize(); i++) {
                if (esChaleco(inventario.getItem(i))) {
                    inventario.setItem(i, ItemStack.EMPTY);
                }
            }
        }
    }

    static void olvidar() {
        CAMISAS.clear();
    }
}
