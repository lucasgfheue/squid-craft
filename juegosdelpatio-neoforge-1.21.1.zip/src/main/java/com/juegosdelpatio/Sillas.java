package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityMountEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * El juego 2, "Las sillas musicales" (el día 2 del ciclo). Todos juntos en una ronda enorme: las sillas en el centro
 * del salón (en anillos alrededor del gramófono gigante, mirando para afuera) y la pista para caminar lejos de ellas,
 * cerca de las paredes.
 *
 * <ol>
 *   <li>Mientras suena la música, todos caminan alrededor por la pista, como las agujas del reloj. Al jugador que deja
 *       de caminar (o se va de la pista) se le avisa y, si sigue sin caminar, queda eliminado.</li>
 *   <li>Cuando la música para, las luces del salón parpadean unos segundos y todos corren al centro a sentarse en una
 *       silla libre (clic derecho). Los que se quedan sin silla quedan eliminados.</li>
 *   <li>El que quedó parado puede sacar a uno que está sentado: clic derecho sobre él varias veces (8 tirones más que
 *       las veces que el otro aguanta). El que está sentado aguanta apretando la Z rápido. Cuando ya no quedan sillas
 *       libres, hay 5 segundos para pelearlas; después salen los que siguen parados. Los bots también tiran y
 *       aguantan.</li>
 *   <li>Son 3 rondas: en la primera hay 3 sillas menos que gente, en la segunda 5 menos y en la tercera 7 menos (15
 *       eliminados en total). Los que quedan después de la tercera, pasan.</li>
 * </ol>
 *
 * Como en todos los juegos, no se puede pegar pero sí empujar (jugadores y bots, a cualquiera que esté parado). Al
 * que está sentado no se lo puede empujar ni se puede levantar hasta que termine la ronda.
 */
public final class Sillas {
    // ------------------------------------------------------------------ la arena (igual que gen_sillas.py)
    public static final ResourceLocation ARENA = Complejo.id("sillas");
    /** Esquina de la plantilla sillas.nbt (81 x 18 x 97). */
    public static final BlockPos ORIGEN = new BlockPos(1960, 99, -17);
    /** 1: la de los 20 círculos chicos; 2: la de la ronda enorme. */
    static final int VERSION_ARENA = 3;                     // 3: paredes negras y notas de luz
    /** Lo que ocupa la arena, para mantenerla cargada mientras se juega. */
    static final int X0 = 1960;
    static final int X1 = 2040;
    static final int Z0 = -17;
    static final int Z1 = 79;
    /** El podio del comandante, en la entrada, mirando al salón (al sur). */
    static final Vec3 PODIO = new Vec3(2000.5, 102.0, -13.5);
    /** Los cuatro sargentos, en las esquinas del salón (afuera de la pista). */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(1963.5, 100.0, 6.5), new Vec3(2036.5, 100.0, 6.5),
            new Vec3(1963.5, 100.0, 63.5), new Vec3(2036.5, 100.0, 63.5),
    };
    /** El centro de la ronda: el bloque del medio, debajo del gramófono. */
    static final int CENTRO_X = 2000;
    static final int CENTRO_Z = 41;
    private static final double CX = CENTRO_X + 0.5;
    private static final double CZ = CENTRO_Z + 0.5;
    /** Donde se para la gente (y donde van las sillas). */
    static final int PISO = 100;
    /** La boca de la bocina del gramófono: de ahí salen las notas. */
    private static final Vec3 BOCINA = new Vec3(2000.5, 113.5, 43.5);

    // ------------------------------------------------------------------ reglas
    /** Cuántas sillas menos que gente hay en cada ronda: 3, 5 y 7 (15 eliminados en total). */
    static final int[] FALTAN = {3, 5, 7};
    static final int RONDAS = FALTAN.length;
    /** Los anillos de sillas alrededor del gramófono, de adentro para afuera (distancia al centro). */
    static final double[] RADIOS_SILLAS = {7.0, 10.0, 13.0, 16.0, 19.0};
    /** Cuánto de cada anillo se llena como mucho: el resto queda de paso para llegar a los anillos de adentro. */
    static final double LLENO_MAXIMO = 0.7;
    /** La pista para caminar, cerca de las paredes: a esta distancia del centro (de 31 a 35,8 todavía es la pista). */
    static final double RADIO_PISTA = 33.0;
    static final double PISTA_MIN = 31.0;
    static final double PISTA_MAX = 35.8;
    /** Caminando, cada segundo hay que avanzar por lo menos esto (en bloques, por la pista). */
    private static final double AVANCE_MINIMO = 0.6;
    /** Segundos seguidos sin caminar: a los 2 se te avisa; a los 5 quedas eliminado. */
    private static final int AVISO_QUIETO = 2;
    private static final int ELIMINA_QUIETO = 5;
    /** La música dura de 7 a 15 segundos (la primera ronda, 3 segundos más). Nadie sabe cuándo para. */
    private static final int MUSICA_MIN = 140;
    private static final int MUSICA_AZAR = 161;
    /** Cuando para la música, hay 12 segundos para llegar a una silla y sentarse. */
    static final int TIEMPO_SENTARSE = 240;
    /** Cuando ya no quedan sillas libres, hay 5 segundos para sacar a alguien; después salen los que siguen parados. */
    static final int TIEMPO_PELEA = 100;
    /** Para sacar a alguien hacen falta 8 tirones más que las veces que él aguantó (apretando la Z). */
    static final int TIRON_MAXIMO = 8;
    /** Cada cuánto cuenta un tirón (clic derecho) de alguien, y una Z del que está sentado (en ticks). */
    private static final int ENTRE_TIRONES = 3;
    private static final int ENTRE_AGUANTES = 2;
    /** Si nadie tira por un rato, los tirones se aflojan solos (uno cada tantos ticks). */
    private static final int AFLOJA = 15;
    /** Hasta dónde llega uno para tirar de otro. */
    static final double ALCANCE_TIRON = 3.0;
    /**
     * Desde dónde se puede sentar uno (distancia al centro de la silla). El jugador, con clic derecho; el bot se sienta
     * solo apenas tiene una silla libre a esta distancia.
     */
    static final double ALCANCE_JUGADOR = 2.0;
    static final double ALCANCE_BOT = 1.8;
    // ------------------------------------------------------------------ los bots (difíciles)
    /** Cuando para la música, los bots se dan cuenta al instante (0 o 1 tick). */
    private static final int REACCION_MAXIMA = 1;
    /** Corriendo a las sillas, los bots van un poco más rápido que un jugador corriendo (y no se cansan). */
    static final double CORRIDA_BOT = 0.95;
    /** Por cada jugador que sigue parado, los bots más cercanos a la silla adonde va él van por esa misma silla. */
    private static final int RIVALES_POR_JUGADOR = 2;
    /** Para sacar a alguien de la silla, los bots van primero por los jugadores (como si estuvieran más cerca). */
    private static final double PREFIEREN_JUGADORES = 0.35;
    /** Mientras suena la música, cada segundo, de cada 100 veces que un bot tiene un jugador al lado, lo empuja 12. */
    static final int EMPUJA_JUGADOR_POR_CIENTO = 12;
    /** Un paso de la música (una corchea) cada 4 ticks. */
    private static final int PASO_MUSICA = 4;
    /**
     * La música (original, hecha para el juego): 8 compases de 8 corcheas, con notas de bloque musical
     * (0 = fa# grave ... 24 = fa# agudo; -1 = silencio). La melodía va con arpa y el bajo, con el bajo.
     */
    private static final int[] MELODIA = {
            22, -1, 13, -1, 18, -1, 22, 20,
            18, -1, 15, -1, 11, -1, 15, -1,
            20, -1, 11, -1, 17, -1, 20, 18,
            17, -1, 13, -1, 8, -1, 13, -1,
            22, -1, 13, -1, 18, -1, 22, 23,
            22, 20, 18, -1, 15, -1, 18, -1,
            20, -1, 17, -1, 13, -1, 17, 20,
            18, -1, 22, -1, 18, -1, -1, -1,
    };
    /** El bajo de cada compás: la nota del tiempo 1 y la del tiempo 3 (do, fa, sol, sol, do, fa, sol, do). */
    private static final int[][] BAJO = {{6, 13}, {11, 18}, {13, 20}, {13, 20}, {6, 13}, {11, 18}, {13, 20}, {6, 13}};
    /** Las celdas de cada anillo de sillas, ordenadas por ángulo. */
    private static final List<List<BlockPos>> ANILLOS = anillos();

    private enum Estado { NINGUNO, EMPEZANDO, MUSICA, SENTARSE, RESULTADO, PAUSA, TERMINADO }

    /** Un bot que va a una silla, y a qué distancia estaba (si otro está más cerca, se la deja). */
    private record Reclamo(UUID quien, double distancia) {
    }

    /** Los tirones que lleva uno que está sentado (0 = nada; con TIRON_MAXIMO lo sacan). */
    private static final class Tiron {
        int fuerza;
        int quieto;
        @Nullable
        UUID ultimo;
    }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int ronda;
    private static int duracion;
    private static int eliminadosRonda;
    private static int llenoDesde = -1;
    /** Los que siguen en la ronda (jugadores y bots), y lo mismo para buscar rápido. */
    private static final List<UUID> GENTE = new ArrayList<>();
    private static final Set<UUID> EN_RONDA = new HashSet<>();
    private static final List<BlockPos> SILLAS = new ArrayList<>();
    private static final Set<BlockPos> ES_SILLA = new HashSet<>();
    /** Silla -> quién está sentado, y los sentados (para buscar rápido). */
    private static final Map<BlockPos, UUID> OCUPADAS = new HashMap<>();
    private static final Set<UUID> SENTADOS = new HashSet<>();
    private static final Map<UUID, JugadorBot> BOTS = new HashMap<>();
    /** Cuando para la música, cada bot tarda un poquito en darse cuenta (ticks). */
    private static final Map<UUID, Integer> REACCION = new HashMap<>();
    private static final Map<BlockPos, Reclamo> RECLAMOS = new HashMap<>();
    /** Jugadores con la música: {ángulo anterior, cuánto avanzó en este segundo, segundos sin caminar, salió de la pista}. */
    private static final Map<UUID, double[]> CAMINATA = new HashMap<>();
    /** Cuándo empujaron a cada uno (si lo empujaron, ese segundo no cuenta como que no caminó). */
    private static final Map<UUID, Long> EMPUJADO = new HashMap<>();
    private static final Set<UUID> PASARON = new HashSet<>();
    /** De cada uno que están tratando de sacar de la silla: cuántos tirones lleva, y quién tiró último. */
    private static final Map<UUID, Tiron> TIRONES = new HashMap<>();
    private static final Map<UUID, Long> ULTIMO_TIRON = new HashMap<>();
    private static final Map<UUID, Long> ULTIMO_AGUANTE = new HashMap<>();
    /** Mientras el juego levanta a todos de las sillas (ahí sí se pueden bajar). */
    private static boolean levantando;
    /** Bot -> el jugador por cuya silla va; jugador -> la silla libre adonde va; y dónde estaba hace 10 ticks. */
    private static final Map<UUID, UUID> RIVALES = new HashMap<>();
    private static final Map<UUID, BlockPos> SILLA_DE = new HashMap<>();
    private static final Map<UUID, Vec3> ANTES = new HashMap<>();
    /** Ticks desde que empezaron a parpadear las luces (-1 = no parpadean). */
    private static int parpadeo = -1;

    private Sillas() {
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean suenaMusica() {
        return estado == Estado.MUSICA;
    }

    static boolean hayQueSentarse() {
        return estado == Estado.SENTARSE;
    }

    static int pasaron() {
        return PASARON.size();
    }

    /** Sigue jugando en la ronda (todavía no terminó el juego y no quedó eliminado). */
    static boolean participa(LivingEntity quien) {
        return EN_RONDA.contains(quien.getUUID()) && estado != Estado.NINGUNO && estado != Estado.TERMINADO;
    }

    /** Sobrevivió a las tres rondas: pasó al juego siguiente. */
    static boolean paso(LivingEntity quien) {
        return PASARON.contains(quien.getUUID());
    }

    /** Lo acaban de empujar (para que ese segundo no cuente como que no caminó). */
    static void empujado(LivingEntity quien) {
        if (estado != Estado.NINGUNO) {
            EMPUJADO.put(quien.getUUID(), quien.level().getGameTime());
        }
    }

    // ------------------------------------------------------------------ la arena
    /**
     * Construye la arena la primera vez (y saca la plataforma provisoria que había antes para el juego 2). Si había un
     * salón de una versión anterior, lo vacía por dentro antes de poner el nuevo. false si no se pudo.
     */
    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionSillas() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        BlockState aire = Blocks.AIR.defaultBlockState();
        Iterable<BlockPos> vaciar = estadoComplejo.versionSillas() > 0
                ? BlockPos.betweenClosed(X0 + 1, PISO, Z0 + 2, X1 - 1, PISO + 15, Z1 - 1)    // el salón viejo, por dentro
                : BlockPos.betweenClosed(1986, 99, -14, 2014, 105, 14);                     // Portales.prepararJuego
        for (BlockPos pos : vaciar) {
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionSillas(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Las sillas musicales colocada en {}", ORIGEN);
        return true;
    }

    /** Dónde aparece quien llega al juego 2: la entrada del salón (delante del podio). */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(1985.5 + azar.nextInt(31), PISO, -10.5 + azar.nextInt(13));
    }

    // ------------------------------------------------------------------ empieza el juego
    /** Todos a la pista, repartidos parejo alrededor; las sillas en el centro (3 menos que la gente). */
    static void empezar(ServerLevel complejo, List<LivingEntity> participantes) {
        olvidar();
        quitarTodasLasSillas(complejo);
        RandomSource azar = complejo.getRandom();
        List<LivingEntity> todos = new ArrayList<>(participantes);
        mezclar(todos, azar);
        for (LivingEntity quien : todos) {
            GENTE.add(quien.getUUID());
            EN_RONDA.add(quien.getUUID());
            if (quien instanceof JugadorBot bot) {
                BOTS.put(bot.getUUID(), bot);
            }
        }
        ronda = 1;
        if (GENTE.size() <= 1) {
            terminarJuego(complejo);                                   // uno solo (o nadie): pasa directo
            return;
        }
        ponerSillas(complejo, sillasDeLaRonda(), azar);
        repartirEnLaPista(complejo);
        anunciarRonda(complejo);
        cambiar(Estado.EMPEZANDO);
    }

    /** A todos a la pista, lejos de las sillas: repartidos parejo alrededor y mirando para donde se camina. */
    private static void repartirEnLaPista(ServerLevel complejo) {
        List<LivingEntity> todos = new ArrayList<>();
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien != null) {
                todos.add(quien);
            }
        }
        RandomSource azar = complejo.getRandom();
        mezclar(todos, azar);                                          // cada ronda, otro orden
        double inicio = azar.nextDouble() * Math.PI * 2.0;
        for (int i = 0; i < todos.size(); i++) {
            LivingEntity quien = todos.get(i);
            double angulo = inicio + Math.PI * 2.0 * i / todos.size();
            Vec3 lugar = enLaPista(angulo, RADIO_PISTA);
            float giro = (float) Math.toDegrees(angulo);                  // mirando para donde se camina
            if (quien instanceof ServerPlayer jugador) {
                jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
            } else if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                bot.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            }
        }
    }

    /** Cuántas sillas hay en esta ronda: los que quedan menos 3, 5 o 7 (por lo menos una). */
    private static int sillasDeLaRonda() {
        return Math.max(1, GENTE.size() - FALTAN[Math.min(ronda, RONDAS) - 1]);
    }

    /** El comandante dice qué ronda es, cuántos son y cuántas sillas hay; en la pantalla, lo mismo. */
    private static void anunciarRonda(ServerLevel complejo) {
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.sillas_ronda_inicio", ronda, RONDAS,
                GENTE.size(), SILLAS.size()));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.ronda_sillas", ronda, RONDAS)
                            .withStyle(ChatFormatting.GOLD),
                    Component.translatable("titulo.juegosdelpatio.ronda_detalle", GENTE.size(), SILLAS.size())
                            .withStyle(ChatFormatting.GRAY), 5, 45, 10);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 1.2F);
        }
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    /** Avanza el juego. true cuando ya terminaron las tres rondas. */
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        if (parpadeo >= 0) {
            parpadear(complejo);
        }
        switch (estado) {
            case EMPEZANDO, PAUSA -> {
                if (tiempo >= 60) {
                    empezarMusica(complejo);
                }
            }
            case MUSICA -> {
                musica(complejo);
                caminatas(complejo);
                if (tiempo >= duracion) {
                    pararMusica(complejo);
                }
            }
            case SENTARSE -> sentarse(complejo);
            case RESULTADO -> {
                validarSentados(complejo);
                if (tiempo >= 50) {
                    levantarse(complejo);
                }
            }
            default -> {
            }
        }
        if (tiempo % 10 == 1 || estado == Estado.TERMINADO) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    private static void empezarMusica(ServerLevel complejo) {
        duracion = MUSICA_MIN + complejo.getRandom().nextInt(MUSICA_AZAR) + (ronda == 1 ? 60 : 0);
        CAMINATA.clear();
        RECLAMOS.clear();
        REACCION.clear();
        cambiar(Estado.MUSICA);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (participa(jugador)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.camina_musica")
                        .withStyle(ChatFormatting.LIGHT_PURPLE), true);
            }
        }
    }

    /** Una nota por paso: la melodía, el bajo y la batería, para todos los que están en el salón. */
    private static void musica(ServerLevel complejo) {
        if ((tiempo - 1) % PASO_MUSICA != 0) {
            return;
        }
        int paso = (tiempo - 1) / PASO_MUSICA;
        int nota = MELODIA[paso % MELODIA.length];
        int enCompas = paso % 8;
        int[] bajo = BAJO[(paso / 8) % BAJO.length];
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (nota >= 0) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_HARP.value(), 0.9F, nota);
            }
            if (enCompas == 0 || enCompas == 4) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_BASS.value(), 0.8F, bajo[enCompas / 4]);
                sonar(jugador, enCompas == 0 ? SoundEvents.NOTE_BLOCK_BASEDRUM.value() : SoundEvents.NOTE_BLOCK_SNARE.value(),
                        0.4F, 12);
            } else if (enCompas == 2 || enCompas == 6) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_HAT.value(), 0.25F, 12);
            }
        }
        if (nota >= 0 && paso % 2 == 0) {                           // las notas de colores salen de la bocina
            complejo.sendParticles(ParticleTypes.NOTE, BOCINA.x, BOCINA.y, BOCINA.z, 0, nota / 24.0, 0.0, 0.0, 1.0);
        }
    }

    private static void sonar(ServerPlayer jugador, SoundEvent sonido, float volumen, int nota) {
        jugador.playNotifySound(sonido, SoundSource.RECORDS, volumen, (float) Math.pow(2.0, (nota - 12) / 12.0));
    }

    /**
     * Con la música, los jugadores tienen que caminar por la pista, alrededor (como las agujas del reloj). Cada segundo
     * se mira cuánto avanzaron: si no caminaron, se les avisa, y si siguen sin caminar, quedan eliminados. Los primeros
     * 2 segundos no cuentan (para arrancar), y si te empujaron, ese segundo tampoco.
     */
    private static void caminatas(ServerLevel complejo) {
        long ahora = complejo.getGameTime();
        boolean juzgar = tiempo % 20 == 0;
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!participa(jugador) || !jugador.isAlive() || jugador.isSpectator() || jugador.isCreative()) {
                continue;
            }
            double dx = jugador.getX() - CX;
            double dz = jugador.getZ() - CZ;
            double angulo = Math.atan2(dz, dx);
            double radio = Math.sqrt(dx * dx + dz * dz);
            double[] caminata = CAMINATA.computeIfAbsent(jugador.getUUID(), id -> new double[] {angulo, 0.0, 0.0, 0.0});
            caminata[1] += diferencia(angulo, caminata[0]) * radio;        // en bloques, por la pista
            caminata[0] = angulo;
            if (radio < PISTA_MIN || radio > PISTA_MAX) {
                caminata[3] = 1.0;
            }
            if (!juzgar) {
                continue;
            }
            if (tiempo > 40) {
                Long empujon = EMPUJADO.get(jugador.getUUID());
                boolean loEmpujaron = empujon != null && ahora - empujon < 40;
                boolean mal = (caminata[1] < AVANCE_MINIMO || caminata[3] > 0.0) && !loEmpujaron;
                caminata[2] = mal ? caminata[2] + 1.0 : 0.0;
                if (caminata[2] >= ELIMINA_QUIETO) {
                    eliminar(complejo, jugador, "no_caminaste");
                    continue;
                }
                if (caminata[2] >= AVISO_QUIETO) {
                    jugador.displayClientMessage(Component.translatable(caminata[3] > 0.0
                            ? "mensaje.juegosdelpatio.vuelve_pista" : "mensaje.juegosdelpatio.camina")
                            .withStyle(ChatFormatting.RED), true);
                    jugador.playNotifySound(SoundEvents.NOTE_BLOCK_DIDGERIDOO.value(), SoundSource.MASTER, 1.0F, 0.6F);
                }
            }
            caminata[1] = 0.0;
            caminata[3] = 0.0;
        }
    }

    /**
     * Para la música: parpadean las luces y todos corren a las sillas. Los bots se dan cuenta al instante, y algunos
     * van derecho a la silla adonde va cada jugador.
     */
    private static void pararMusica(ServerLevel complejo) {
        levantarATodos(complejo);                                      // nadie puede llegar sentado de antes
        cambiar(Estado.SENTARSE);
        eliminadosRonda = 0;
        llenoDesde = -1;
        RandomSource azar = complejo.getRandom();
        for (UUID id : BOTS.keySet()) {
            REACCION.put(id, azar.nextInt(REACCION_MAXIMA + 1));
        }
        ANTES.clear();
        elegirRivales(complejo);
        empezarParpadeo(complejo);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (participa(jugador)) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.a_sentarse").withStyle(ChatFormatting.RED),
                        Component.translatable("titulo.juegosdelpatio.a_sentarse_detalle").withStyle(ChatFormatting.GRAY),
                        0, 30, 8);
            }
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), SoundSource.RECORDS, 1.0F, 0.5F);
        }
    }

    // ------------------------------------------------------------------ las luces que parpadean
    /**
     * Las luces del salón empiezan a parpadear (4 segundos). Cada cliente dibuja el parpadeo (ver {@link Parpadeo});
     * acá solo se avisa y suenan los clics de las luces al mismo ritmo.
     */
    private static void empezarParpadeo(ServerLevel complejo) {
        parpadeo = 0;
        Parpadeo aviso = new Parpadeo(Parpadeo.DURACION);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            PacketDistributor.sendToPlayer(jugador, aviso);
        }
        clicLuces(complejo, false);
    }

    /** Cada tick del parpadeo: cuando las luces se apagan o se prenden, suena el clic. */
    private static void parpadear(ServerLevel complejo) {
        parpadeo++;
        if (parpadeo >= Parpadeo.DURACION) {
            parpadeo = -1;                                             // se terminó: quedan prendidas
            return;
        }
        boolean apagadas = Parpadeo.apagadas(parpadeo);
        if (apagadas != Parpadeo.apagadas(parpadeo - 1)) {
            clicLuces(complejo, !apagadas);
        }
    }

    private static void clicLuces(ServerLevel complejo, boolean prenden) {
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(prenden ? SoundEvents.COPPER_BULB_TURN_ON : SoundEvents.COPPER_BULB_TURN_OFF,
                    SoundSource.BLOCKS, 0.8F, prenden ? 1.0F : 0.8F);
        }
    }

    /** Si estaban parpadeando, las luces vuelven ya (el juego se cortó). */
    private static void cortarParpadeo(ServerLevel complejo) {
        if (parpadeo >= 0) {
            Parpadeo corte = new Parpadeo(0);
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                PacketDistributor.sendToPlayer(jugador, corte);
            }
        }
        parpadeo = -1;
    }

    /**
     * Los bots van por la silla de los jugadores: para cada jugador que sigue parado se calcula a qué silla libre va
     * (la más cercana a donde va a estar en un rato, por cómo se viene moviendo) y los 2 bots parados más cercanos a
     * esa silla van por ella, y lo empujan si lo tienen al lado.
     */
    private static void elegirRivales(ServerLevel complejo) {
        RIVALES.clear();
        SILLA_DE.clear();
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            UUID id = jugador.getUUID();
            Vec3 ahora = jugador.position();
            Vec3 antes = ANTES.put(id, ahora);
            if (!EN_RONDA.contains(id) || SENTADOS.contains(id)) {
                continue;
            }
            Vec3 va = antes == null ? ahora : ahora.add(ahora.subtract(antes).scale(1.5));   // dentro de unos 15 ticks
            BlockPos silla = libreMasCercana(complejo, va);
            if (silla == null) {
                continue;
            }
            SILLA_DE.put(id, silla);
            List<JugadorBot> cerca = new ArrayList<>();
            for (JugadorBot bot : BOTS.values()) {
                UUID botId = bot.getUUID();
                if (bot.isAlive() && EN_RONDA.contains(botId) && !SENTADOS.contains(botId) && !RIVALES.containsKey(botId)) {
                    cerca.add(bot);
                }
            }
            cerca.sort(Comparator.comparingDouble(bot -> bot.distanceToSqr(silla.getX() + 0.5, silla.getY(), silla.getZ() + 0.5)));
            for (int i = 0; i < Math.min(RIVALES_POR_JUGADOR, cerca.size()); i++) {
                RIVALES.put(cerca.get(i).getUUID(), id);
            }
        }
    }

    @Nullable
    private static BlockPos libreMasCercana(ServerLevel complejo, Vec3 donde) {
        BlockPos mejor = null;
        double menor = Double.MAX_VALUE;
        for (BlockPos silla : SILLAS) {
            if (ocupada(complejo, silla)) {
                continue;
            }
            double d = distancia2(donde.x, donde.z, silla.getX() + 0.5, silla.getZ() + 0.5);
            if (d < menor) {
                menor = d;
                mejor = silla;
            }
        }
        return mejor;
    }

    /**
     * Cada tick mientras la gente se sienta: cuando ya no quedan sillas libres, los que quedaron parados tienen 5
     * segundos para sacar a alguien; después salen. Si nunca se ocupan todas, a los 12 segundos sale el que siga
     * parado. Cuando no queda nadie parado, se terminó la ronda.
     */
    private static void sentarse(ServerLevel complejo) {
        validarSentados(complejo);
        tirones(complejo);
        if (tiempo % 10 == 0) {
            elegirRivales(complejo);                                   // el jugador cambió de idea: lo siguen
        }
        List<LivingEntity> parados = parados(complejo);
        if (!parados.isEmpty()) {
            boolean lleno = OCUPADAS.size() >= SILLAS.size();
            if (!lleno) {
                llenoDesde = -1;
            } else if (llenoDesde < 0) {
                llenoDesde = tiempo;
                avisarPelea(complejo);                                 // no quedan sillas libres: a pelearlas
            }
            boolean finPelea = lleno && tiempo - llenoDesde >= TIEMPO_PELEA;
            boolean finTiempo = !lleno && tiempo >= TIEMPO_SENTARSE || tiempo >= TIEMPO_SENTARSE + TIEMPO_PELEA;
            if (finPelea || finTiempo) {
                for (LivingEntity quien : parados) {
                    eliminar(complejo, quien, "sin_silla");              // se quedó sin silla
                }
                parados.clear();
            }
        }
        if (parados.isEmpty()) {
            Juego.decir(complejo, eliminadosRonda == 0
                    ? Component.translatable("juego.juegosdelpatio.sillas_ronda_todos", ronda)
                    : Component.translatable("juego.juegosdelpatio.sillas_ronda", ronda, eliminadosRonda));
            cambiar(Estado.RESULTADO);
        }
    }

    /**
     * Todos se levantan. Si fue la tercera ronda, el juego terminó y los que quedan pasan; si no, se sacan sillas
     * para la ronda siguiente (5 menos que la gente, y después 7 menos) y todos vuelven a la pista.
     */
    private static void levantarse(ServerLevel complejo) {
        levantarATodos(complejo);
        RECLAMOS.clear();
        REACCION.clear();
        TIRONES.clear();
        ULTIMO_TIRON.clear();
        ULTIMO_AGUANTE.clear();
        RIVALES.clear();
        SILLA_DE.clear();
        GENTE.removeIf(id -> buscar(complejo, id) == null);           // se fueron o quedaron eliminados
        EN_RONDA.retainAll(GENTE);
        if (ronda >= RONDAS || GENTE.size() <= 1) {
            terminarJuego(complejo);
            return;
        }
        ronda++;
        int quedan = sillasDeLaRonda();
        RandomSource azar = complejo.getRandom();
        while (SILLAS.size() > quedan) {
            quitarSilla(complejo, SILLAS.get(azar.nextInt(SILLAS.size())));   // se saca una silla
        }
        repartirEnLaPista(complejo);                                   // todos de vuelta a la pista, lejos
        anunciarRonda(complejo);
        cambiar(Estado.PAUSA);
    }

    /** Terminaron las tres rondas: los que quedan pasan, y se sacan las sillas. */
    private static void terminarJuego(ServerLevel complejo) {
        quitarSillas(complejo);
        PASARON.addAll(GENTE);
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien instanceof ServerPlayer jugador) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.pasaste").withStyle(ChatFormatting.GREEN),
                        Component.translatable("titulo.juegosdelpatio.pasaste_sillas").withStyle(ChatFormatting.GRAY),
                        5, 50, 15);
                jugador.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
            } else if (quien instanceof JugadorBot bot) {
                bot.mostrarEmote(Emote.FELIZ);
            }
        }
        cambiar(Estado.TERMINADO);
    }

    private static void eliminar(ServerLevel complejo, LivingEntity quien, String motivo) {
        GENTE.remove(quien.getUUID());
        EN_RONDA.remove(quien.getUUID());
        eliminadosRonda++;
        Juego.eliminar(complejo, quien, false, motivo);
    }

    private static void cambiar(Estado nuevo) {
        estado = nuevo;
        tiempo = 0;
    }

    private static void barra(ServerLevel complejo) {
        int gente = GENTE.size();
        int sillas = SILLAS.size();
        Component nombre;
        BossEvent.BossBarColor color;
        float progreso = 1.0F;
        switch (estado) {
            case MUSICA -> {
                nombre = Component.translatable("barra.juegosdelpatio.sillas_musica", ronda, RONDAS, gente, sillas);
                color = BossEvent.BossBarColor.PURPLE;
            }
            case SENTARSE -> {
                boolean pelea = llenoDesde >= 0;
                nombre = Component.translatable(pelea ? "barra.juegosdelpatio.sillas_pelea"
                        : "barra.juegosdelpatio.sillas_sentarse", ronda, RONDAS, gente, sillas);
                color = pelea ? BossEvent.BossBarColor.YELLOW : BossEvent.BossBarColor.RED;
                progreso = pelea ? 1.0F - (tiempo - llenoDesde) / (float) TIEMPO_PELEA
                        : 1.0F - tiempo / (float) TIEMPO_SENTARSE;
            }
            case TERMINADO -> {
                nombre = Component.translatable("barra.juegosdelpatio.sillas_fin", PASARON.size());
                color = BossEvent.BossBarColor.GREEN;
            }
            default -> {
                nombre = Component.translatable("barra.juegosdelpatio.sillas_ronda", ronda, RONDAS, gente, sillas);
                color = BossEvent.BossBarColor.WHITE;
            }
        }
        Juego.barraJuego(complejo, nombre, color, progreso);
    }

    // ------------------------------------------------------------------ sillas
    /**
     * Las celdas de cada anillo de sillas (las que están a ese radio del centro), ordenadas por ángulo, sin dos pegadas
     * de costado: así delante de cada silla siempre queda lugar para pararse y sentarse.
     */
    private static List<List<BlockPos>> anillos() {
        List<List<BlockPos>> todos = new ArrayList<>();
        for (double radio : RADIOS_SILLAS) {
            List<BlockPos> celdas = new ArrayList<>();
            int hasta = (int) Math.ceil(radio) + 1;
            for (int dx = -hasta; dx <= hasta; dx++) {
                for (int dz = -hasta; dz <= hasta; dz++) {
                    if (Math.abs(Math.sqrt(dx * dx + dz * dz) - radio) < 0.5) {    // una sola celda de ancho
                        celdas.add(new BlockPos(CENTRO_X + dx, PISO, CENTRO_Z + dz));
                    }
                }
            }
            celdas.sort(Comparator.comparingDouble(pos -> Math.atan2(pos.getZ() - CENTRO_Z, pos.getX() - CENTRO_X)));
            List<BlockPos> sueltas = new ArrayList<>();
            for (BlockPos celda : celdas) {
                if (sueltas.isEmpty() || !pegadas(celda, sueltas.get(sueltas.size() - 1))) {
                    sueltas.add(celda);
                }
            }
            if (sueltas.size() > 1 && pegadas(sueltas.get(0), sueltas.get(sueltas.size() - 1))) {
                sueltas.remove(sueltas.size() - 1);
            }
            todos.add(List.copyOf(sueltas));
        }
        return List.copyOf(todos);
    }

    private static boolean pegadas(BlockPos a, BlockPos b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getZ() - b.getZ()) == 1;
    }

    /**
     * Pone las sillas en el centro, en anillos alrededor del gramófono, mirando para afuera: se usan los anillos de
     * adentro que hagan falta y las sillas se reparten parejo entre ellos, dejando lugar para pasar a los de adentro.
     */
    private static void ponerSillas(ServerLevel complejo, int cantidad, RandomSource azar) {
        quitarSillas(complejo);
        int total = 0;
        for (List<BlockPos> anillo : ANILLOS) {
            total += anillo.size();
        }
        cantidad = Math.min(cantidad, total);
        int usados = 0;
        int lugar = 0;
        while (usados < ANILLOS.size() && lugar < cantidad) {
            lugar += (int) (ANILLOS.get(usados).size() * LLENO_MAXIMO);
            usados++;
        }
        boolean apretado = lugar < cantidad;                            // más sillas de las que entran con paso
        int[] capacidad = new int[usados];
        int suma = 0;
        for (int i = 0; i < usados; i++) {
            capacidad[i] = apretado ? ANILLOS.get(i).size() : (int) (ANILLOS.get(i).size() * LLENO_MAXIMO);
            suma += capacidad[i];
        }
        int puestas = 0;
        for (int i = 0; i < usados; i++) {
            List<BlockPos> celdas = ANILLOS.get(i);
            int aca = i == usados - 1 ? cantidad - puestas : (int) Math.round((double) cantidad * capacidad[i] / suma);
            aca = Math.max(0, Math.min(aca, celdas.size()));
            double desfase = azar.nextDouble();
            for (int j = 0; j < aca; j++) {
                ponerSilla(complejo, celdas.get((int) ((j + desfase) * celdas.size() / aca) % celdas.size()), i);
            }
            puestas += aca;
        }
    }

    private static void ponerSilla(ServerLevel complejo, BlockPos pos, int anillo) {
        if (ES_SILLA.contains(pos)) {
            return;
        }
        Direction mira = Direction.getNearest(pos.getX() + 0.5 - CX, 0.0, pos.getZ() + 0.5 - CZ);   // para afuera
        BlockState silla = Registro.SILLA.get().defaultBlockState()
                .setValue(SillaBlock.FACING, mira).setValue(SillaBlock.COLOR, anillo % SillaBlock.COLORES);
        complejo.setBlock(pos, silla, Block.UPDATE_ALL);
        SILLAS.add(pos);
        ES_SILLA.add(pos);
        complejo.sendParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 3,
                0.2, 0.2, 0.2, 0.01);
    }

    private static void quitarSilla(ServerLevel complejo, BlockPos pos) {
        SILLAS.remove(pos);
        ES_SILLA.remove(pos);
        UUID sentado = OCUPADAS.remove(pos);
        if (sentado != null) {
            SENTADOS.remove(sentado);
        }
        if (complejo.getBlockState(pos).getBlock() instanceof SillaBlock) {
            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
            complejo.sendParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 8,
                    0.25, 0.3, 0.25, 0.02);
            complejo.playSound(null, pos, SoundEvents.WOOD_BREAK, SoundSource.BLOCKS, 1.0F, 0.9F);
        }
    }

    private static void quitarSillas(ServerLevel complejo) {
        for (BlockPos pos : List.copyOf(SILLAS)) {
            quitarSilla(complejo, pos);
        }
    }

    /** Saca todas las sillas del centro (y los asientos), aunque hayan quedado de un juego que se cortó. */
    private static void quitarTodasLasSillas(ServerLevel complejo) {
        levantarATodos(complejo);
        int hasta = (int) Math.ceil(RADIOS_SILLAS[RADIOS_SILLAS.length - 1]) + 2;
        for (int dx = -hasta; dx <= hasta; dx++) {
            for (int dz = -hasta; dz <= hasta; dz++) {
                BlockPos pos = new BlockPos(CENTRO_X + dx, PISO, CENTRO_Z + dz);
                if (complejo.getBlockState(pos).getBlock() instanceof SillaBlock) {
                    complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                }
            }
        }
        SILLAS.clear();
        ES_SILLA.clear();
    }

    /** Todos se levantan de las sillas del salón (se sacan los asientos). */
    private static void levantarATodos(ServerLevel complejo) {
        levantando = true;
        try {
            AABB salon = new AABB(X0, PISO - 1, Z0, X1 + 1, PISO + 4, Z1 + 1);
            for (Asiento asiento : complejo.getEntities(Registro.ASIENTO.get(), salon, cualquiera -> true)) {
                asiento.ejectPassengers();
                asiento.discard();
            }
        } finally {
            levantando = false;
        }
        OCUPADAS.clear();
        SENTADOS.clear();
    }

    /**
     * ¿Hay alguien sentado de verdad en esa silla? Si quedó anotado alguien que ya no está ahí (se fue, lo levantaron,
     * o es de antes), se borra y la silla queda libre.
     */
    private static boolean ocupada(ServerLevel complejo, BlockPos silla) {
        UUID quien = OCUPADAS.get(silla);
        if (quien == null) {
            return false;
        }
        if (sentadoAhi(buscar(complejo, quien), silla)) {
            return true;
        }
        OCUPADAS.remove(silla);
        if (!OCUPADAS.containsValue(quien)) {
            SENTADOS.remove(quien);
        }
        return false;
    }

    /** Está de verdad sentado en esa silla: montado en el asiento de esa silla, encima de ella, y sigue en la ronda. */
    private static boolean sentadoAhi(@Nullable LivingEntity quien, BlockPos silla) {
        return quien != null && EN_RONDA.contains(quien.getUUID()) && quien.getVehicle() instanceof Asiento asiento
                && !asiento.isRemoved() && asiento.blockPosition().equals(silla)
                && quien.distanceToSqr(silla.getX() + 0.5, quien.getY(), silla.getZ() + 0.5) < 1.0;
    }

    /** Se olvida de los que ya no están sentados en su silla (se fueron, o los levantaron). */
    private static void validarSentados(ServerLevel complejo) {
        OCUPADAS.entrySet().removeIf(sentado -> !sentadoAhi(buscar(complejo, sentado.getValue()), sentado.getKey()));
        SENTADOS.retainAll(Set.copyOf(OCUPADAS.values()));             // sentado = está en una silla anotada
    }

    private static List<LivingEntity> parados(ServerLevel complejo) {
        List<LivingEntity> parados = new ArrayList<>();
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien != null && !SENTADOS.contains(id)) {
                parados.add(quien);
            }
        }
        return parados;
    }

    private static boolean sentar(ServerLevel complejo, BlockPos silla, LivingEntity quien) {
        BlockState estadoSilla = complejo.getBlockState(silla);
        if (!(estadoSilla.getBlock() instanceof SillaBlock) || quien.isPassenger()) {
            return false;
        }
        levantando = true;                                             // un asiento viejo en esa silla: afuera
        try {
            for (Asiento viejo : complejo.getEntities(Registro.ASIENTO.get(), new AABB(silla), cualquiera -> true)) {
                viejo.ejectPassengers();
                viejo.discard();
            }
        } finally {
            levantando = false;
        }
        Asiento asiento = Asiento.sentar(complejo, silla, estadoSilla.getValue(SillaBlock.FACING), quien);
        if (asiento == null || quien.getVehicle() != asiento) {
            return false;
        }
        OCUPADAS.values().removeIf(id -> id.equals(quien.getUUID()));  // si quedó anotado en otra silla, ya no
        OCUPADAS.put(silla, quien.getUUID());
        SENTADOS.add(quien.getUUID());
        RECLAMOS.remove(silla);
        complejo.playSound(null, silla, SoundEvents.WOOD_PLACE, SoundSource.BLOCKS, 0.8F, 1.3F);
        if (quien instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.sentado")
                    .withStyle(ChatFormatting.GREEN), true);
        }
        return true;
    }

    /**
     * Un jugador hizo clic derecho en una silla. En el juego: solo cuando paró la música, en una silla libre y estando
     * cerca. Fuera del juego, cualquier silla libre sirve para sentarse.
     */
    static void alUsarSilla(ServerPlayer jugador, BlockPos pos) {
        ServerLevel complejo = jugador.serverLevel();
        if (!ES_SILLA.contains(pos) || estado == Estado.NINGUNO || estado == Estado.TERMINADO) {
            BlockState silla = complejo.getBlockState(pos);
            if (!jugador.isPassenger() && silla.getBlock() instanceof SillaBlock
                    && complejo.getEntities(Registro.ASIENTO.get(), new AABB(pos), cualquiera -> true).isEmpty()) {
                Asiento.sentar(complejo, pos, silla.getValue(SillaBlock.FACING), jugador);
            }
            return;
        }
        MutableComponent problema = null;
        if (!EN_RONDA.contains(jugador.getUUID())) {
            problema = Component.translatable("mensaje.juegosdelpatio.no_juegas");
        } else if (estado != Estado.SENTARSE) {
            problema = Component.translatable("mensaje.juegosdelpatio.todavia_musica");
        } else if (jugador.isPassenger()) {
            return;                                                    // ya está sentado
        } else {
            boolean ocupada = ocupada(complejo, pos);
            boolean lejos = distancia2(jugador.getX(), jugador.getZ(), pos.getX() + 0.5, pos.getZ() + 0.5)
                    > ALCANCE_JUGADOR * ALCANCE_JUGADOR;
            if (ocupada || lejos) {
                // tocó una silla ocupada (a veces es el respaldo de la de adelante) o una que no alcanza: si tiene una
                // libre a mano, para el lado que mira, se sienta en esa
                BlockPos aMano = libreAMano(complejo, jugador);
                if (aMano != null) {
                    sentar(complejo, aMano, jugador);
                    return;
                }
                LivingEntity sentado = ocupada ? buscar(complejo, OCUPADAS.get(pos)) : null;
                problema = sentado != null
                        ? Component.translatable("mensaje.juegosdelpatio.silla_ocupada", nombreDe(sentado))
                        : Component.translatable("mensaje.juegosdelpatio.mas_cerca");
            }
        }
        if (problema != null) {
            jugador.displayClientMessage(problema.withStyle(ChatFormatting.YELLOW), true);
            return;
        }
        sentar(complejo, pos, jugador);
    }

    /** La silla libre que el jugador tiene a mano (a menos de ALCANCE_JUGADOR), la que más queda para donde mira. */
    @Nullable
    private static BlockPos libreAMano(ServerLevel complejo, ServerPlayer jugador) {
        Vec3 ojos = jugador.getEyePosition();
        Vec3 mira = jugador.getLookAngle();
        BlockPos mejor = null;
        double mejorPuntaje = -Double.MAX_VALUE;
        for (BlockPos silla : SILLAS) {
            double d2 = distancia2(jugador.getX(), jugador.getZ(), silla.getX() + 0.5, silla.getZ() + 0.5);
            if (d2 > ALCANCE_JUGADOR * ALCANCE_JUGADOR || ocupada(complejo, silla)) {
                continue;
            }
            Vec3 hacia = new Vec3(silla.getX() + 0.5, silla.getY() + 0.4, silla.getZ() + 0.5).subtract(ojos).normalize();
            double puntaje = mira.dot(hacia) - Math.sqrt(d2) * 0.15;
            if (puntaje > mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = silla;
            }
        }
        return mejor;
    }

    // ------------------------------------------------------------------ sacar a otro de la silla
    /**
     * Uno que está parado tira de uno que está sentado (los jugadores, con clic derecho sobre él; los bots, solos).
     * Cada tirón suma uno; cuando junta 8 más que las veces que el otro aguantó, lo saca de la silla y se sienta él.
     * false si acá no corresponde (no es el momento de sentarse, o el otro no está sentado en una silla del juego).
     */
    static boolean tirar(LivingEntity quien, LivingEntity sentado) {
        if (estado != Estado.SENTARSE || !SENTADOS.contains(sentado.getUUID()) || !(quien.level() instanceof ServerLevel complejo)) {
            return false;
        }
        if (!EN_RONDA.contains(quien.getUUID()) || quien.isPassenger() || quien == sentado
                || quien.distanceToSqr(sentado) > ALCANCE_TIRON * ALCANCE_TIRON) {
            return true;                                               // es del juego, pero así no cuenta
        }
        long ahora = complejo.getGameTime();
        Long antes = ULTIMO_TIRON.get(quien.getUUID());
        if (antes != null && ahora - antes < ENTRE_TIRONES) {
            return true;                                               // muy rápido: ese clic no cuenta
        }
        ULTIMO_TIRON.put(quien.getUUID(), ahora);
        Tiron tiron = TIRONES.computeIfAbsent(sentado.getUUID(), id -> new Tiron());
        tiron.fuerza++;
        tiron.quieto = 0;
        tiron.ultimo = quien.getUUID();
        quien.swing(InteractionHand.MAIN_HAND);
        complejo.playSound(null, sentado.getX(), sentado.getY(), sentado.getZ(), SoundEvents.PLAYER_ATTACK_WEAK,
                SoundSource.PLAYERS, 0.6F, 0.8F + tiron.fuerza * 0.06F);
        if (tiron.fuerza >= TIRON_MAXIMO) {
            sacar(complejo, sentado, quien);
        } else {
            avisarTiron(sentado, quien, tiron.fuerza);
        }
        return true;
    }

    /** El que está sentado apretó la Z: aguanta un tirón. */
    static void resistir(ServerPlayer jugador) {
        Tiron tiron = TIRONES.get(jugador.getUUID());
        if (estado != Estado.SENTARSE || tiron == null || !SENTADOS.contains(jugador.getUUID())) {
            return;
        }
        long ahora = jugador.level().getGameTime();
        Long antes = ULTIMO_AGUANTE.get(jugador.getUUID());
        if (antes != null && ahora - antes < ENTRE_AGUANTES) {
            return;
        }
        ULTIMO_AGUANTE.put(jugador.getUUID(), ahora);
        tiron.fuerza = Math.max(0, tiron.fuerza - 1);
        LivingEntity quien = tiron.ultimo == null ? null : buscar(jugador.serverLevel(), tiron.ultimo);
        avisarTiron(jugador, quien, tiron.fuerza);
    }

    /** Cada tick: los bots sentados aguantan solos (cada uno con su fuerza), y si nadie tira, se afloja. */
    private static void tirones(ServerLevel complejo) {
        RandomSource azar = complejo.getRandom();
        for (Iterator<Map.Entry<UUID, Tiron>> it = TIRONES.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Tiron> par = it.next();
            Tiron tiron = par.getValue();
            if (!SENTADOS.contains(par.getKey())) {
                it.remove();
                continue;
            }
            JugadorBot bot = BOTS.get(par.getKey());
            if (bot != null && tiron.fuerza > 0 && azar.nextFloat() < fuerzaDe(bot)) {
                tiron.fuerza--;                                        // el bot aguanta
            }
            if (++tiron.quieto >= AFLOJA) {
                tiron.quieto = 0;
                tiron.fuerza--;
            }
            if (tiron.fuerza <= 0) {
                it.remove();
            }
        }
    }

    /** Cuánto aguanta cada bot sentado: entre 3,2 y 7 tirones por segundo (siempre el mismo para cada bot). */
    private static float fuerzaDe(JugadorBot bot) {
        return 0.16F + Math.floorMod(bot.getId() * 37, 20) / 100.0F;
    }

    /** Lo sacaron de la silla: se para y en su lugar se sienta el que lo sacó. */
    private static void sacar(ServerLevel complejo, LivingEntity sentado, LivingEntity quien) {
        TIRONES.remove(sentado.getUUID());
        BlockPos silla = null;
        for (Map.Entry<BlockPos, UUID> par : OCUPADAS.entrySet()) {
            if (par.getValue().equals(sentado.getUUID())) {
                silla = par.getKey();
                break;
            }
        }
        if (silla == null) {
            return;
        }
        levantando = true;
        try {
            sentado.stopRiding();
        } finally {
            levantando = false;
        }
        OCUPADAS.remove(silla);
        SENTADOS.remove(sentado.getUUID());
        complejo.sendParticles(ParticleTypes.POOF, silla.getX() + 0.5, silla.getY() + 0.8, silla.getZ() + 0.5, 10,
                0.3, 0.3, 0.3, 0.03);
        complejo.playSound(null, silla, SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.0F, 0.8F);
        if (sentado instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.te_sacaron", nombreDe(quien))
                    .withStyle(ChatFormatting.RED), true);
        } else if (sentado instanceof JugadorBot bot) {
            bot.mostrarEmote(Emote.ENOJO);
        }
        sentar(complejo, silla, quien);                                // el que lo sacó se sienta
        if (quien instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.sacaste", nombreDe(sentado))
                    .withStyle(ChatFormatting.GREEN), true);
        }
    }

    /** Cómo va el tirón, en la pantalla de los dos (si son jugadores): una rayita por tirón. */
    private static void avisarTiron(LivingEntity sentado, @Nullable LivingEntity quien, int fuerza) {
        String rayitas = "■".repeat(Math.max(0, fuerza)) + "□".repeat(Math.max(0, TIRON_MAXIMO - fuerza));
        if (sentado instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.te_tiran", rayitas)
                    .withStyle(ChatFormatting.RED), true);
        }
        if (quien instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.tiras", nombreDe(sentado), rayitas)
                    .withStyle(ChatFormatting.YELLOW), true);
        }
    }

    /** No quedan sillas libres: a los parados se les dice que saquen a alguien, y a los sentados, que aguanten. */
    private static void avisarPelea(ServerLevel complejo) {
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!EN_RONDA.contains(jugador.getUUID())) {
                continue;
            }
            boolean sentado = SENTADOS.contains(jugador.getUUID());
            jugador.displayClientMessage(Component.translatable(sentado ? "mensaje.juegosdelpatio.aguanta"
                    : "mensaje.juegosdelpatio.sin_sillas_libres").withStyle(sentado ? ChatFormatting.GOLD : ChatFormatting.RED), true);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, sentado ? 1.6F : 0.8F);
        }
    }

    private static Component nombreDe(LivingEntity quien) {
        return quien instanceof JugadorBot bot ? Component.literal(bot.nombre()) : quien.getName();
    }

    /** Para los bots que se quedaron sin silla: a quién tratar de sacar (el más cercano; un poco más, si es jugador). */
    @Nullable
    static LivingEntity aQuienSacar(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity mejor = null;
        double dMejor = Double.MAX_VALUE;
        for (UUID id : SENTADOS) {
            LivingEntity sentado = buscar(complejo, id);
            if (sentado == null) {
                continue;
            }
            double d = bot.distanceToSqr(sentado) * (sentado instanceof ServerPlayer ? PREFIEREN_JUGADORES : 1.0);
            if (d < dMejor) {
                dMejor = d;
                mejor = sentado;
            }
        }
        return mejor;
    }

    static boolean estaSentado(LivingEntity quien) {
        return SENTADOS.contains(quien.getUUID());
    }

    /** Al lado de la silla de uno que está sentado (adonde va el bot que lo quiere sacar). */
    static Vec3 alLadoDe(Level nivel, LivingEntity sentado) {
        for (Map.Entry<BlockPos, UUID> par : OCUPADAS.entrySet()) {
            if (par.getValue().equals(sentado.getUUID())) {
                return frenteDe(nivel, par.getKey());
            }
        }
        return sentado.position();
    }

    /** Sentado, nadie se levanta hasta que termine la ronda (si no, se quedaría sin silla). */
    static void alMontar(EntityMountEvent evento) {
        if (evento.getEntityMounting().level().isClientSide() || !evento.isDismounting() || levantando
                || !(evento.getEntityBeingMounted() instanceof Asiento asiento) || asiento.isRemoved()) {
            return;
        }
        if ((estado == Estado.SENTARSE || estado == Estado.RESULTADO)
                && evento.getEntityMounting() instanceof LivingEntity quien && participa(quien)) {
            evento.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ para los bots
    /** ¿Ya se dio cuenta de que paró la música? (cada llamada es un tick) */
    static boolean reacciono(JugadorBot bot) {
        Integer falta = REACCION.get(bot.getUUID());
        if (falta == null || falta <= 0) {
            return true;
        }
        REACCION.put(bot.getUUID(), falta - 1);
        return false;
    }

    /** Con la música: un punto un poco más adelante en la pista (cada bot camina a su distancia del centro). */
    static Vec3 adondeCaminar(JugadorBot bot) {
        double angulo = Math.atan2(bot.getZ() - CZ, bot.getX() - CX);
        double radio = RADIO_PISTA + (Math.floorMod(bot.getId(), 5) - 2) * 0.15;
        return enLaPista(angulo + 1.8 / radio, radio);
    }

    /** Tiene a alguien de la ronda justo adelante en la pista (para no llevárselo puesto). */
    static boolean alguienAdelante(JugadorBot bot) {
        double angulo = Math.atan2(bot.getZ() - CZ, bot.getX() - CX);
        double haciaX = -Math.sin(angulo);                             // para donde se camina
        double haciaZ = Math.cos(angulo);
        for (LivingEntity otro : bot.level().getEntitiesOfClass(LivingEntity.class,
                bot.getBoundingBox().inflate(1.6, 0.5, 1.6))) {
            if (otro == bot || otro.isPassenger() || !EN_RONDA.contains(otro.getUUID())) {
                continue;
            }
            double dx = otro.getX() - bot.getX();
            double dz = otro.getZ() - bot.getZ();
            if (dx * dx + dz * dz < 1.6 * 1.6 && dx * haciaX + dz * haciaZ > 0.2) {
                return true;
            }
        }
        return false;
    }

    /** El más cercano de la ronda (parado) que tiene al lado, a menos de {@code alcance}. */
    @Nullable
    static LivingEntity alLado(JugadorBot bot, double alcance) {
        LivingEntity cerca = null;
        double mejor = alcance * alcance;
        for (LivingEntity otro : bot.level().getEntitiesOfClass(LivingEntity.class,
                bot.getBoundingBox().inflate(alcance, 0.5, alcance))) {
            if (otro == bot || otro.isPassenger() || !EN_RONDA.contains(otro.getUUID())) {
                continue;
            }
            double d = bot.distanceToSqr(otro);
            if (d < mejor) {
                mejor = d;
                cerca = otro;
            }
        }
        return cerca;
    }

    /**
     * La silla libre a la que conviene ir: la más cercana, salvo que otro bot que va a esa esté más cerca (así no van
     * todos a la misma). Si todas las libres tienen dueño más cerca, va igual a la más cercana.
     */
    @Nullable
    static BlockPos sillaPara(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        UUID jugador = RIVALES.get(bot.getUUID());
        BlockPos suya = jugador == null ? null : SILLA_DE.get(jugador);
        if (suya != null && !ocupada(complejo, suya)) {
            RECLAMOS.values().removeIf(reclamo -> reclamo.quien().equals(bot.getUUID()));
            RECLAMOS.put(suya, new Reclamo(bot.getUUID(), 0.0));      // va por la silla del jugador, primero que nadie
            return suya;
        }
        BlockPos mejor = null;
        BlockPos cualquiera = null;
        double dMejor = Double.MAX_VALUE;
        double dCualquiera = Double.MAX_VALUE;
        for (BlockPos silla : SILLAS) {
            if (ocupada(complejo, silla)) {
                continue;
            }
            double d = distancia2(bot.getX(), bot.getZ(), silla.getX() + 0.5, silla.getZ() + 0.5);
            if (d < dCualquiera) {
                dCualquiera = d;
                cualquiera = silla;
            }
            Reclamo reclamo = RECLAMOS.get(silla);
            if (reclamo != null && !reclamo.quien().equals(bot.getUUID()) && reclamo.distancia() < d
                    && sigueYendo(complejo, reclamo.quien())) {
                continue;                                              // va otro que está más cerca
            }
            if (d < dMejor) {
                dMejor = d;
                mejor = silla;
            }
        }
        BlockPos elegida = mejor != null ? mejor : cualquiera;
        RECLAMOS.values().removeIf(reclamo -> reclamo.quien().equals(bot.getUUID()));
        if (elegida != null) {
            RECLAMOS.put(elegida, new Reclamo(bot.getUUID(), mejor != null ? dMejor : dCualquiera));
        }
        return elegida;
    }

    private static boolean sigueYendo(ServerLevel complejo, UUID quien) {
        LivingEntity otro = buscar(complejo, quien);
        return otro != null && !otro.isPassenger();
    }

    /**
     * Si el bot tiene a mano una silla libre (cualquiera, no solo a la que iba; de cualquier lado), se sienta ya. true
     * si se sentó.
     */
    static boolean sentarseAMano(JugadorBot bot) {
        if (estado != Estado.SENTARSE || !EN_RONDA.contains(bot.getUUID()) || SENTADOS.contains(bot.getUUID())
                || bot.isPassenger() || Math.abs(bot.getY() - PISO) > 1.5 || !(bot.level() instanceof ServerLevel complejo)) {
            return false;
        }
        BlockPos cerca = null;
        double mejor = ALCANCE_BOT * ALCANCE_BOT;
        for (BlockPos silla : SILLAS) {
            if (ocupada(complejo, silla)) {
                continue;
            }
            double d = distancia2(bot.getX(), bot.getZ(), silla.getX() + 0.5, silla.getZ() + 0.5);
            if (d <= mejor) {
                mejor = d;
                cerca = silla;
            }
        }
        if (cerca == null) {
            return false;
        }
        bot.getNavigation().stop();
        return sentar(complejo, cerca, bot);
    }

    /** Otro de la ronda, parado al lado de la silla que quiere y a mano para empujarlo (primero, el jugador que sigue). */
    @Nullable
    static LivingEntity rivalPorLaSilla(JugadorBot bot, BlockPos silla) {
        UUID seguido = RIVALES.get(bot.getUUID());
        if (seguido != null && bot.level() instanceof ServerLevel complejo) {
            LivingEntity jugador = buscar(complejo, seguido);
            if (jugador != null && jugador.isAlive() && !jugador.isPassenger() && bot.distanceToSqr(jugador) < 2.4 * 2.4) {
                return jugador;                                        // el jugador al que le quiere ganar la silla
            }
        }
        for (LivingEntity otro : bot.level().getEntitiesOfClass(LivingEntity.class,
                bot.getBoundingBox().inflate(2.3, 0.5, 2.3))) {
            if (otro != bot && !otro.isPassenger() && EN_RONDA.contains(otro.getUUID())
                    && bot.distanceToSqr(otro) < 2.3 * 2.3
                    && distancia2(otro.getX(), otro.getZ(), silla.getX() + 0.5, silla.getZ() + 0.5) < 1.8 * 1.8) {
                return otro;
            }
        }
        return null;
    }

    /** Delante de la silla (del lado de afuera), adonde va el que quiere sentarse. */
    static Vec3 frenteDe(Level nivel, BlockPos silla) {
        BlockState estadoSilla = nivel.getBlockState(silla);
        Direction mira = estadoSilla.getBlock() instanceof SillaBlock ? estadoSilla.getValue(SillaBlock.FACING) : Direction.NORTH;
        return new Vec3(silla.getX() + 0.5 + mira.getStepX() * 0.9, PISO, silla.getZ() + 0.5 + mira.getStepZ() * 0.9);
    }

    // ------------------------------------------------------------------ fin
    /** Al terminar (o cortarse) el juego: todos se levantan, se sacan las sillas y se olvida todo. */
    static void limpiar(ServerLevel complejo) {
        cortarParpadeo(complejo);
        quitarTodasLasSillas(complejo);
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ronda = 0;
        llenoDesde = -1;
        parpadeo = -1;
        GENTE.clear();
        EN_RONDA.clear();
        SILLAS.clear();
        ES_SILLA.clear();
        OCUPADAS.clear();
        SENTADOS.clear();
        BOTS.clear();
        REACCION.clear();
        RECLAMOS.clear();
        CAMINATA.clear();
        EMPUJADO.clear();
        PASARON.clear();
        TIRONES.clear();
        ULTIMO_TIRON.clear();
        ULTIMO_AGUANTE.clear();
        RIVALES.clear();
        SILLA_DE.clear();
        ANTES.clear();
    }

    // ------------------------------------------------------------------ ayudas
    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID id) {
        ServerPlayer jugador = complejo.getServer().getPlayerList().getPlayer(id);
        if (jugador != null) {
            return jugador.level() == complejo && jugador.isAlive() ? jugador : null;
        }
        JugadorBot bot = BOTS.get(id);
        return bot != null && bot.isAlive() && !bot.isRemoved() ? bot : null;
    }

    private static Vec3 enLaPista(double angulo, double radio) {
        return new Vec3(CX + radio * Math.cos(angulo), PISO, CZ + radio * Math.sin(angulo));
    }

    /** Cuánto hay que girar de {@code desde} a {@code hasta} (en radianes, entre -pi y pi). */
    private static double diferencia(double hasta, double desde) {
        double d = hasta - desde;
        while (d > Math.PI) {
            d -= Math.PI * 2.0;
        }
        while (d < -Math.PI) {
            d += Math.PI * 2.0;
        }
        return d;
    }

    private static double distancia2(double x1, double z1, double x2, double z2) {
        double dx = x1 - x2;
        double dz = z1 - z2;
        return dx * dx + dz * dz;
    }

    private static <T> void mezclar(List<T> lista, RandomSource azar) {
        for (int i = lista.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            T aux = lista.get(i);
            lista.set(i, lista.get(j));
            lista.set(j, aux);
        }
    }
}
