package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityMountEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * El juego 2, "Asientos al vacío" (el día 2 del ciclo): un campo de 24 torres altísimas, con el gramófono en el
 * medio (ver gen_asientos.py). Un juego nuevo, con un guiño a las sillas musicales.
 *
 * <ol>
 *   <li>Mientras suena el gramófono (un vals), cada uno anda por donde quiere: por su torre o saltando a otra (entre
 *       las torres hay 2 bloques de vacío).</li>
 *   <li>Cuando la música para, las luces parpadean y aparecen sillas en algunas torres: menos sillas que gente. Hay
 *       que llegar a una silla libre y sentarse (clic derecho).</li>
 *   <li>A los 10 segundos (o un segundo después de que se ocupen todas), se cae el piso de todas las torres: queda
 *       solo lo que está debajo de las sillas. El que no está sentado, se cae (59 bloques) y queda eliminado.</li>
 *   <li>Vuelve el piso, todos se levantan y vuelve la música. Son 3 rondas, cada una con más sillas de menos.</li>
 * </ol>
 *
 * Como en todos los juegos, no se puede pegar pero sí empujar: el empujado sale para atrás y, por un momento, no se
 * puede sentar. Al que está sentado no se lo puede empujar ni se puede levantar hasta que vuelva el piso.
 */
public final class Sillas {
    // ------------------------------------------------------------------ la arena (igual que gen_asientos.py)
    public static final ResourceLocation ARENA = Complejo.id("asientos");
    /** Esquina de la plantilla asientos.nbt (63 x 78 x 80): abajo de todo, en el suelo. */
    public static final BlockPos ORIGEN = new BlockPos(1969, 40, -17);
    /** 1 y 2: los salones viejos de las sillas; 3: paredes negras; 4: Asientos al vacío (las torres). */
    static final int VERSION_ARENA = 4;
    /** Lo que ocupa la arena (y el salón de antes, que se borra al cambiar de versión). */
    static final int X0 = 1960;
    static final int X1 = 2040;
    static final int Z0 = -17;
    static final int Z1 = 79;
    /** Donde se para la gente: arriba de las torres. El suelo, allá abajo, en y = 41. */
    static final int PISO = 100;
    static final int SUELO = 41;
    /** Las torres: de 9 x 9, una cada 11 bloques (2 de vacío), en una grilla de 5 x 5; la del medio es el gramófono. */
    static final int LADO = 9;
    static final int[] X_TORRES = {1974, 1985, 1996, 2007, 2018};
    static final int[] Z_TORRES = {8, 19, 30, 41, 52};
    /** El campo: las 24 torres donde se juega (la del gramófono, más alta, no), y de cuál se puede saltar a cuál. */
    static final CampoDeTorres CAMPO = campo();
    static final Vec3 PODIO = new Vec3(2000.5, 102.0, -13.5);
    /** Los cuatro sargentos, en el palco: dos en las esquinas de adelante y dos junto al podio. */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(1978.5, 100.0, -0.5), new Vec3(2022.5, 100.0, -0.5),
            new Vec3(1992.5, 100.0, -13.5), new Vec3(2008.5, 100.0, -13.5),
    };
    static final float[] GIROS_SARGENTOS = {0.0F, 0.0F, 0.0F, 0.0F};
    /** El gramófono: de dónde salen las notas (la boca de la bocina) y hacia dónde miran las sillas. */
    private static final Vec3 BOCINA = new Vec3(2000.5, 116.5, 36.5);
    private static final double CX = 2000.5;
    private static final double CZ = 34.5;

    // ------------------------------------------------------------------ reglas
    static final int RONDAS = 3;
    /** Cuántas sillas de menos hay en cada ronda: el 10, el 12 y el 15 por ciento de los que quedan (1 por lo menos). */
    private static final int[] FALTAN_POR_CIENTO = {10, 12, 15};
    /** La música dura de 8 a 16 segundos (la primera ronda, 3 más). Nadie sabe cuándo para. */
    private static final int MUSICA_MIN = 160;
    private static final int MUSICA_AZAR = 161;
    /** Cuando para la música hay 10 segundos para sentarse; si ya no quedan sillas libres, un segundo. */
    static final int TIEMPO_SENTARSE = 200;
    private static final int ESPERA_LLENO = 20;
    /** El piso queda caído 3 segundos; entre ronda y ronda, 3 segundos más. */
    private static final int CAIDA = 60;
    private static final int PAUSA = 60;
    /** En cuántas torres aparecen sillas: una cada 6 sillas, entre 3 y todas. */
    private static final int SILLAS_POR_TORRE = 6;
    /** Al que empujan, por un momento (ticks) no se sienta. */
    static final int TRASTABILLA = 12;
    /** Desde dónde se puede sentar uno (distancia al centro de la silla). */
    static final double ALCANCE_JUGADOR = 2.0;
    static final double ALCANCE_BOT = 1.6;
    /** Cuando para la música, los bots tardan de 5 a 20 ticks en darse cuenta. */
    private static final int REACCION_MIN = 5;
    private static final int REACCION_AZAR = 16;
    /**
     * La música (original, hecha para el juego): un vals en re menor, 16 compases de 3 tiempos (un tiempo cada 10
     * ticks), con notas de bloque musical (0 = fa# grave ... 24 = fa# agudo; -1 = silencio).
     */
    private static final int TIEMPO_MUSICA = 10;
    private static final int[] MELODIA = {
            15, 20, 22, 23, 22, 20, 18, 22, 20, 16, -1, -1,
            15, 19, 22, 23, 22, 19, 20, 15, 11, 8, -1, -1,
            20, 23, 20, 22, 18, 16, 18, 22, 18, 23, -1, -1,
            13, 16, 20, 19, 22, 15, 20, -1, 15, 20, -1, -1,
    };
    /** El bajo de cada compás (re, re, sol, sol, la, la, re, re, re, sol, do, fa, sol, la, re, re). */
    private static final int[] BAJO = {8, 8, 1, 1, 3, 3, 8, 8, 8, 1, 6, 11, 1, 3, 8, 8};

    private enum Estado { NINGUNO, EMPEZANDO, MUSICA, SENTARSE, CAIDA, PAUSA, TERMINADO }

    /** Un bot que va a una silla, y qué tan lejos estaba (si otro está más cerca, se la deja). */
    private record Reclamo(UUID quien, double costo) {
    }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int ronda;
    private static int duracion;
    private static int llenoDesde = -1;
    private static final List<UUID> GENTE = new ArrayList<>();
    private static final Set<UUID> EN_RONDA = new HashSet<>();
    private static final List<BlockPos> SILLAS = new ArrayList<>();
    private static final Set<BlockPos> ES_SILLA = new HashSet<>();
    /** Silla -> quién está sentado, y los sentados (para buscar rápido). */
    private static final Map<BlockPos, UUID> OCUPADAS = new HashMap<>();
    private static final Set<UUID> SENTADOS = new HashSet<>();
    private static final Map<UUID, JugadorBot> BOTS = new HashMap<>();
    private static final Map<UUID, Integer> REACCION = new HashMap<>();
    private static final Map<BlockPos, Reclamo> RECLAMOS = new HashMap<>();
    private static final Map<UUID, Long> EMPUJADO = new HashMap<>();
    private static final Set<UUID> PASARON = new HashSet<>();
    /** Mientras el juego levanta a todos de las sillas (ahí sí se pueden bajar). */
    private static boolean levantando;
    private static int parpadeo = -1;

    private Sillas() {
    }

    private static CampoDeTorres campo() {
        List<int[]> torres = new ArrayList<>();
        Map<Long, Integer> indice = new HashMap<>();
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (i == 2 && j == 2) {
                    continue;                                        // el gramófono
                }
                indice.put(i * 10L + j, torres.size());
                torres.add(new int[] {X_TORRES[i], X_TORRES[i] + LADO - 1, Z_TORRES[j], Z_TORRES[j] + LADO - 1});
            }
        }
        int[][] vecinos = new int[torres.size()][];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                Integer yo = indice.get(i * 10L + j);
                if (yo == null) {
                    continue;
                }
                List<Integer> al = new ArrayList<>();
                for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                    Integer otro = indice.get((i + d[0]) * 10L + (j + d[1]));
                    if (i + d[0] >= 0 && i + d[0] < 5 && j + d[1] >= 0 && j + d[1] < 5 && otro != null) {
                        al.add(otro);
                    }
                }
                vecinos[yo] = al.stream().mapToInt(Integer::intValue).toArray();
            }
        }
        return new CampoDeTorres(PISO, torres.toArray(new int[0][]), vecinos, new int[torres.size()][], null);
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean suenaMusica() {
        return estado == Estado.MUSICA || estado == Estado.EMPEZANDO || estado == Estado.PAUSA;
    }

    static boolean hayQueSentarse() {
        return estado == Estado.SENTARSE;
    }

    static int pasaron() {
        return PASARON.size();
    }

    /** Sigue jugando (todavía no terminó el juego y no quedó eliminado). */
    static boolean participa(LivingEntity quien) {
        return EN_RONDA.contains(quien.getUUID()) && estado != Estado.NINGUNO && estado != Estado.TERMINADO;
    }

    /** En las torres, los bots no se chocan con nadie (si no, en una torre llena se tirarían unos a otros). */
    static boolean sinChoques(LivingEntity quien) {
        return estado != Estado.NINGUNO && EN_RONDA.contains(quien.getUUID());
    }

    static boolean sentado(LivingEntity quien) {
        return SENTADOS.contains(quien.getUUID());
    }

    static void empujado(LivingEntity quien) {
        if (estado != Estado.NINGUNO) {
            EMPUJADO.put(quien.getUUID(), quien.level().getGameTime());
        }
    }

    /** Lo acaban de empujar (hace menos de TRASTABILLA ticks): sale para atrás y, mientras, no se sienta. */
    static boolean trastabillando(LivingEntity quien) {
        Long empujon = EMPUJADO.get(quien.getUUID());
        long hace = empujon == null ? -1 : quien.level().getGameTime() - empujon;
        return hace >= 0 && hace < TRASTABILLA;
    }

    // ------------------------------------------------------------------ la arena
    /**
     * Construye la arena la primera vez (o si cambió de versión: entonces borra entero lo que había, el salón viejo
     * de las sillas incluido). false si falta la estructura.
     */
    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionSillas() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        BlockState aire = Blocks.AIR.defaultBlockState();
        Iterable<BlockPos> vaciar = estadoComplejo.versionSillas() > 0
                ? BlockPos.betweenClosed(X0, SUELO - 1, Z0, X1, PISO + 18, Z1)           // lo de antes, entero
                : BlockPos.betweenClosed(1986, 99, -14, 2014, 105, 14);                 // Portales.prepararJuego
        for (BlockPos pos : vaciar) {
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionSillas(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Asientos al vacío colocada en {}", ORIGEN);
        return true;
    }

    /** Dónde aparece quien llega al juego 2: en el palco, delante del podio. */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(1980.5 + azar.nextInt(41), PISO, -10.5 + azar.nextInt(10));
    }

    // ------------------------------------------------------------------ empieza el juego
    /** Todos a las torres, repartidos al azar; la música empieza en 3 segundos. */
    static void empezar(ServerLevel complejo, List<LivingEntity> participantes) {
        olvidar();
        quitarTodasLasSillas(complejo);
        restaurarPiso(complejo);
        RandomSource azar = complejo.getRandom();
        for (LivingEntity quien : participantes) {
            GENTE.add(quien.getUUID());
            EN_RONDA.add(quien.getUUID());
            if (quien instanceof JugadorBot bot) {
                BOTS.put(bot.getUUID(), bot);
            }
            Vec3 lugar = CAMPO.lugarEn(azar.nextInt(CAMPO.cuantas()), azar, 1);
            llevar(complejo, quien, lugar, azar.nextFloat() * 360.0F);
        }
        ronda = 1;
        if (GENTE.size() <= 1) {
            terminarJuego(complejo);                                   // uno solo (o nadie): pasa directo
            return;
        }
        anunciarRonda(complejo);
        cambiar(Estado.EMPEZANDO);
    }

    private static void llevar(ServerLevel complejo, LivingEntity quien, Vec3 lugar, float giro) {
        quien.setDeltaMovement(Vec3.ZERO);
        quien.fallDistance = 0.0F;
        if (quien instanceof ServerPlayer jugador) {
            jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
        } else {
            quien.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            quien.setYHeadRot(giro);
            if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
            }
        }
    }

    /** Cuántas sillas de menos hay esta ronda (al menos una, y al menos queda una silla). */
    private static int faltanDeLaRonda() {
        int quedan = GENTE.size();
        int faltan = Math.round(quedan * FALTAN_POR_CIENTO[Math.min(ronda, RONDAS) - 1] / 100.0F);
        return Math.max(1, Math.min(quedan - 1, faltan));
    }

    private static void anunciarRonda(ServerLevel complejo) {
        int faltan = faltanDeLaRonda();
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.sillas_ronda_inicio", ronda, RONDAS,
                GENTE.size(), faltan));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.ronda_sillas", ronda, RONDAS)
                    .withStyle(ChatFormatting.GOLD), Component.translatable("titulo.juegosdelpatio.ronda_sillas_detalle",
                    faltan).withStyle(ChatFormatting.GRAY), 5, 40, 10);
        }
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        if (parpadeo >= 0) {
            parpadear(complejo);
        }
        if (tiempo % 20 == 0 && estado != Estado.CAIDA) {             // los que se cayeron saltando ya no cuentan
            GENTE.removeIf(id -> {
                LivingEntity quien = buscar(complejo, id);
                boolean afuera = quien == null || Juego.eliminado(quien);
                if (afuera) {
                    EN_RONDA.remove(id);
                }
                return afuera;
            });
        }
        switch (estado) {
            case EMPEZANDO -> {
                if (tiempo >= 60) {
                    empezarMusica(complejo);
                }
            }
            case MUSICA -> {
                musica(complejo);
                if (tiempo >= duracion) {
                    pararMusica(complejo);
                }
            }
            case SENTARSE -> sentarse(complejo);
            case CAIDA -> {
                if (tiempo >= CAIDA) {
                    terminarRonda(complejo);
                }
            }
            case PAUSA -> {
                if (tiempo >= PAUSA) {
                    anunciarRonda(complejo);
                    empezarMusica(complejo);
                }
            }
            default -> {
            }
        }
        if (tiempo % 10 == 1) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    private static void empezarMusica(ServerLevel complejo) {
        duracion = MUSICA_MIN + complejo.getRandom().nextInt(MUSICA_AZAR) + (ronda == 1 ? 60 : 0);
        RECLAMOS.clear();
        REACCION.clear();
        cambiar(Estado.MUSICA);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (participa(jugador)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.suena_vals")
                        .withStyle(ChatFormatting.GOLD), true);
            }
        }
    }

    /** Una nota por tiempo: la melodía y, en el primer tiempo de cada compás, el bajo (y los otros dos, el platillo). */
    private static void musica(ServerLevel complejo) {
        if ((tiempo - 1) % TIEMPO_MUSICA != 0) {
            return;
        }
        int paso = (tiempo - 1) / TIEMPO_MUSICA;
        int nota = MELODIA[paso % MELODIA.length];
        int enCompas = paso % 3;
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (nota >= 0) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_HARP.value(), 0.9F, nota);
            }
            if (enCompas == 0) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_BASS.value(), 0.9F, BAJO[(paso / 3) % BAJO.length]);
            } else {
                sonar(jugador, SoundEvents.NOTE_BLOCK_HAT.value(), 0.2F, 12);
            }
        }
        if (nota >= 0) {                                               // las notas salen de la bocina
            complejo.sendParticles(ParticleTypes.NOTE, BOCINA.x, BOCINA.y, BOCINA.z, 0, nota / 24.0, 0.0, 0.0, 1.0);
        }
    }

    private static void sonar(ServerPlayer jugador, SoundEvent sonido, float volumen, int nota) {
        jugador.playNotifySound(sonido, SoundSource.RECORDS, volumen, (float) Math.pow(2.0, (nota - 12) / 12.0));
    }

    /** Paró la música: parpadean las luces, aparecen las sillas y todos a sentarse. */
    private static void pararMusica(ServerLevel complejo) {
        levantarATodos(complejo);
        cambiar(Estado.SENTARSE);
        llenoDesde = -1;
        RandomSource azar = complejo.getRandom();
        for (UUID id : BOTS.keySet()) {
            REACCION.put(id, REACCION_MIN + azar.nextInt(REACCION_AZAR));
        }
        ponerSillas(complejo, Math.max(1, GENTE.size() - faltanDeLaRonda()), azar);
        empezarParpadeo(complejo);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (participa(jugador)) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.a_sentarse").withStyle(ChatFormatting.RED),
                        Component.translatable("titulo.juegosdelpatio.a_sentarse_detalle").withStyle(ChatFormatting.GRAY),
                        0, 30, 8);
            }
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), SoundSource.RECORDS, 1.0F, 0.5F);
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.sillas_a_sentarse", TIEMPO_SENTARSE / 20));
    }

    /** Hay que sentarse: cuando ya no quedan sillas libres (o se acaba el tiempo), se cae el piso. */
    private static void sentarse(ServerLevel complejo) {
        validarSentados(complejo);
        boolean lleno = SENTADOS.size() >= SILLAS.size() || SENTADOS.size() >= enRonda(complejo).size();
        if (lleno && llenoDesde < 0) {
            llenoDesde = tiempo;
        } else if (!lleno) {
            llenoDesde = -1;
        }
        int queda = TIEMPO_SENTARSE - tiempo;
        if (queda > 0 && queda <= 100 && queda % 20 == 0) {
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 1.0F, 0.6F);
            }
        }
        if (tiempo % 10 == 5) {
            int libres = 0;
            for (BlockPos silla : SILLAS) {
                if (!ocupada(complejo, silla)) {
                    libres++;
                }
            }
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                if (participa(jugador) && !SENTADOS.contains(jugador.getUUID())) {
                    jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.sillas_libres", libres,
                            Math.max(0, queda) / 20 + 1).withStyle(ChatFormatting.YELLOW), true);
                }
            }
        }
        if (tiempo >= TIEMPO_SENTARSE || llenoDesde >= 0 && tiempo - llenoDesde >= ESPERA_LLENO) {
            derrumbe(complejo);
        }
    }

    /** Se cae el piso de todas las torres: queda solo lo que está debajo de las sillas. */
    private static void derrumbe(ServerLevel complejo) {
        cortarParpadeo(complejo);
        validarSentados(complejo);
        Set<BlockPos> debajo = new HashSet<>();
        for (BlockPos silla : SILLAS) {
            debajo.add(silla.below());
        }
        BlockState aire = Blocks.AIR.defaultBlockState();
        RandomSource azar = complejo.getRandom();
        for (int[] t : CAMPO.torres) {
            for (int x = t[0]; x <= t[1]; x++) {
                for (int z = t[2]; z <= t[3]; z++) {
                    BlockPos pos = new BlockPos(x, PISO - 1, z);
                    if (debajo.contains(pos)) {
                        continue;
                    }
                    BlockState antes = complejo.getBlockState(pos);
                    if (!antes.isAir()) {
                        complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
                        if (azar.nextInt(12) == 0) {
                            complejo.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, antes), x + 0.5, PISO - 0.5,
                                    z + 0.5, 4, 0.3, 0.2, 0.3, 0.05);
                        }
                    }
                }
            }
            complejo.playSound(null, (t[0] + t[1]) / 2.0, PISO, (t[2] + t[3]) / 2.0, SoundEvents.DEEPSLATE_BREAK,
                    SoundSource.BLOCKS, 2.0F, 0.6F);
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, 0.5F, 0.5F);
        }
        cambiar(Estado.CAIDA);
    }

    /**
     * Vuelve el piso. Los que no se sentaron ya se cayeron (en 3 segundos se llega abajo); el que sigue vivo igual (se
     * paró arriba de una silla, o cayó y no se mató) queda eliminado. Todos se levantan, se sacan las sillas y viene la
     * ronda siguiente (o se termina).
     */
    private static void terminarRonda(ServerLevel complejo) {
        int eliminados = 0;
        for (LivingEntity quien : enRonda(complejo)) {
            if (!SENTADOS.contains(quien.getUUID())) {
                Juego.eliminar(complejo, quien, false, "no_te_sentaste");
            }
        }
        for (UUID id : List.copyOf(GENTE)) {
            if (!SENTADOS.contains(id)) {                              // los que se cayeron (o se van a caer)
                eliminados++;
                GENTE.remove(id);
                EN_RONDA.remove(id);
            }
        }
        restaurarPiso(complejo);
        levantarATodos(complejo);
        quitarSillas(complejo);
        Juego.decir(complejo, eliminados > 0
                ? Component.translatable("juego.juegosdelpatio.sillas_ronda", ronda, eliminados)
                : Component.translatable("juego.juegosdelpatio.sillas_ronda_todos", ronda));
        ronda++;
        if (ronda > RONDAS || GENTE.size() <= 1) {
            terminarJuego(complejo);
            return;
        }
        cambiar(Estado.PAUSA);
    }

    private static void terminarJuego(ServerLevel complejo) {
        PASARON.clear();
        for (LivingEntity quien : enRonda(complejo)) {
            PASARON.add(quien.getUUID());
            if (quien instanceof ServerPlayer jugador) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.pasaste_sillas")
                        .withStyle(ChatFormatting.GREEN), Component.empty(), 5, 40, 10);
            }
        }
        cambiar(Estado.TERMINADO);
    }

    private static void cambiar(Estado nuevo) {
        estado = nuevo;
        tiempo = 0;
    }

    private static void barra(ServerLevel complejo) {
        int gente = enRonda(complejo).size();
        String clave = estado == Estado.MUSICA ? "barra.juegosdelpatio.sillas_musica"
                : estado == Estado.SENTARSE ? "barra.juegosdelpatio.sillas_sentarse" : "barra.juegosdelpatio.sillas_ronda";
        float progreso = estado == Estado.SENTARSE ? Math.max(0, TIEMPO_SENTARSE - tiempo) / (float) TIEMPO_SENTARSE : 1.0F;
        Juego.barraJuego(complejo, Component.translatable(clave, Math.min(ronda, RONDAS), RONDAS, gente,
                        estado == Estado.SENTARSE ? SILLAS.size() : Math.max(1, gente - faltanDeLaRonda())),
                estado == Estado.SENTARSE ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.YELLOW, progreso);
    }

    // ------------------------------------------------------------------ el piso
    /** El piso de baile de cada torre, como en gen_asientos.py: borde oscuro y damero negro y gris. */
    private static void restaurarPiso(ServerLevel complejo) {
        BlockState borde = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState negro = Blocks.POLISHED_BLACKSTONE.defaultBlockState();
        BlockState gris = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
        for (int[] t : CAMPO.torres) {
            for (int x = t[0]; x <= t[1]; x++) {
                for (int z = t[2]; z <= t[3]; z++) {
                    BlockPos pos = new BlockPos(x, PISO - 1, z);
                    BlockState debe = x == t[0] || x == t[1] || z == t[2] || z == t[3] ? borde : (x + z) % 2 == 0 ? negro : gris;
                    if (!complejo.getBlockState(pos).equals(debe)) {
                        complejo.setBlock(pos, debe, Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ las sillas
    /**
     * Pone las sillas: en algunas torres al azar (una cada 6 sillas), en lugares libres a un bloque del borde o más,
     * todas mirando al gramófono.
     */
    private static void ponerSillas(ServerLevel complejo, int cantidad, RandomSource azar) {
        List<Integer> torres = new ArrayList<>();
        for (int i = 0; i < CAMPO.cuantas(); i++) {
            torres.add(i);
        }
        mezclar(torres, azar);
        int cuantas = Math.max(3, Math.min(torres.size(), (cantidad + SILLAS_POR_TORRE - 1) / SILLAS_POR_TORRE));
        List<BlockPos> lugares = new ArrayList<>();
        for (int k = 0; k < cuantas; k++) {
            int[] t = CAMPO.torres[torres.get(k)];
            for (int x = t[0] + 1; x <= t[1] - 1; x++) {
                for (int z = t[2] + 1; z <= t[3] - 1; z++) {
                    lugares.add(new BlockPos(x, PISO, z));
                }
            }
        }
        mezclar(lugares, azar);
        for (BlockPos pos : lugares) {
            if (SILLAS.size() >= cantidad) {
                break;
            }
            if (!complejo.getBlockState(pos).isAir()
                    || !complejo.getEntitiesOfClass(LivingEntity.class, new AABB(pos).inflate(0.2)).isEmpty()) {
                continue;                                              // ahí hay alguien parado
            }
            ponerSilla(complejo, pos);
        }
    }

    private static void ponerSilla(ServerLevel complejo, BlockPos pos) {
        if (ES_SILLA.contains(pos)) {
            return;
        }
        Direction mira = Direction.getNearest(CX - (pos.getX() + 0.5), 0.0, CZ - (pos.getZ() + 0.5));   // al gramófono
        BlockState silla = Registro.SILLA.get().defaultBlockState()
                .setValue(SillaBlock.FACING, mira).setValue(SillaBlock.COLOR, 0);
        complejo.setBlock(pos, silla, Block.UPDATE_ALL);
        SILLAS.add(pos);
        ES_SILLA.add(pos);
        complejo.sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 4,
                0.2, 0.2, 0.2, 0.01);
    }

    private static void quitarSilla(ServerLevel complejo, BlockPos pos) {
        SILLAS.remove(pos);
        ES_SILLA.remove(pos);
        UUID sentado = OCUPADAS.remove(pos);
        if (sentado != null) {
            SENTADOS.remove(sentado);
        }
        if (complejo.getBlockState(pos).getBlock() instanceof SillaBlock) {
            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
            complejo.sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 6,
                    0.25, 0.3, 0.25, 0.02);
        }
    }

    private static void quitarSillas(ServerLevel complejo) {
        for (BlockPos pos : List.copyOf(SILLAS)) {
            quitarSilla(complejo, pos);
        }
    }

    /** Saca todas las sillas de las torres (y los asientos), aunque hayan quedado de un juego que se cortó. */
    private static void quitarTodasLasSillas(ServerLevel complejo) {
        levantarATodos(complejo);
        for (int[] t : CAMPO.torres) {
            for (int x = t[0]; x <= t[1]; x++) {
                for (int z = t[2]; z <= t[3]; z++) {
                    BlockPos pos = new BlockPos(x, PISO, z);
                    if (complejo.getBlockState(pos).getBlock() instanceof SillaBlock) {
                        complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                    }
                }
            }
        }
        SILLAS.clear();
        ES_SILLA.clear();
    }

    /** Todos se levantan de las sillas (se sacan los asientos). */
    private static void levantarATodos(ServerLevel complejo) {
        levantando = true;
        try {
            AABB campo = new AABB(X0, PISO - 2, Z0, X1 + 1, PISO + 4, Z1 + 1);
            for (Asiento asiento : complejo.getEntities(Registro.ASIENTO.get(), campo, cualquiera -> true)) {
                asiento.ejectPassengers();
                asiento.discard();
            }
        } finally {
            levantando = false;
        }
        OCUPADAS.clear();
        SENTADOS.clear();
    }

    /** ¿Hay alguien sentado de verdad en esa silla? (si quedó anotado alguien que ya no está, la silla queda libre) */
    private static boolean ocupada(ServerLevel complejo, BlockPos silla) {
        UUID quien = OCUPADAS.get(silla);
        if (quien == null) {
            return false;
        }
        if (sentadoAhi(buscar(complejo, quien), silla)) {
            return true;
        }
        OCUPADAS.remove(silla);
        if (!OCUPADAS.containsValue(quien)) {
            SENTADOS.remove(quien);
        }
        return false;
    }

    private static boolean sentadoAhi(@Nullable LivingEntity quien, BlockPos silla) {
        return quien != null && EN_RONDA.contains(quien.getUUID()) && quien.getVehicle() instanceof Asiento asiento
                && !asiento.isRemoved() && asiento.blockPosition().equals(silla);
    }

    private static void validarSentados(ServerLevel complejo) {
        OCUPADAS.entrySet().removeIf(sentado -> !sentadoAhi(buscar(complejo, sentado.getValue()), sentado.getKey()));
        SENTADOS.retainAll(Set.copyOf(OCUPADAS.values()));
    }

    private static boolean sentar(ServerLevel complejo, BlockPos silla, LivingEntity quien) {
        BlockState estadoSilla = complejo.getBlockState(silla);
        if (!(estadoSilla.getBlock() instanceof SillaBlock) || quien.isPassenger() || ocupada(complejo, silla)) {
            return false;
        }
        levantando = true;                                             // un asiento viejo en esa silla: afuera
        try {
            for (Asiento viejo : complejo.getEntities(Registro.ASIENTO.get(), new AABB(silla), cualquiera -> true)) {
                viejo.ejectPassengers();
                viejo.discard();
            }
        } finally {
            levantando = false;
        }
        Asiento asiento = Asiento.sentar(complejo, silla, estadoSilla.getValue(SillaBlock.FACING), quien);
        if (asiento == null || quien.getVehicle() != asiento) {
            return false;
        }
        OCUPADAS.values().removeIf(id -> id.equals(quien.getUUID()));
        OCUPADAS.put(silla, quien.getUUID());
        SENTADOS.add(quien.getUUID());
        RECLAMOS.remove(silla);
        complejo.playSound(null, silla, SoundEvents.WOOD_PLACE, SoundSource.BLOCKS, 0.8F, 1.3F);
        if (quien instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.sentado")
                    .withStyle(ChatFormatting.GREEN), true);
        }
        return true;
    }

    /**
     * Un jugador hizo clic derecho en una silla. En el juego: solo cuando paró la música, en una silla libre y estando
     * cerca. Fuera del juego, cualquier silla libre sirve para sentarse.
     */
    static void alUsarSilla(ServerPlayer jugador, BlockPos pos) {
        ServerLevel complejo = jugador.serverLevel();
        if (!ES_SILLA.contains(pos) || estado == Estado.NINGUNO || estado == Estado.TERMINADO) {
            BlockState silla = complejo.getBlockState(pos);
            if (!jugador.isPassenger() && silla.getBlock() instanceof SillaBlock
                    && complejo.getEntities(Registro.ASIENTO.get(), new AABB(pos), cualquiera -> true).isEmpty()) {
                Asiento.sentar(complejo, pos, silla.getValue(SillaBlock.FACING), jugador);
            }
            return;
        }
        MutableComponent problema = null;
        if (!EN_RONDA.contains(jugador.getUUID())) {
            problema = Component.translatable("mensaje.juegosdelpatio.no_juegas");
        } else if (estado != Estado.SENTARSE) {
            problema = Component.translatable("mensaje.juegosdelpatio.todavia_musica");
        } else if (jugador.isPassenger()) {
            return;
        } else if (trastabillando(jugador)) {
            return;                                                    // lo acaban de empujar
        } else {
            boolean ocupada = ocupada(complejo, pos);
            boolean lejos = distancia2(jugador.getX(), jugador.getZ(), pos.getX() + 0.5, pos.getZ() + 0.5)
                    > ALCANCE_JUGADOR * ALCANCE_JUGADOR;
            if (ocupada || lejos) {
                BlockPos aMano = libreAMano(complejo, jugador);
                if (aMano != null) {
                    sentar(complejo, aMano, jugador);
                    return;
                }
                LivingEntity sentado = ocupada ? buscar(complejo, OCUPADAS.get(pos)) : null;
                problema = sentado != null
                        ? Component.translatable("mensaje.juegosdelpatio.silla_ocupada", Juego.nombreDe(sentado))
                        : Component.translatable("mensaje.juegosdelpatio.mas_cerca");
            }
        }
        if (problema != null) {
            jugador.displayClientMessage(problema.withStyle(ChatFormatting.YELLOW), true);
            return;
        }
        sentar(complejo, pos, jugador);
    }

    @Nullable
    private static BlockPos libreAMano(ServerLevel complejo, ServerPlayer jugador) {
        Vec3 ojos = jugador.getEyePosition();
        Vec3 mira = jugador.getLookAngle();
        BlockPos mejor = null;
        double mejorPuntaje = -Double.MAX_VALUE;
        for (BlockPos silla : SILLAS) {
            double d2 = distancia2(jugador.getX(), jugador.getZ(), silla.getX() + 0.5, silla.getZ() + 0.5);
            if (d2 > ALCANCE_JUGADOR * ALCANCE_JUGADOR || ocupada(complejo, silla)) {
                continue;
            }
            Vec3 hacia = new Vec3(silla.getX() + 0.5, silla.getY() + 0.4, silla.getZ() + 0.5).subtract(ojos).normalize();
            double puntaje = mira.dot(hacia) - Math.sqrt(d2) * 0.15;
            if (puntaje > mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = silla;
            }
        }
        return mejor;
    }

    /** Sentado, nadie se levanta hasta que vuelva el piso (si no, se caería). */
    static void alMontar(EntityMountEvent evento) {
        if (evento.getEntityMounting().level().isClientSide() || !evento.isDismounting() || levantando
                || !(evento.getEntityBeingMounted() instanceof Asiento asiento) || asiento.isRemoved()) {
            return;
        }
        if ((estado == Estado.SENTARSE || estado == Estado.CAIDA)
                && evento.getEntityMounting() instanceof LivingEntity quien && participa(quien)) {
            evento.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ las luces que parpadean
    private static void empezarParpadeo(ServerLevel complejo) {
        parpadeo = 0;
        Parpadeo aviso = new Parpadeo(Parpadeo.DURACION);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            PacketDistributor.sendToPlayer(jugador, aviso);
        }
        clicLuces(complejo, false);
    }

    private static void parpadear(ServerLevel complejo) {
        parpadeo++;
        if (parpadeo >= Parpadeo.DURACION) {
            parpadeo = -1;
            return;
        }
        boolean apagadas = Parpadeo.apagadas(parpadeo);
        if (apagadas != Parpadeo.apagadas(parpadeo - 1)) {
            clicLuces(complejo, !apagadas);
        }
    }

    private static void clicLuces(ServerLevel complejo, boolean prenden) {
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(prenden ? SoundEvents.COPPER_BULB_TURN_ON : SoundEvents.COPPER_BULB_TURN_OFF,
                    SoundSource.BLOCKS, 0.8F, prenden ? 1.0F : 0.8F);
        }
    }

    private static void cortarParpadeo(ServerLevel complejo) {
        if (parpadeo >= 0) {
            Parpadeo corte = new Parpadeo(0);
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                PacketDistributor.sendToPlayer(jugador, corte);
            }
        }
        parpadeo = -1;
    }

    // ------------------------------------------------------------------ para los bots
    /** ¿Ya se dio cuenta de que paró la música? (cada llamada es un tick) */
    static boolean reacciono(JugadorBot bot) {
        Integer falta = REACCION.get(bot.getUUID());
        if (falta == null || falta <= 0) {
            return true;
        }
        REACCION.put(bot.getUUID(), falta - 1);
        return false;
    }

    /**
     * La silla libre adonde va el bot: la que le queda más cerca (los saltos cuentan como 12 bloques), salvo que otro
     * bot más cerca ya vaya por ella. null si no queda ninguna.
     */
    @Nullable
    static BlockPos sillaPara(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo) || estado != Estado.SENTARSE) {
            return null;
        }
        int aca = CAMPO.torreDe(bot);
        BlockPos mejor = null;
        double mejorCosto = Double.MAX_VALUE;
        for (BlockPos silla : SILLAS) {
            if (ocupada(complejo, silla)) {
                continue;
            }
            int torre = CAMPO.torreEn(silla.getX() + 0.5, silla.getZ() + 0.5);
            double saltos = aca < 0 || torre < 0 ? 3 : CAMPO.saltos(aca, torre);
            double costo = saltos * 12.0 + Math.sqrt(distancia2(bot.getX(), bot.getZ(), silla.getX() + 0.5, silla.getZ() + 0.5));
            Reclamo reclamo = RECLAMOS.get(silla);
            if (reclamo != null && !reclamo.quien().equals(bot.getUUID()) && reclamo.costo() <= costo
                    && sigueYendo(complejo, reclamo.quien())) {
                continue;                                              // va otro que está más cerca
            }
            if (costo < mejorCosto) {
                mejorCosto = costo;
                mejor = silla;
            }
        }
        RECLAMOS.values().removeIf(r -> r.quien().equals(bot.getUUID()));
        if (mejor != null) {
            RECLAMOS.put(mejor, new Reclamo(bot.getUUID(), mejorCosto));
        }
        return mejor;
    }

    /** ¿Ese bot sigue en pie, parado (no sentado) y en la ronda? */
    private static boolean sigueYendo(ServerLevel complejo, UUID quien) {
        LivingEntity bot = buscar(complejo, quien);
        return bot != null && !SENTADOS.contains(quien) && EN_RONDA.contains(quien);
    }

    /** La torre de esa silla. */
    static int torreDe(BlockPos silla) {
        return CAMPO.torreEn(silla.getX() + 0.5, silla.getZ() + 0.5);
    }

    /** El bot llegó al lado de la silla: se sienta si sigue libre. */
    static boolean sentarBot(JugadorBot bot, BlockPos silla) {
        if (!(bot.level() instanceof ServerLevel complejo) || estado != Estado.SENTARSE || trastabillando(bot)
                || distancia2(bot.getX(), bot.getZ(), silla.getX() + 0.5, silla.getZ() + 0.5) > ALCANCE_BOT * ALCANCE_BOT) {
            return false;
        }
        return sentar(complejo, silla, bot);
    }

    /** La probabilidad de que a un bot le salga mal un salto de torre a torre (casi nunca; a los torpes, más). */
    static double riesgo(JugadorBot bot) {
        return 0.003 * (0.5 + Math.floorMod(bot.getUUID().getMostSignificantBits(), 100) * 0.012);
    }

    // ------------------------------------------------------------------ fin
    static void limpiar(ServerLevel complejo) {
        cortarParpadeo(complejo);
        quitarTodasLasSillas(complejo);
        if (EstadoComplejo.de(complejo.getServer()).versionSillas() == VERSION_ARENA) {
            restaurarPiso(complejo);
        }
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ronda = 0;
        llenoDesde = -1;
        parpadeo = -1;
        GENTE.clear();
        EN_RONDA.clear();
        SILLAS.clear();
        ES_SILLA.clear();
        OCUPADAS.clear();
        SENTADOS.clear();
        BOTS.clear();
        REACCION.clear();
        RECLAMOS.clear();
        EMPUJADO.clear();
        PASARON.clear();
    }

    // ------------------------------------------------------------------ ayudas
    private static List<LivingEntity> enRonda(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>();
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien != null && !Juego.eliminado(quien)) {
                lista.add(quien);
            }
        }
        return lista;
    }

    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID id) {
        ServerPlayer jugador = complejo.getServer().getPlayerList().getPlayer(id);
        if (jugador != null) {
            return jugador.level() == complejo && jugador.isAlive() ? jugador : null;
        }
        JugadorBot bot = BOTS.get(id);
        return bot != null && bot.isAlive() && !bot.isRemoved() ? bot : null;
    }

    private static double distancia2(double x1, double z1, double x2, double z2) {
        double dx = x1 - x2;
        double dz = z1 - z2;
        return dx * dx + dz * dz;
    }

    private static <T> void mezclar(List<T> lista, RandomSource azar) {
        for (int i = lista.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            T aux = lista.get(i);
            lista.set(i, lista.get(j));
            lista.set(j, aux);
        }
    }
}
