package com.juegosdelpatio;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * La bola de fuego de Fuego cruzado: se tira con clic derecho (como una bola de nieve, un poco más rápida) y deja una
 * estela de llamas. Al que le pega lo empuja (y lo quema un poco); al piso de las torres lo quema: se vuelve magma y,
 * si le vuelven a pegar, se rompe (ver {@link Fuego}). Atraviesa a los del propio equipo.
 */
public class BolaDeFuego extends ThrowableItemProjectile {
    public BolaDeFuego(EntityType<? extends BolaDeFuego> tipo, Level nivel) {
        super(tipo, nivel);
    }

    public BolaDeFuego(Level nivel, LivingEntity tirador) {
        super(Registro.BOLA_DE_FUEGO.get(), tirador, nivel);
    }

    @Override
    protected Item getDefaultItem() {
        return Registro.BOLA_DE_FUEGO_ITEM.get();
    }

    @Override
    protected double getDefaultGravity() {
        return 0.03;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) {
            level().addParticle(ParticleTypes.FLAME, getX(), getY() + 0.1, getZ(), 0.0, 0.01, 0.0);
            if (this.tickCount % 2 == 0) {
                level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.1, getZ(), 0.0, 0.02, 0.0);
            }
        } else if (this.tickCount > 200 || getY() < level().getMinBuildHeight()) {
            discard();                                   // se cayó de las torres: no vuelve
        }
    }

    @Override
    protected boolean canHitEntity(Entity objetivo) {
        return super.canHitEntity(objetivo) && Fuego.puedePegar(getOwner(), objetivo);
    }

    @Override
    protected void onHitEntity(EntityHitResult resultado) {
        super.onHitEntity(resultado);
        Fuego.golpe(this, getOwner(), resultado.getEntity());
    }

    @Override
    protected void onHitBlock(BlockHitResult resultado) {
        super.onHitBlock(resultado);
        if (level() instanceof ServerLevel complejo) {
            Fuego.alPegarPiso(complejo, resultado.getBlockPos());
        }
    }

    @Override
    protected void onHit(HitResult resultado) {
        super.onHit(resultado);
        if (level() instanceof ServerLevel servidor) {
            servidor.sendParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 10, 0.15, 0.15, 0.15, 0.04);
            servidor.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 3, 0.1, 0.1, 0.1, 0.02);
            servidor.playSound(null, getX(), getY(), getZ(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.7F, 1.2F);
            discard();
        }
    }
}
