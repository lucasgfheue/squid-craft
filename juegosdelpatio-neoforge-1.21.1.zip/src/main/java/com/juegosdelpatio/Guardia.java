package com.juegosdelpatio;

import java.util.EnumSet;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * Guardia del complejo, con máscara de gas y uno de los cuatro rangos de {@link Rango}.
 *
 * Se queda quieto en su puesto y es neutral: solo ataca a quien lo ataque a él o a otro guardia,
 * a quien lastime a un jugador (de verdad o bot) cerca suyo, y a los monstruos que se acerquen.
 * Usa la porra cuerpo a cuerpo; con un arma de fuego dispara desde lejos.
 */
public class Guardia extends PathfinderMob implements RangedAttackMob {
    private static final EntityDataAccessor<Integer> RANGO =
            SynchedEntityData.defineId(Guardia.class, EntityDataSerializers.INT);

    private final MeleeAttackGoal ataqueCuerpo = new MeleeAttackGoal(this, 1.15, true);
    @Nullable
    private RangedAttackGoal ataqueDistancia;
    /** Lugar que custodia: se queda ahí quieto y vuelve si tuvo que pelear. */
    @Nullable
    private Vec3 puesto;
    /** Hacia dónde mira cuando está en su puesto y no hay nadie cerca. */
    private float giroPuesto;
    /** Si un jugador se acerca a menos de esto, gira la cabeza para mirarlo. */
    private static final float DISTANCIA_MIRAR = 6.0F;
    /** Tanda de guardias del complejo a la que pertenece (-1 = puesto a mano, nunca se borra solo). */
    private int generacion = -1;
    private int tiempoSinVer;
    /** Guardia del desfile de la ceremonia: no patrulla y desaparece cuando la ceremonia termina. */
    private boolean escolta;

    public Guardia(EntityType<? extends Guardia> tipo, Level nivel) {
        super(tipo, nivel);
        if (this.getNavigation() instanceof GroundPathNavigation navegacion) {
            navegacion.setCanOpenDoors(true);
        }
        this.setPersistenceRequired();
        if (!nivel.isClientSide()) {
            reevaluarArma();
        }
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 24.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.ATTACK_DAMAGE, 2.0)
                .add(Attributes.ARMOR, 2.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        super.defineSynchedData(datos);
        datos.define(RANGO, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        // prioridad 2: el ataque (cuerpo a cuerpo o a distancia según el arma, ver reevaluarArma)
        this.goalSelector.addGoal(4, new VolverAlPuestoGoal(this));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, DISTANCIA_MIRAR));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, Guardia.class, JugadorBot.class).setAlertOthers());
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false,
                objetivo -> objetivo instanceof Enemy));
    }

    // ------------------------------------------------------------------ rango y equipo
    public Rango getRango() {
        return Rango.deIndice(this.entityData.get(RANGO));
    }

    /** Le da el rango con su vida, armadura, arma y nombre. */
    public void configurar(Rango rango, @Nullable Vec3 lugar, int tanda) {
        this.entityData.set(RANGO, rango.ordinal());
        this.puesto = lugar;
        this.giroPuesto = getYRot();
        this.generacion = tanda;
        AttributeInstance vida = getAttribute(Attributes.MAX_HEALTH);
        if (vida != null) {
            vida.setBaseValue(rango.vida);
        }
        AttributeInstance armadura = getAttribute(Attributes.ARMOR);
        if (armadura != null) {
            armadura.setBaseValue(rango.armadura);
        }
        setHealth(getMaxHealth());
        setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(rango.arma()));
        setDropChance(EquipmentSlot.MAINHAND, 0.05F);
        setCustomName(rango.nombre());
    }

    @Override
    public void setItemSlot(EquipmentSlot lugar, ItemStack objeto) {
        super.setItemSlot(lugar, objeto);
        if (lugar == EquipmentSlot.MAINHAND && !level().isClientSide()) {
            reevaluarArma();
        }
    }

    /** Elige cómo pelear según lo que tenga en la mano (como hacen los esqueletos). */
    private void reevaluarArma() {
        if (level().isClientSide() || ataqueCuerpo == null) {
            return;
        }
        this.goalSelector.removeGoal(ataqueCuerpo);
        if (ataqueDistancia != null) {
            this.goalSelector.removeGoal(ataqueDistancia);
            ataqueDistancia = null;
        }
        if (getMainHandItem().getItem() instanceof ArmaDeFuego arma) {
            ataqueDistancia = new RangedAttackGoal(this, 1.0, arma.intervaloGuardia, arma.alcanceGuardia);
            this.goalSelector.addGoal(2, ataqueDistancia);
        } else {
            this.goalSelector.addGoal(2, ataqueCuerpo);
        }
    }

    /** Lo convierte en parte del desfile de la ceremonia. */
    public void hacerEscolta() {
        this.escolta = true;
        this.puesto = null;
        this.generacion = -1;
    }

    /** Escolta que se queda fija en un lugar (los que reparten la comida): no se mueve y se va con los demás. */
    public void hacerEscoltaFija(Vec3 lugar) {
        hacerEscolta();
        this.puesto = lugar;
        this.giroPuesto = getYRot();
    }

    public boolean esEscolta() {
        return escolta;
    }

    /** Camina hasta un lugar (lo usa la ceremonia para mover el desfile). */
    public void marcharA(Vec3 destino, double velocidad) {
        getNavigation().moveTo(destino.x, destino.y, destino.z, velocidad);
    }

    /** true si lo puso el complejo (no un huevo ni un comando). */
    public boolean esDeLaTanda() {
        return generacion >= 0;
    }

    @Override
    public void performRangedAttack(LivingEntity objetivo, float fuerza) {
        if (getMainHandItem().getItem() instanceof ArmaDeFuego arma) {
            arma.dispararHacia(this, objetivo);
        }
    }

    @Override
    public boolean isAlliedTo(Entity otro) {
        return otro instanceof Guardia || otro instanceof JugadorBot || super.isAlliedTo(otro);
    }

    @Override
    public boolean removeWhenFarAway(double distancia) {
        return false;
    }

    /** Los que tienen puesto no se dejan empujar por la gente que pasa. */
    @Override
    public boolean isPushable() {
        return puesto == null && super.isPushable();
    }

    // ------------------------------------------------------------------ guardado
    @Override
    public void addAdditionalSaveData(CompoundTag datos) {
        super.addAdditionalSaveData(datos);
        datos.putInt("Rango", getRango().ordinal());
        datos.putInt("Generacion", generacion);
        datos.putBoolean("Escolta", escolta);
        if (puesto != null) {
            datos.putDouble("PuestoX", puesto.x);
            datos.putDouble("PuestoY", puesto.y);
            datos.putDouble("PuestoZ", puesto.z);
            datos.putFloat("GiroPuesto", giroPuesto);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag datos) {
        super.readAdditionalSaveData(datos);
        this.entityData.set(RANGO, Math.floorMod(datos.getInt("Rango"), Rango.values().length));
        generacion = datos.contains("Generacion") ? datos.getInt("Generacion") : -1;
        escolta = datos.getBoolean("Escolta");
        puesto = datos.contains("PuestoX")
                ? new Vec3(datos.getDouble("PuestoX"), datos.getDouble("PuestoY"), datos.getDouble("PuestoZ"))
                : null;
        giroPuesto = datos.getFloat("GiroPuesto");
        reevaluarArma();
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor nivel, DifficultyInstance dificultad,
                                        MobSpawnType tipo, @Nullable SpawnGroupData datos) {
        SpawnGroupData resultado = super.finalizeSpawn(nivel, dificultad, tipo, datos);
        configurar(Rango.alAzar(getRandom()), position(), -1);
        return resultado;
    }

    // ------------------------------------------------------------------ cada tick
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (escolta && !Ceremonia.enCurso() && !Juego.enCurso() && !Comida.enCurso()) {
            discard();                                    // un desfile que quedó de una ceremonia anterior
            return;
        }
        LivingEntity objetivo = getTarget();
        if (objetivo != null) {
            tiempoSinVer = getSensing().hasLineOfSight(objetivo) ? 0 : tiempoSinVer + 1;
            if (!objetivo.isAlive() || objetivo.level() != level() || !canAttack(objetivo)
                    || distanceToSqr(objetivo) > 48.0 * 48.0 || tiempoSinVer > 200) {
                setTarget(null);                          // se escapó o ya no es una amenaza
                objetivo = null;
            }
        }
        setAggressive(objetivo != null);

        // Quieto en su puesto: si no hay nadie cerca, mira al frente
        if (puesto != null && objetivo == null && getNavigation().isDone() && distanceToSqr(puesto) <= 2.25
                && level().getNearestPlayer(this, DISTANCIA_MIRAR) == null) {
            double giro = Math.toRadians(giroPuesto);
            getLookControl().setLookAt(getX() - Math.sin(giro) * 5.0, getEyeY(), getZ() + Math.cos(giro) * 5.0);
        }

        // Si se pidió una tanda nueva de guardias, los viejos se van solos
        if (this.tickCount % 40 == 0 && generacion >= 0 && level() instanceof ServerLevel servidor
                && servidor.dimension().equals(Complejo.DIMENSION)
                && generacion != EstadoComplejo.de(servidor.getServer()).generacionGuardias()) {
            discard();
        }
    }

    // ------------------------------------------------------------------ defensa de los jugadores
    /** Avisa a los guardias cercanos que {@code atacante} lastimó a alguien que tienen que cuidar. */
    static void pedirAyuda(LivingEntity victima, LivingEntity atacante) {
        if (atacante instanceof Guardia || atacante instanceof JugadorBot || !atacante.canBeSeenAsEnemy()) {
            return;
        }
        if (Juego.enArena() && Juego.estaEnArena(victima)) {
            return;                                             // en pleno juego los guardias no se meten: se arreglan solos
        }
        AABB zona = victima.getBoundingBox().inflate(24.0, 8.0, 24.0);
        for (Guardia guardia : victima.level().getEntitiesOfClass(Guardia.class, zona)) {
            if (guardia.getTarget() == null && guardia.canAttack(atacante)) {
                guardia.setTarget(atacante);
            }
        }
    }

    /** Escucha todo el daño del juego: si lastiman a un jugador o a un bot, los guardias cercanos reaccionan. */
    static void alRecibirDanio(LivingIncomingDamageEvent evento) {
        LivingEntity victima = evento.getEntity();
        if (victima.level().isClientSide() || !(victima instanceof JugadorBot || victima instanceof Player)) {
            return;
        }
        if (evento.getSource().getEntity() instanceof LivingEntity atacante && atacante != victima) {
            pedirAyuda(victima, atacante);
        }
    }

    // ================================================================== puesto

    /** Si se alejó de su puesto (por ejemplo, para pelear), vuelve y se queda ahí quieto. */
    static class VolverAlPuestoGoal extends Goal {
        private final Guardia guardia;

        VolverAlPuestoGoal(Guardia guardia) {
            this.guardia = guardia;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            Vec3 lugar = guardia.puesto;
            return lugar != null && guardia.getTarget() == null && guardia.distanceToSqr(lugar) > 2.25;
        }

        @Override
        public void start() {
            Vec3 lugar = guardia.puesto;
            if (lugar != null) {
                guardia.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 0.8);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return guardia.getTarget() == null && !guardia.getNavigation().isDone();
        }

        @Override
        public void stop() {
            guardia.getNavigation().stop();
        }
    }
}
