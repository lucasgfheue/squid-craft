package com.juegosdelpatio;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Clic derecho: si estás afuera te lleva al dormitorio; si estás adentro te devuelve. */
public class InvitacionItem extends Item {

    public InvitacionItem(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level nivel, Player jugador, InteractionHand mano) {
        ItemStack invitacion = jugador.getItemInHand(mano);
        jugador.getCooldowns().addCooldown(this, 40);
        if (jugador instanceof ServerPlayer jugadorServidor) {
            Complejo.usarInvitacion(jugadorServidor);
        }
        return InteractionResultHolder.sidedSuccess(invitacion, nivel.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack objeto) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack objeto, TooltipContext contexto, List<Component> lineas, TooltipFlag opciones) {
        lineas.add(Component.translatable("item.juegosdelpatio.invitacion.descripcion").withStyle(ChatFormatting.GRAY));
    }
}
