package com.juegosdelpatio;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** Lugar al que vuelve el jugador cuando sale del complejo. */
public record PosicionRetorno(Optional<ResourceKey<Level>> dimension, double x, double y, double z,
                              float yRot, float xRot) {

    public static final PosicionRetorno NINGUNA = new PosicionRetorno(Optional.empty(), 0, 0, 0, 0, 0);

    public static final Codec<PosicionRetorno> CODEC = RecordCodecBuilder.create(i -> i.group(
            Level.RESOURCE_KEY_CODEC.optionalFieldOf("dimension").forGetter(PosicionRetorno::dimension),
            Codec.DOUBLE.fieldOf("x").forGetter(PosicionRetorno::x),
            Codec.DOUBLE.fieldOf("y").forGetter(PosicionRetorno::y),
            Codec.DOUBLE.fieldOf("z").forGetter(PosicionRetorno::z),
            Codec.FLOAT.fieldOf("y_rot").forGetter(PosicionRetorno::yRot),
            Codec.FLOAT.fieldOf("x_rot").forGetter(PosicionRetorno::xRot)
    ).apply(i, PosicionRetorno::new));
}
