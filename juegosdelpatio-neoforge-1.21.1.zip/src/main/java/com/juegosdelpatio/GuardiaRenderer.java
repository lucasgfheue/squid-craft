package com.juegosdelpatio;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;

/** Dibuja a los guardias con el modelo de jugador y la skin de su rango; apuntan cuando pelean. */
public class GuardiaRenderer extends HumanoidMobRenderer<Guardia, PlayerModel<Guardia>> {
    private static final ResourceLocation[] TEXTURAS = new ResourceLocation[Rango.values().length];

    static {
        for (Rango rango : Rango.values()) {
            TEXTURAS[rango.ordinal()] = ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID,
                    "textures/entity/guardia/" + rango.id + ".png");
        }
    }

    public GuardiaRenderer(EntityRendererProvider.Context contexto) {
        super(contexto, new PlayerModel<>(contexto.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(Guardia guardia) {
        return TEXTURAS[guardia.getRango().ordinal()];
    }

    @Override
    public void render(Guardia guardia, float giro, float parcial, PoseStack pose, MultiBufferSource buffers, int luz) {
        ItemStack arma = guardia.getMainHandItem();
        HumanoidModel.ArmPose brazo = HumanoidModel.ArmPose.EMPTY;
        if (!arma.isEmpty()) {
            brazo = arma.getItem() instanceof ArmaDeFuego && guardia.isAggressive()
                    ? HumanoidModel.ArmPose.CROSSBOW_HOLD     // apunta con las dos manos
                    : HumanoidModel.ArmPose.ITEM;
        }
        boolean diestro = guardia.getMainArm() == HumanoidArm.RIGHT;
        this.model.rightArmPose = diestro ? brazo : HumanoidModel.ArmPose.EMPTY;
        this.model.leftArmPose = diestro ? HumanoidModel.ArmPose.EMPTY : brazo;
        super.render(guardia, giro, parcial, pose, buffers, luz);
    }
}
