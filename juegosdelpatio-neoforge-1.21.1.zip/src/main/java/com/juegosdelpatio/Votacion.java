package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * La votación después de un juego: seguir jugando o irse. Votan los jugadores que siguen en el complejo (con los
 * botones del chat, o con /votar seguir y /votar irse) y también los bots. Gana la mayoría; si empatan, se sigue.
 * Si gana irse, el premio se reparte entre todos los que quedan (jugadores y bots) y, unos segundos después,
 * los jugadores vuelven a su mundo con su parte en diamantes.
 *
 * Mientras haya muchos bots (por lo menos {@link #BOTS_PARA_SEGUIR} más que jugadores), siempre gana seguir, pero
 * por muy poco: durante casi todo el minuto va ganando irse por uno o dos votos, y en los últimos segundos votan los
 * indecisos, que dan vuelta la votación (o empatan, y con empate se sigue). Los bots tienen en cuenta cómo votan los
 * jugadores. Cuando quedan pocos bots, cada uno vota lo que quiere y puede ganar cualquiera.
 */
final class Votacion {
    /** Un minuto para votar (se termina antes si ya votaron todos). */
    private static final int DURACION = 60 * 20;
    private static final int ESPERA_SALIDA = 10 * 20;
    /** Con por lo menos tantos bots más que jugadores, la votación la deciden los bots: gana seguir, por poco. */
    static final int BOTS_PARA_SEGUIR = 10;
    /** Los últimos 10 segundos: votan los indecisos (los que deciden la votación). */
    private static final int ULTIMOS = 10 * 20;
    /** Los indecisos son tantos más que los jugadores (así alcanzan para dar vuelta lo que voten ellos). */
    private static final int INDECISOS_DE_MAS = 8;

    private static boolean activa;
    private static int tiempo;
    /** Votos de los jugadores: true = seguir. */
    private static final Map<UUID, Boolean> VOTOS = new HashMap<>();
    /**
     * Votos de los bots que todavía no se dijeron: {tick en que votan, 1 = seguir, 0 = irse o -1 = lo decide en el
     * momento, 1 si es de los indecisos de los últimos segundos}.
     */
    private static final List<int[]> PENDIENTES = new ArrayList<>();
    /** Esta votación la deciden los bots (hay muchos): gana seguir por {@link #margen} votos (0 = empate). */
    private static boolean decidenBots;
    private static int margen;
    private static int botsSeguir;
    private static int botsIrse;
    /** Cuántos quedan en total (jugadores y bots) para repartir el premio. */
    private static int quedan;
    private static int parte;
    private static int salidaEn;
    /** Cómo salió la última votación: si ganó seguir (o empataron). */
    private static boolean ganoSeguir;
    @Nullable
    private static ServerBossEvent barra;

    private Votacion() {
    }

    static boolean enCurso() {
        return activa;
    }

    /** La última votación terminó en seguir (o en empate). */
    static boolean ganoSeguir() {
        return ganoSeguir;
    }

    /**
     * Empieza a votar. Cuantos más eliminados hubo, más bots quieren irse.
     * false si ya había una votación.
     */
    static boolean empezar(ServerLevel complejo, int quedanTotal, double fraccionEliminados) {
        if (activa) {
            return false;
        }
        activa = true;
        tiempo = 0;
        VOTOS.clear();
        PENDIENTES.clear();
        botsSeguir = 0;
        botsIrse = 0;
        quedan = Math.max(1, quedanTotal);
        RandomSource azar = complejo.getRandom();
        List<JugadorBot> bots = new ArrayList<>(complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive()));
        int jugadores = votantes(complejo).size();
        decidenBots = bots.size() >= jugadores + BOTS_PARA_SEGUIR;
        if (decidenBots) {
            // si votan todos, ¿son pares o impares? gana seguir por 1 (o 3), o por 2 (o empatan)
            boolean impares = (bots.size() + jugadores) % 2 == 1;
            margen = impares ? (azar.nextInt(10) < 7 ? 1 : 3) : (azar.nextInt(10) < 6 ? 2 : 0);
            int indecisos = Math.min(bots.size(), jugadores + INDECISOS_DE_MAS);
            for (int i = 0; i < bots.size(); i++) {
                boolean indeciso = i < indecisos;
                int cuando = indeciso ? DURACION - ULTIMOS + azar.nextInt(ULTIMOS - 20)
                        : 40 + azar.nextInt(DURACION - ULTIMOS - 80);
                PENDIENTES.add(new int[] {cuando, -1, indeciso ? 1 : 0});
            }
        } else {
            double quierenIrse = Math.min(0.85, 0.2 + 0.6 * fraccionEliminados);
            for (JugadorBot bot : bots) {
                PENDIENTES.add(new int[] {40 + azar.nextInt(700), azar.nextDouble() < quierenIrse ? 0 : 1, 0});
            }
        }
        barra = new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
        for (ServerPlayer jugador : votantes(complejo)) {
            botones(jugador);
            barra.addPlayer(jugador);
        }
        actualizarBarra();
        return true;
    }

    /** Los botones del chat: tocar uno es como escribir /votar seguir o /votar irse. */
    private static void botones(ServerPlayer jugador) {
        MutableComponent seguir = Component.translatable("voto.juegosdelpatio.boton_seguir").withStyle(estilo -> estilo
                .withColor(ChatFormatting.GREEN).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/votar seguir"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        Component.translatable("voto.juegosdelpatio.ayuda_seguir"))));
        MutableComponent irse = Component.translatable("voto.juegosdelpatio.boton_irse").withStyle(estilo -> estilo
                .withColor(ChatFormatting.RED).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/votar irse"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        Component.translatable("voto.juegosdelpatio.ayuda_irse"))));
        jugador.sendSystemMessage(Component.translatable("voto.juegosdelpatio.pregunta").withStyle(ChatFormatting.GOLD));
        jugador.sendSystemMessage(Component.empty().append(seguir).append(Component.literal("    ")).append(irse));
        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 1.2F);
    }

    /** /votar seguir o /votar irse. 0: votó; 1: no hay votación; 2: ya había votado; 3: no está en el complejo. */
    static int votar(ServerPlayer jugador, boolean seguir) {
        if (!activa) {
            return 1;
        }
        if (!jugador.level().dimension().equals(Complejo.DIMENSION) || !jugador.isAlive() || jugador.isSpectator()) {
            return 3;
        }
        if (VOTOS.containsKey(jugador.getUUID())) {
            return 2;
        }
        VOTOS.put(jugador.getUUID(), seguir);
        actualizarBarra();
        return 0;
    }

    static void alTick(ServerTickEvent.Post evento) {
        MinecraftServer servidor = evento.getServer();
        ServerLevel complejo = servidor.getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        if (salidaEn > 0 && --salidaEn == 0) {
            repartirYSalir(complejo);
        }
        if (!activa) {
            return;
        }
        tiempo++;
        boolean cambio = false;
        RandomSource azar = complejo.getRandom();
        int sinVotar = sinVotar(complejo);
        for (Iterator<int[]> it = PENDIENTES.iterator(); it.hasNext(); ) {
            int[] voto = it.next();
            if (voto[0] <= tiempo) {                                 // los bots votan de a poco
                if (votoDe(voto, azar, sinVotar)) {
                    botsSeguir++;
                } else {
                    botsIrse++;
                }
                it.remove();
                cambio = true;
            }
        }
        if (decidenBots && tiempo == DURACION - ULTIMOS) {
            for (ServerPlayer jugador : votantes(complejo)) {        // ¡los últimos votos!
                jugador.displayClientMessage(Component.translatable("voto.juegosdelpatio.ultimos")
                        .withStyle(ChatFormatting.GOLD), true);
                jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 1.0F, 0.8F);
            }
        }
        if (cambio || tiempo % 20 == 0) {
            actualizarBarra();
        }
        if (barra != null && tiempo % 40 == 0) {
            for (ServerPlayer jugador : votantes(complejo)) {
                barra.addPlayer(jugador);                            // por si alguien entró recién
            }
        }
        boolean votaronTodos = PENDIENTES.isEmpty()
                && votantes(complejo).stream().allMatch(jugador -> VOTOS.containsKey(jugador.getUUID()));
        boolean ultimoIndeciso = decidenBots && PENDIENTES.isEmpty() && tiempo >= DURACION - ULTIMOS;
        if (tiempo >= DURACION || votaronTodos && tiempo >= 100 || ultimoIndeciso) {
            terminar(complejo);                                      // (votó el último indeciso: ya está)
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        activa = false;
        decidenBots = false;
        VOTOS.clear();
        PENDIENTES.clear();
        salidaEn = 0;
        barra = null;
    }

    private static void terminar(ServerLevel complejo) {
        activa = false;
        RandomSource azar = complejo.getRandom();
        for (Iterator<int[]> it = PENDIENTES.iterator(); it.hasNext(); ) {   // los bots que faltaban, votan ahora
            int[] voto = it.next();
            if (votoDe(voto, azar, 0)) {
                botsSeguir++;
            } else {
                botsIrse++;
            }
            it.remove();
        }
        PENDIENTES.clear();
        int seguir = botsSeguir;
        int irse = botsIrse;
        for (boolean voto : VOTOS.values()) {
            if (voto) {
                seguir++;
            } else {
                irse++;
            }
        }
        if (barra != null) {
            barra.removeAllPlayers();
            barra = null;
        }
        ganoSeguir = irse <= seguir;
        if (irse > seguir) {
            decir(complejo, Component.translatable("voto.juegosdelpatio.gano_irse", irse, seguir));
            int premio = EstadoComplejo.de(complejo.getServer()).premio();
            parte = Math.max(1, premio / quedan);
            decir(complejo, Component.translatable("voto.juegosdelpatio.reparto", premio, quedan, parte));
            salidaEn = ESPERA_SALIDA;
        } else if (irse == seguir) {
            decir(complejo, Component.translatable("voto.juegosdelpatio.empate", seguir, irse));
        } else {
            decir(complejo, Component.translatable("voto.juegosdelpatio.gano_seguir", seguir, irse));
        }
    }

    /**
     * Lo que vota un bot ahora (true = seguir). Si no lo tenía decidido: los del medio de la votación hacen que vaya
     * ganando irse por uno o dos (o tres) votos; los indecisos, en los últimos segundos, la dan vuelta para que gane
     * seguir por {@link #margen} (contando lo que votaron los jugadores, y guardando votos por si los
     * {@code sinVotar} jugadores que todavía no votaron votan irse a último momento).
     */
    private static boolean votoDe(int[] voto, RandomSource azar, int sinVotar) {
        if (voto[1] >= 0) {
            return voto[1] == 1;
        }
        int seguir = botsSeguir;
        int irse = botsIrse;
        for (boolean v : VOTOS.values()) {
            if (v) {
                seguir++;
            } else {
                irse++;
            }
        }
        if (voto[2] == 0) {
            int ventaja = irse - seguir;                             // que vaya ganando irse, por poco
            return ventaja >= 2 && (ventaja > 3 || azar.nextBoolean());
        }
        int faltan = 0;                                              // los indecisos que quedan (con este)
        for (int[] otro : PENDIENTES) {
            if (otro[2] == 1) {
                faltan++;
            }
        }
        faltan = Math.max(1, faltan);
        // si este votara irse, ¿los indecisos que quedan alcanzarían igual (aunque los que faltan voten irse)?
        int haranFalta = (int) Math.ceil((faltan - 1 + margen - (seguir - irse - 1) + sinVotar) / 2.0);
        if (haranFalta > faltan - 1) {
            return true;                                             // irse ya no: vota seguir
        }
        int seguirFaltan = (int) Math.ceil((faltan + margen - (seguir - irse)) / 2.0);   // cuántos tienen que votar seguir
        seguirFaltan = Math.max(0, Math.min(faltan, seguirFaltan));
        return azar.nextInt(faltan) < seguirFaltan;
    }

    /** Cuántos jugadores del complejo todavía no votaron. */
    private static int sinVotar(ServerLevel complejo) {
        int faltan = 0;
        for (ServerPlayer jugador : votantes(complejo)) {
            if (!VOTOS.containsKey(jugador.getUUID())) {
                faltan++;
            }
        }
        return faltan;
    }

    /** Ganó irse: cada jugador se lleva su parte en diamantes y vuelve a su mundo. El premio vuelve a empezar. */
    private static void repartirYSalir(ServerLevel complejo) {
        for (ServerPlayer jugador : List.copyOf(complejo.players())) {
            if (!jugador.isAlive()) {
                continue;
            }
            int faltan = parte;
            while (faltan > 0) {
                ItemStack diamantes = new ItemStack(Items.DIAMOND, Math.min(64, faltan));
                faltan -= diamantes.getCount();
                if (!jugador.getInventory().add(diamantes)) {
                    jugador.drop(diamantes, false);                  // no le entra: queda a sus pies (y viaja igual)
                }
            }
            jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
            jugador.connection.send(new ClientboundSetSubtitleTextPacket(
                    Component.translatable("titulo.juegosdelpatio.te_llevas", parte).withStyle(ChatFormatting.AQUA)));
            jugador.connection.send(new ClientboundSetTitleTextPacket(
                    Component.translatable("titulo.juegosdelpatio.fin_juegos").withStyle(ChatFormatting.GOLD)));
            Complejo.salir(jugador);
        }
        EstadoComplejo.de(complejo.getServer()).setPremio(Complejo.PREMIO_DIAMANTES);
    }

    private static List<ServerPlayer> votantes(ServerLevel complejo) {
        List<ServerPlayer> lista = new ArrayList<>();
        for (ServerPlayer jugador : complejo.players()) {
            if (jugador.isAlive() && !jugador.isSpectator()) {
                lista.add(jugador);
            }
        }
        return lista;
    }

    private static void actualizarBarra() {
        if (barra == null) {
            return;
        }
        int seguir = botsSeguir;
        int irse = botsIrse;
        for (boolean voto : VOTOS.values()) {
            if (voto) {
                seguir++;
            } else {
                irse++;
            }
        }
        int segundos = Math.max(0, (DURACION - tiempo + 19) / 20);
        barra.setName(Component.translatable("voto.juegosdelpatio.barra", seguir, irse, segundos));
        barra.setProgress(Math.max(0.0F, 1.0F - tiempo / (float) DURACION));
    }

    private static void decir(ServerLevel complejo, Component texto) {
        MutableComponent mensaje = Component.literal("<").append(Rango.COMANDANTE.nombre())
                .append(Component.literal("> "))
                .append(Component.empty().append(texto).withStyle(ChatFormatting.YELLOW));
        for (ServerPlayer jugador : complejo.players()) {
            jugador.sendSystemMessage(mensaje);
        }
    }
}
