package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * La votación después de un juego: seguir jugando o irse. Votan los jugadores que siguen en el complejo (con los
 * botones del chat, o con /votar seguir y /votar irse) y también los bots. Gana la mayoría; si empatan, se sigue.
 * Si gana irse, el premio se reparte entre todos los que quedan (jugadores y bots) y, unos segundos después,
 * los jugadores vuelven a su mundo con su parte en diamantes.
 */
final class Votacion {
    /** Un minuto para votar (se termina antes si ya votaron todos). */
    private static final int DURACION = 60 * 20;
    private static final int ESPERA_SALIDA = 10 * 20;

    private static boolean activa;
    private static int tiempo;
    /** Votos de los jugadores: true = seguir. */
    private static final Map<UUID, Boolean> VOTOS = new HashMap<>();
    /** Votos de los bots que todavía no se dijeron: {tick en que votan, 1 = seguir o 0 = irse}. */
    private static final List<int[]> PENDIENTES = new ArrayList<>();
    private static int botsSeguir;
    private static int botsIrse;
    /** Cuántos quedan en total (jugadores y bots) para repartir el premio. */
    private static int quedan;
    private static int parte;
    private static int salidaEn;
    /** Cómo salió la última votación: si ganó seguir (o empataron). */
    private static boolean ganoSeguir;
    @Nullable
    private static ServerBossEvent barra;

    private Votacion() {
    }

    static boolean enCurso() {
        return activa;
    }

    /** La última votación terminó en seguir (o en empate). */
    static boolean ganoSeguir() {
        return ganoSeguir;
    }

    /**
     * Empieza a votar. Cuantos más eliminados hubo, más bots quieren irse.
     * false si ya había una votación.
     */
    static boolean empezar(ServerLevel complejo, int quedanTotal, double fraccionEliminados) {
        if (activa) {
            return false;
        }
        activa = true;
        tiempo = 0;
        VOTOS.clear();
        PENDIENTES.clear();
        botsSeguir = 0;
        botsIrse = 0;
        quedan = Math.max(1, quedanTotal);
        RandomSource azar = complejo.getRandom();
        double quierenIrse = Math.min(0.85, 0.2 + 0.6 * fraccionEliminados);
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive())) {
            PENDIENTES.add(new int[] {40 + azar.nextInt(700), azar.nextDouble() < quierenIrse ? 0 : 1});
        }
        barra = new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
        for (ServerPlayer jugador : votantes(complejo)) {
            botones(jugador);
            barra.addPlayer(jugador);
        }
        actualizarBarra();
        return true;
    }

    /** Los botones del chat: tocar uno es como escribir /votar seguir o /votar irse. */
    private static void botones(ServerPlayer jugador) {
        MutableComponent seguir = Component.translatable("voto.juegosdelpatio.boton_seguir").withStyle(estilo -> estilo
                .withColor(ChatFormatting.GREEN).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/votar seguir"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        Component.translatable("voto.juegosdelpatio.ayuda_seguir"))));
        MutableComponent irse = Component.translatable("voto.juegosdelpatio.boton_irse").withStyle(estilo -> estilo
                .withColor(ChatFormatting.RED).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/votar irse"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        Component.translatable("voto.juegosdelpatio.ayuda_irse"))));
        jugador.sendSystemMessage(Component.translatable("voto.juegosdelpatio.pregunta").withStyle(ChatFormatting.GOLD));
        jugador.sendSystemMessage(Component.empty().append(seguir).append(Component.literal("    ")).append(irse));
        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 1.2F);
    }

    /** /votar seguir o /votar irse. 0: votó; 1: no hay votación; 2: ya había votado; 3: no está en el complejo. */
    static int votar(ServerPlayer jugador, boolean seguir) {
        if (!activa) {
            return 1;
        }
        if (!jugador.level().dimension().equals(Complejo.DIMENSION) || !jugador.isAlive() || jugador.isSpectator()) {
            return 3;
        }
        if (VOTOS.containsKey(jugador.getUUID())) {
            return 2;
        }
        VOTOS.put(jugador.getUUID(), seguir);
        actualizarBarra();
        return 0;
    }

    static void alTick(ServerTickEvent.Post evento) {
        MinecraftServer servidor = evento.getServer();
        ServerLevel complejo = servidor.getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        if (salidaEn > 0 && --salidaEn == 0) {
            repartirYSalir(complejo);
        }
        if (!activa) {
            return;
        }
        tiempo++;
        boolean cambio = false;
        for (Iterator<int[]> it = PENDIENTES.iterator(); it.hasNext(); ) {
            int[] voto = it.next();
            if (voto[0] <= tiempo) {                                 // los bots votan de a poco
                if (voto[1] == 1) {
                    botsSeguir++;
                } else {
                    botsIrse++;
                }
                it.remove();
                cambio = true;
            }
        }
        if (cambio || tiempo % 20 == 0) {
            actualizarBarra();
        }
        if (barra != null && tiempo % 40 == 0) {
            for (ServerPlayer jugador : votantes(complejo)) {
                barra.addPlayer(jugador);                            // por si alguien entró recién
            }
        }
        boolean votaronTodos = PENDIENTES.isEmpty()
                && votantes(complejo).stream().allMatch(jugador -> VOTOS.containsKey(jugador.getUUID()));
        if (tiempo >= DURACION || votaronTodos && tiempo >= 100) {
            terminar(complejo);
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        activa = false;
        VOTOS.clear();
        PENDIENTES.clear();
        salidaEn = 0;
        barra = null;
    }

    private static void terminar(ServerLevel complejo) {
        activa = false;
        for (int[] voto : PENDIENTES) {                              // los bots que faltaban, votan ahora
            if (voto[1] == 1) {
                botsSeguir++;
            } else {
                botsIrse++;
            }
        }
        PENDIENTES.clear();
        int seguir = botsSeguir;
        int irse = botsIrse;
        for (boolean voto : VOTOS.values()) {
            if (voto) {
                seguir++;
            } else {
                irse++;
            }
        }
        if (barra != null) {
            barra.removeAllPlayers();
            barra = null;
        }
        ganoSeguir = irse <= seguir;
        if (irse > seguir) {
            decir(complejo, Component.translatable("voto.juegosdelpatio.gano_irse", irse, seguir));
            int premio = EstadoComplejo.de(complejo.getServer()).premio();
            parte = Math.max(1, premio / quedan);
            decir(complejo, Component.translatable("voto.juegosdelpatio.reparto", premio, quedan, parte));
            salidaEn = ESPERA_SALIDA;
        } else {
            decir(complejo, Component.translatable("voto.juegosdelpatio.gano_seguir", seguir, irse));
        }
    }

    /** Ganó irse: cada jugador se lleva su parte en diamantes y vuelve a su mundo. El premio vuelve a empezar. */
    private static void repartirYSalir(ServerLevel complejo) {
        for (ServerPlayer jugador : List.copyOf(complejo.players())) {
            if (!jugador.isAlive()) {
                continue;
            }
            int faltan = parte;
            while (faltan > 0) {
                ItemStack diamantes = new ItemStack(Items.DIAMOND, Math.min(64, faltan));
                faltan -= diamantes.getCount();
                if (!jugador.getInventory().add(diamantes)) {
                    jugador.drop(diamantes, false);                  // no le entra: queda a sus pies (y viaja igual)
                }
            }
            jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
            jugador.connection.send(new ClientboundSetSubtitleTextPacket(
                    Component.translatable("titulo.juegosdelpatio.te_llevas", parte).withStyle(ChatFormatting.AQUA)));
            jugador.connection.send(new ClientboundSetTitleTextPacket(
                    Component.translatable("titulo.juegosdelpatio.fin_juegos").withStyle(ChatFormatting.GOLD)));
            Complejo.salir(jugador);
        }
        EstadoComplejo.de(complejo.getServer()).setPremio(Complejo.PREMIO_DIAMANTES);
    }

    private static List<ServerPlayer> votantes(ServerLevel complejo) {
        List<ServerPlayer> lista = new ArrayList<>();
        for (ServerPlayer jugador : complejo.players()) {
            if (jugador.isAlive() && !jugador.isSpectator()) {
                lista.add(jugador);
            }
        }
        return lista;
    }

    private static void actualizarBarra() {
        if (barra == null) {
            return;
        }
        int seguir = botsSeguir;
        int irse = botsIrse;
        for (boolean voto : VOTOS.values()) {
            if (voto) {
                seguir++;
            } else {
                irse++;
            }
        }
        int segundos = Math.max(0, (DURACION - tiempo + 19) / 20);
        barra.setName(Component.translatable("voto.juegosdelpatio.barra", seguir, irse, segundos));
        barra.setProgress(Math.max(0.0F, 1.0F - tiempo / (float) DURACION));
    }

    private static void decir(ServerLevel complejo, Component texto) {
        MutableComponent mensaje = Component.literal("<").append(Rango.COMANDANTE.nombre())
                .append(Component.literal("> "))
                .append(Component.empty().append(texto).withStyle(ChatFormatting.YELLOW));
        for (ServerPlayer jugador : complejo.players()) {
            jugador.sendSystemMessage(mensaje);
        }
    }
}
