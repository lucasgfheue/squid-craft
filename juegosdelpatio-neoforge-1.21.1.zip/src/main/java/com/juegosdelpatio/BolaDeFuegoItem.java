package com.juegosdelpatio;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** La bola de fuego de Fuego cruzado: clic derecho para tirarla. En el juego, la nueva llega a los 2 segundos. */
public class BolaDeFuegoItem extends Item {
    public BolaDeFuegoItem(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level nivel, Player jugador, InteractionHand mano) {
        ItemStack bola = jugador.getItemInHand(mano);
        if (!nivel.isClientSide()) {
            String motivo = Fuego.porQueNoTira(jugador);
            if (motivo != null) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio." + motivo)
                        .withStyle(ChatFormatting.GRAY), true);
                return InteractionResultHolder.fail(bola);
            }
            BolaDeFuego fuego = new BolaDeFuego(nivel, jugador);
            fuego.setItem(bola);
            fuego.shootFromRotation(jugador, jugador.getXRot(), jugador.getYRot(), 0.0F, Fuego.FUERZA, 1.0F);
            nivel.addFreshEntity(fuego);
            nivel.playSound(null, jugador.getX(), jugador.getY(), jugador.getZ(), SoundEvents.BLAZE_SHOOT,
                    SoundSource.PLAYERS, 0.5F, 1.3F);
            Fuego.tiro(jugador);
        }
        jugador.getCooldowns().addCooldown(this, 10);
        if (!jugador.getAbilities().instabuild) {
            bola.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(bola, nivel.isClientSide());
    }
}
