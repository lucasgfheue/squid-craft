package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * El juego 4, "El puente de Londres" (el día 4 del ciclo: 4, 10, 16...). Se juega en una plaza de Londres de noche,
 * techada (puente.nbt, ver gen_puente.py): fachadas de ladrillo con ventanas alrededor, una plaza de piedra oscura en el
 * medio y, alrededor, una calle de adoquines en ronda, con faroles. Del lado este de la ronda, dos robots gigantes
 * ({@link Robot}), uno a cada lado de la calle, se dan las dos manos por encima: con los brazos en alto forman el
 * puente.
 *
 * <ol>
 *   <li>Todos van enganchados en fila por la calle, uno detrás del otro (los bots, con las manos en los hombros del de
 *       adelante). Suena la canción (la melodía tradicional del puente de Londres, con bloques musicales) y la fila
 *       camina alrededor, como las agujas del reloj, pasando por debajo del puente. Nadie se puede adelantar ni quedar
 *       atrás: la fila los lleva a todos al mismo paso (a los jugadores también) y cada uno conserva su lugar.</li>
 *   <li>Mientras suena, los robots mueven los brazos: los bajan un poco, o amagan con bajarlos, para dar suspenso.</li>
 *   <li>Cuando termina la canción (o en un momento sorpresa, en el medio) los robots bajan los brazos de golpe: el que
 *       está pasando por debajo queda atrapado entre los brazos y, después de un redoble, eliminado. Los de al lado
 *       salen de abajo de los brazos, y después la fila se vuelve a juntar.</li>
 * </ol>
 *
 * Son 5 rondas; los que siguen en la fila al final, pasan. Enganchados, no se puede empujar ni pegar. En cada ronda,
 * el paso de la fila cambia un poco (para que siempre haya alguien pasando por debajo cuando se caen los brazos): a
 * quién le toca, es suerte.
 */
public final class Puente {
    // ------------------------------------------------------------------ la arena (igual que gen_puente.py)
    public static final ResourceLocation ARENA = Complejo.id("puente");
    /** Esquina de la plantilla puente.nbt (63 x 18 x 72). */
    public static final BlockPos ORIGEN = new BlockPos(3969, 99, -17);
    static final int VERSION_ARENA = 2;                     // 2: plaza de Londres de noche
    /** Lo que ocupa la arena, para mantenerla cargada mientras se juega. */
    static final int X0 = 3969;
    static final int X1 = 4031;
    static final int Z0 = -17;
    static final int Z1 = 54;
    /** El podio del comandante, en la entrada, mirando al cuarto (al sur). */
    static final Vec3 PODIO = new Vec3(4000.5, 102.0, -13.5);
    /** Los cuatro sargentos, contra las paredes de los costados (lejos de la calle y de los faroles). */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(3973.5, 100.0, 20.5), new Vec3(4027.5, 100.0, 20.5),
            new Vec3(3973.5, 100.0, 40.5), new Vec3(4027.5, 100.0, 40.5),
    };
    static final float[] GIROS_SARGENTOS = {-90.0F, 90.0F, -90.0F, 90.0F};
    /** El centro de la ronda (el medio de la plaza, donde está el farol alto). */
    static final int CENTRO_X = 4000;
    static final int CENTRO_Z = 26;
    private static final double CX = CENTRO_X + 0.5;
    private static final double CZ = CENTRO_Z + 0.5;
    /** Donde se para la gente. */
    static final int PISO = 100;
    /** La calle: el medio está a esta distancia del centro; de 14 a 18 todavía es la calle. */
    static final double RADIO = 16.0;
    static final double CALLE_MIN = 14.0;
    static final double CALLE_MAX = 18.0;
    /** El puente, en el lado este de la ronda, y los robots, uno a cada lado de la calle, mirándose. */
    static final Vec3 PUENTE = new Vec3(CX + RADIO, PISO, CZ);
    static final Vec3 ROBOT_ADENTRO = new Vec3(CX + RADIO - Robot.AL_MEDIO, PISO, CZ);
    static final Vec3 ROBOT_AFUERA = new Vec3(CX + RADIO + Robot.AL_MEDIO, PISO, CZ);
    /** El rojo (adentro) mira al este y el azul (afuera), al oeste. */
    private static final float GIRO_ADENTRO = -90.0F;
    private static final float GIRO_AFUERA = 90.0F;
    /** Lo que queda encerrado entre los brazos bajados: a lo largo de la calle, a cada lado del medio del puente. */
    static final double JAULA = Robot.HOMBRO_X - 0.4;
    /** Y de ancho: de un lado y del otro del medio de la calle. */
    private static final double JAULA_ANCHO = 2.2;

    // ------------------------------------------------------------------ reglas
    static final int RONDAS = 5;
    /** En 1 de cada 3 rondas, los brazos bajan en un momento sorpresa (en el medio de la canción). */
    private static final int SORPRESA = 3;
    /**
     * Si cuando hay que bajar los brazos no pasa nadie por debajo, la canción sigue hasta que pase alguien; si en 4
     * segundos no pasó nadie, atrapan al que está por pasar (el primero de la fila antes del puente, si está a menos de
     * esto del medio). Casi nunca hace falta: la fila va al paso justo para que haya alguien.
     */
    private static final int ESPERA_ALGUIEN = 4 * 20;
    private static final double POR_PASAR = 4.5;
    /** El atrapado: con un redoble, a los 2 segundos y medio queda eliminado; al rato, los robots levantan los brazos. */
    private static final int ELIMINA_ATRAPADO = 50;
    private static final int LEVANTAN = 80;

    // ------------------------------------------------------------------ la fila enganchada
    /** El largo de la calle, por el medio (una vuelta a la ronda). */
    static final double VUELTA = 2.0 * Math.PI * RADIO;
    /**
     * Uno detrás del otro, a 1 bloque (las manos en los hombros del de adelante). Si son tantos que no entran en una
     * vuelta, más juntos: la fila da toda la vuelta.
     */
    static final double SEPARACION = 1.0;
    /**
     * El paso de la fila, en bloques por tick: cerca de 2,2 bloques por segundo. En cada ronda cambia un poco (de 1,6 a
     * 3,2) para que, cuando se caigan los brazos, uno de la fila (al azar) esté justo pasando por debajo del puente.
     */
    static final double PASO = 0.11;
    static final double PASO_MIN = 0.08;
    static final double PASO_MAX = 0.16;
    /** Las vueltas a la canción, si los brazos bajan cuando termina: de 2 a 6 (la primera ronda, 3 como mínimo). */
    static final int VUELTAS_MIN = 2;
    static final int VUELTAS_MAX = 6;
    /** Si es un momento sorpresa: después de la primera vuelta a la canción y antes de la quinta. */
    static final int SORPRESA_MAX = 5;
    /**
     * Los jugadores van enganchados: cada tick, la fila los lleva al paso y, además, hacia su lugar (un cuarto de lo que
     * les falta); como mucho, a esta velocidad (bloques por tick).
     */
    static final double TIRON = 0.25;
    private static final double TIRON_MAX = 0.35;
    /** Si alguien quedó lejos de su lugar (más de 4 bloques), vuelve de una. */
    private static final double LEJOS = 4.0;
    /** Cuando sale alguien de la fila, los de atrás se juntan de a poco (bloques por tick). */
    private static final double JUNTARSE = 0.05;
    /** Los de al lado del atrapado salen de abajo de los brazos: el primero, a esto del medio; los demás, en orden. */
    private static final double AFUERA = JAULA + 0.9;
    private static final double SIN_ENCIMARSE = 0.7;

    // ------------------------------------------------------------------ la canción
    /** Un paso (una corchea) cada 5 ticks: la negra a 120 por minuto. */
    private static final int PASO_MUSICA = 5;
    /**
     * "London Bridge Is Falling Down" (canción tradicional inglesa, de dominio público), con notas de bloque musical
     * (6 = do, 8 = re, 10 = mi, 11 = fa, 13 = sol, 15 = la; -1 = silencio): 4 compases de 8 corcheas, 8 segundos.
     */
    static final int[] MELODIA = {
            13, 15, 13, 11, 10, 11, 13, -1,     // Lon-don Bridge is fall-ing down,
            8, 10, 11, -1, 10, 11, 13, -1,      // fall-ing down, fall-ing down,
            13, 15, 13, 11, 10, 11, 13, -1,     // Lon-don Bridge is fall-ing down,
            8, -1, 13, -1, 10, 6, -1, -1,       // my fair la-dy.
    };
    /** El bajo de cada compás: la nota del tiempo 1 y la del tiempo 3 (do-sol, sol-do, do-sol, sol-do). */
    private static final int[][] BAJO = {{6, 13}, {13, 6}, {6, 13}, {13, 6}};
    /** Una vuelta a la canción, en ticks (8 segundos). */
    static final int CANCION = 32 * PASO_MUSICA;

    // ------------------------------------------------------------------ los brazos
    /** Cada cuánto los robots amagan (bajan un poco los brazos) mientras suena la canción, y cuánto. */
    private static final int AMAGUE_MIN = 30;
    private static final int AMAGUE_AZAR = 50;
    /** Grados por tick: normal, el amague grande (casi los bajan) y cuando los bajan de golpe. */
    private static final float VELOCIDAD = 2.0F;
    private static final float VELOCIDAD_AMAGUE = 6.0F;
    private static final float VELOCIDAD_GOLPE = 16.0F;

    private enum Estado { NINGUNO, EMPEZANDO, MUSICA, BAJAN, PAUSA, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int ronda;
    /** Cuándo bajan los brazos (en ticks de la canción), y desde cuándo esperan que pase alguien. */
    private static int duracion;
    private static int esperando;
    /** Los que siguen en la fila (jugadores y bots). */
    private static final List<UUID> GENTE = new ArrayList<>();
    private static final Set<UUID> EN_FILA = new HashSet<>();
    private static final Map<UUID, JugadorBot> BOTS = new HashMap<>();
    private static final Set<UUID> PASARON = new HashSet<>();
    /**
     * La fila: dónde va la cabeza (en bloques a lo largo de la calle, desde el medio del puente, para donde se camina),
     * a qué paso va en esta ronda y a qué distancia de la cabeza va cada uno (se acomoda de a poco).
     */
    private static double fase;
    private static double paso = PASO;
    private static final Map<UUID, Double> ATRAS = new HashMap<>();
    /** Los robots: el rojo (adentro de la ronda) y el azul (afuera). */
    @Nullable
    private static UUID robotRojo;
    @Nullable
    private static UUID robotAzul;
    /** Los brazos (los dos robots igual): dónde están, adónde van y a qué velocidad; y cuándo es el próximo amague. */
    private static float brazos = Robot.ARRIBA;
    private static float objetivoBrazos = Robot.ARRIBA;
    private static float velocidadBrazos = VELOCIDAD;
    private static int amague;
    private static int vuelveEn;
    /** El que quedó atrapado debajo del puente en esta ronda. */
    @Nullable
    private static UUID atrapado;

    private Puente() {
    }

    // ------------------------------------------------------------------ consultas (las usan los bots y Juego)
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean suenaMusica() {
        return estado == Estado.MUSICA;
    }

    static int pasaron() {
        return PASARON.size();
    }

    /** Sigue en la fila (todavía no terminó el juego y no quedó eliminado). */
    static boolean participa(LivingEntity quien) {
        return EN_FILA.contains(quien.getUUID()) && estado != Estado.NINGUNO && estado != Estado.TERMINADO;
    }

    /** Es el que quedó atrapado debajo del puente en esta ronda. */
    static boolean encerrado(LivingEntity quien) {
        return atrapado != null && atrapado.equals(quien.getUUID()) && estado == Estado.BAJAN;
    }

    /** Pasó las 5 rondas. */
    static boolean paso(LivingEntity quien) {
        return PASARON.contains(quien.getUUID());
    }

    /** Se cayó el puente: la fila está quieta (nadie se mueve hasta que levanten los brazos). */
    static boolean filaQuieta() {
        return estado == Estado.BAJAN;
    }

    /** Cuánto le falta para llegar al medio del puente, caminando por la calle (en bloques; negativo si ya pasó). */
    static double antesDelPuente(Entity quien) {
        return -Math.atan2(quien.getZ() - CZ, quien.getX() - CX) * RADIO;   // el puente está en el ángulo 0
    }

    // ------------------------------------------------------------------ la arena
    /**
     * Construye la arena la primera vez (y saca la plataforma provisoria que había antes para el juego 4). Si había una
     * versión anterior (el cuarto de juguetes), la vacía por dentro antes de poner la nueva.
     */
    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionPuente() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        BlockState aire = Blocks.AIR.defaultBlockState();
        Iterable<BlockPos> vaciar = estadoComplejo.versionPuente() > 0
                ? BlockPos.betweenClosed(X0 + 1, PISO, Z0 + 2, X1 - 1, PISO + 15, Z1 - 1)    // el cuarto viejo, por dentro
                : BlockPos.betweenClosed(3986, 99, -14, 4014, 105, 14);                     // Portales.prepararJuego
        for (BlockPos pos : vaciar) {
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionPuente(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de El puente de Londres colocada en {}", ORIGEN);
        return true;
    }

    /** Dónde aparece quien llega al juego 4: la entrada de la plaza (delante del podio). */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(3985.5 + azar.nextInt(31), PISO, -10.5 + azar.nextInt(13));
    }

    // ------------------------------------------------------------------ empieza el juego
    /** Los robots en su lugar, con los brazos arriba, y todos en fila en la calle (repartidos parejo). */
    static void empezar(ServerLevel complejo, List<LivingEntity> participantes) {
        olvidar();
        sacarRobots(complejo);
        ponerRobots(complejo);
        RandomSource azar = complejo.getRandom();
        List<LivingEntity> todos = new ArrayList<>(participantes);
        for (int i = todos.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            LivingEntity cambio = todos.get(i);
            todos.set(i, todos.get(j));
            todos.set(j, cambio);
        }
        for (LivingEntity quien : todos) {
            GENTE.add(quien.getUUID());
            EN_FILA.add(quien.getUUID());
            if (quien instanceof JugadorBot bot) {
                BOTS.put(bot.getUUID(), bot);
            }
        }
        ronda = 1;
        if (GENTE.size() <= 1) {
            terminarJuego(complejo);                                   // uno solo (o nadie): pasa directo
            return;
        }
        ponerEnFila(complejo, todos);
        anunciarRonda(complejo);
        cambiar(Estado.EMPEZANDO);
    }

    /** Todos en fila en la calle, uno detrás del otro: la cabeza, justo antes del puente, y los demás, atrás. */
    private static void ponerEnFila(ServerLevel complejo, List<LivingEntity> todos) {
        fase = -(JAULA + 0.6);
        ATRAS.clear();
        double separacion = separacion();
        for (int i = 0; i < todos.size(); i++) {
            LivingEntity quien = todos.get(i);
            ATRAS.put(quien.getUUID(), i * separacion);
            double angulo = (fase - i * separacion) / RADIO;
            Vec3 lugar = enLaCalle(angulo, RADIO);
            float giro = (float) Math.toDegrees(angulo);                  // mirando para donde se camina
            if (quien instanceof ServerPlayer jugador) {
                jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
            } else if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                bot.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            }
        }
    }

    private static void ponerRobots(ServerLevel complejo) {
        Robot rojo = Robot.poner(complejo, ROBOT_ADENTRO, GIRO_ADENTRO, Robot.ROJO);
        Robot azul = Robot.poner(complejo, ROBOT_AFUERA, GIRO_AFUERA, Robot.AZUL);
        robotRojo = rojo == null ? null : rojo.getUUID();
        robotAzul = azul == null ? null : azul.getUUID();
        brazos = Robot.ARRIBA;
        objetivoBrazos = Robot.ARRIBA;
    }

    /** Saca los robots que haya en el cuarto (de este juego o de uno anterior que se cortó). */
    private static void sacarRobots(ServerLevel complejo) {
        AABB cuarto = new AABB(X0, PISO - 1, Z0, X1 + 1, PISO + 17, Z1 + 1);
        for (Robot robot : complejo.getEntitiesOfClass(Robot.class, cuarto)) {
            robot.discard();
        }
        robotRojo = null;
        robotAzul = null;
    }

    @Nullable
    private static Robot robot(ServerLevel complejo, int color) {
        UUID id = color == Robot.AZUL ? robotAzul : robotRojo;
        return id != null && complejo.getEntity(id) instanceof Robot robot && robot.isAlive() ? robot : null;
    }

    /** El comandante dice qué ronda es y cuántos quedan; en la pantalla, lo mismo. */
    private static void anunciarRonda(ServerLevel complejo) {
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.puente_ronda_inicio", ronda, RONDAS, GENTE.size()));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.ronda_puente", ronda, RONDAS)
                            .withStyle(ChatFormatting.GOLD),
                    Component.translatable("titulo.juegosdelpatio.ronda_puente_detalle", GENTE.size())
                            .withStyle(ChatFormatting.GRAY), 5, 45, 10);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 1.2F);
        }
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    /** Avanza el juego. true cuando ya terminaron las 5 rondas. */
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        revisarFila(complejo);
        switch (estado) {
            case EMPEZANDO -> {
                if (tiempo >= 60) {
                    empezarMusica(complejo);
                }
            }
            case MUSICA -> {
                fase += paso;                                           // la fila avanza
                musica(complejo);
                amagues(complejo);
                if (tiempo >= duracion) {
                    intentarBajar(complejo);
                }
            }
            case BAJAN -> encerrar(complejo);
            case PAUSA -> {
                if (tiempo >= 60) {
                    empezarMusica(complejo);
                }
            }
            default -> {
            }
        }
        if (estado != Estado.BAJAN && estado != Estado.TERMINADO) {
            acomodar();
            llevarJugadores(complejo);
        }
        moverBrazos(complejo);
        if (tiempo % 10 == 1 || estado == Estado.TERMINADO) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    /** Si alguien de la fila se fue (se desconectó, murió de otra cosa), sale de la fila. */
    private static void revisarFila(ServerLevel complejo) {
        if (tiempo % 20 != 0 || estado == Estado.TERMINADO) {
            return;
        }
        for (UUID id : List.copyOf(GENTE)) {
            LivingEntity quien = buscar(complejo, id);
            if (quien == null || !Juego.estaEnArena(quien) || Juego.eliminado(quien)) {
                GENTE.remove(id);
                EN_FILA.remove(id);
                ATRAS.remove(id);
            }
        }
    }

    private static void empezarMusica(ServerLevel complejo) {
        RandomSource azar = complejo.getRandom();
        planear(azar);
        esperando = 0;
        amague = AMAGUE_MIN + azar.nextInt(AMAGUE_AZAR);
        cambiar(Estado.MUSICA);
        cantar(complejo, true);
        objetivoBrazos = Robot.ARRIBA;
        velocidadBrazos = VELOCIDAD;
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (participa(jugador)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.camina_fila")
                        .withStyle(ChatFormatting.AQUA), true);
            }
        }
    }

    /** Una nota por paso: la melodía, el bajo y la batería, para todos los que están en el cuarto. */
    private static void musica(ServerLevel complejo) {
        if ((tiempo - 1) % PASO_MUSICA != 0) {
            return;
        }
        int paso = (tiempo - 1) / PASO_MUSICA;
        int nota = MELODIA[paso % MELODIA.length];
        int enCompas = paso % 8;
        int[] bajo = BAJO[(paso / 8) % BAJO.length];
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (nota >= 0) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_BELL.value(), 0.55F, nota);
                sonar(jugador, SoundEvents.NOTE_BLOCK_HARP.value(), 0.8F, nota);
            }
            if (enCompas == 0 || enCompas == 4) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_BASS.value(), 0.8F, bajo[enCompas / 4]);
                sonar(jugador, enCompas == 0 ? SoundEvents.NOTE_BLOCK_BASEDRUM.value() : SoundEvents.NOTE_BLOCK_SNARE.value(),
                        0.35F, 12);
            }
        }
        if (nota >= 0 && paso % 2 == 0) {                               // las notas salen de las cabezas de los robots
            for (Vec3 robot : List.of(ROBOT_ADENTRO, ROBOT_AFUERA)) {
                complejo.sendParticles(ParticleTypes.NOTE, robot.x, robot.y + 9.6, robot.z, 0, nota / 24.0, 0.0, 0.0, 1.0);
            }
        }
    }

    private static void sonar(ServerPlayer jugador, SoundEvent sonido, float volumen, int nota) {
        jugador.playNotifySound(sonido, SoundSource.RECORDS, volumen, (float) Math.pow(2.0, (nota - 12) / 12.0));
    }

    /**
     * Cuánto dura la canción en esta ronda y a qué paso va la fila. Se elige al azar uno de la fila y se busca el paso
     * (cerca de 2,2 bloques por segundo) para que, cuando bajen los brazos, esté justo pasando por debajo del puente:
     * así siempre hay alguien, y le puede tocar a cualquiera. En 2 de cada 3 rondas, los brazos bajan cuando termina la
     * canción (después de 2 a 6 vueltas, las menos que se pueda); en la otra, en un momento sorpresa.
     */
    private static void planear(RandomSource azar) {
        paso = PASO;
        duracion = CANCION * (ronda == 1 ? 3 : 2);                     // por si acaso (no debería hacer falta)
        if (GENTE.isEmpty()) {
            return;
        }
        int elegido = azar.nextInt(GENTE.size());
        double falta = ((elegido * separacion() - fase) % VUELTA + VUELTA) % VUELTA;   // lo que le falta para el medio
        if (azar.nextInt(SORPRESA) != 0) {
            double mejor = Double.MAX_VALUE;
            for (int vueltas = ronda == 1 ? VUELTAS_MIN + 1 : VUELTAS_MIN; vueltas <= VUELTAS_MAX; vueltas++) {
                for (int extra = 0; extra <= 2; extra++) {
                    double p = (falta + extra * VUELTA) / (vueltas * CANCION);
                    double puntaje = Math.abs(p / PASO - 1.0) + 0.04 * vueltas;
                    if (p >= PASO_MIN && p <= PASO_MAX && puntaje < mejor) {
                        mejor = puntaje;
                        paso = p;
                        duracion = vueltas * CANCION;
                    }
                }
            }
            return;
        }
        for (int extra = 0; extra <= 2; extra++) {                      // sorpresa: en cualquier momento
            double lejos = falta + extra * VUELTA;
            int desde = (int) Math.ceil(Math.max(CANCION, lejos / PASO_MAX));
            int hasta = (int) Math.floor(Math.min(SORPRESA_MAX * CANCION, lejos / PASO_MIN));
            if (desde <= hasta) {
                duracion = desde + azar.nextInt(hasta - desde + 1);
                paso = lejos / duracion;
                return;
            }
        }
    }

    /** La separación de la fila: 1 bloque; si no entran todos en una vuelta, menos (la fila da toda la vuelta). */
    private static double separacion() {
        return Math.min(SEPARACION, VUELTA / Math.max(1, GENTE.size()));
    }

    /** Dónde le toca estar a alguien de la fila (null si no está en la fila). */
    @Nullable
    static Vec3 lugarEnLaFila(LivingEntity quien) {
        Double atras = ATRAS.get(quien.getUUID());
        if (atras == null || !EN_FILA.contains(quien.getUUID())) {
            return null;
        }
        return enLaCalle((fase - atras) / RADIO, RADIO);
    }

    /** Cuando sale alguien de la fila, los de atrás se juntan de a poco (y si la fila da toda la vuelta, se abre). */
    private static void acomodar() {
        double separacion = separacion();
        for (int i = 0; i < GENTE.size(); i++) {
            UUID id = GENTE.get(i);
            double meta = i * separacion;
            double ahora = ATRAS.getOrDefault(id, meta);
            ATRAS.put(id, ahora + Math.max(-JUNTARSE, Math.min(JUNTARSE, meta - ahora)));
        }
    }

    /**
     * Los jugadores de la fila van enganchados: cada tick, la fila los lleva (al paso de la fila y hacia su lugar). Así
     * nadie se adelanta ni se queda atrás. Si alguien quedó lejos de su lugar, vuelve de una.
     */
    private static void llevarJugadores(ServerLevel complejo) {
        double avance = estado == Estado.MUSICA ? paso : 0.0;
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!participa(jugador) || !jugador.isAlive() || jugador.isSpectator() || jugador.isCreative()) {
                continue;
            }
            Vec3 lugar = lugarEnLaFila(jugador);
            if (lugar == null) {
                continue;
            }
            double dx = lugar.x - jugador.getX();
            double dz = lugar.z - jugador.getZ();
            double angulo = Math.atan2(lugar.z - CZ, lugar.x - CX);
            if (dx * dx + dz * dz > LEJOS * LEJOS) {
                jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, (float) Math.toDegrees(angulo), jugador.getXRot());
                continue;
            }
            double vx = -Math.sin(angulo) * avance + dx * TIRON;            // al paso de la fila, para adelante...
            double vz = Math.cos(angulo) * avance + dz * TIRON;             // ...y hacia su lugar
            double rapidez = Math.sqrt(vx * vx + vz * vz);
            if (rapidez > TIRON_MAX) {
                vx *= TIRON_MAX / rapidez;
                vz *= TIRON_MAX / rapidez;
            }
            jugador.setDeltaMovement(vx, -0.08, vz);
            jugador.hurtMarked = true;                                  // que le llegue ya
        }
    }

    /**
     * Lleva a un bot de la fila a su lugar, mirando para adelante: camina con la fila (si quedó un poco lejos, va un
     * poco más rápido hasta llegar; si quedó muy lejos, vuelve de una).
     */
    static void llevar(JugadorBot bot) {
        Vec3 lugar = lugarEnLaFila(bot);
        if (lugar == null) {
            return;
        }
        float giro = (float) Math.toDegrees(Math.atan2(lugar.z - CZ, lugar.x - CX));
        double dx = lugar.x - bot.getX();
        double dz = lugar.z - bot.getZ();
        double distancia = Math.sqrt(dx * dx + dz * dz);
        if (distancia > LEJOS) {
            bot.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
        } else {
            double maximo = (estado == Estado.MUSICA ? paso : 0.0) + 0.12;
            if (distancia > maximo) {
                dx *= maximo / distancia;
                dz *= maximo / distancia;
            }
            bot.setPos(bot.getX() + dx, lugar.y, bot.getZ() + dz);
            bot.setYRot(giro);
        }
        bot.setYBodyRot(giro);
        bot.setYHeadRot(giro);
        bot.setDeltaMovement(Vec3.ZERO);
    }

    // ------------------------------------------------------------------ los brazos
    /**
     * Mientras suena la canción, cada tanto los robots amagan: bajan un poco los brazos y los vuelven a subir. A veces
     * el amague es grande (los bajan casi del todo, rápido), para asustar.
     */
    private static void amagues(ServerLevel complejo) {
        if (vuelveEn > 0 && --vuelveEn == 0) {
            objetivoBrazos = Robot.ARRIBA;                              // vuelven a subir
            velocidadBrazos = VELOCIDAD;
        }
        if (--amague > 0) {
            return;
        }
        RandomSource azar = complejo.getRandom();
        amague = AMAGUE_MIN + azar.nextInt(AMAGUE_AZAR);
        if (azar.nextInt(4) == 0) {
            objetivoBrazos = -12.0F + azar.nextFloat() * 8.0F;          // ¡casi los bajan! (las manos, a unos 6 bloques)
            velocidadBrazos = VELOCIDAD_AMAGUE;
            vuelveEn = 6 + azar.nextInt(6);
            ruidoBrazos(complejo, 0.7F, 1.4F);
        } else {
            objetivoBrazos = Robot.ARRIBA - 5.0F - azar.nextFloat() * 9.0F;
            velocidadBrazos = 1.5F;
            vuelveEn = 10 + azar.nextInt(12);
        }
    }

    /** Los brazos van hacia donde tienen que ir, de a poco; los dos robots igual (se están dando la mano). */
    private static void moverBrazos(ServerLevel complejo) {
        if (brazos != objetivoBrazos) {
            float paso = Math.min(velocidadBrazos, Math.abs(objetivoBrazos - brazos));
            brazos += objetivoBrazos > brazos ? paso : -paso;
        }
        for (int color = Robot.ROJO; color <= Robot.AZUL; color++) {
            Robot robot = robot(complejo, color);
            if (robot != null) {
                robot.ponerBrazos(brazos);
            }
        }
    }

    private static void cantar(ServerLevel complejo, boolean canta) {
        for (int color = Robot.ROJO; color <= Robot.AZUL; color++) {
            Robot robot = robot(complejo, color);
            if (robot != null) {
                robot.cantar(canta);
            }
        }
    }

    private static void ruidoBrazos(ServerLevel complejo, float volumen, float tono) {
        complejo.playSound(null, PUENTE.x, PUENTE.y + 6.0, PUENTE.z, SoundEvents.PISTON_EXTEND, SoundSource.HOSTILE,
                volumen, tono);
    }

    // ------------------------------------------------------------------ se cae el puente
    /**
     * Se terminó la canción (o es el momento sorpresa): si alguien está pasando por debajo del puente, los brazos bajan
     * de golpe. Si no pasa nadie, la canción sigue hasta que pase alguien; si tarda (4 segundos), atrapan al que está
     * por pasar.
     */
    private static void intentarBajar(ServerLevel complejo) {
        LivingEntity debajo = debajoDelPuente(complejo);
        if (debajo == null && ++esperando < ESPERA_ALGUIEN) {
            return;
        }
        if (debajo == null) {
            debajo = porPasar(complejo);
        }
        if (debajo == null) {
            esperando = 0;                                              // no hay nadie cerca: un poco más de canción
            return;
        }
        bajar(complejo, debajo);
    }

    /** El que está pasando por debajo del puente (el más cerca del medio), o null. */
    @Nullable
    private static LivingEntity debajoDelPuente(ServerLevel complejo) {
        LivingEntity mejor = null;
        double menor = JAULA;
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien == null) {
                continue;
            }
            double dz = Math.abs(quien.getZ() - PUENTE.z);
            if (Math.abs(quien.getX() - PUENTE.x) <= JAULA_ANCHO && dz <= menor) {
                menor = dz;
                mejor = quien;
            }
        }
        return mejor;
    }

    /** El primero de la fila que todavía no pasó por debajo del puente, si está cerca (a menos de POR_PASAR del medio). */
    @Nullable
    private static LivingEntity porPasar(ServerLevel complejo) {
        LivingEntity mejor = null;
        double menor = POR_PASAR;
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien == null || !estaEnLaCalle(quien)) {
                continue;
            }
            double falta = antesDelPuente(quien);
            if (falta > 0.0 && falta <= menor) {
                menor = falta;
                mejor = quien;
            }
        }
        return mejor;
    }

    /**
     * Los brazos bajan de golpe: el que pasaba queda atrapado; los que estaban al lado salen de abajo de los brazos
     * (para adelante o para atrás, en orden, sin encimarse). La fila se para.
     */
    private static void bajar(ServerLevel complejo, LivingEntity quien) {
        atrapado = quien.getUUID();
        cambiar(Estado.BAJAN);
        cantar(complejo, false);
        objetivoBrazos = Robot.ABAJO;
        velocidadBrazos = VELOCIDAD_GOLPE;
        vuelveEn = 0;
        moverA(complejo, quien, PUENTE.x, PUENTE.z);
        List<LivingEntity> pasaron = new ArrayList<>();
        List<LivingEntity> llegaban = new ArrayList<>();
        for (UUID id : GENTE) {
            LivingEntity otro = buscar(complejo, id);
            if (otro == null || otro == quien || !estaEnLaCalle(otro) || Math.abs(antesDelPuente(otro)) > 8.0) {
                continue;
            }
            (antesDelPuente(otro) < 0.0 ? pasaron : llegaban).add(otro);
        }
        salirDeAbajo(complejo, pasaron, 1.0);
        salirDeAbajo(complejo, llegaban, -1.0);
        ruidoBrazos(complejo, 1.2F, 0.6F);
        complejo.playSound(null, PUENTE.x, PUENTE.y + 1.0, PUENTE.z, SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 1.0F, 0.6F);
        Component nombre = nombreDe(quien);
        Juego.decir(complejo, Component.translatable("mensaje.juegosdelpatio.atrapado", nombre));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            boolean esEl = jugador == quien;
            Juego.titulo(jugador, Component.translatable(esEl ? "titulo.juegosdelpatio.te_atrapo" : "titulo.juegosdelpatio.cayo_puente")
                            .withStyle(ChatFormatting.RED),
                    (esEl ? Component.translatable("titulo.juegosdelpatio.te_atrapo_detalle")
                            : Component.translatable("titulo.juegosdelpatio.cayo_puente_detalle", nombre)).withStyle(ChatFormatting.GRAY),
                    0, 50, 10);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), SoundSource.RECORDS, 1.0F, 0.5F);
        }
        if (quien instanceof JugadorBot bot) {
            bot.mostrarEmote(Emote.TRISTE);
        }
    }

    /**
     * Los de un lado del puente (signo 1: los que ya pasaron; -1: los que llegaban), del más cerca al más lejos: el
     * primero sale de abajo de los brazos y cada uno queda por lo menos a SIN_ENCIMARSE del anterior.
     */
    private static void salirDeAbajo(ServerLevel complejo, List<LivingEntity> lado, double signo) {
        lado.sort(Comparator.comparingDouble(otro -> Math.abs(antesDelPuente(otro))));
        double minimo = AFUERA;
        for (LivingEntity otro : lado) {
            if (Math.abs(antesDelPuente(otro)) >= minimo) {
                break;                                                  // ya está afuera (y los de más allá también)
            }
            Vec3 lugar = enLaCalle(signo * minimo / RADIO, RADIO);
            moverA(complejo, otro, lugar.x, lugar.z);
            minimo += SIN_ENCIMARSE;
        }
    }

    private static void moverA(ServerLevel complejo, LivingEntity quien, double x, double z) {
        if (quien instanceof ServerPlayer jugador) {
            jugador.teleportTo(complejo, x, PISO, z, jugador.getYRot(), jugador.getXRot());
        } else if (quien instanceof JugadorBot bot) {
            bot.getNavigation().stop();
            bot.dejarDeCorrer();
            bot.moveTo(x, PISO, z, bot.getYRot(), 0.0F);
        }
    }

    /** El encerrado no se puede ir: si se corre del medio, vuelve. */
    private static void sujetar(ServerLevel complejo) {
        LivingEntity quien = atrapado == null ? null : buscar(complejo, atrapado);
        if (quien != null && quien.distanceToSqr(PUENTE.x, quien.getY(), PUENTE.z) > 0.8 * 0.8) {
            moverA(complejo, quien, PUENTE.x, PUENTE.z);
        }
    }

    // ------------------------------------------------------------------ el atrapado
    /**
     * El atrapado: los robots lo tienen encerrado y suena un redoble; a los 2 segundos y medio queda eliminado. Después
     * los robots levantan los brazos y sigue la ronda siguiente.
     */
    private static void encerrar(ServerLevel complejo) {
        sujetar(complejo);
        if (tiempo >= 10 && tiempo < ELIMINA_ATRAPADO && tiempo % 2 == 0) {
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                jugador.playNotifySound(SoundEvents.NOTE_BLOCK_SNARE.value(), SoundSource.RECORDS, 0.6F, 1.0F);
            }
        }
        if (tiempo == ELIMINA_ATRAPADO) {
            LivingEntity quien = atrapado == null ? null : buscar(complejo, atrapado);
            if (quien != null) {
                eliminar(complejo, quien, "atrapado_puente");
            }
        }
        if (tiempo >= LEVANTAN) {
            levantar(complejo);
        }
    }

    /** Los robots levantan los brazos (otra vez el puente) y, después de una pausa, la ronda siguiente. */
    private static void levantar(ServerLevel complejo) {
        atrapado = null;
        objetivoBrazos = Robot.ARRIBA;
        velocidadBrazos = VELOCIDAD + 1.0F;
        ruidoBrazos(complejo, 0.8F, 0.9F);
        if (ronda >= RONDAS || GENTE.size() <= 1) {
            terminarJuego(complejo);
            return;
        }
        ronda++;
        anunciarRonda(complejo);
        cambiar(Estado.PAUSA);
    }

    private static void eliminar(ServerLevel complejo, LivingEntity quien, String motivo) {
        GENTE.remove(quien.getUUID());
        EN_FILA.remove(quien.getUUID());
        ATRAS.remove(quien.getUUID());
        Juego.eliminar(complejo, quien, false, motivo);
    }

    private static void terminarJuego(ServerLevel complejo) {
        cantar(complejo, false);
        objetivoBrazos = Robot.ARRIBA;
        PASARON.addAll(GENTE);
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien instanceof ServerPlayer jugador) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.pasaste").withStyle(ChatFormatting.GREEN),
                        Component.translatable("titulo.juegosdelpatio.pasaste_puente").withStyle(ChatFormatting.GRAY),
                        5, 50, 15);
                jugador.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
            } else if (quien instanceof JugadorBot bot) {
                bot.mostrarEmote(Emote.FELIZ);
            }
        }
        cambiar(Estado.TERMINADO);
    }

    // ------------------------------------------------------------------ la barra de arriba
    private static void barra(ServerLevel complejo) {
        Component nombre;
        BossEvent.BossBarColor color;
        float progreso = 1.0F;
        switch (estado) {
            case MUSICA -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_musica", ronda, RONDAS, GENTE.size());
                color = BossEvent.BossBarColor.BLUE;
            }
            case BAJAN -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_atrapado", ronda, RONDAS, GENTE.size());
                color = BossEvent.BossBarColor.RED;
                progreso = Math.max(0.0F, 1.0F - tiempo / (float) ELIMINA_ATRAPADO);   // se le acaba el tiempo
            }
            case TERMINADO -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_fin", PASARON.size());
                color = BossEvent.BossBarColor.GREEN;
            }
            default -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_ronda", ronda, RONDAS, GENTE.size());
                color = BossEvent.BossBarColor.WHITE;
            }
        }
        Juego.barraJuego(complejo, nombre, color, progreso);
    }

    // ------------------------------------------------------------------ los bots (los guía JugadorBot.PuenteGoal)
    /** Hacia dónde mira la gente cuando la fila está parada: al atrapado (o al puente). */
    static Vec3 aDondeMirar() {
        return PUENTE.add(0.0, 1.5, 0.0);
    }

    // ------------------------------------------------------------------ fin
    /** Al terminar (o cortarse) el juego: se sacan los robots y se olvida todo. */
    static void limpiar(ServerLevel complejo) {
        sacarRobots(complejo);
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ronda = 0;
        duracion = 0;
        esperando = 0;
        GENTE.clear();
        EN_FILA.clear();
        BOTS.clear();
        PASARON.clear();
        ATRAS.clear();
        fase = 0.0;
        paso = PASO;
        atrapado = null;
        brazos = Robot.ARRIBA;
        objetivoBrazos = Robot.ARRIBA;
        velocidadBrazos = VELOCIDAD;
        amague = 0;
        vuelveEn = 0;
    }

    // ------------------------------------------------------------------ ayudas
    private static void cambiar(Estado nuevo) {
        estado = nuevo;
        tiempo = 0;
    }

    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID id) {
        ServerPlayer jugador = complejo.getServer().getPlayerList().getPlayer(id);
        if (jugador != null) {
            return jugador.level() == complejo && jugador.isAlive() ? jugador : null;
        }
        JugadorBot bot = BOTS.get(id);
        return bot != null && bot.isAlive() && !bot.isRemoved() ? bot : null;
    }

    private static Component nombreDe(LivingEntity quien) {
        return quien instanceof JugadorBot bot ? Component.literal(bot.nombre()) : quien.getName();
    }

    private static boolean estaEnLaCalle(Entity quien) {
        double dx = quien.getX() - CX;
        double dz = quien.getZ() - CZ;
        double radio = Math.sqrt(dx * dx + dz * dz);
        return radio >= CALLE_MIN && radio <= CALLE_MAX;
    }

    private static Vec3 enLaCalle(double angulo, double radio) {
        return new Vec3(CX + radio * Math.cos(angulo), PISO, CZ + radio * Math.sin(angulo));
    }
}
