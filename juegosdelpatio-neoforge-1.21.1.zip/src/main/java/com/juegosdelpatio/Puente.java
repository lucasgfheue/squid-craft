package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * El juego 4, "El puente de Londres" (el día 4 del ciclo: 4, 10, 16...). Se juega en una plaza de Londres de noche,
 * techada (puente.nbt, ver gen_puente.py): fachadas de ladrillo con ventanas alrededor, una plaza de piedra oscura en el
 * medio y, alrededor, una calle de adoquines en ronda, con faroles. Del lado este de la ronda, dos robots gigantes
 * ({@link Robot}), uno a cada lado de la calle, se dan las dos manos por encima: con los brazos en alto forman el
 * puente.
 *
 * <ol>
 *   <li>Todos se ponen en fila en la calle. Suena la canción (la melodía tradicional del puente de Londres, con bloques
 *       musicales) y la fila camina alrededor, como las agujas del reloj, pasando por debajo del puente. Se puede ir más
 *       despacio (agachado), pero el que se para (o se sale de la calle) queda eliminado, como en las sillas
 *       musicales.</li>
 *   <li>Mientras suena, los robots mueven los brazos: los bajan un poco, o amagan con bajarlos, para dar suspenso.</li>
 *   <li>Cuando termina la canción (o en un momento sorpresa, en el medio) los robots bajan los brazos de golpe: el que
 *       está pasando por debajo queda atrapado entre los brazos y, después de un redoble, eliminado. Si no pasa nadie,
 *       la canción sigue un poco, hasta que pase alguien (y si nadie se anima, atrapan al que estaba por pasar).</li>
 *   <li>Se vale empujar: al de adelante, para que pase él por debajo del puente (y que le toque a él). Al empujado, por
 *       un momento, no se lo puede frenar; si queda atrapado, se dice quién lo empujó. Los bots también juegan así:
 *       algunos van despacio cuando la canción está por terminar y, si tienen al de adelante por meterse debajo del
 *       puente, lo empujan.</li>
 * </ol>
 *
 * Son 5 rondas; los que siguen en la fila al final, pasan. Como en todos los juegos, no se puede pegar.
 */
public final class Puente {
    // ------------------------------------------------------------------ la arena (igual que gen_puente.py)
    public static final ResourceLocation ARENA = Complejo.id("puente");
    /** Esquina de la plantilla puente.nbt (63 x 18 x 72). */
    public static final BlockPos ORIGEN = new BlockPos(3969, 99, -17);
    static final int VERSION_ARENA = 2;                     // 2: plaza de Londres de noche
    /** Lo que ocupa la arena, para mantenerla cargada mientras se juega. */
    static final int X0 = 3969;
    static final int X1 = 4031;
    static final int Z0 = -17;
    static final int Z1 = 54;
    /** El podio del comandante, en la entrada, mirando al cuarto (al sur). */
    static final Vec3 PODIO = new Vec3(4000.5, 102.0, -13.5);
    /** Los cuatro sargentos, contra las paredes de los costados (lejos de la calle y de los faroles). */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(3973.5, 100.0, 20.5), new Vec3(4027.5, 100.0, 20.5),
            new Vec3(3973.5, 100.0, 40.5), new Vec3(4027.5, 100.0, 40.5),
    };
    static final float[] GIROS_SARGENTOS = {-90.0F, 90.0F, -90.0F, 90.0F};
    /** El centro de la ronda (el medio de la plaza, donde está el farol alto). */
    static final int CENTRO_X = 4000;
    static final int CENTRO_Z = 26;
    private static final double CX = CENTRO_X + 0.5;
    private static final double CZ = CENTRO_Z + 0.5;
    /** Donde se para la gente. */
    static final int PISO = 100;
    /** La calle: el medio está a esta distancia del centro; de 14 a 18 todavía es la calle. */
    static final double RADIO = 16.0;
    static final double CALLE_MIN = 14.0;
    static final double CALLE_MAX = 18.0;
    /** El puente, en el lado este de la ronda, y los robots, uno a cada lado de la calle, mirándose. */
    static final Vec3 PUENTE = new Vec3(CX + RADIO, PISO, CZ);
    static final Vec3 ROBOT_ADENTRO = new Vec3(CX + RADIO - Robot.AL_MEDIO, PISO, CZ);
    static final Vec3 ROBOT_AFUERA = new Vec3(CX + RADIO + Robot.AL_MEDIO, PISO, CZ);
    /** El rojo (adentro) mira al este y el azul (afuera), al oeste. */
    private static final float GIRO_ADENTRO = -90.0F;
    private static final float GIRO_AFUERA = 90.0F;
    /** Lo que queda encerrado entre los brazos bajados: a lo largo de la calle, a cada lado del medio del puente. */
    static final double JAULA = Robot.HOMBRO_X - 0.4;
    /** Y de ancho: de un lado y del otro del medio de la calle. */
    private static final double JAULA_ANCHO = 2.2;

    // ------------------------------------------------------------------ reglas
    static final int RONDAS = 5;
    /**
     * Mientras suena la canción, cada segundo hay que avanzar por lo menos esto por la calle (en bloques). Se puede ir
     * despacio (agachado se avanza más de 1 por segundo): lo que no se puede es pararse.
     */
    private static final double AVANCE_MINIMO = 0.5;
    /** Segundos seguidos sin caminar: a los 2 se te avisa; a los 5 quedas eliminado. */
    private static final int AVISO_QUIETO = 2;
    private static final int ELIMINA_QUIETO = 5;
    /** En 1 de cada 3 rondas, los brazos bajan en un momento sorpresa (en el medio de la canción). */
    private static final int SORPRESA = 3;
    /**
     * Si cuando hay que bajar los brazos no pasa nadie por debajo, la canción sigue hasta que pase alguien; si en 4
     * segundos no pasó nadie, atrapan al que está por pasar (el primero de la fila antes del puente, si está a menos de
     * esto del medio).
     */
    private static final int ESPERA_ALGUIEN = 4 * 20;
    private static final double POR_PASAR = 4.5;
    /** El atrapado: con un redoble, a los 2 segundos y medio queda eliminado; al rato, los robots levantan los brazos. */
    private static final int ELIMINA_ATRAPADO = 50;
    private static final int LEVANTAN = 80;
    /** Si al atrapado lo empujaron hace poco (3 segundos), se dice quién fue. */
    private static final int EMPUJON_RECIENTE = 3 * 20;
    /** Al que empujan, por un momento (ticks) no se frena: sale para adelante de verdad (igual el bot que el jugador). */
    static final int TRASTABILLA = 12;

    // ------------------------------------------------------------------ los bots
    /** El final de cada vuelta a la canción (los últimos 2 segundos y medio): ahí es cuando más se cae el puente. */
    private static final int FINAL_CANCION = 50;
    /** De cada 100 bots, unos 60 son cuidadosos: con el final de la canción, antes del puente van despacio. */
    private static final int CUIDADOSOS_POR_CIENTO = 60;
    /** Desde cuánto antes del medio del puente van despacio los cuidadosos (a lo largo de la calle, en bloques). */
    private static final double ZONA_LENTA = 8.0;
    /**
     * Despacio, un bot va como un jugador agachado: unos 1,3 bloques por segundo (lo que camina un bot crece con el
     * cuadrado de esto: 0,58 x 0,58 es un tercio).
     */
    static final double LENTO = 0.58;
    /** Hasta dónde llega el empujón de un bot. */
    private static final double ALCANCE_EMPUJE = 2.3;
    /**
     * Si el bot tiene justo adelante a alguien por meterse debajo del puente: con el final de la canción, cada segundo,
     * de cada 100 veces lo empuja tantas (a los jugadores, más); el resto de la canción, casi nunca.
     */
    private static final int EMPUJA_JUGADOR_POR_CIENTO = 45;
    private static final int EMPUJA_BOT_POR_CIENTO = 25;
    private static final int EMPUJA_SIN_APURO_POR_CIENTO = 4;

    // ------------------------------------------------------------------ la canción
    /** Un paso (una corchea) cada 5 ticks: la negra a 120 por minuto. */
    private static final int PASO_MUSICA = 5;
    /**
     * "London Bridge Is Falling Down" (canción tradicional inglesa, de dominio público), con notas de bloque musical
     * (6 = do, 8 = re, 10 = mi, 11 = fa, 13 = sol, 15 = la; -1 = silencio): 4 compases de 8 corcheas, 8 segundos.
     */
    static final int[] MELODIA = {
            13, 15, 13, 11, 10, 11, 13, -1,     // Lon-don Bridge is fall-ing down,
            8, 10, 11, -1, 10, 11, 13, -1,      // fall-ing down, fall-ing down,
            13, 15, 13, 11, 10, 11, 13, -1,     // Lon-don Bridge is fall-ing down,
            8, -1, 13, -1, 10, 6, -1, -1,       // my fair la-dy.
    };
    /** El bajo de cada compás: la nota del tiempo 1 y la del tiempo 3 (do-sol, sol-do, do-sol, sol-do). */
    private static final int[][] BAJO = {{6, 13}, {13, 6}, {6, 13}, {13, 6}};
    /** Cuántas vueltas a la canción, como mucho, antes de que bajen los brazos: 2 o 3 (la primera ronda, 3). */
    private static final int VUELTAS_MIN = 2;

    // ------------------------------------------------------------------ los brazos
    /** Cada cuánto los robots amagan (bajan un poco los brazos) mientras suena la canción, y cuánto. */
    private static final int AMAGUE_MIN = 30;
    private static final int AMAGUE_AZAR = 50;
    /** Grados por tick: normal, el amague grande (casi los bajan) y cuando los bajan de golpe. */
    private static final float VELOCIDAD = 2.0F;
    private static final float VELOCIDAD_AMAGUE = 6.0F;
    private static final float VELOCIDAD_GOLPE = 16.0F;

    private enum Estado { NINGUNO, EMPEZANDO, MUSICA, BAJAN, PAUSA, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int ronda;
    /** Cuándo bajan los brazos (en ticks de la canción), y desde cuándo esperan que pase alguien. */
    private static int duracion;
    private static int esperando;
    /** Los que siguen en la fila (jugadores y bots). */
    private static final List<UUID> GENTE = new ArrayList<>();
    private static final Set<UUID> EN_FILA = new HashSet<>();
    private static final Map<UUID, JugadorBot> BOTS = new HashMap<>();
    private static final Set<UUID> PASARON = new HashSet<>();
    /** Jugadores con la canción: {ángulo anterior, cuánto avanzó en este segundo, segundos sin caminar, salió}. */
    private static final Map<UUID, double[]> CAMINATA = new HashMap<>();
    /** Cuándo empujaron a cada uno (si lo empujaron, ese segundo no cuenta como que no caminó), y quién. */
    private static final Map<UUID, Long> EMPUJADO = new HashMap<>();
    private static final Map<UUID, Component> EMPUJADOR = new HashMap<>();
    /** Los robots: el rojo (adentro de la ronda) y el azul (afuera). */
    @Nullable
    private static UUID robotRojo;
    @Nullable
    private static UUID robotAzul;
    /** Los brazos (los dos robots igual): dónde están, adónde van y a qué velocidad; y cuándo es el próximo amague. */
    private static float brazos = Robot.ARRIBA;
    private static float objetivoBrazos = Robot.ARRIBA;
    private static float velocidadBrazos = VELOCIDAD;
    private static int amague;
    private static int vuelveEn;
    /** El que quedó atrapado debajo del puente en esta ronda. */
    @Nullable
    private static UUID atrapado;

    private Puente() {
    }

    // ------------------------------------------------------------------ consultas (las usan los bots y Juego)
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean suenaMusica() {
        return estado == Estado.MUSICA;
    }

    static int pasaron() {
        return PASARON.size();
    }

    /** Sigue en la fila (todavía no terminó el juego y no quedó eliminado). */
    static boolean participa(LivingEntity quien) {
        return EN_FILA.contains(quien.getUUID()) && estado != Estado.NINGUNO && estado != Estado.TERMINADO;
    }

    /** Es el que quedó atrapado debajo del puente en esta ronda. */
    static boolean encerrado(LivingEntity quien) {
        return atrapado != null && atrapado.equals(quien.getUUID()) && estado == Estado.BAJAN;
    }

    /** Pasó las 5 rondas. */
    static boolean paso(LivingEntity quien) {
        return PASARON.contains(quien.getUUID());
    }

    /**
     * Lo acaban de empujar: ese segundo no cuenta como que no caminó, por un momento no se frena (el bot tampoco) y se
     * anota quién fue (si queda atrapado, se dice).
     */
    static void empujado(LivingEntity quien, LivingEntity empujador) {
        if (estado == Estado.NINGUNO) {
            return;
        }
        EMPUJADO.put(quien.getUUID(), quien.level().getGameTime());
        EMPUJADOR.put(quien.getUUID(), nombreDe(empujador));
        if (quien instanceof JugadorBot bot && EN_FILA.contains(bot.getUUID())) {
            bot.getNavigation().stop();                                // ya mismo: que no camine contra el empujón
        }
    }

    /** Lo acaban de empujar (hace menos de TRASTABILLA ticks) con la canción: sale para adelante sin frenarse. */
    static boolean trastabillando(LivingEntity quien) {
        if (estado != Estado.MUSICA) {
            return false;
        }
        Long empujon = EMPUJADO.get(quien.getUUID());
        long pasaron = empujon == null ? -1 : quien.level().getGameTime() - empujon;
        return pasaron >= 0 && pasaron < TRASTABILLA;
    }

    /** La canción está en el final de una vuelta (los últimos 2 segundos y medio): ahí es cuando más se cae el puente. */
    static boolean finalDeLaCancion() {
        int cancion = MELODIA.length * PASO_MUSICA;
        return estado == Estado.MUSICA && tiempo % cancion >= cancion - FINAL_CANCION;
    }

    /** Cuánto le falta para llegar al medio del puente, caminando por la calle (en bloques; negativo si ya pasó). */
    static double antesDelPuente(Entity quien) {
        return -Math.atan2(quien.getZ() - CZ, quien.getX() - CX) * RADIO;   // el puente está en el ángulo 0
    }

    // ------------------------------------------------------------------ la arena
    /**
     * Construye la arena la primera vez (y saca la plataforma provisoria que había antes para el juego 4). Si había una
     * versión anterior (el cuarto de juguetes), la vacía por dentro antes de poner la nueva.
     */
    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionPuente() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        BlockState aire = Blocks.AIR.defaultBlockState();
        Iterable<BlockPos> vaciar = estadoComplejo.versionPuente() > 0
                ? BlockPos.betweenClosed(X0 + 1, PISO, Z0 + 2, X1 - 1, PISO + 15, Z1 - 1)    // el cuarto viejo, por dentro
                : BlockPos.betweenClosed(3986, 99, -14, 4014, 105, 14);                     // Portales.prepararJuego
        for (BlockPos pos : vaciar) {
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionPuente(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de El puente de Londres colocada en {}", ORIGEN);
        return true;
    }

    /** Dónde aparece quien llega al juego 4: la entrada de la plaza (delante del podio). */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(3985.5 + azar.nextInt(31), PISO, -10.5 + azar.nextInt(13));
    }

    // ------------------------------------------------------------------ empieza el juego
    /** Los robots en su lugar, con los brazos arriba, y todos en fila en la calle (repartidos parejo). */
    static void empezar(ServerLevel complejo, List<LivingEntity> participantes) {
        olvidar();
        sacarRobots(complejo);
        ponerRobots(complejo);
        RandomSource azar = complejo.getRandom();
        List<LivingEntity> todos = new ArrayList<>(participantes);
        for (int i = todos.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            LivingEntity cambio = todos.get(i);
            todos.set(i, todos.get(j));
            todos.set(j, cambio);
        }
        for (LivingEntity quien : todos) {
            GENTE.add(quien.getUUID());
            EN_FILA.add(quien.getUUID());
            if (quien instanceof JugadorBot bot) {
                BOTS.put(bot.getUUID(), bot);
            }
        }
        ronda = 1;
        if (GENTE.size() <= 1) {
            terminarJuego(complejo);                                   // uno solo (o nadie): pasa directo
            return;
        }
        ponerEnFila(complejo, todos);
        anunciarRonda(complejo);
        cambiar(Estado.EMPEZANDO);
    }

    /** Todos en la calle, repartidos parejo alrededor y mirando para donde se camina (el puente, adelante de alguno). */
    private static void ponerEnFila(ServerLevel complejo, List<LivingEntity> todos) {
        double inicio = 0.35;                                           // nadie empieza debajo del puente
        for (int i = 0; i < todos.size(); i++) {
            LivingEntity quien = todos.get(i);
            double angulo = inicio + (Math.PI * 2.0 - 0.7) * i / todos.size();
            Vec3 lugar = enLaCalle(angulo, RADIO);
            float giro = (float) Math.toDegrees(angulo);                  // mirando para donde se camina
            if (quien instanceof ServerPlayer jugador) {
                jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
            } else if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                bot.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            }
        }
    }

    private static void ponerRobots(ServerLevel complejo) {
        Robot rojo = Robot.poner(complejo, ROBOT_ADENTRO, GIRO_ADENTRO, Robot.ROJO);
        Robot azul = Robot.poner(complejo, ROBOT_AFUERA, GIRO_AFUERA, Robot.AZUL);
        robotRojo = rojo == null ? null : rojo.getUUID();
        robotAzul = azul == null ? null : azul.getUUID();
        brazos = Robot.ARRIBA;
        objetivoBrazos = Robot.ARRIBA;
    }

    /** Saca los robots que haya en el cuarto (de este juego o de uno anterior que se cortó). */
    private static void sacarRobots(ServerLevel complejo) {
        AABB cuarto = new AABB(X0, PISO - 1, Z0, X1 + 1, PISO + 17, Z1 + 1);
        for (Robot robot : complejo.getEntitiesOfClass(Robot.class, cuarto)) {
            robot.discard();
        }
        robotRojo = null;
        robotAzul = null;
    }

    @Nullable
    private static Robot robot(ServerLevel complejo, int color) {
        UUID id = color == Robot.AZUL ? robotAzul : robotRojo;
        return id != null && complejo.getEntity(id) instanceof Robot robot && robot.isAlive() ? robot : null;
    }

    /** El comandante dice qué ronda es y cuántos quedan; en la pantalla, lo mismo. */
    private static void anunciarRonda(ServerLevel complejo) {
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.puente_ronda_inicio", ronda, RONDAS, GENTE.size()));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.ronda_puente", ronda, RONDAS)
                            .withStyle(ChatFormatting.GOLD),
                    Component.translatable("titulo.juegosdelpatio.ronda_puente_detalle", GENTE.size())
                            .withStyle(ChatFormatting.GRAY), 5, 45, 10);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 1.2F);
        }
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    /** Avanza el juego. true cuando ya terminaron las 5 rondas. */
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        revisarFila(complejo);
        switch (estado) {
            case EMPEZANDO -> {
                if (tiempo >= 60) {
                    empezarMusica(complejo);
                }
            }
            case MUSICA -> {
                musica(complejo);
                caminatas(complejo);
                amagues(complejo);
                if (tiempo >= duracion) {
                    intentarBajar(complejo);
                }
            }
            case BAJAN -> encerrar(complejo);
            case PAUSA -> {
                if (tiempo >= 60) {
                    empezarMusica(complejo);
                }
            }
            default -> {
            }
        }
        moverBrazos(complejo);
        if (tiempo % 10 == 1 || estado == Estado.TERMINADO) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    /** Si alguien de la fila se fue (se desconectó, murió de otra cosa), sale de la fila. */
    private static void revisarFila(ServerLevel complejo) {
        if (tiempo % 20 != 0 || estado == Estado.TERMINADO) {
            return;
        }
        for (UUID id : List.copyOf(GENTE)) {
            LivingEntity quien = buscar(complejo, id);
            if (quien == null || !Juego.estaEnArena(quien) || Juego.eliminado(quien)) {
                GENTE.remove(id);
                EN_FILA.remove(id);
            }
        }
    }

    private static void empezarMusica(ServerLevel complejo) {
        RandomSource azar = complejo.getRandom();
        int cancion = MELODIA.length * PASO_MUSICA;                     // una vuelta a la canción: 8 segundos
        int vueltas = ronda == 1 ? VUELTAS_MIN + 1 : VUELTAS_MIN + azar.nextInt(2);
        duracion = azar.nextInt(SORPRESA) == 0
                ? cancion + azar.nextInt(cancion * (vueltas - 1))      // sorpresa: en cualquier momento
                : cancion * vueltas;                                    // justo cuando termina la canción
        esperando = 0;
        amague = AMAGUE_MIN + azar.nextInt(AMAGUE_AZAR);
        CAMINATA.clear();
        cambiar(Estado.MUSICA);
        cantar(complejo, true);
        objetivoBrazos = Robot.ARRIBA;
        velocidadBrazos = VELOCIDAD;
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (participa(jugador)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.camina_fila")
                        .withStyle(ChatFormatting.AQUA), true);
            }
        }
    }

    /** Una nota por paso: la melodía, el bajo y la batería, para todos los que están en el cuarto. */
    private static void musica(ServerLevel complejo) {
        if ((tiempo - 1) % PASO_MUSICA != 0) {
            return;
        }
        int paso = (tiempo - 1) / PASO_MUSICA;
        int nota = MELODIA[paso % MELODIA.length];
        int enCompas = paso % 8;
        int[] bajo = BAJO[(paso / 8) % BAJO.length];
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (nota >= 0) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_BELL.value(), 0.55F, nota);
                sonar(jugador, SoundEvents.NOTE_BLOCK_HARP.value(), 0.8F, nota);
            }
            if (enCompas == 0 || enCompas == 4) {
                sonar(jugador, SoundEvents.NOTE_BLOCK_BASS.value(), 0.8F, bajo[enCompas / 4]);
                sonar(jugador, enCompas == 0 ? SoundEvents.NOTE_BLOCK_BASEDRUM.value() : SoundEvents.NOTE_BLOCK_SNARE.value(),
                        0.35F, 12);
            }
        }
        if (nota >= 0 && paso % 2 == 0) {                               // las notas salen de las cabezas de los robots
            for (Vec3 robot : List.of(ROBOT_ADENTRO, ROBOT_AFUERA)) {
                complejo.sendParticles(ParticleTypes.NOTE, robot.x, robot.y + 9.6, robot.z, 0, nota / 24.0, 0.0, 0.0, 1.0);
            }
        }
    }

    private static void sonar(ServerPlayer jugador, SoundEvent sonido, float volumen, int nota) {
        jugador.playNotifySound(sonido, SoundSource.RECORDS, volumen, (float) Math.pow(2.0, (nota - 12) / 12.0));
    }

    /**
     * Con la canción, los jugadores tienen que caminar en la fila por la calle, alrededor (como las agujas del reloj).
     * Se puede ir despacio (agachado), pero no pararse: cada segundo se mira cuánto avanzaron, y si no caminaron, se
     * les avisa, y si siguen sin caminar, quedan eliminados. Los primeros 2 segundos no cuentan (para arrancar), y si
     * te empujaron, ese segundo tampoco.
     */
    private static void caminatas(ServerLevel complejo) {
        long ahora = complejo.getGameTime();
        boolean juzgar = tiempo % 20 == 0;
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!participa(jugador) || !jugador.isAlive() || jugador.isSpectator() || jugador.isCreative()) {
                continue;
            }
            double dx = jugador.getX() - CX;
            double dz = jugador.getZ() - CZ;
            double angulo = Math.atan2(dz, dx);
            double radio = Math.sqrt(dx * dx + dz * dz);
            double[] caminata = CAMINATA.computeIfAbsent(jugador.getUUID(), id -> new double[] {angulo, 0.0, 0.0, 0.0});
            caminata[1] += diferencia(angulo, caminata[0]) * radio;        // en bloques, por la calle
            caminata[0] = angulo;
            if (radio < CALLE_MIN || radio > CALLE_MAX) {
                caminata[3] = 1.0;
            }
            if (!juzgar) {
                continue;
            }
            if (tiempo > 40) {
                Long empujon = EMPUJADO.get(jugador.getUUID());
                boolean loEmpujaron = empujon != null && ahora - empujon < 40;
                boolean mal = (caminata[1] < AVANCE_MINIMO || caminata[3] > 0.0) && !loEmpujaron;
                caminata[2] = mal ? caminata[2] + 1.0 : 0.0;
                if (caminata[2] >= ELIMINA_QUIETO) {
                    eliminar(complejo, jugador, "no_caminaste_fila");
                    continue;
                }
                if (caminata[2] >= AVISO_QUIETO) {
                    jugador.displayClientMessage(Component.translatable(caminata[3] > 0.0
                            ? "mensaje.juegosdelpatio.vuelve_calle" : "mensaje.juegosdelpatio.camina_en_fila")
                            .withStyle(ChatFormatting.RED), true);
                    jugador.playNotifySound(SoundEvents.NOTE_BLOCK_DIDGERIDOO.value(), SoundSource.MASTER, 1.0F, 0.6F);
                }
            }
            caminata[1] = 0.0;
            caminata[3] = 0.0;
        }
    }

    // ------------------------------------------------------------------ los brazos
    /**
     * Mientras suena la canción, cada tanto los robots amagan: bajan un poco los brazos y los vuelven a subir. A veces
     * el amague es grande (los bajan casi del todo, rápido), para asustar.
     */
    private static void amagues(ServerLevel complejo) {
        if (vuelveEn > 0 && --vuelveEn == 0) {
            objetivoBrazos = Robot.ARRIBA;                              // vuelven a subir
            velocidadBrazos = VELOCIDAD;
        }
        if (--amague > 0) {
            return;
        }
        RandomSource azar = complejo.getRandom();
        amague = AMAGUE_MIN + azar.nextInt(AMAGUE_AZAR);
        if (azar.nextInt(4) == 0) {
            objetivoBrazos = -12.0F + azar.nextFloat() * 8.0F;          // ¡casi los bajan! (las manos, a unos 6 bloques)
            velocidadBrazos = VELOCIDAD_AMAGUE;
            vuelveEn = 6 + azar.nextInt(6);
            ruidoBrazos(complejo, 0.7F, 1.4F);
        } else {
            objetivoBrazos = Robot.ARRIBA - 5.0F - azar.nextFloat() * 9.0F;
            velocidadBrazos = 1.5F;
            vuelveEn = 10 + azar.nextInt(12);
        }
    }

    /** Los brazos van hacia donde tienen que ir, de a poco; los dos robots igual (se están dando la mano). */
    private static void moverBrazos(ServerLevel complejo) {
        if (brazos != objetivoBrazos) {
            float paso = Math.min(velocidadBrazos, Math.abs(objetivoBrazos - brazos));
            brazos += objetivoBrazos > brazos ? paso : -paso;
        }
        for (int color = Robot.ROJO; color <= Robot.AZUL; color++) {
            Robot robot = robot(complejo, color);
            if (robot != null) {
                robot.ponerBrazos(brazos);
            }
        }
    }

    private static void cantar(ServerLevel complejo, boolean canta) {
        for (int color = Robot.ROJO; color <= Robot.AZUL; color++) {
            Robot robot = robot(complejo, color);
            if (robot != null) {
                robot.cantar(canta);
            }
        }
    }

    private static void ruidoBrazos(ServerLevel complejo, float volumen, float tono) {
        complejo.playSound(null, PUENTE.x, PUENTE.y + 6.0, PUENTE.z, SoundEvents.PISTON_EXTEND, SoundSource.HOSTILE,
                volumen, tono);
    }

    // ------------------------------------------------------------------ se cae el puente
    /**
     * Se terminó la canción (o es el momento sorpresa): si alguien está pasando por debajo del puente, los brazos bajan
     * de golpe. Si no pasa nadie, la canción sigue hasta que pase alguien; si tarda (4 segundos), atrapan al que está
     * por pasar.
     */
    private static void intentarBajar(ServerLevel complejo) {
        LivingEntity debajo = debajoDelPuente(complejo);
        if (debajo == null && ++esperando < ESPERA_ALGUIEN) {
            return;
        }
        if (debajo == null) {
            debajo = porPasar(complejo);
        }
        if (debajo == null) {
            esperando = 0;                                              // no hay nadie cerca: un poco más de canción
            return;
        }
        bajar(complejo, debajo);
    }

    /** El que está pasando por debajo del puente (el más cerca del medio), o null. */
    @Nullable
    private static LivingEntity debajoDelPuente(ServerLevel complejo) {
        LivingEntity mejor = null;
        double menor = JAULA;
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien == null) {
                continue;
            }
            double dz = Math.abs(quien.getZ() - PUENTE.z);
            if (Math.abs(quien.getX() - PUENTE.x) <= JAULA_ANCHO && dz <= menor) {
                menor = dz;
                mejor = quien;
            }
        }
        return mejor;
    }

    /** El primero de la fila que todavía no pasó por debajo del puente, si está cerca (a menos de POR_PASAR del medio). */
    @Nullable
    private static LivingEntity porPasar(ServerLevel complejo) {
        LivingEntity mejor = null;
        double menor = POR_PASAR;
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien == null || !estaEnLaCalle(quien)) {
                continue;
            }
            double falta = antesDelPuente(quien);
            if (falta > 0.0 && falta <= menor) {
                menor = falta;
                mejor = quien;
            }
        }
        return mejor;
    }

    /**
     * Los brazos bajan de golpe: el que pasaba queda atrapado (si lo acababan de empujar, se dice quién fue); los que
     * estaban al lado quedan afuera. La fila se para.
     */
    private static void bajar(ServerLevel complejo, LivingEntity quien) {
        atrapado = quien.getUUID();
        cambiar(Estado.BAJAN);
        cantar(complejo, false);
        objetivoBrazos = Robot.ABAJO;
        velocidadBrazos = VELOCIDAD_GOLPE;
        vuelveEn = 0;
        moverA(complejo, quien, PUENTE.x, PUENTE.z);
        for (UUID id : GENTE) {
            LivingEntity otro = buscar(complejo, id);
            if (otro == null || otro == quien) {
                continue;
            }
            double dz = otro.getZ() - PUENTE.z;
            if (Math.abs(otro.getX() - PUENTE.x) <= JAULA_ANCHO + 0.5 && Math.abs(dz) <= JAULA + 0.8) {
                moverA(complejo, otro, otro.getX(), PUENTE.z + (dz >= 0.0 ? JAULA + 1.2 : -JAULA - 1.2));   // afuera
            }
        }
        ruidoBrazos(complejo, 1.2F, 0.6F);
        complejo.playSound(null, PUENTE.x, PUENTE.y + 1.0, PUENTE.z, SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 1.0F, 0.6F);
        Component nombre = nombreDe(quien);
        Long empujon = EMPUJADO.get(quien.getUUID());
        Component empujador = EMPUJADOR.get(quien.getUUID());
        boolean loEmpujaron = empujon != null && empujador != null && complejo.getGameTime() - empujon <= EMPUJON_RECIENTE;
        Juego.decir(complejo, Component.translatable("mensaje.juegosdelpatio.atrapado", nombre));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            boolean esEl = jugador == quien;
            Juego.titulo(jugador, Component.translatable(esEl ? "titulo.juegosdelpatio.te_atrapo" : "titulo.juegosdelpatio.cayo_puente")
                            .withStyle(ChatFormatting.RED),
                    (esEl ? Component.translatable("titulo.juegosdelpatio.te_atrapo_detalle")
                            : Component.translatable("titulo.juegosdelpatio.cayo_puente_detalle", nombre)).withStyle(ChatFormatting.GRAY),
                    0, 50, 10);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), SoundSource.RECORDS, 1.0F, 0.5F);
            if (loEmpujaron) {
                jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio.empujo_al_puente", empujador, nombre)
                        .withStyle(ChatFormatting.GOLD));
            }
        }
        if (quien instanceof JugadorBot bot) {
            bot.mostrarEmote(Emote.TRISTE);
        }
    }

    private static void moverA(ServerLevel complejo, LivingEntity quien, double x, double z) {
        if (quien instanceof ServerPlayer jugador) {
            jugador.teleportTo(complejo, x, PISO, z, jugador.getYRot(), jugador.getXRot());
        } else if (quien instanceof JugadorBot bot) {
            bot.getNavigation().stop();
            bot.dejarDeCorrer();
            bot.moveTo(x, PISO, z, bot.getYRot(), 0.0F);
        }
    }

    /** El encerrado no se puede ir: si se corre del medio, vuelve. */
    private static void sujetar(ServerLevel complejo) {
        LivingEntity quien = atrapado == null ? null : buscar(complejo, atrapado);
        if (quien != null && quien.distanceToSqr(PUENTE.x, quien.getY(), PUENTE.z) > 0.8 * 0.8) {
            moverA(complejo, quien, PUENTE.x, PUENTE.z);
        }
    }

    // ------------------------------------------------------------------ el atrapado
    /**
     * El atrapado: los robots lo tienen encerrado y suena un redoble; a los 2 segundos y medio queda eliminado. Después
     * los robots levantan los brazos y sigue la ronda siguiente.
     */
    private static void encerrar(ServerLevel complejo) {
        sujetar(complejo);
        if (tiempo >= 10 && tiempo < ELIMINA_ATRAPADO && tiempo % 2 == 0) {
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                jugador.playNotifySound(SoundEvents.NOTE_BLOCK_SNARE.value(), SoundSource.RECORDS, 0.6F, 1.0F);
            }
        }
        if (tiempo == ELIMINA_ATRAPADO) {
            LivingEntity quien = atrapado == null ? null : buscar(complejo, atrapado);
            if (quien != null) {
                eliminar(complejo, quien, "atrapado_puente");
            }
        }
        if (tiempo >= LEVANTAN) {
            levantar(complejo);
        }
    }

    /** Los robots levantan los brazos (otra vez el puente) y, después de una pausa, la ronda siguiente. */
    private static void levantar(ServerLevel complejo) {
        atrapado = null;
        objetivoBrazos = Robot.ARRIBA;
        velocidadBrazos = VELOCIDAD + 1.0F;
        ruidoBrazos(complejo, 0.8F, 0.9F);
        if (ronda >= RONDAS || GENTE.size() <= 1) {
            terminarJuego(complejo);
            return;
        }
        ronda++;
        anunciarRonda(complejo);
        cambiar(Estado.PAUSA);
    }

    private static void eliminar(ServerLevel complejo, LivingEntity quien, String motivo) {
        GENTE.remove(quien.getUUID());
        EN_FILA.remove(quien.getUUID());
        Juego.eliminar(complejo, quien, false, motivo);
    }

    private static void terminarJuego(ServerLevel complejo) {
        cantar(complejo, false);
        objetivoBrazos = Robot.ARRIBA;
        PASARON.addAll(GENTE);
        for (UUID id : GENTE) {
            LivingEntity quien = buscar(complejo, id);
            if (quien instanceof ServerPlayer jugador) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.pasaste").withStyle(ChatFormatting.GREEN),
                        Component.translatable("titulo.juegosdelpatio.pasaste_puente").withStyle(ChatFormatting.GRAY),
                        5, 50, 15);
                jugador.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
            } else if (quien instanceof JugadorBot bot) {
                bot.mostrarEmote(Emote.FELIZ);
            }
        }
        cambiar(Estado.TERMINADO);
    }

    // ------------------------------------------------------------------ la barra de arriba
    private static void barra(ServerLevel complejo) {
        Component nombre;
        BossEvent.BossBarColor color;
        float progreso = 1.0F;
        switch (estado) {
            case MUSICA -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_musica", ronda, RONDAS, GENTE.size());
                color = BossEvent.BossBarColor.BLUE;
            }
            case BAJAN -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_atrapado", ronda, RONDAS, GENTE.size());
                color = BossEvent.BossBarColor.RED;
                progreso = Math.max(0.0F, 1.0F - tiempo / (float) ELIMINA_ATRAPADO);   // se le acaba el tiempo
            }
            case TERMINADO -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_fin", PASARON.size());
                color = BossEvent.BossBarColor.GREEN;
            }
            default -> {
                nombre = Component.translatable("barra.juegosdelpatio.puente_ronda", ronda, RONDAS, GENTE.size());
                color = BossEvent.BossBarColor.WHITE;
            }
        }
        Juego.barraJuego(complejo, nombre, color, progreso);
    }

    // ------------------------------------------------------------------ los bots (los guía JugadorBot.PuenteGoal)
    /** Adónde camina un bot con la canción: un poco más adelante en la calle (cada uno, en su carril). */
    static Vec3 adondeCaminar(JugadorBot bot) {
        double angulo = Math.atan2(bot.getZ() - CZ, bot.getX() - CX);
        double radio = RADIO + (Math.floorMod(bot.getId(), 5) - 2) * 0.2;
        return enLaCalle(angulo + 1.8 / radio, radio);
    }

    /**
     * Qué tan cerca tiene al que va adelante en la fila: 0 si nadie (o lejos), 1 si muy cerca (hay que frenar), y
     * algo en el medio si hay que ir más despacio.
     */
    static double adelante(JugadorBot bot) {
        double angulo = Math.atan2(bot.getZ() - CZ, bot.getX() - CX);
        double haciaX = -Math.sin(angulo);                              // para donde se camina
        double haciaZ = Math.cos(angulo);
        double peor = 0.0;
        for (LivingEntity otro : bot.level().getEntitiesOfClass(LivingEntity.class, bot.getBoundingBox().inflate(1.8, 0.5, 1.8))) {
            if (otro == bot || !EN_FILA.contains(otro.getUUID())) {
                continue;
            }
            double dx = otro.getX() - bot.getX();
            double dz = otro.getZ() - bot.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d < 1.8 && (dx * haciaX + dz * haciaZ) > 0.3 * d) {
                peor = Math.max(peor, d < 0.9 ? 1.0 : (1.8 - d) / 0.9);
            }
        }
        return peor;
    }

    /** Los bots cuidadosos, con el final de la canción y por llegar al puente, van despacio (agachados). */
    static boolean irDespacio(JugadorBot bot) {
        if (!finalDeLaCancion() || Math.floorMod(bot.getUUID().hashCode(), 100) >= CUIDADOSOS_POR_CIENTO) {
            return false;
        }
        double falta = antesDelPuente(bot);
        return falta > JAULA + 0.3 && falta <= ZONA_LENTA;
    }

    /**
     * A quién empuja un bot ahora (o null). Al que lo empujó (y lo hizo enojar), si lo tiene a mano: se lo devuelve.
     * Si no, si está por llegar al puente y tiene justo adelante a alguien por meterse debajo, a veces (con el final de
     * la canción, bastante) lo empuja: así le toca a él.
     */
    @Nullable
    static LivingEntity paraEmpujar(JugadorBot bot) {
        if (estado != Estado.MUSICA || !EN_FILA.contains(bot.getUUID())) {
            return null;
        }
        if (bot.getTarget() instanceof LivingEntity enojo && enojo.isAlive() && EN_FILA.contains(enojo.getUUID())
                && bot.distanceToSqr(enojo) <= ALCANCE_EMPUJE * ALCANCE_EMPUJE) {
            return enojo;                                               // te devuelve el empujón
        }
        double falta = antesDelPuente(bot);
        if (falta <= JAULA || falta > ZONA_LENTA + 2.0) {
            return null;
        }
        LivingEntity adelante = elDeAdelante(bot, ALCANCE_EMPUJE);
        if (adelante == null) {
            return null;
        }
        double faltaOtro = antesDelPuente(adelante);
        if (faltaOtro < JAULA - 0.3 || faltaOtro > JAULA + 2.8) {
            return null;                                                // todavía lejos (o ya debajo: lo sacaría)
        }
        int chance = !finalDeLaCancion() ? EMPUJA_SIN_APURO_POR_CIENTO
                : adelante instanceof Player ? EMPUJA_JUGADOR_POR_CIENTO : EMPUJA_BOT_POR_CIENTO;
        return bot.getRandom().nextInt(100) < chance ? adelante : null;
    }

    /** El que va justo adelante en la fila (a menos de {@code hasta}), o null. */
    @Nullable
    private static LivingEntity elDeAdelante(JugadorBot bot, double hasta) {
        double angulo = Math.atan2(bot.getZ() - CZ, bot.getX() - CX);
        double haciaX = -Math.sin(angulo);                              // para donde se camina
        double haciaZ = Math.cos(angulo);
        LivingEntity mejor = null;
        double menor = hasta;
        for (LivingEntity otro : bot.level().getEntitiesOfClass(LivingEntity.class, bot.getBoundingBox().inflate(hasta, 0.5, hasta))) {
            if (otro == bot || !otro.isAlive() || !EN_FILA.contains(otro.getUUID())) {
                continue;
            }
            double dx = otro.getX() - bot.getX();
            double dz = otro.getZ() - bot.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d < menor && (dx * haciaX + dz * haciaZ) > 0.5 * d) {
                menor = d;
                mejor = otro;
            }
        }
        return mejor;
    }

    /** Hacia dónde mira la gente cuando la fila está parada: al atrapado (o al puente). */
    static Vec3 aDondeMirar() {
        return PUENTE.add(0.0, 1.5, 0.0);
    }

    // ------------------------------------------------------------------ fin
    /** Al terminar (o cortarse) el juego: se sacan los robots y se olvida todo. */
    static void limpiar(ServerLevel complejo) {
        sacarRobots(complejo);
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ronda = 0;
        duracion = 0;
        esperando = 0;
        GENTE.clear();
        EN_FILA.clear();
        BOTS.clear();
        PASARON.clear();
        CAMINATA.clear();
        EMPUJADO.clear();
        EMPUJADOR.clear();
        atrapado = null;
        brazos = Robot.ARRIBA;
        objetivoBrazos = Robot.ARRIBA;
        velocidadBrazos = VELOCIDAD;
        amague = 0;
        vuelveEn = 0;
    }

    // ------------------------------------------------------------------ ayudas
    private static void cambiar(Estado nuevo) {
        estado = nuevo;
        tiempo = 0;
    }

    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID id) {
        ServerPlayer jugador = complejo.getServer().getPlayerList().getPlayer(id);
        if (jugador != null) {
            return jugador.level() == complejo && jugador.isAlive() ? jugador : null;
        }
        JugadorBot bot = BOTS.get(id);
        return bot != null && bot.isAlive() && !bot.isRemoved() ? bot : null;
    }

    private static Component nombreDe(LivingEntity quien) {
        return quien instanceof JugadorBot bot ? Component.literal(bot.nombre()) : quien.getName();
    }

    private static boolean estaEnLaCalle(Entity quien) {
        double dx = quien.getX() - CX;
        double dz = quien.getZ() - CZ;
        double radio = Math.sqrt(dx * dx + dz * dz);
        return radio >= CALLE_MIN && radio <= CALLE_MAX;
    }

    private static Vec3 enLaCalle(double angulo, double radio) {
        return new Vec3(CX + radio * Math.cos(angulo), PISO, CZ + radio * Math.sin(angulo));
    }

    /** Cuánto hay que girar de {@code desde} a {@code hasta} (en radianes, entre -pi y pi). */
    private static double diferencia(double hasta, double desde) {
        double d = hasta - desde;
        while (d > Math.PI) {
            d -= Math.PI * 2.0;
        }
        while (d < -Math.PI) {
            d += Math.PI * 2.0;
        }
        return d;
    }
}
