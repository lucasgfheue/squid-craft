package com.juegosdelpatio;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;

/**
 * Las puertas numeradas de la Torre de los Juegos. Al abrirse, en lugar de la puerta aparece un portal de luz que
 * lleva al juego de ese número. Los juegos no están detrás de las puertas sino lejos, en otra parte del complejo
 * (cada juego en su lugar, lejos de los otros), así cada uno puede ser tan grande como haga falta.
 *
 * Mientras un juego no está hecho, ahí hay una plataforma provisoria con su número y un portal de vuelta a la sala.
 */
public final class Portales {
    /** Puertas de la torre: pared (0 oeste, 1 norte, 2 este, 3 sur), centro y nivel, en coordenadas de la torre. */
    private static final int[][] PUERTAS = {{0, 6, 8}, {1, 14, 16}, {2, 14, 24}, {3, 6, 32}, {0, 6, 40}, {1, 14, 48},
            {2, 14, 56}};
    public static final int CANTIDAD = PUERTAS.length;
    /** Distancia entre un juego y el siguiente, y altura del piso de llegada. */
    public static final int SEPARACION_JUEGOS = 1000;
    public static final int ALTURA_JUEGOS = 100;
    /** La plataforma provisoria va lejos de las arenas (que están entre z -60 y 85). */
    private static final int LEJOS_Z = 300;
    private static final String[][] DIGITOS = {
            {".X.", "XX.", ".X.", ".X.", "XXX"},
            {"XXX", "..X", "XXX", "X..", "XXX"},
            {"XXX", "..X", "XXX", "..X", "XXX"},
            {"X.X", "X.X", "XXX", "..X", "..X"},
            {"XXX", "X..", "XXX", "..X", "XXX"},
            {"XXX", "X..", "XXX", "X.X", "XXX"},
            {"XXX", "..X", ".X.", ".X.", ".X."},
    };
    /** Para no teletransportar dos veces seguidas al mismo jugador (toca varios bloques del portal a la vez). */
    private static final Map<UUID, Long> ULTIMO_VIAJE = new HashMap<>();

    private Portales() {
    }

    /** Bloque de la puerta {@code numero}: columna -1..1 (de izquierda a derecha, mirando la puerta) y fila 0..3. */
    static BlockPos celdaPuerta(int numero, int columna, int fila) {
        int[] puerta = PUERTAS[numero - 1];
        int centro = puerta[1];
        int y = puerta[2] + 1 + fila;
        int x;
        int z;
        switch (puerta[0]) {
            case 0 -> {
                x = 0;
                z = centro - columna;
            }
            case 1 -> {
                x = centro + columna;
                z = 0;
            }
            case 2 -> {
                x = 20;
                z = centro + columna;
            }
            default -> {
                x = centro - columna;
                z = 20;
            }
        }
        return Complejo.ORIGEN_TORRE.offset(x, y, z);
    }

    /** El lugar de afuera de la torre, justo detrás de una celda de la puerta (ahí va una barrera invisible). */
    private static BlockPos detras(int numero, BlockPos celda) {
        return switch (PUERTAS[numero - 1][0]) {
            case 0 -> celda.offset(-1, 0, 0);
            case 1 -> celda.offset(0, 0, -1);
            case 2 -> celda.offset(1, 0, 0);
            default -> celda.offset(0, 0, 1);
        };
    }

    public static boolean puertaAbierta(ServerLevel nivel, int numero) {
        return nivel.getBlockState(celdaPuerta(numero, 0, 1)).is(Registro.PORTAL_JUEGO.get());
    }

    /** La puerta desaparece y en su lugar queda el portal al juego. */
    public static void abrirPuerta(ServerLevel nivel, int numero) {
        BlockState portal = Registro.PORTAL_JUEGO.get().defaultBlockState()
                .setValue(PortalJuego.JUEGO, numero).setValue(PortalJuego.REGRESO, false);
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = -1; columna <= 1; columna++) {
                BlockPos celda = celdaPuerta(numero, columna, fila);
                nivel.setBlock(celda, portal, Block.UPDATE_CLIENTS);
                // por si algo falla, que nadie atraviese el portal y caiga al vacío de afuera
                nivel.setBlock(detras(numero, celda), Blocks.BARRIER.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        BlockPos medio = celdaPuerta(numero, 0, 1);
        nivel.playSound(null, medio, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 2.0F, 1.2F);
        nivel.playSound(null, medio, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 1.5F, 0.6F);
    }

    /** Vuelve a poner la puerta (igual que en torre.nbt: negro abajo y arriba, hierro en el medio). */
    public static void cerrarPuerta(ServerLevel nivel, int numero) {
        for (int fila = 0; fila < 4; fila++) {
            BlockState bloque = fila == 0 || fila == 3
                    ? Blocks.POLISHED_BLACKSTONE.defaultBlockState() : Blocks.IRON_BLOCK.defaultBlockState();
            for (int columna = -1; columna <= 1; columna++) {
                BlockPos celda = celdaPuerta(numero, columna, fila);
                nivel.setBlock(celda, bloque, Block.UPDATE_CLIENTS);
                if (nivel.getBlockState(detras(numero, celda)).is(Blocks.BARRIER)) {
                    nivel.setBlock(detras(numero, celda), Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                }
            }
        }
        BlockPos medio = celdaPuerta(numero, 0, 1);
        nivel.playSound(null, medio, SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 2.0F, 1.0F);
        nivel.playSound(null, medio, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 1.5F, 0.6F);
    }

    // ------------------------------------------------------------------ viajes
    static void usar(ServerPlayer jugador, int juego, boolean regreso) {
        ServerLevel nivel = jugador.serverLevel();
        long ahora = nivel.getGameTime();
        Long antes = ULTIMO_VIAJE.get(jugador.getUUID());
        if (antes != null && ahora - antes < 40) {
            return;
        }
        ULTIMO_VIAJE.put(jugador.getUUID(), ahora);
        if (!regreso && juego == Juego.numero() && Juego.caminando()) {
            // en el minuto para ir, por el portal pasan los bots y el comandante; los jugadores pasan todos juntos
            // cuando se termina el minuto (así la sala sigue cargada y no queda ningún bot atrás)
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.esperar_portal")
                    .withStyle(ChatFormatting.YELLOW), true);
            return;
        }
        if (regreso && Juego.enArena()) {
            Vec3 salida = Juego.lugarDeSalida(Juego.numero(), nivel.getRandom());   // en pleno juego no se puede escapar
            jugador.teleportTo(nivel, salida.x, salida.y, salida.z, 0.0F, 0.0F);
        } else if (regreso) {
            Complejo.llevarALaSala(jugador);
        } else if (Juego.tieneArena(juego) && Juego.prepararArena(nivel, juego)) {
            Vec3 salida = Juego.lugarDeSalida(juego, nivel.getRandom());   // este juego ya tiene su arena
            jugador.teleportTo(nivel, salida.x, salida.y, salida.z, 0.0F, 0.0F);
        } else {
            prepararJuego(nivel, juego);
            Vec3 llegada = llegadaJuego(juego);
            jugador.teleportTo(nivel, llegada.x, llegada.y, llegada.z, 0.0F, 0.0F);
            jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
            jugador.connection.send(new ClientboundSetSubtitleTextPacket(
                    Component.translatable("titulo.juegosdelpatio.en_construccion").withStyle(ChatFormatting.GRAY)));
            jugador.connection.send(new ClientboundSetTitleTextPacket(
                    Component.translatable("titulo.juegosdelpatio.juego", juego).withStyle(ChatFormatting.GOLD)));
        }
        jugador.playNotifySound(SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.3F);
    }

    /**
     * Dónde aparece el jugador en la plataforma provisoria (si un juego no tiene arena): mirando hacia el sur, con el
     * portal de vuelta a la espalda. Está lejos (en z = 300), para no caer encima de ninguna arena.
     */
    public static Vec3 llegadaJuego(int juego) {
        return new Vec3(SEPARACION_JUEGOS * juego + 0.5, ALTURA_JUEGOS, LEJOS_Z - 8.5);
    }

    /**
     * Construye la plataforma provisoria del juego si todavía no existe: piso de 25 x 25 con luces, el número del
     * juego dibujado con lámparas, una barrera invisible alrededor (para no caerse al vacío) y el portal de vuelta.
     */
    static void prepararJuego(ServerLevel nivel, int juego) {
        BlockPos centro = new BlockPos(SEPARACION_JUEGOS * juego, ALTURA_JUEGOS - 1, LEJOS_Z);
        if (nivel.getBlockState(centro.offset(-12, 0, -12)).is(Blocks.POLISHED_BLACKSTONE)) {
            return;                                       // ya está hecha
        }
        BlockState borde = Blocks.POLISHED_BLACKSTONE.defaultBlockState();
        BlockState piso = Blocks.POLISHED_ANDESITE.defaultBlockState();
        BlockState luz = Blocks.SEA_LANTERN.defaultBlockState();
        BlockState barrera = Blocks.BARRIER.defaultBlockState();
        BlockState lampara = Blocks.WAXED_COPPER_BULB.defaultBlockState().setValue(BlockStateProperties.LIT, true);
        for (int dx = -12; dx <= 12; dx++) {
            for (int dz = -12; dz <= 12; dz++) {
                boolean esBorde = Math.abs(dx) == 12 || Math.abs(dz) == 12;
                boolean esLuz = dx % 6 == 0 && dz % 6 == 0 && Math.abs(dx) + Math.abs(dz) > 6;
                boolean panel = dx >= -4 && dx <= 3 && dz >= -4 && dz <= 7;
                nivel.setBlock(centro.offset(dx, 0, dz), esBorde || panel ? borde : esLuz ? luz : piso, Block.UPDATE_CLIENTS);
            }
        }
        // el número, de 6 x 10, que se lee mirando hacia el sur desde la llegada
        String[] digito = DIGITOS[juego - 1];
        for (int fila = 0; fila < 5; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                if (digito[fila].charAt(columna) != 'X') {
                    continue;
                }
                for (int a = 0; a < 2; a++) {
                    for (int b = 0; b < 2; b++) {
                        nivel.setBlock(centro.offset(2 - 2 * columna - a, 0, 6 - 2 * fila - b), lampara, Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
        for (int i = -13; i <= 13; i++) {
            for (int y = 1; y <= 5; y++) {
                nivel.setBlock(centro.offset(i, y, -13), barrera, Block.UPDATE_CLIENTS);
                nivel.setBlock(centro.offset(i, y, 13), barrera, Block.UPDATE_CLIENTS);
                nivel.setBlock(centro.offset(-13, y, i), barrera, Block.UPDATE_CLIENTS);
                nivel.setBlock(centro.offset(13, y, i), barrera, Block.UPDATE_CLIENTS);
            }
        }
        // portal de vuelta a la sala, en el borde norte
        BlockState vuelta = Registro.PORTAL_JUEGO.get().defaultBlockState()
                .setValue(PortalJuego.JUEGO, juego).setValue(PortalJuego.REGRESO, true);
        for (int dx = -2; dx <= 2; dx++) {
            for (int y = 1; y <= 5; y++) {
                boolean marco = Math.abs(dx) == 2 || y == 5;
                nivel.setBlock(centro.offset(dx, y, -12), marco ? borde : vuelta, Block.UPDATE_CLIENTS);
            }
        }
    }
}
