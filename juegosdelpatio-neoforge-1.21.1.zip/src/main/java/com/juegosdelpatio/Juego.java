package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * El día de juego. Por ahora hay un solo juego: el 1, "Luz verde, luz roja", que se juega el día 1 del ciclo
 * (el día después de la entrada: 1, 7, 13...).
 *
 * <ol>
 *   <li>LLAMADO: un minuto después de que se prenden las luces, si hay jugadores en el complejo, entra el
 *       comandante con sus cuatro sargentos (la ceremonia de tipo llamado) y avisa que empieza el juego.
 *       Vuelven al pasillo y la puerta 1 de la torre se abre como portal.</li>
 *   <li>CAMINO: hay un minuto para entrar por el portal (se ve una barra con el tiempo). El comandante sube
 *       caminando hasta la puerta 1 y los sargentos marcan el camino; los bots se juntan en el portón. Cuando
 *       se termina el minuto, todos los que siguen en el complejo pasan solos a la arena.</li>
 *   <li>REGLAS: el comandante, desde su podio, explica las reglas.</li>
 *   <li>JUEGO: 3 minutos (en pantalla). Con luz verde se avanza; con luz roja hay que quedarse quieto. Quien
 *       se mueve con luz roja queda eliminado: muere y reaparece en el mundo normal.</li>
 *   <li>FINAL: los que no cruzaron la meta también quedan eliminados; los que pasaron vuelven a la sala.</li>
 * </ol>
 */
public final class Juego {
    private enum Fase { NINGUNA, LLAMADO, CAMINO, REGLAS, JUEGO, FINAL }

    public static final ResourceLocation ARENA = Complejo.id("luz_verde");
    /** Esquina de la plantilla luz_verde.nbt (102 x 33 x 308). */
    public static final BlockPos ORIGEN_ARENA = new BlockPos(949, 99, -1);
    public static final int VERSION_ARENA = 1;
    /** Cruzar esta z es llegar a la meta. */
    public static final double META_Z = 290.0;
    /** Hacia dónde miran los bots cuando están quietos: el semáforo gigante. */
    public static final Vec3 SEMAFORO = new Vec3(999.5, 118.0, 300.0);
    /** Un minuto después de que empieza el día (hora 1200 del mundo normal) llega el comandante. */
    public static final long HORA_LLAMADO = 1200L;
    public static final int MINUTO = 60 * 20;
    public static final int DURACION_JUEGO = 3 * 60 * 20;
    private static final int GRACIA = 15;                 // tiempo para frenar cuando se pone en rojo
    /** Cuánto se puede correr alguien con luz roja sin quedar eliminado (por los empujones de la gente). */
    private static final double MOVIMIENTO = 0.2;
    /** En cada luz roja, de cada 100 bots que siguen jugando, unos 3 no frenan a tiempo. */
    private static final int DISTRAIDOS_POR_CIENTO = 3;
    private static final int TICKS_POR_REGLA = 70;
    private static final String[] REGLAS = {"reglas_1", "reglas_2", "reglas_3", "reglas_4", "reglas_5", "reglas_6"};

    // semáforos (deben coincidir con gen_luz_verde.py)
    private static final int SEM_X0 = 996;
    private static final int SEM_X1 = 1002;
    private static final int SEM_Z = 300;
    private static final int VERDE_Y0 = 114;
    private static final int ROJO_Y0 = 122;
    private static final int[] LADOS_X = {949, 1050};
    private static final int[] LADOS_Z = {35, 85, 135, 185, 235, 285};

    // el minuto para ir: a dónde camina cada uno del desfile (0 = comandante, 1..4 = sargentos)
    /** El comandante sube a la puerta 1 en dos tramos: el pie de la escalera de la torre y el descanso de la puerta. */
    private static final Vec3[] CAMINO_COMANDANTE = {new Vec3(-8.5, 65.0, -35.5), new Vec3(-8.5, 73.0, -49.5)};
    /** Dos sargentos en la entrada de la torre y dos en el pasillo, cerca del portón. */
    private static final Vec3[] PUESTOS_CAMINO = {
            new Vec3(-8.5, 73.0, -49.5),
            new Vec3(-1.5, 65.0, -36.5), new Vec3(2.5, 65.0, -36.5),
            new Vec3(-2.5, 65.0, -8.5), new Vec3(3.5, 65.0, -8.5),
    };
    /** Hacia dónde miran al llegar: el comandante hacia el centro de la torre; los sargentos, hacia la sala. */
    private static final float[] GIROS_CAMINO = {-90.0F, 0.0F, 0.0F, 0.0F, 0.0F};
    /** Si en 30 segundos alguno no llegó (se trabó), aparece en su lugar. */
    private static final int ESPERA_ESCOLTA = 30 * 20;

    private static Fase fase = Fase.NINGUNA;
    private static int tiempo;
    private static int regla;
    private static boolean verde;
    private static int cambio;
    private static int gracia;
    private static int pasoComandante;
    private static final Set<UUID> LLEGARON = new HashSet<>();
    private static final Set<UUID> ELIMINADOS = new HashSet<>();
    private static final Set<UUID> DISTRAIDOS = new HashSet<>();
    private static final Map<UUID, Vec3> QUIETOS = new HashMap<>();
    private static final List<JugadorBot> BOTS = new ArrayList<>();
    private static final List<Guardia> ESCOLTA = new ArrayList<>();
    private static final List<long[]> FORZADOS = new ArrayList<>();
    @Nullable
    private static ServerBossEvent barra;
    /** Si el servidor se cerró en pleno juego, la arena quedó "forzada" (siempre cargada): se libera al volver. */
    private static boolean arenaLiberada;

    private Juego() {
    }

    // ------------------------------------------------------------------ consultas (las usan los bots y los guardias)
    public static boolean enCurso() {
        return fase != Fase.NINGUNA;
    }

    /** Minuto para ir al juego: los bots se juntan en el portón. */
    public static boolean caminando() {
        return fase == Fase.CAMINO;
    }

    /** Hay gente en la arena (reglas, juego o final). */
    public static boolean enArena() {
        return fase == Fase.REGLAS || fase == Fase.JUEGO || fase == Fase.FINAL;
    }

    public static boolean jugando() {
        return fase == Fase.JUEGO;
    }

    public static boolean luzVerde() {
        return fase == Fase.JUEGO && verde;
    }

    public static boolean llego(LivingEntity quien) {
        return LLEGARON.contains(quien.getUUID());
    }

    public static boolean distraido(LivingEntity quien) {
        return DISTRAIDOS.contains(quien.getUUID());
    }

    public static boolean estaEnArena(LivingEntity quien) {
        return quien.getX() > ORIGEN_ARENA.getX() - 20;
    }

    // ------------------------------------------------------------------ eventos
    static void alTick(ServerTickEvent.Post evento) {
        MinecraftServer servidor = evento.getServer();
        ServerLevel complejo = servidor.getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        if (fase == Fase.NINGUNA) {
            if (servidor.getTickCount() % 20 == 0) {
                revisarReloj(servidor, complejo);
            }
            return;
        }
        tiempo++;
        switch (fase) {
            case LLAMADO -> {
                if (tiempo > 2 * MINUTO) {
                    terminar(complejo);                   // la ceremonia no terminó (por ejemplo, mataron al comandante)
                }
            }
            case CAMINO -> camino(complejo);
            case REGLAS -> reglas(complejo);
            case JUEGO -> jugar(complejo);
            case FINAL -> fin(complejo);
            default -> {
            }
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        fase = Fase.NINGUNA;
        arenaLiberada = false;
        limpiarListas();
        barra = null;
        FORZADOS.clear();
    }

    /** El día 1 del ciclo, un minuto después de levantarse, empieza el llamado. */
    private static void revisarReloj(MinecraftServer servidor, ServerLevel complejo) {
        if (!arenaLiberada) {
            FORZADOS.clear();
            for (int cx = ORIGEN_ARENA.getX() >> 4; cx <= (ORIGEN_ARENA.getX() + 101) >> 4; cx++) {
                for (int cz = ORIGEN_ARENA.getZ() >> 4; cz <= (ORIGEN_ARENA.getZ() + 307) >> 4; cz++) {
                    complejo.setChunkForced(cx, cz, false);
                }
            }
            arenaLiberada = true;
        }
        EstadoComplejo estado = EstadoComplejo.de(servidor);
        if (estado.versionSala() != Complejo.VERSION_SALA) {
            return;
        }
        long reloj = servidor.overworld().getDayTime();
        long dia = reloj / 24000L;
        long hora = reloj % 24000L;
        if (dia % Complejo.CICLO_DIAS != 1 || hora < HORA_LLAMADO || hora >= 11000L) {
            return;
        }
        if (estado.ultimoJuego() == dia || Noche.esDeNoche() || Ceremonia.enCurso() || complejo.players().isEmpty()) {
            return;
        }
        llamar(complejo);
    }

    /** Hoy ya se jugó (aunque haya sido con un comando): no se vuelve a llamar a jugar hasta el próximo día de juego. */
    private static void marcarDia(ServerLevel complejo) {
        MinecraftServer servidor = complejo.getServer();
        EstadoComplejo.de(servidor).setUltimoJuego(servidor.overworld().getDayTime() / 24000L);
    }

    // ------------------------------------------------------------------ 1. llamado
    /** Empieza el día de juego desde el llamado del comandante. false si ya hay algo en curso. */
    public static boolean llamar(ServerLevel complejo) {
        if (fase != Fase.NINGUNA || !Ceremonia.empezarLlamado(complejo)) {
            return false;
        }
        limpiarListas();
        marcarDia(complejo);
        cambiarA(Fase.LLAMADO);
        return true;
    }

    /**
     * Lo llama la ceremonia cuando el comandante terminó de hablar y el desfile volvió al pasillo: el comandante
     * se para junto a la puerta 1 de la torre (que se abre) y los sargentos guían el camino.
     */
    static void desfileListo(ServerLevel complejo, List<Guardia> desfile) {
        if (fase != Fase.LLAMADO) {
            desfile.forEach(Guardia::discard);             // el juego se cortó mientras hablaba el comandante
            Ceremonia.cerrarPorton(complejo);
            return;
        }
        ESCOLTA.clear();
        ESCOLTA.addAll(desfile);
        ESCOLTA.forEach(guardia -> guardia.getNavigation().stop());
        pasoComandante = 0;
        moverEscolta(false);                                  // el comandante sale para la torre
        Portales.abrirPuerta(complejo, 1);
        prepararArena(complejo);
        barra = new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.PROGRESS);
        cambiarA(Fase.CAMINO);
    }

    // ------------------------------------------------------------------ 2. un minuto para ir
    private static void camino(ServerLevel complejo) {
        if (tiempo % 10 == 0) {
            moverEscolta(tiempo >= ESPERA_ESCOLTA);
        }
        if (tiempo % 10 == 1 && barra != null) {
            int quedan = Math.max(0, MINUTO - tiempo);
            barra.setName(Component.translatable("barra.juegosdelpatio.camino", reloj(quedan)));
            barra.setProgress(quedan / (float) MINUTO);
            for (ServerPlayer jugador : complejo.players()) {
                barra.addPlayer(jugador);
            }
        }
        if (tiempo >= MINUTO) {
            trasladar(complejo, true);
        }
    }

    /** El comandante camina hasta la puerta 1 (la gente lo sigue) y los sargentos van a marcar el camino. */
    private static void moverEscolta(boolean yaTarde) {
        for (int i = 0; i < ESCOLTA.size() && i < PUESTOS_CAMINO.length; i++) {
            Guardia guardia = ESCOLTA.get(i);
            if (!guardia.isAlive()) {
                continue;
            }
            Vec3 destino = i == 0 ? CAMINO_COMANDANTE[pasoComandante] : PUESTOS_CAMINO[i];
            if (guardia.distanceToSqr(destino) < 1.0) {
                if (i == 0 && pasoComandante < CAMINO_COMANDANTE.length - 1) {
                    pasoComandante++;                                // sigue con el próximo tramo
                    guardia.marcharA(CAMINO_COMANDANTE[pasoComandante], 0.9);
                } else {
                    guardia.getNavigation().stop();
                    guardia.setYRot(GIROS_CAMINO[i]);
                    guardia.setYHeadRot(GIROS_CAMINO[i]);
                    guardia.setYBodyRot(GIROS_CAMINO[i]);
                }
            } else if (yaTarde) {
                Vec3 fin = PUESTOS_CAMINO[i];                        // se trabó: aparece en su lugar
                if (i == 0) {
                    pasoComandante = CAMINO_COMANDANTE.length - 1;
                }
                guardia.getNavigation().stop();
                guardia.moveTo(fin.x, fin.y, fin.z, GIROS_CAMINO[i], 0.0F);
            } else if (guardia.getNavigation().isDone()) {
                guardia.marcharA(destino, i == 0 ? 0.9 : 1.0);
            }
        }
    }

    /** Lleva a la arena a todos los que siguen en el complejo (jugadores y bots) y prepara las reglas. */
    private static void trasladar(ServerLevel complejo, boolean cerrarPuerta) {
        if (!prepararArena(complejo)) {
            terminar(complejo);                                  // sin arena no hay juego (nadie va al vacío)
            return;
        }
        forzarArena(complejo, true);
        RandomSource azar = complejo.getRandom();
        ponerBarreraSalida(complejo, true);
        for (ServerPlayer jugador : List.copyOf(complejo.players())) {
            if (jugador.isAlive() && !estaEnArena(jugador)) {
                Vec3 lugar = lugarDeSalida(azar);
                jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, 0.0F, 0.0F);
                titulo(jugador, Component.empty(), Component.translatable("titulo.juegosdelpatio.te_llevaron")
                        .withStyle(ChatFormatting.GRAY), 10, 40, 10);
            }
        }
        BOTS.clear();
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive())) {
            Vec3 lugar = lugarDeSalida(azar);
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
            bot.moveTo(lugar.x, lugar.y, lugar.z, azar.nextFloat() * 40.0F - 20.0F, 0.0F);
            BOTS.add(bot);
        }
        // el comandante a su podio y los sargentos a los costados del campo
        Vec3[] lugares = {
                new Vec3(1042.5, 103.0, 4.5),
                new Vec3(952.5, 100.0, 75.5), new Vec3(1047.5, 100.0, 75.5),
                new Vec3(952.5, 100.0, 175.5), new Vec3(1047.5, 100.0, 175.5),
        };
        float[] giros = {90.0F, -90.0F, 90.0F, -90.0F, 90.0F};
        for (int i = 0; i < ESCOLTA.size() && i < lugares.length; i++) {
            Guardia guardia = ESCOLTA.get(i);
            if (guardia.isAlive()) {
                guardia.getNavigation().stop();
                guardia.moveTo(lugares[i].x, lugares[i].y, lugares[i].z, giros[i], 0.0F);
            }
        }
        if (cerrarPuerta) {
            Portales.cerrarPuerta(complejo, 1);
            Ceremonia.cerrarPorton(complejo);
        }
        if (barra != null) {
            barra.removeAllPlayers();
        }
        barra = new ServerBossEvent(Component.translatable("juego.juegosdelpatio.nombre_1"),
                BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);
        ponerSemaforos(complejo, false, true);
        regla = 0;
        cambiarA(Fase.REGLAS);
    }

    // ------------------------------------------------------------------ 3. reglas
    private static void reglas(ServerLevel complejo) {
        if (tiempo % 20 == 1) {
            mostrarBarra(complejo, 1.0F);
        }
        if (tiempo < 40 || (tiempo - 40) % TICKS_POR_REGLA != 0) {
            return;
        }
        if (regla < REGLAS.length) {
            String clave = "juego.juegosdelpatio." + REGLAS[regla];
            decir(complejo, REGLAS[regla].equals("reglas_5")
                    ? Component.translatable(clave, DURACION_JUEGO / MINUTO) : Component.translatable(clave));
            regla++;
            return;
        }
        // ¡que empiece el juego!
        ponerBarreraSalida(complejo, false);
        LLEGARON.clear();
        ELIMINADOS.clear();
        cambiarA(Fase.JUEGO);
        cambiarLuz(complejo, true);
    }

    // ------------------------------------------------------------------ 4. el juego
    private static void jugar(ServerLevel complejo) {
        if (tiempo >= DURACION_JUEGO) {
            finDelTiempo(complejo);
            return;
        }
        if (tiempo % 10 == 0) {
            mostrarBarra(complejo, 1.0F - tiempo / (float) DURACION_JUEGO);
        }
        if (--cambio <= 0) {
            cambiarLuz(complejo, !verde);
        }
        List<LivingEntity> enJuego = participantes(complejo);
        for (LivingEntity quien : enJuego) {
            if (quien.getZ() >= META_Z && LLEGARON.add(quien.getUUID()) && quien instanceof ServerPlayer jugador) {
                titulo(jugador, Component.translatable("titulo.juegosdelpatio.pasaste").withStyle(ChatFormatting.GREEN),
                        Component.translatable("titulo.juegosdelpatio.a_la_meta").withStyle(ChatFormatting.GRAY), 5, 50, 15);
                jugador.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
            }
        }
        if (verde) {
            return;
        }
        if (gracia > 0) {
            if (--gracia == 0) {
                QUIETOS.clear();
                for (LivingEntity quien : enJuego) {
                    QUIETOS.put(quien.getUUID(), quien.position());       // desde ahora, nadie se mueve
                }
            }
            return;
        }
        for (LivingEntity quien : enJuego) {
            Vec3 antes = QUIETOS.get(quien.getUUID());
            if (antes == null || LLEGARON.contains(quien.getUUID())) {
                continue;
            }
            double dx = quien.getX() - antes.x;
            double dz = quien.getZ() - antes.z;
            if (dx * dx + dz * dz > MOVIMIENTO * MOVIMIENTO || Math.abs(quien.getY() - antes.y) > 0.3) {
                eliminar(complejo, quien);
            }
        }
    }

    private static void cambiarLuz(ServerLevel complejo, boolean ahoraVerde) {
        RandomSource azar = complejo.getRandom();
        verde = ahoraVerde;
        cambio = verde ? 60 + azar.nextInt(81) : 50 + azar.nextInt(61);
        ponerSemaforos(complejo, verde, !verde);
        DISTRAIDOS.clear();
        if (!verde) {
            gracia = GRACIA;
            for (JugadorBot bot : BOTS) {
                if (bot.isAlive() && !LLEGARON.contains(bot.getUUID()) && azar.nextInt(100) < DISTRAIDOS_POR_CIENTO) {
                    DISTRAIDOS.add(bot.getUUID());                       // este no va a frenar a tiempo
                }
            }
        }
        Component titulo = verde
                ? Component.translatable("titulo.juegosdelpatio.luz_verde").withStyle(ChatFormatting.GREEN)
                : Component.translatable("titulo.juegosdelpatio.luz_roja").withStyle(ChatFormatting.RED);
        for (ServerPlayer jugador : jugadoresEnArena(complejo)) {
            if (!LLEGARON.contains(jugador.getUUID())) {
                titulo(jugador, titulo, Component.empty(), 2, 20, 6);
            }
            jugador.playNotifySound(verde ? SoundEvents.BELL_BLOCK : SoundEvents.ANVIL_LAND, SoundSource.MASTER,
                    verde ? 1.0F : 0.6F, verde ? 1.6F : 0.7F);
        }
        if (barra != null) {
            barra.setColor(verde ? BossEvent.BossBarColor.GREEN : BossEvent.BossBarColor.RED);
        }
    }

    /** Disparo: el que se movió (o no llegó) muere. Los jugadores reaparecen en el mundo normal. */
    private static void eliminar(ServerLevel complejo, LivingEntity quien) {
        if (!ELIMINADOS.add(quien.getUUID())) {
            return;
        }
        complejo.playSound(null, quien.getX(), quien.getY(), quien.getZ(), SoundEvents.FIREWORK_ROCKET_BLAST,
                SoundSource.HOSTILE, 3.0F, 1.4F);
        complejo.sendParticles(ParticleTypes.SMOKE, quien.getX(), quien.getY(1.0), quien.getZ(), 10, 0.2, 0.4, 0.2, 0.02);
        if (quien instanceof ServerPlayer jugador) {
            if (barra != null) {
                barra.removePlayer(jugador);
            }
            if (!jugador.getRespawnDimension().equals(Level.OVERWORLD)) {
                jugador.setRespawnPosition(Level.OVERWORLD, null, 0.0F, false, false);   // reaparece en el mundo normal
            }
            jugador.kill();
        } else {
            quien.kill();
        }
    }

    // ------------------------------------------------------------------ 5. final
    private static void finDelTiempo(ServerLevel complejo) {
        ponerSemaforos(complejo, false, true);
        decir(complejo, Component.translatable("juego.juegosdelpatio.fin_tiempo"));
        for (LivingEntity quien : participantes(complejo)) {
            if (!LLEGARON.contains(quien.getUUID())) {
                eliminar(complejo, quien);
            }
        }
        if (barra != null) {
            barra.setName(Component.translatable("barra.juegosdelpatio.fin"));
            barra.setProgress(0.0F);
            barra.setColor(BossEvent.BossBarColor.RED);
        }
        cambiarA(Fase.FINAL);
    }

    private static void fin(ServerLevel complejo) {
        if (tiempo == 60) {
            decir(complejo, Component.translatable("juego.juegosdelpatio.felicitaciones"));
        }
        if (tiempo >= 140) {
            terminar(complejo);
        }
    }

    /** Todos los que siguen vivos en la arena vuelven a la sala, y se deja todo listo para la próxima vez. */
    static void terminar(ServerLevel complejo) {
        RandomSource azar = complejo.getRandom();
        for (ServerPlayer jugador : List.copyOf(complejo.players())) {
            if (estaEnArena(jugador) && jugador.isAlive()) {
                Complejo.llevarALaSala(jugador);
            }
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive() && estaEnArena(bot))) {
            Vec3 lugar = Complejo.lugarAlAzar(azar);
            bot.getNavigation().stop();
            bot.moveTo(lugar.x, lugar.y, lugar.z, azar.nextFloat() * 360.0F, 0.0F);
        }
        for (Guardia guardia : ESCOLTA) {
            guardia.discard();
        }
        if (Portales.puertaAbierta(complejo, 1)) {
            Portales.cerrarPuerta(complejo, 1);
        }
        Ceremonia.cerrarPorton(complejo);
        if (barra != null) {
            barra.removeAllPlayers();
            barra = null;
        }
        if (EstadoComplejo.de(complejo.getServer()).versionArena() == VERSION_ARENA) {
            ponerBarreraSalida(complejo, true);
            ponerSemaforos(complejo, false, false);
        }
        forzarArena(complejo, false);
        limpiarListas();
        cambiarA(Fase.NINGUNA);
    }

    // ------------------------------------------------------------------ comandos
    /** Saltea el llamado: lleva a todos a la arena y empieza con las reglas. */
    public static boolean empezarYa(ServerLevel complejo) {
        if (fase != Fase.NINGUNA || !Complejo.prepararComplejo(complejo, false)) {
            return false;
        }
        limpiarListas();
        if (!prepararArena(complejo)) {
            return false;
        }
        forzarArena(complejo, true);
        for (int i = 0; i < 5; i++) {
            Guardia guardia = Complejo.invocarGuardia(complejo, new Vec3(1042.5, 103.0, 4.5), 90.0F,
                    i == 0 ? Rango.COMANDANTE : Rango.SARGENTO, -1);
            if (guardia != null) {
                guardia.hacerEscolta();
                guardia.setCustomNameVisible(i == 0);
                ESCOLTA.add(guardia);
            }
        }
        marcarDia(complejo);
        trasladar(complejo, false);
        return true;
    }

    /** Corta el juego: nadie queda eliminado y todos vuelven a la sala. */
    public static boolean parar(ServerLevel complejo) {
        if (fase == Fase.NINGUNA) {
            return false;
        }
        terminar(complejo);
        return true;
    }

    // ------------------------------------------------------------------ portal de la puerta 1
    /** Dónde aparece quien entra por el portal 1 (y quien es llevado): la zona de salida de la arena. */
    public static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(952.5 + azar.nextInt(85), 100.0, 1.5 + azar.nextInt(8));
    }

    /**
     * Construye la arena la primera vez (y saca la plataforma provisoria que había antes en ese lugar).
     * false si no se pudo (falta la estructura en el mod).
     */
    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estado = EstadoComplejo.de(complejo.getServer());
        if (estado.versionArena() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        for (BlockPos pos : BlockPos.betweenClosed(987, 99, -14, 1013, 105, 14)) {
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN_ARENA, ORIGEN_ARENA, new StructurePlaceSettings(),
                complejo.getRandom(), Block.UPDATE_CLIENTS);
        for (int x = 999; x <= 1001; x++) {
            for (int y = 100; y <= 103; y++) {
                complejo.setBlock(new BlockPos(x, y, -2), Blocks.BARRIER.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        estado.setVersionArena(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Luz verde, luz roja colocada en {}", ORIGEN_ARENA);
        return true;
    }

    // ------------------------------------------------------------------ ayudas
    private static void cambiarA(Fase nueva) {
        fase = nueva;
        tiempo = 0;
    }

    private static void limpiarListas() {
        LLEGARON.clear();
        ELIMINADOS.clear();
        DISTRAIDOS.clear();
        QUIETOS.clear();
        BOTS.clear();
        ESCOLTA.clear();
    }

    private static List<ServerPlayer> jugadoresEnArena(ServerLevel complejo) {
        List<ServerPlayer> lista = new ArrayList<>();
        for (ServerPlayer jugador : complejo.players()) {
            if (estaEnArena(jugador)) {
                lista.add(jugador);
            }
        }
        return lista;
    }

    /** Jugadores (en supervivencia o aventura) y bots que siguen en juego. */
    private static List<LivingEntity> participantes(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>();
        for (ServerPlayer jugador : jugadoresEnArena(complejo)) {
            if (jugador.isAlive() && !jugador.isSpectator() && !jugador.isCreative() && !ELIMINADOS.contains(jugador.getUUID())) {
                lista.add(jugador);
            }
        }
        for (JugadorBot bot : BOTS) {
            if (bot.isAlive() && !ELIMINADOS.contains(bot.getUUID())) {
                lista.add(bot);
            }
        }
        return lista;
    }

    private static void mostrarBarra(ServerLevel complejo, float progreso) {
        if (barra == null) {
            return;
        }
        int quedan = 0;
        for (LivingEntity quien : participantes(complejo)) {
            if (!LLEGARON.contains(quien.getUUID())) {
                quedan++;
            }
        }
        if (fase == Fase.JUEGO) {
            barra.setName(Component.translatable("barra.juegosdelpatio.juego",
                    reloj(Math.max(0, DURACION_JUEGO - tiempo)), quedan));
        }
        barra.setProgress(Math.max(0.0F, Math.min(1.0F, progreso)));
        List<ServerPlayer> enArena = jugadoresEnArena(complejo);
        for (ServerPlayer jugador : List.copyOf(barra.getPlayers())) {
            if (!enArena.contains(jugador) || ELIMINADOS.contains(jugador.getUUID())) {
                barra.removePlayer(jugador);             // se fue, se desconectó o quedó eliminado
            }
        }
        for (ServerPlayer jugador : enArena) {
            if (jugador.isAlive() && !ELIMINADOS.contains(jugador.getUUID())) {
                barra.addPlayer(jugador);
            }
        }
    }

    private static String reloj(int ticks) {
        int segundos = (ticks + 19) / 20;
        return segundos / 60 + ":" + (segundos % 60 < 10 ? "0" : "") + segundos % 60;
    }

    private static void decir(ServerLevel complejo, Component texto) {
        MutableComponent mensaje = Component.literal("<").append(Rango.COMANDANTE.nombre())
                .append(Component.literal("> "))
                .append(Component.empty().append(texto).withStyle(ChatFormatting.YELLOW));
        for (ServerPlayer jugador : complejo.players()) {
            jugador.sendSystemMessage(mensaje);
        }
    }

    private static void titulo(ServerPlayer jugador, Component titulo, Component subtitulo, int entrada, int queda, int salida) {
        jugador.connection.send(new ClientboundSetTitlesAnimationPacket(entrada, queda, salida));
        jugador.connection.send(new ClientboundSetSubtitleTextPacket(subtitulo));
        jugador.connection.send(new ClientboundSetTitleTextPacket(titulo));
    }

    /** Prende o apaga las lámparas del semáforo gigante y de los semáforos chicos de los costados. */
    private static void ponerSemaforos(ServerLevel complejo, boolean verdePrendido, boolean rojoPrendido) {
        if (EstadoComplejo.de(complejo.getServer()).versionArena() != VERSION_ARENA) {
            return;
        }
        BlockState verdeSi = Blocks.LIME_CONCRETE.defaultBlockState();
        BlockState verdeNo = Blocks.GREEN_TERRACOTTA.defaultBlockState();
        BlockState rojoSi = Blocks.RED_CONCRETE.defaultBlockState();
        BlockState rojoNo = Blocks.RED_TERRACOTTA.defaultBlockState();
        for (int x = SEM_X0; x <= SEM_X1; x++) {
            for (int d = 0; d < 7; d++) {
                complejo.setBlock(new BlockPos(x, VERDE_Y0 + d, SEM_Z), verdePrendido ? verdeSi : verdeNo, Block.UPDATE_CLIENTS);
                complejo.setBlock(new BlockPos(x, ROJO_Y0 + d, SEM_Z), rojoPrendido ? rojoSi : rojoNo, Block.UPDATE_CLIENTS);
            }
        }
        for (int x : LADOS_X) {
            for (int zc : LADOS_Z) {
                for (int z = zc - 1; z <= zc + 1; z++) {
                    for (int y = 103; y <= 104; y++) {
                        complejo.setBlock(new BlockPos(x, y, z), verdePrendido ? verdeSi : verdeNo, Block.UPDATE_CLIENTS);
                    }
                    for (int y = 106; y <= 107; y++) {
                        complejo.setBlock(new BlockPos(x, y, z), rojoPrendido ? rojoSi : rojoNo, Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
    }

    /** La barrera invisible de la línea de salida (se saca cuando empieza el juego). */
    private static void ponerBarreraSalida(ServerLevel complejo, boolean poner) {
        BlockState estado = poner ? Blocks.BARRIER.defaultBlockState() : Blocks.AIR.defaultBlockState();
        for (int x = 950; x <= 1049; x++) {
            for (int y = 100; y <= 103; y++) {
                complejo.setBlock(new BlockPos(x, y, 10), estado, Block.UPDATE_CLIENTS);
            }
        }
    }

    /** Mantiene cargada toda la arena mientras se juega (para que los bots de atrás también se muevan). */
    private static void forzarArena(ServerLevel complejo, boolean forzar) {
        if (forzar) {
            FORZADOS.clear();
            for (int cx = ORIGEN_ARENA.getX() >> 4; cx <= (ORIGEN_ARENA.getX() + 101) >> 4; cx++) {
                for (int cz = ORIGEN_ARENA.getZ() >> 4; cz <= (ORIGEN_ARENA.getZ() + 307) >> 4; cz++) {
                    complejo.setChunkForced(cx, cz, true);
                    complejo.getChunk(cx, cz);
                    FORZADOS.add(new long[] {cx, cz});
                }
            }
        } else {
            for (long[] chunk : FORZADOS) {
                complejo.setChunkForced((int) chunk[0], (int) chunk[1], false);
            }
            FORZADOS.clear();
        }
    }
}
