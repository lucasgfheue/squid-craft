package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetExperiencePacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.joml.Vector3f;

/**
 * El día de juego. Hay dos juegos hechos: el 1, "Luz verde, luz roja", que se juega el día 1 del ciclo (el día
 * después de la entrada: 1, 7, 13...), y el 2, "Las sillas musicales" (día 2, 8, 14...; ver {@link Sillas}). El
 * llamado, el minuto para ir, las reglas y el final son iguales para los dos; cambia la puerta de la torre, la
 * arena y el juego en sí. Lo que sigue es el juego 1:
 *
 * <ol>
 *   <li>LLAMADO: un minuto después de que se prenden las luces, si hay jugadores en el complejo, entra el
 *       comandante con sus cuatro sargentos (la ceremonia de tipo llamado) y avisa que empieza el juego.
 *       Vuelven al pasillo y la puerta 1 de la torre se abre como portal.</li>
 *   <li>CAMINO: hay un minuto para entrar por el portal (se ve una barra con el tiempo). El comandante sube
 *       caminando hasta la puerta 1 y entra al portal; los bots lo siguen y los sargentos marcan el camino.
 *       Cuando se termina el minuto, todos los que siguen en el complejo pasan solos a la arena.</li>
 *   <li>REGLAS: el comandante, desde su podio, explica las reglas.</li>
 *   <li>JUEGO: 3 minutos (en pantalla). Al fondo está el Vigía, un gigante de espaldas: luz verde, se avanza.
 *       Cuando se da vuelta (luz roja) hay que quedarse quieto: quien se mueve queda eliminado (muere y
 *       reaparece en el mundo normal). Algunos bots empujan a otros (jugadores o bots) con la luz roja, más
 *       a quien les tienen rencor. En el juego no se puede pegar: solo empujar (clic derecho, cada 5 segundos),
 *       y algunos de los que llegan empujan para atrás a los que quieren cruzar.</li>
 *   <li>FINAL: los que no cruzaron la meta también quedan eliminados; los que pasaron vuelven a la sala.</li>
 * </ol>
 */
public final class Juego {
    private enum Fase { NINGUNA, LLAMADO, CAMINO, REGLAS, JUEGO, FINAL }

    /** Cuántos juegos están hechos: el 1 y el 2 (los días de los juegos 3 a 5 todavía no pasa nada). */
    public static final int JUEGOS_HECHOS = 2;
    /** Qué juego se está jugando (o se jugó por última vez): 1 Luz verde, luz roja; 2 Las sillas musicales. */
    private static int numero = 1;
    /** De qué juego son los últimos resultados. */
    private static int ultimoNumero = 1;
    /** Si un juego de las sillas se traba, a los 8 minutos se termina igual. */
    private static final int DURACION_MAX_SILLAS = 8 * 60 * 20;
    private static final String[] REGLAS_SILLAS = {"sillas_1", "sillas_2", "sillas_3", "sillas_4", "sillas_5",
            "sillas_6", "sillas_8", "sillas_7", "reglas_7"};
    /** A la puerta 2: la misma escalera; pasa por el descanso de la puerta 1 y sube un tramo más. */
    private static final Vec3[] CAMINO_COMANDANTE_2 = {new Vec3(-8.5, 65.0, -35.5), new Vec3(-8.5, 73.0, -46.5),
            new Vec3(-7.5, 73.0, -51.5), new Vec3(4.5, 81.0, -51.5)};
    /** La celda del medio del portal de la puerta 2. */
    private static final BlockPos PORTAL_2 = new BlockPos(4, 81, -54);

    public static final ResourceLocation ARENA = Complejo.id("luz_verde");
    /** Esquina de la plantilla luz_verde.nbt (102 x 33 x 308). */
    public static final BlockPos ORIGEN_ARENA = new BlockPos(949, 99, -1);
    public static final int VERSION_ARENA = 2;
    /** Cruzar esta z es llegar a la meta. */
    public static final double META_Z = 290.0;
    /** El podio del comandante, en la salida. */
    static final Vec3 PODIO = new Vec3(1042.5, 103.0, 4.5);
    /** El visor del Vigía: de ahí sale el rayo cuando ve moverse a alguien. */
    private static final Vec3 VISOR = new Vec3(1000.0, 130.5, 297.6);
    /** Un minuto después de que empieza el día (hora 1200 del mundo normal) llega el comandante. */
    public static final long HORA_LLAMADO = 1200L;
    public static final int MINUTO = 60 * 20;
    public static final int DURACION_JUEGO = 3 * 60 * 20;
    private static final int GRACIA = 15;                 // tiempo para frenar cuando se pone en rojo
    /** Si te pega algo que no es un jugador ni un bot (un guardia), lo que te corre el golpe no cuenta. */
    private static final int PERDON_GOLPE = 15;
    /** Tiempo de espera entre empujón y empujón: 5 segundos, para todos (jugadores y bots). */
    static final int ESPERA_EMPUJON = 5 * 20;
    /** Cuánto se puede correr alguien con luz roja sin quedar eliminado (por los empujones de la gente). */
    private static final double MOVIMIENTO = 0.2;
    /** Mover la cabeza (la cámara) también cuenta: más de 3 grados, para cualquier lado, y quedas eliminado. */
    private static final float GIRO_CABEZA = 3.0F;
    /** En cada luz roja, de cada 100 bots que siguen jugando, unos 2 no frenan a tiempo. */
    private static final int DISTRAIDOS_POR_CIENTO = 2;
    /** Hasta dónde llega un empujón, y en cuántas de cada 100 luces rojas se anima el que empuja. */
    private static final double ALCANCE_EMPUJE = 2.3;
    private static final int EMPUJA_POR_CIENTO = 55;
    /** Cuántos diamantes sube el premio por cada eliminado (jugador o bot). */
    static final int PREMIO_POR_ELIMINADO = 10;
    /** Bots que empujan a otros bots: uno por cada tantos de los que siguen jugando. */
    private static final int BOTS_POR_EMPUJADOR = 50;
    /** De cada 100 bots que cruzan la meta, unos 25 se quedan a no dejar pasar (como mucho 8 a la vez). */
    private static final int BLOQUEAN_POR_CIENTO = 25;
    private static final int MAX_BLOQUEADORES = 8;
    private static final int TICKS_POR_REGLA = 70;
    private static final String[] REGLAS = {"reglas_1", "reglas_2", "reglas_3", "reglas_4", "reglas_5", "reglas_6",
            "reglas_7"};

    // luces de las paredes (deben coincidir con gen_luz_verde.py)
    private static final int LUZ_Y0 = 104;
    private static final int LUZ_Y1 = 107;
    private static final int APAGADA = 0;
    private static final int VERDE = 1;
    private static final int ROJA = 2;
    private static final int[] LADOS_X = {949, 1050};
    private static final int[] LADOS_Z = {35, 85, 135, 185, 235, 285};

    // el minuto para ir: a dónde camina cada uno del desfile (0 = comandante, 1..4 = sargentos)
    /**
     * El comandante sube a la puerta 1 en dos tramos (el pie de la escalera de la torre y el descanso frente a la
     * puerta) y después entra al portal.
     */
    private static final Vec3[] CAMINO_COMANDANTE = {new Vec3(-8.5, 65.0, -35.5), new Vec3(-8.5, 73.0, -46.5)};
    /** La celda del medio del portal de la puerta 1. */
    private static final BlockPos PORTAL_1 = new BlockPos(-10, 73, -48);
    /** Dos sargentos en la entrada de la torre y dos en el pasillo, cerca del portón (el 0 es el comandante). */
    private static final Vec3[] PUESTOS_CAMINO = {
            new Vec3(-8.5, 73.0, -46.5),
            new Vec3(-1.5, 65.0, -36.5), new Vec3(2.5, 65.0, -36.5),
            new Vec3(-2.5, 65.0, -8.5), new Vec3(3.5, 65.0, -8.5),
    };
    /** Hacia dónde miran al llegar: los sargentos, hacia la sala. */
    private static final float[] GIROS_CAMINO = {-90.0F, 0.0F, 0.0F, 0.0F, 0.0F};
    /** Si en 30 segundos alguno no llegó (se trabó), aparece en su lugar. */
    private static final int ESPERA_ESCOLTA = 30 * 20;

    private static Fase fase = Fase.NINGUNA;
    private static int tiempo;
    private static int regla;
    private static boolean verde;
    private static int cambio;
    private static int gracia;
    private static int pasoComandante;
    /** Cómo terminó el último juego (para el discurso de resultados), y cuánto falta para que vuelva el comandante. */
    private static int ultimosLlegaron;
    private static int ultimosEliminados;
    private static int resultadosEn;
    private static final int ESPERA_RESULTADOS = 10 * 20;
    private static int lucesVerdes;
    private static final Set<UUID> LLEGARON = new HashSet<>();
    private static final Set<UUID> ELIMINADOS = new HashSet<>();
    private static final Set<UUID> DISTRAIDOS = new HashSet<>();
    private static final Map<UUID, Vec3> QUIETOS = new HashMap<>();
    /** Para dónde miraba cada jugador cuando se puso en rojo (giro y altura de la cabeza). */
    private static final Map<UUID, float[]> MIRADAS = new HashMap<>();
    private static final List<JugadorBot> BOTS = new ArrayList<>();
    private static final List<Guardia> ESCOLTA = new ArrayList<>();
    private static final List<long[]> FORZADOS = new ArrayList<>();
    /** Bots que empujan -> a quién (un jugador o un bot); y, en esta luz roja, cuánto falta para el empujón. */
    private static final Map<UUID, UUID> EMPUJADORES = new HashMap<>();
    private static final Map<UUID, Integer> EMPUJE_EN = new HashMap<>();
    /** A quién empujaron en esta luz roja, y quién (para avisarle al jugador). */
    private static final Map<UUID, String> EMPUJADO_POR = new HashMap<>();
    /** Bots que ya cruzaron y no dejan pasar a los demás, y en qué lugar de la meta se paran. */
    private static final Set<UUID> BLOQUEADORES = new HashSet<>();
    private static final Map<UUID, Double> PUESTO_BLOQUEO = new HashMap<>();
    private static final Map<UUID, JugadorBot> BOTS_POR_ID = new HashMap<>();
    /** Rencor de los bots con cada jugador (sube cuando muere un bot al que le pegó). No se borra entre juegos. */
    private static final Map<UUID, Integer> RENCOR = new HashMap<>();
    /** Bots (y el comandante) que tocaron el portal de la puerta 1: pasan a la arena al final del tick. */
    private static final List<LivingEntity> ENTRAN = new ArrayList<>();
    /**
     * Correr cansa (a los jugadores, no a los bots, y solo en el juego): con el aire lleno se puede correr 3
     * segundos seguidos; sin correr, se recupera de a poco. Si se vacía, te cansas y no puedes correr hasta que
     * se llene otra vez (5 segundos). La barra de experiencia muestra el aire mientras se juega.
     */
    private static final int AIRE_MAX = 300;
    /** Corriendo se gasta en 3 segundos (5 por tick); sin correr se llena en 5 segundos (3 por tick). */
    private static final int GASTO_AIRE = 5;
    private static final int RECARGA_AIRE = 3;
    private static final Map<UUID, Integer> AIRE = new HashMap<>();
    /**
     * Los que se cansaron, y cuánta comida tenían de verdad: mientras están cansados se les deja la comida en 3
     * muslos (6 puntos), que es lo que hace que Minecraft no deje correr. Después se les devuelve tal cual.
     */
    private static final Map<UUID, Integer> CANSADOS = new HashMap<>();
    private static final int COMIDA_SIN_CORRER = 6;
    /**
     * Cansancio de comida de más por cada tick corriendo en el juego (correr ya gasta ~0,028 por tick): unas 2,5 veces
     * más hambre que corriendo afuera. Una carrera de 3 s gasta cerca de medio muslo.
     */
    private static final float HAMBRE_CORRIENDO = 0.04F;
    /** Cuándo empujó cada uno (jugador o bot) por última vez. */
    private static final Map<UUID, Long> ULTIMO_EMPUJON = new HashMap<>();
    /** Los que recibieron un golpe de un guardia con la luz roja: por unos ticks no se les mira si se mueven. */
    private static final Map<UUID, Integer> GOLPEADOS = new HashMap<>();
    @Nullable
    private static ServerBossEvent barra;
    /** Si el servidor se cerró en pleno juego, la arena quedó "forzada" (siempre cargada): se libera al volver. */
    private static boolean arenaLiberada;
    /**
     * El dormitorio, el pasillo y la torre, en chunks (x -32..32, z -54..68). En el minuto para ir se mantienen
     * cargados: si no, cuando los jugadores entran al portal, los bots que quedaron en la sala se "congelan" y al
     * terminar el minuto no se los encuentra para llevarlos a la arena.
     */
    private static final int SALA_CX0 = -2;
    private static final int SALA_CX1 = 2;
    private static final int SALA_CZ0 = -4;
    private static final int SALA_CZ1 = 4;
    private static boolean salaForzada;

    private Juego() {
    }

    // ------------------------------------------------------------------ consultas (las usan los bots y los guardias)
    public static boolean enCurso() {
        return fase != Fase.NINGUNA;
    }

    /** Qué juego es: 1 Luz verde, luz roja; 2 Las sillas musicales. */
    public static int numero() {
        return numero;
    }

    /** ¿Este juego ya tiene su arena hecha? */
    static boolean tieneArena(int juego) {
        return juego >= 1 && juego <= JUEGOS_HECHOS;
    }

    /** Terminó el juego y en unos segundos vuelve el comandante con los resultados. */
    static boolean resultadosPendientes() {
        return resultadosEn > 0;
    }

    /** Minuto para ir al juego: los bots se juntan en el portón. */
    public static boolean caminando() {
        return fase == Fase.CAMINO;
    }

    /** Hay gente en la arena (reglas, juego o final). */
    public static boolean enArena() {
        return fase == Fase.REGLAS || fase == Fase.JUEGO || fase == Fase.FINAL;
    }

    public static boolean jugando() {
        return fase == Fase.JUEGO;
    }

    public static boolean luzVerde() {
        return fase == Fase.JUEGO && verde;
    }

    public static boolean llego(LivingEntity quien) {
        return LLEGARON.contains(quien.getUUID());
    }

    public static boolean distraido(LivingEntity quien) {
        return DISTRAIDOS.contains(quien.getUUID());
    }

    public static boolean estaEnArena(LivingEntity quien) {
        return quien.getX() > ORIGEN_ARENA.getX() - 20;
    }

    // ------------------------------------------------------------------ eventos
    static void alTick(ServerTickEvent.Post evento) {
        MinecraftServer servidor = evento.getServer();
        ServerLevel complejo = servidor.getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        avisarEmpujones(servidor);
        if (fase == Fase.NINGUNA) {
            if (resultadosEn > 0 && --resultadosEn == 0 && !empezarResultados(complejo)
                    && !complejo.players().isEmpty()) {
                resultadosEn = 20;                          // la ceremonia estaba ocupada: prueba de nuevo en un segundo
            }
            if (servidor.getTickCount() % 20 == 0) {
                revisarReloj(servidor, complejo);
            }
            return;
        }
        tiempo++;
        if (!ENTRAN.isEmpty()) {
            List<LivingEntity> entran = List.copyOf(ENTRAN);
            ENTRAN.clear();
            entran.forEach(quien -> entrar(complejo, quien));
        }
        if (enArena() && numero == 1) {
            Vigia.tick(complejo);                              // el gigante gira la cabeza de a poco
        }
        switch (fase) {
            case LLAMADO -> {
                if (tiempo > 2 * MINUTO) {
                    terminar(complejo);                   // la ceremonia no terminó (por ejemplo, mataron al comandante)
                }
            }
            case CAMINO -> camino(complejo);
            case REGLAS -> reglas(complejo);
            case JUEGO -> jugar(complejo);
            case FINAL -> fin(complejo);
            default -> {
            }
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        fase = Fase.NINGUNA;
        arenaLiberada = false;
        salaForzada = false;
        resultadosEn = 0;
        limpiarListas();
        RENCOR.clear();
        ULTIMO_EMPUJON.clear();
        AIRE.clear();
        CANSADOS.clear();
        Vigia.olvidar();
        Sillas.olvidar();
        barra = null;
        FORZADOS.clear();
        numero = 1;
        ultimoNumero = 1;
    }

    /** El día 1 del ciclo, un minuto después de levantarse, empieza el llamado. */
    private static void revisarReloj(MinecraftServer servidor, ServerLevel complejo) {
        if (!arenaLiberada) {
            FORZADOS.clear();
            for (int cx = ORIGEN_ARENA.getX() >> 4; cx <= (ORIGEN_ARENA.getX() + 101) >> 4; cx++) {
                for (int cz = ORIGEN_ARENA.getZ() >> 4; cz <= (ORIGEN_ARENA.getZ() + 307) >> 4; cz++) {
                    complejo.setChunkForced(cx, cz, false);
                }
            }
            for (int cx = SALA_CX0; cx <= SALA_CX1; cx++) {
                for (int cz = SALA_CZ0; cz <= SALA_CZ1; cz++) {
                    complejo.setChunkForced(cx, cz, false);
                }
            }
            for (int cx = Sillas.X0 >> 4; cx <= Sillas.X1 >> 4; cx++) {
                for (int cz = Sillas.Z0 >> 4; cz <= Sillas.Z1 >> 4; cz++) {
                    complejo.setChunkForced(cx, cz, false);
                }
            }
            arenaLiberada = true;
        }
        EstadoComplejo estado = EstadoComplejo.de(servidor);
        if (estado.versionSala() != Complejo.VERSION_SALA) {
            return;
        }
        long reloj = servidor.overworld().getDayTime();
        long dia = reloj / 24000L;
        long hora = reloj % 24000L;
        int hoy = (int) (dia % Complejo.CICLO_DIAS);                   // el día 1 el juego 1, el día 2 el juego 2...
        if (!tieneArena(hoy) || hora < HORA_LLAMADO || hora >= 11000L) {
            return;
        }
        if (estado.ultimoJuego() == dia || Noche.esDeNoche() || Ceremonia.enCurso() || Comida.enCurso()
                || complejo.players().isEmpty()) {
            return;
        }
        llamar(complejo, hoy);
    }

    /** Hoy ya se jugó (aunque haya sido con un comando): no se vuelve a llamar a jugar hasta el próximo día de juego. */
    private static void marcarDia(ServerLevel complejo) {
        MinecraftServer servidor = complejo.getServer();
        EstadoComplejo.de(servidor).setUltimoJuego(servidor.overworld().getDayTime() / 24000L);
    }

    // ------------------------------------------------------------------ 1. llamado
    /** Empieza el día del juego {@code juego} desde el llamado del comandante. false si ya hay algo en curso. */
    public static boolean llamar(ServerLevel complejo, int juego) {
        if (fase != Fase.NINGUNA || !tieneArena(juego) || !Ceremonia.empezarLlamado(complejo, juego)) {
            return false;
        }
        numero = juego;
        limpiarListas();
        marcarDia(complejo);
        cambiarA(Fase.LLAMADO);
        return true;
    }

    /**
     * Lo llama la ceremonia cuando el comandante terminó de hablar y el desfile volvió al pasillo: se abre la
     * puerta 1 de la torre, el comandante va hasta ella y entra al portal, y los sargentos guían el camino.
     */
    static void desfileListo(ServerLevel complejo, List<Guardia> desfile) {
        if (fase != Fase.LLAMADO) {
            desfile.forEach(Guardia::discard);             // el juego se cortó mientras hablaba el comandante
            Ceremonia.cerrarPorton(complejo);
            return;
        }
        ESCOLTA.clear();
        ESCOLTA.addAll(desfile);
        ESCOLTA.forEach(guardia -> guardia.getNavigation().stop());
        pasoComandante = 0;
        moverEscolta(complejo, false);                        // el comandante sale para la torre
        Portales.abrirPuerta(complejo, numero);
        if (prepararArena(complejo, numero)) {
            forzarArena(complejo, true);                      // los que entran antes ya pueden esperar en la arena
        }
        forzarSala(complejo, true);                           // y los bots de la sala siguen cargados aunque no quede nadie
        barra = new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.PROGRESS);
        cambiarA(Fase.CAMINO);
    }

    // ------------------------------------------------------------------ 2. un minuto para ir
    private static void camino(ServerLevel complejo) {
        if (tiempo % 10 == 0) {
            moverEscolta(complejo, tiempo >= ESPERA_ESCOLTA);
        }
        if (tiempo % 10 == 1 && barra != null) {
            int quedan = Math.max(0, MINUTO - tiempo);
            barra.setName(Component.translatable("barra.juegosdelpatio.camino", reloj(quedan)));
            barra.setProgress(quedan / (float) MINUTO);
            for (ServerPlayer jugador : complejo.players()) {
                barra.addPlayer(jugador);
            }
        }
        if (tiempo >= MINUTO) {
            trasladar(complejo, true);
        }
    }

    /** El comandante camina hasta la puerta 1 y entra al portal (la gente lo sigue); los sargentos marcan el camino. */
    private static void moverEscolta(ServerLevel complejo, boolean yaTarde) {
        for (int i = 0; i < ESCOLTA.size() && i < PUESTOS_CAMINO.length; i++) {
            Guardia guardia = ESCOLTA.get(i);
            if (!guardia.isAlive() || estaEnArena(guardia)) {
                continue;
            }
            if (i == 0) {
                moverComandante(complejo, guardia, yaTarde);
                continue;
            }
            Vec3 destino = PUESTOS_CAMINO[i];
            if (guardia.distanceToSqr(destino) < 1.0) {
                guardia.getNavigation().stop();
                girar(guardia, GIROS_CAMINO[i]);
            } else if (yaTarde) {
                guardia.getNavigation().stop();                      // se trabó: aparece en su lugar
                guardia.moveTo(destino.x, destino.y, destino.z, GIROS_CAMINO[i], 0.0F);
            } else if (guardia.getNavigation().isDone()) {
                guardia.marcharA(destino, 1.0);
            }
        }
    }

    /** Sube la escalera de la torre en dos tramos y después camina hasta adentro del portal. */
    private static void moverComandante(ServerLevel complejo, Guardia comandante, boolean yaTarde) {
        if (yaTarde) {
            entrar(complejo, comandante);                            // se trabó: pasa directo a la arena
            return;
        }
        Vec3[] recorrido = numero == 2 ? CAMINO_COMANDANTE_2 : CAMINO_COMANDANTE;
        if (pasoComandante < recorrido.length) {
            Vec3 destino = recorrido[pasoComandante];
            if (comandante.distanceToSqr(destino) < 1.5) {
                pasoComandante++;
                comandante.getNavigation().stop();
            } else if (comandante.getNavigation().isDone()) {
                comandante.marcharA(destino, 1.0);
            }
        }
        if (pasoComandante >= recorrido.length && comandante.getNavigation().isDone()) {
            Path camino = comandante.getNavigation().createPath(numero == 2 ? PORTAL_2 : PORTAL_1, 0);
            comandante.getNavigation().moveTo(camino, 0.9);           // entra al portal
        }
    }

    private static void girar(Guardia guardia, float giro) {
        guardia.setYRot(giro);
        guardia.setYHeadRot(giro);
        guardia.setYBodyRot(giro);
    }

    /**
     * En el juego no hay peleas: entre jugadores y bots, los golpes no hacen nada (ni daño ni retroceso). Lo único
     * que vale es empujar. Si el que pega es un bot enojado, en vez de pegarte te empuja (si no está esperando).
     * Si te pega otra cosa (un guardia), con la luz roja lo que te corre el golpe no cuenta como moverse.
     */
    static void alRecibirGolpe(LivingIncomingDamageEvent evento) {
        LivingEntity victima = evento.getEntity();
        Entity atacante = evento.getSource().getEntity();
        if (victima.level().isClientSide() || atacante == null || atacante == victima) {
            return;
        }
        if (sinPeleas(victima) && (victima instanceof Player || victima instanceof JugadorBot)
                && (atacante instanceof Player || atacante instanceof JugadorBot)) {
            evento.setCanceled(true);                                // en este juego no se pega
            if (atacante instanceof JugadorBot bot) {
                empujar(bot, victima, false);                        // el bot enojado te empuja
            }
            return;
        }
        if (numero != 1 || fase != Fase.JUEGO || verde || !estaEnArena(victima) || LLEGARON.contains(victima.getUUID())
                || ELIMINADOS.contains(victima.getUUID())) {
            return;
        }
        GOLPEADOS.put(victima.getUUID(), PERDON_GOLPE);
    }

    /** En la arena, durante el juego (reglas, juego y final), no hay peleas: solo empujones. */
    static boolean sinPeleas(LivingEntity quien) {
        return enArena() && estaEnArena(quien);
    }

    /** ¿Ya pasaron los 5 segundos desde su último empujón? Si sí, lo anota como empujando ahora. */
    private static boolean usarEmpujon(UUID quien, long ahora) {
        Long antes = ULTIMO_EMPUJON.get(quien);
        if (antes != null && ahora - antes < ESPERA_EMPUJON) {
            return false;
        }
        ULTIMO_EMPUJON.put(quien, ahora);
        return true;
    }

    /** Cuando a un jugador se le termina la espera, se lo dice en la pantalla. Y se olvidan los viejos. */
    private static void avisarEmpujones(MinecraftServer servidor) {
        if (ULTIMO_EMPUJON.isEmpty()) {
            return;
        }
        long ahora = servidor.overworld().getGameTime();
        for (Iterator<Map.Entry<UUID, Long>> it = ULTIMO_EMPUJON.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Long> empujon = it.next();
            long pasaron = ahora - empujon.getValue();
            if (pasaron == ESPERA_EMPUJON) {
                ServerPlayer jugador = servidor.getPlayerList().getPlayer(empujon.getKey());
                if (jugador != null) {
                    jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.empujon_listo")
                            .withStyle(ChatFormatting.GREEN), true);
                }
            } else if (pasaron > ESPERA_EMPUJON + 20 || pasaron < 0) {
                it.remove();
            }
        }
    }

    /**
     * Empujar: clic derecho con la mano vacía sobre un bot o sobre otro jugador, una vez cada 5 segundos. No
     * lastima, pero lo tira para atrás: con la luz roja, al que empujaste se movió y queda eliminado (tú no cuentas
     * como que te moviste). Sirve en cualquier lado; el bot que empujas se enoja (en el juego, te devuelve el
     * empujón; en la sala, te pega), y si muere, los demás te guardan rencor.
     */
    static void alInteractuar(PlayerInteractEvent.EntityInteract evento) {
        Player jugador = evento.getEntity();
        Entity objetivo = evento.getTarget();
        if (evento.getHand() != InteractionHand.MAIN_HAND || !jugador.getMainHandItem().isEmpty() || jugador.isSpectator()
                || objetivo == jugador || !(objetivo instanceof JugadorBot || objetivo instanceof Player)) {
            return;
        }
        evento.setCancellationResult(InteractionResult.SUCCESS);   // el brazo se mueve (y no hace nada más)
        evento.setCanceled(true);
        if (evento.getLevel().isClientSide() || !(objetivo instanceof LivingEntity victima) || !victima.isAlive()) {
            return;
        }
        if (victima.isPassenger()) {
            if (!Sillas.tirar(jugador, victima)) {                     // en las sillas: tirar para sacarlo
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.no_empujar_sentado")
                        .withStyle(ChatFormatting.GRAY), true);        // si no, al que está sentado no se lo mueve
            }
            return;
        }
        long ahora = evento.getLevel().getServer().overworld().getGameTime();
        Long antes = ULTIMO_EMPUJON.get(jugador.getUUID());
        if (!usarEmpujon(jugador.getUUID(), ahora)) {
            long faltan = (ESPERA_EMPUJON - (ahora - antes) + 19) / 20;   // todavía no: cuántos segundos faltan
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.empujon_espera", faltan)
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        jugador.swing(InteractionHand.MAIN_HAND);
        double dx = jugador.getX() - victima.getX();
        double dz = jugador.getZ() - victima.getZ();
        if (dx * dx + dz * dz < 1.0E-4) {
            dz = -1.0;
        }
        victima.knockback(0.6, dx, dz);
        victima.hurtMarked = true;                                   // que al jugador empujado le llegue ya
        Sillas.empujado(victima);
        evento.getLevel().playSound(null, victima.getX(), victima.getY(), victima.getZ(), SoundEvents.PLAYER_ATTACK_WEAK,
                SoundSource.PLAYERS, 1.0F, 1.0F);
        if (victima instanceof JugadorBot bot) {
            bot.empujadoPor(jugador);
        } else if (numero == 1 && fase == Fase.JUEGO && !verde) {
            EMPUJADO_POR.put(victima.getUUID(), jugador.getName().getString());
        }
    }

    /**
     * Con la luz roja, nadie que esté en la cancha (antes de la meta) puede caminar: ni los que siguen en carrera ni
     * los que cruzaron y volvieron. Pasando la meta, sí. Un bot enojado empuja solo si te tiene al lado.
     */
    static boolean debeQuedarseQuieto(LivingEntity quien) {
        return numero == 1 && fase == Fase.JUEGO && !verde && estaEnArena(quien) && enLaCancha(quien);
    }

    /** Está antes de la línea de meta: ahí el Vigía elimina al que se mueve. Pasando la línea, nadie queda eliminado. */
    static boolean enLaCancha(LivingEntity quien) {
        return quien.getZ() < META_Z;
    }

    /** Un bot (o el comandante) tocó el portal del juego de hoy en el minuto para ir: pasa a la arena. */
    static void entraAlPortal(Entity quien, int juego) {
        if (fase == Fase.CAMINO && juego == numero && quien instanceof LivingEntity vivo && !estaEnArena(vivo)
                && !ENTRAN.contains(vivo)) {
            ENTRAN.add(vivo);                                        // se mueve al final del tick (no en el medio del suyo)
        }
    }

    private static void entrar(ServerLevel complejo, LivingEntity quien) {
        if (!quien.isAlive() || estaEnArena(quien)) {
            return;
        }
        complejo.playSound(null, quien.getX(), quien.getY(), quien.getZ(), SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.NEUTRAL, 0.6F, 1.3F);
        if (quien instanceof JugadorBot bot) {
            Vec3 lugar = lugarDeSalida(numero, complejo.getRandom());
            bot.getNavigation().stop();
            bot.moveTo(lugar.x, lugar.y, lugar.z, complejo.getRandom().nextFloat() * 40.0F - 20.0F, 0.0F);
        } else if (quien instanceof Guardia guardia && !ESCOLTA.isEmpty() && ESCOLTA.get(0) == guardia) {
            Vec3 podio = podio();
            guardia.getNavigation().stop();
            guardia.moveTo(podio.x, podio.y, podio.z, giroPodio(), 0.0F);   // espera a todos en su podio
            girar(guardia, giroPodio());
        }
    }

    /** Lleva a la arena a todos los que siguen en el complejo (jugadores y bots) y prepara las reglas. */
    private static void trasladar(ServerLevel complejo, boolean cerrarPuerta) {
        if (!prepararArena(complejo, numero)) {
            terminar(complejo);                                  // sin arena no hay juego (nadie va al vacío)
            return;
        }
        forzarArena(complejo, true);
        RandomSource azar = complejo.getRandom();
        if (numero == 1) {
            ponerBarreraSalida(complejo, true);
        }
        for (ServerPlayer jugador : List.copyOf(complejo.players())) {
            if (jugador.isAlive() && !estaEnArena(jugador)) {
                Vec3 lugar = lugarDeSalida(numero, azar);
                jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, 0.0F, 0.0F);
                titulo(jugador, Component.empty(), Component.translatable("titulo.juegosdelpatio.te_llevaron")
                        .withStyle(ChatFormatting.GRAY), 10, 40, 10);
            }
        }
        BOTS.clear();
        BOTS_POR_ID.clear();
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive())) {
            Vec3 lugar = lugarDeSalida(numero, azar);
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
            bot.moveTo(lugar.x, lugar.y, lugar.z, azar.nextFloat() * 40.0F - 20.0F, 0.0F);
            BOTS.add(bot);
            BOTS_POR_ID.put(bot.getUUID(), bot);
        }
        // el comandante a su podio y los sargentos a los costados del campo (o en las esquinas del salón)
        Vec3[] lugares = numero == 2
                ? new Vec3[] {Sillas.PODIO, Sillas.PUESTOS_SARGENTOS[0], Sillas.PUESTOS_SARGENTOS[1],
                        Sillas.PUESTOS_SARGENTOS[2], Sillas.PUESTOS_SARGENTOS[3]}
                : new Vec3[] {PODIO, new Vec3(952.5, 100.0, 75.5), new Vec3(1047.5, 100.0, 75.5),
                        new Vec3(952.5, 100.0, 175.5), new Vec3(1047.5, 100.0, 175.5)};
        float[] giros = numero == 2 ? new float[] {0.0F, -52.0F, 52.0F, -128.0F, 128.0F}
                : new float[] {90.0F, -90.0F, 90.0F, -90.0F, 90.0F};
        for (int i = 0; i < ESCOLTA.size() && i < lugares.length; i++) {
            Guardia guardia = ESCOLTA.get(i);
            if (guardia.isAlive()) {
                guardia.getNavigation().stop();
                guardia.moveTo(lugares[i].x, lugares[i].y, lugares[i].z, giros[i], 0.0F);
            }
        }
        if (cerrarPuerta) {
            Portales.cerrarPuerta(complejo, numero);
            Ceremonia.cerrarPorton(complejo);
        }
        forzarSala(complejo, false);                          // ya se llevó a todos: la sala puede descansar
        if (barra != null) {
            barra.removeAllPlayers();
        }
        barra = new ServerBossEvent(Component.translatable(numero == 2 ? "juego.juegosdelpatio.nombre_2"
                : "juego.juegosdelpatio.nombre_1"), BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);
        if (numero == 1) {
            ponerLuces(complejo, ROJA);
            Vigia.reiniciar(complejo, Vigia.MIRANDO);          // mientras explican las reglas, el Vigía los mira
        }
        reiniciarMecanicas();
        regla = 0;
        cambiarA(Fase.REGLAS);
    }

    // ------------------------------------------------------------------ 3. reglas
    private static void reglas(ServerLevel complejo) {
        if (tiempo % 20 == 1) {
            mostrarBarra(complejo, 1.0F);
        }
        if (tiempo < 40 || (tiempo - 40) % TICKS_POR_REGLA != 0) {
            return;
        }
        String[] reglas = numero == 2 ? REGLAS_SILLAS : REGLAS;
        if (regla < reglas.length) {
            String clave = "juego.juegosdelpatio." + reglas[regla];
            decir(complejo, reglas[regla].equals("reglas_5") ? Component.translatable(clave, DURACION_JUEGO / MINUTO)
                    : reglas[regla].equals("sillas_2") ? Component.translatable(clave, Sillas.FALTAN[0])
                    : reglas[regla].equals("sillas_6") ? Component.translatable(clave, Sillas.FALTAN[1], Sillas.FALTAN[2])
                    : Component.translatable(clave));
            regla++;
            return;
        }
        // ¡que empiece el juego!
        for (ServerPlayer jugador : jugadoresEnArena(complejo)) {
            if (numero == 2) {
                jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio.como_sentarse")
                        .withStyle(ChatFormatting.GRAY));
            }
            jugador.sendSystemMessage(Component.translatable(numero == 2 ? "mensaje.juegosdelpatio.como_empujar_sillas"
                    : "mensaje.juegosdelpatio.como_empujar").withStyle(ChatFormatting.GRAY));
            jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio.como_correr")
                    .withStyle(ChatFormatting.GRAY));
        }
        if (numero == 2) {
            ELIMINADOS.clear();
            cambiarA(Fase.JUEGO);
            Sillas.empezar(complejo, participantes(complejo));     // a cada uno su círculo
            return;
        }
        ponerBarreraSalida(complejo, false);
        LLEGARON.clear();
        ELIMINADOS.clear();
        cambiarA(Fase.JUEGO);
        cambiarLuz(complejo, true);
    }

    // ------------------------------------------------------------------ 4. el juego
    private static void jugar(ServerLevel complejo) {
        if (numero == 2) {
            cansancio(complejo);
            if (Sillas.tick(complejo) || tiempo >= DURACION_MAX_SILLAS) {
                finSillas(complejo);
            }
            return;
        }
        if (tiempo >= DURACION_JUEGO) {
            finDelTiempo(complejo);
            return;
        }
        cansancio(complejo);
        if (tiempo % 10 == 0) {
            mostrarBarra(complejo, 1.0F - tiempo / (float) DURACION_JUEGO);
        }
        if (--cambio <= 0) {
            cambiarLuz(complejo, !verde);
        }
        List<LivingEntity> enJuego = participantes(complejo);
        for (LivingEntity quien : enJuego) {
            if (quien.getZ() < META_Z || !LLEGARON.add(quien.getUUID())) {
                continue;
            }
            EMPUJADORES.remove(quien.getUUID());                     // ya cruzó: deja de empujar
            if (quien instanceof ServerPlayer jugador) {
                titulo(jugador, Component.translatable("titulo.juegosdelpatio.pasaste").withStyle(ChatFormatting.GREEN),
                        Component.translatable("titulo.juegosdelpatio.a_la_meta", LLEGARON.size())
                                .withStyle(ChatFormatting.GRAY), 5, 50, 15);
                jugador.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
                jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio.meta_cuidado")
                        .withStyle(ChatFormatting.GOLD));               // el Vigía te sigue viendo
            } else if (BLOQUEADORES.size() < MAX_BLOQUEADORES
                    && complejo.getRandom().nextInt(100) < BLOQUEAN_POR_CIENTO) {
                BLOQUEADORES.add(quien.getUUID());                   // este se queda a no dejar pasar
                PUESTO_BLOQUEO.put(quien.getUUID(), Math.max(953.0, Math.min(1046.0, quien.getX())));
            }
        }
        if (verde) {
            return;
        }
        if (!GOLPEADOS.isEmpty()) {
            for (Iterator<Map.Entry<UUID, Integer>> it = GOLPEADOS.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<UUID, Integer> golpe = it.next();
                if (golpe.getValue() > 1) {
                    golpe.setValue(golpe.getValue() - 1);
                    continue;
                }
                it.remove();                                         // ya se frenó: desde acá, quieto otra vez
                LivingEntity quien = buscar(complejo, golpe.getKey());
                if (quien != null && QUIETOS.containsKey(golpe.getKey())) {
                    QUIETOS.put(golpe.getKey(), quien.position());
                }
            }
        }
        if (gracia > 0) {
            if (--gracia == 0) {
                QUIETOS.clear();
                MIRADAS.clear();
                for (LivingEntity quien : enJuego) {
                    QUIETOS.put(quien.getUUID(), quien.position());       // desde ahora, nadie se mueve
                    if (quien instanceof ServerPlayer jugador) {
                        MIRADAS.put(jugador.getUUID(), new float[] {jugador.getYRot(), jugador.getXRot()});   // ni la cabeza
                    }
                }
            }
            return;
        }
        empujones(complejo);
        for (LivingEntity quien : enJuego) {
            Vec3 antes = QUIETOS.get(quien.getUUID());
            if (antes == null || GOLPEADOS.containsKey(quien.getUUID()) || !enLaCancha(quien)) {
                continue;                       // pasando la meta nadie queda eliminado
            }
            double dx = quien.getX() - antes.x;
            double dz = quien.getZ() - antes.z;
            if (dx * dx + dz * dz > MOVIMIENTO * MOVIMIENTO || Math.abs(quien.getY() - antes.y) > 0.3) {
                eliminar(complejo, quien, true, EMPUJADO_POR.containsKey(quien.getUUID()) ? null : "te_moviste");
                continue;
            }
            float[] mirada = MIRADAS.get(quien.getUUID());
            if (mirada != null && quien instanceof ServerPlayer jugador
                    && (Math.abs(Mth.wrapDegrees(jugador.getYRot() - mirada[0])) > GIRO_CABEZA
                    || Math.abs(jugador.getXRot() - mirada[1]) > GIRO_CABEZA)) {
                eliminar(complejo, quien, true, "moviste_cabeza");      // mover la cabeza también es moverse
            }
        }
    }

    private static void cambiarLuz(ServerLevel complejo, boolean ahoraVerde) {
        RandomSource azar = complejo.getRandom();
        verde = ahoraVerde;
        cambio = verde ? 60 + azar.nextInt(81) : 50 + azar.nextInt(61);
        ponerLuces(complejo, verde ? VERDE : ROJA);
        Vigia.mirar(!verde);                                   // se da vuelta para mirar (o vuelve a quedar de espaldas)
        DISTRAIDOS.clear();
        EMPUJE_EN.clear();
        GOLPEADOS.clear();
        if (verde) {
            EMPUJADO_POR.clear();
            if (++lucesVerdes >= 2) {
                elegirEmpujadores(complejo);                   // desde la segunda luz verde
            }
        } else {
            gracia = GRACIA;
            for (JugadorBot bot : BOTS) {
                if (bot.isAlive() && !LLEGARON.contains(bot.getUUID()) && azar.nextInt(100) < DISTRAIDOS_POR_CIENTO) {
                    DISTRAIDOS.add(bot.getUUID());                       // este no va a frenar a tiempo
                }
            }
        }
        Component titulo = verde
                ? Component.translatable("titulo.juegosdelpatio.luz_verde").withStyle(ChatFormatting.GREEN)
                : Component.translatable("titulo.juegosdelpatio.luz_roja").withStyle(ChatFormatting.RED);
        for (ServerPlayer jugador : jugadoresEnArena(complejo)) {
            titulo(jugador, titulo, Component.empty(), 2, 20, 6);        // también a los que cruzaron: los sigue viendo
            jugador.playNotifySound(verde ? SoundEvents.BELL_BLOCK : SoundEvents.ANVIL_LAND, SoundSource.MASTER,
                    verde ? 1.0F : 0.6F, verde ? 1.6F : 0.7F);
            jugador.playNotifySound(SoundEvents.PISTON_EXTEND, SoundSource.HOSTILE, 0.7F, 0.5F);   // el Vigía gira
        }
        if (barra != null) {
            barra.setColor(verde ? BossEvent.BossBarColor.GREEN : BossEvent.BossBarColor.RED);
        }
    }

    /**
     * El que se movió (o no llegó) muere. Los jugadores reaparecen en el mundo normal, y se les dice por qué
     * (motivo: una clave de mensaje.juegosdelpatio, o null).
     */
    static void eliminar(ServerLevel complejo, LivingEntity quien, boolean conRayo, @Nullable String motivo) {
        if (!ELIMINADOS.add(quien.getUUID())) {
            return;
        }
        EMPUJADORES.remove(quien.getUUID());
        EstadoComplejo.de(complejo.getServer()).sumarPremio(PREMIO_POR_ELIMINADO);   // cada eliminado sube el premio
        if (conRayo) {
            rayo(complejo, quien);                             // el Vigía lo vio
        }
        complejo.playSound(null, quien.getX(), quien.getY(), quien.getZ(), SoundEvents.FIREWORK_ROCKET_BLAST,
                SoundSource.HOSTILE, 3.0F, 1.4F);
        complejo.sendParticles(ParticleTypes.SMOKE, quien.getX(), quien.getY(1.0), quien.getZ(), 10, 0.2, 0.4, 0.2, 0.02);
        if (quien instanceof ServerPlayer jugador) {
            CANSADOS.remove(jugador.getUUID());                      // al reaparecer ya tiene la comida llena
            AIRE.remove(jugador.getUUID());
            String empujon = EMPUJADO_POR.get(jugador.getUUID());
            if (empujon != null) {
                jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio.te_empujaron", empujon)
                        .withStyle(ChatFormatting.RED));
            } else if (motivo != null) {
                jugador.sendSystemMessage(Component.translatable("mensaje.juegosdelpatio." + motivo)
                        .withStyle(ChatFormatting.RED));
            }
            if (barra != null) {
                barra.removePlayer(jugador);
            }
            if (!jugador.getRespawnDimension().equals(Level.OVERWORLD)) {
                jugador.setRespawnPosition(Level.OVERWORLD, null, 0.0F, false, false);   // reaparece en el mundo normal
            }
            jugador.kill();
        } else {
            quien.kill();
        }
    }

    // ------------------------------------------------------------------ 5. final
    private static void finDelTiempo(ServerLevel complejo) {
        ponerLuces(complejo, ROJA);
        Vigia.mirar(true);
        terminarCansancio(complejo.getServer());
        decir(complejo, Component.translatable("juego.juegosdelpatio.fin_tiempo"));
        for (LivingEntity quien : participantes(complejo)) {
            if (!LLEGARON.contains(quien.getUUID()) || enLaCancha(quien)) {
                eliminar(complejo, quien, false, "no_llegaste");   // al terminar, el que esté antes de la meta
            }
        }
        if (barra != null) {
            barra.setName(Component.translatable("barra.juegosdelpatio.fin"));
            barra.setProgress(0.0F);
            barra.setColor(BossEvent.BossBarColor.RED);
        }
        cambiarA(Fase.FINAL);
    }

    /** Terminaron todos los círculos de las sillas: los que quedan pasan. */
    private static void finSillas(ServerLevel complejo) {
        terminarCansancio(complejo.getServer());
        decir(complejo, Component.translatable("juego.juegosdelpatio.sillas_fin", Sillas.pasaron()));
        if (barra != null) {
            barra.setName(Component.translatable("barra.juegosdelpatio.sillas_fin", Sillas.pasaron()));
            barra.setProgress(1.0F);
            barra.setColor(BossEvent.BossBarColor.GREEN);
        }
        cambiarA(Fase.FINAL);
    }

    private static void fin(ServerLevel complejo) {
        if (tiempo == 60) {
            decir(complejo, Component.translatable("juego.juegosdelpatio.felicitaciones"));
        }
        if (tiempo >= 140) {
            ultimosLlegaron = numero == 2 ? Sillas.pasaron() : LLEGARON.size();
            ultimosEliminados = ELIMINADOS.size();
            ultimoNumero = numero;
            terminar(complejo);
            resultadosEn = ESPERA_RESULTADOS;               // cuando ya están todos en la sala, vuelve el comandante
        }
    }

    /**
     * El comandante vuelve con sus escoltas y dice cómo terminó el último juego; después se vota.
     * false si no hay nadie en el complejo o si ya hay algo en curso.
     */
    public static boolean empezarResultados(ServerLevel complejo) {
        if (fase != Fase.NINGUNA || Votacion.enCurso()) {
            return false;
        }
        int jugadores = 0;
        for (ServerPlayer jugador : complejo.players()) {
            if (jugador.isAlive() && !jugador.isSpectator()) {
                jugadores++;
            }
        }
        if (jugadores == 0) {
            return false;
        }
        int quedan = jugadores + complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive()).size();
        return Ceremonia.empezarResultados(complejo, ultimoNumero, ultimosLlegaron, ultimosEliminados, quedan,
                PREMIO_POR_ELIMINADO,
                EstadoComplejo.de(complejo.getServer()).premio());
    }

    /** Todos los que siguen vivos en la arena vuelven a la sala, y se deja todo listo para la próxima vez. */
    static void terminar(ServerLevel complejo) {
        if (numero == 2) {
            Sillas.limpiar(complejo);                       // primero todos se levantan de las sillas
        }
        terminarCansancio(complejo.getServer());
        RandomSource azar = complejo.getRandom();
        for (ServerPlayer jugador : List.copyOf(complejo.players())) {
            if (estaEnArena(jugador) && jugador.isAlive()) {
                Complejo.llevarALaSala(jugador);
            }
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive() && estaEnArena(bot))) {
            Vec3 lugar = Complejo.lugarAlAzar(azar);
            bot.getNavigation().stop();
            bot.moveTo(lugar.x, lugar.y, lugar.z, azar.nextFloat() * 360.0F, 0.0F);
        }
        for (Guardia guardia : ESCOLTA) {
            guardia.discard();
        }
        if (Portales.puertaAbierta(complejo, numero)) {
            Portales.cerrarPuerta(complejo, numero);
        }
        Ceremonia.cerrarPorton(complejo);
        if (barra != null) {
            barra.removeAllPlayers();
            barra = null;
        }
        if (numero == 1 && EstadoComplejo.de(complejo.getServer()).versionArena() == VERSION_ARENA) {
            ponerBarreraSalida(complejo, true);
            ponerLuces(complejo, APAGADA);
            Vigia.reiniciar(complejo, Vigia.DE_ESPALDAS);
        }
        forzarArena(complejo, false);
        forzarSala(complejo, false);
        limpiarListas();
        cambiarA(Fase.NINGUNA);
    }

    // ------------------------------------------------------------------ comandos
    /** Saltea el llamado: lleva a todos a la arena del juego {@code juego} y empieza con las reglas. */
    public static boolean empezarYa(ServerLevel complejo, int juego) {
        if (fase != Fase.NINGUNA || !tieneArena(juego) || !Complejo.prepararComplejo(complejo, false)) {
            return false;
        }
        limpiarListas();
        numero = juego;
        if (!prepararArena(complejo, numero)) {
            return false;
        }
        forzarArena(complejo, true);
        for (int i = 0; i < 5; i++) {
            Guardia guardia = Complejo.invocarGuardia(complejo, podio(), giroPodio(),
                    i == 0 ? Rango.COMANDANTE : Rango.SARGENTO, -1);
            if (guardia != null) {
                guardia.hacerEscolta();
                guardia.setCustomNameVisible(i == 0);
                ESCOLTA.add(guardia);
            }
        }
        marcarDia(complejo);
        forzarSala(complejo, true);                           // que se carguen los bots aunque no haya nadie en la sala
        barra = new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.PROGRESS);
        cambiarA(Fase.CAMINO);
        tiempo = MINUTO - 40;                                 // en 2 segundos los lleva a todos a la arena
        return true;
    }

    /** Corta el juego: nadie queda eliminado y todos vuelven a la sala. */
    public static boolean parar(ServerLevel complejo) {
        if (fase == Fase.NINGUNA) {
            return false;
        }
        terminar(complejo);
        return true;
    }

    // ------------------------------------------------------------------ portal de la puerta 1
    /** Dónde aparece quien llega al juego {@code juego} (por el portal o llevado). */
    public static Vec3 lugarDeSalida(int juego, RandomSource azar) {
        return juego == 2 ? Sillas.lugarDeSalida(azar) : lugarDeSalida(azar);
    }

    /** Construye la arena del juego {@code juego} si hace falta. false si no se pudo. */
    static boolean prepararArena(ServerLevel complejo, int juego) {
        return juego == 2 ? Sillas.prepararArena(complejo) : prepararArena(complejo);
    }

    /** El podio del comandante en la arena del juego de hoy, y hacia dónde mira. */
    private static Vec3 podio() {
        return numero == 2 ? Sillas.PODIO : PODIO;
    }

    private static float giroPodio() {
        return numero == 2 ? 0.0F : 90.0F;
    }

    /** Dónde aparece quien entra por el portal 1 (y quien es llevado): la zona de salida de la arena. */
    public static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(952.5 + azar.nextInt(85), 100.0, 1.5 + azar.nextInt(8));
    }

    /**
     * Construye la arena la primera vez (y saca la plataforma provisoria que había antes en ese lugar).
     * false si no se pudo (falta la estructura en el mod).
     */
    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estado = EstadoComplejo.de(complejo.getServer());
        if (estado.versionArena() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        for (BlockPos pos : BlockPos.betweenClosed(987, 99, -14, 1013, 105, 14)) {
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        for (BlockPos pos : BlockPos.betweenClosed(989, 100, 295, 1010, 137, 305)) {   // el semáforo de la versión 1
            if (!complejo.getBlockState(pos).isAir()) {
                complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN_ARENA, ORIGEN_ARENA, new StructurePlaceSettings(),
                complejo.getRandom(), Block.UPDATE_CLIENTS);
        for (int x = 999; x <= 1001; x++) {
            for (int y = 100; y <= 103; y++) {
                complejo.setBlock(new BlockPos(x, y, -2), Blocks.BARRIER.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        estado.setVersionArena(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Luz verde, luz roja colocada en {}", ORIGEN_ARENA);
        return true;
    }

    // ------------------------------------------------------------------ cansancio
    /** Gasta o recupera el aire de cada jugador, y lo muestra en la barra de experiencia. */
    private static void cansancio(ServerLevel complejo) {
        for (ServerPlayer jugador : jugadoresEnArena(complejo)) {
            if (!jugador.isAlive() || jugador.isCreative() || jugador.isSpectator()) {
                continue;
            }
            UUID id = jugador.getUUID();
            int aire = AIRE.getOrDefault(id, AIRE_MAX);
            int antes = aire;
            FoodData comida = jugador.getFoodData();
            Integer guardada = CANSADOS.get(id);
            if (guardada != null) {
                if (comida.getFoodLevel() > COMIDA_SIN_CORRER) {      // comió algo mientras estaba cansado: se le guarda
                    guardada = Math.min(20, guardada + comida.getFoodLevel() - COMIDA_SIN_CORRER);
                    CANSADOS.put(id, guardada);
                    comida.setFoodLevel(COMIDA_SIN_CORRER);
                }
                aire = Math.min(AIRE_MAX, aire + RECARGA_AIRE);
                if (aire >= AIRE_MAX) {
                    CANSADOS.remove(id);
                    comida.setFoodLevel(guardada);                     // descansó: ya puede correr
                    jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.descansado")
                            .withStyle(ChatFormatting.GREEN), true);
                }
            } else if (jugador.isSprinting()) {
                aire = Math.max(0, aire - GASTO_AIRE);
                jugador.causeFoodExhaustion(HAMBRE_CORRIENDO);         // acá correr da mucha más hambre
                if (aire == 0) {
                    CANSADOS.put(id, comida.getFoodLevel());
                    comida.setFoodLevel(Math.min(comida.getFoodLevel(), COMIDA_SIN_CORRER));
                    jugador.setSprinting(false);
                    jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.cansado")
                            .withStyle(ChatFormatting.GOLD), true);
                }
            } else {
                aire = Math.min(AIRE_MAX, aire + RECARGA_AIRE);
            }
            AIRE.put(id, aire);
            if (aire != antes || tiempo % 40 == 0) {
                jugador.connection.send(new ClientboundSetExperiencePacket(aire / (float) AIRE_MAX, 0, 0));
            }
        }
    }

    /** Fin del juego: a cada uno se le devuelve la comida (si estaba cansado) y su barra de experiencia de verdad. */
    private static void terminarCansancio(MinecraftServer servidor) {
        for (UUID id : AIRE.keySet()) {
            ServerPlayer jugador = servidor.getPlayerList().getPlayer(id);
            if (jugador == null) {
                continue;
            }
            Integer guardada = CANSADOS.get(id);
            if (guardada != null && jugador.isAlive()) {
                jugador.getFoodData().setFoodLevel(guardada);
            }
            jugador.connection.send(new ClientboundSetExperiencePacket(jugador.experienceProgress,
                    jugador.totalExperience, jugador.experienceLevel));
        }
        AIRE.clear();
        CANSADOS.clear();
    }

    /** Si alguien se desconecta cansado, antes de guardarlo se le devuelve la comida. */
    static void alSalir(PlayerEvent.PlayerLoggedOutEvent evento) {
        Integer guardada = CANSADOS.remove(evento.getEntity().getUUID());
        if (guardada != null) {
            evento.getEntity().getFoodData().setFoodLevel(guardada);
        }
        AIRE.remove(evento.getEntity().getUUID());
    }

    // ------------------------------------------------------------------ empujones, rencor y la meta
    private static void reiniciarMecanicas() {
        GOLPEADOS.clear();
        EMPUJADORES.clear();
        EMPUJE_EN.clear();
        EMPUJADO_POR.clear();
        BLOQUEADORES.clear();
        PUESTO_BLOQUEO.clear();
        lucesVerdes = 0;
    }

    /** Sigue en carrera: vivo, en la arena, sin cruzar la meta, sin quedar eliminado (y no en creativo). */
    static boolean esParticipante(LivingEntity quien) {
        if (!quien.isAlive() || !estaEnArena(quien) || LLEGARON.contains(quien.getUUID())
                || ELIMINADOS.contains(quien.getUUID())) {
            return false;
        }
        return !(quien instanceof ServerPlayer jugador) || !jugador.isCreative() && !jugador.isSpectator();
    }

    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID id) {
        ServerPlayer jugador = complejo.getServer().getPlayerList().getPlayer(id);
        if (jugador != null) {
            return jugador.level() == complejo ? jugador : null;
        }
        return BOTS_POR_ID.get(id);
    }

    /**
     * Al ponerse en verde: algunos bots eligen a quién empujar en la próxima luz roja. A cada jugador le toca uno,
     * y dos más por cada bot al que le pegó y murió (rencor). Además, unos pocos bots le tienen ganas a otro bot.
     */
    private static void elegirEmpujadores(ServerLevel complejo) {
        EMPUJADORES.entrySet().removeIf(par -> {
            JugadorBot bot = BOTS_POR_ID.get(par.getKey());
            LivingEntity victima = buscar(complejo, par.getValue());
            return bot == null || !esParticipante(bot) || victima == null || !esParticipante(victima);
        });
        RandomSource azar = complejo.getRandom();
        List<JugadorBot> libres = new ArrayList<>();
        for (JugadorBot bot : BOTS) {
            if (esParticipante(bot) && !bot.enojado() && !EMPUJADORES.containsKey(bot.getUUID())
                    && !EMPUJADORES.containsValue(bot.getUUID())) {
                libres.add(bot);
            }
        }
        for (ServerPlayer jugador : jugadoresEnArena(complejo)) {
            if (!esParticipante(jugador)) {
                continue;
            }
            int quiero = Math.min(1 + 2 * RENCOR.getOrDefault(jugador.getUUID(), 0), 7);
            int tiene = 0;
            for (UUID victima : EMPUJADORES.values()) {
                if (victima.equals(jugador.getUUID())) {
                    tiene++;
                }
            }
            libres.sort(Comparator.comparingDouble(bot -> bot.distanceToSqr(jugador)));
            for (Iterator<JugadorBot> it = libres.iterator(); it.hasNext() && tiene < quiero; ) {
                JugadorBot bot = it.next();
                if (bot.distanceToSqr(jugador) > 40.0 * 40.0) {
                    break;
                }
                EMPUJADORES.put(bot.getUUID(), jugador.getUUID());
                bot.mostrarEmote(Emote.ENOJO);                        // se le nota en la cara
                it.remove();
                tiene++;
            }
        }
        int entreBots = 0;
        for (UUID victima : EMPUJADORES.values()) {
            if (BOTS_POR_ID.containsKey(victima)) {
                entreBots++;
            }
        }
        int faltan = Math.max(1, libres.size() / BOTS_POR_EMPUJADOR) - entreBots;
        for (int n = 0; n < faltan && libres.size() > 1; n++) {
            JugadorBot bot = libres.remove(azar.nextInt(libres.size()));
            JugadorBot victima = null;
            double cerca = 12.0 * 12.0;
            for (JugadorBot otro : libres) {
                double d = otro.distanceToSqr(bot);
                if (d < cerca) {
                    cerca = d;
                    victima = otro;
                }
            }
            if (victima != null) {
                EMPUJADORES.put(bot.getUUID(), victima.getUUID());
                libres.remove(victima);
            }
        }
    }

    /** Con la luz roja (pasado el momento para frenar), los que empujan y quedaron al lado de su víctima la empujan. */
    private static void empujones(ServerLevel complejo) {
        if (verde || gracia > 0 || EMPUJADORES.isEmpty()) {
            return;
        }
        RandomSource azar = complejo.getRandom();
        for (Map.Entry<UUID, UUID> par : EMPUJADORES.entrySet()) {
            JugadorBot bot = BOTS_POR_ID.get(par.getKey());
            LivingEntity victima = buscar(complejo, par.getValue());
            if (bot == null || !esParticipante(bot) || victima == null || !esParticipante(victima)) {
                continue;
            }
            Integer espera = EMPUJE_EN.get(bot.getUUID());
            if (espera == null) {
                if (bot.distanceToSqr(victima) <= ALCANCE_EMPUJE * ALCANCE_EMPUJE) {
                    EMPUJE_EN.put(bot.getUUID(), azar.nextInt(100) < EMPUJA_POR_CIENTO ? 4 + azar.nextInt(17) : -1);
                }
            } else if (espera > 0) {
                if (espera == 1 && bot.distanceToSqr(victima) <= 9.0 && empujar(bot, victima, false)) {
                    EMPUJADO_POR.put(victima.getUUID(), bot.nombre());
                }
                EMPUJE_EN.put(bot.getUUID(), espera == 1 ? -1 : espera - 1);
            }
        }
    }

    /**
     * Un bot empuja (no lastima): la víctima sale despedida, y con la luz roja eso es moverse. Fuerte: los que no
     * dejan cruzar la meta. También espera 5 segundos entre empujón y empujón. false si todavía estaba esperando.
     */
    static boolean empujar(JugadorBot bot, LivingEntity victima, boolean fuerte) {
        if (victima.isPassenger() || !(bot.level() instanceof ServerLevel nivel)
                || !usarEmpujon(bot.getUUID(), nivel.getServer().overworld().getGameTime())) {
            return false;                                            // al que está sentado no se lo empuja
        }
        bot.swing(InteractionHand.MAIN_HAND);
        double dx = bot.getX() - victima.getX();
        double dz = bot.getZ() - victima.getZ();
        if (dx * dx + dz * dz < 1.0E-4) {
            dz = 1.0;
        }
        victima.knockback(fuerte ? 0.9 : 0.6, dx, dz);
        victima.hurtMarked = true;                                   // que al jugador le llegue el empujón ya
        Sillas.empujado(victima);
        bot.level().playSound(null, victima.getX(), victima.getY(), victima.getZ(),
                fuerte ? SoundEvents.PLAYER_ATTACK_KNOCKBACK : SoundEvents.PLAYER_ATTACK_WEAK, SoundSource.HOSTILE, 1.0F, 1.0F);
        return true;
    }

    /** Si el bot es de los que empujan: su víctima (para pegársele con la luz verde, y correr si ella corre). */
    @Nullable
    static LivingEntity victimaDe(JugadorBot bot) {
        UUID id = EMPUJADORES.get(bot.getUUID());
        if (id == null || !(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity victima = buscar(complejo, id);
        return victima != null && esParticipante(victima) ? victima : null;
    }

    static boolean esBloqueador(JugadorBot bot) {
        return BLOQUEADORES.contains(bot.getUUID());
    }

    static double puestoBloqueo(JugadorBot bot) {
        return PUESTO_BLOQUEO.getOrDefault(bot.getUUID(), bot.getX());
    }

    /**
     * A quién le pega un bloqueador: el que esté por cruzar más cerca. Primero los jugadores; a los bots solo los
     * frenan algunos bloqueadores (4 de cada 10). Lo empujan fuerte para atrás (con la luz roja, eso lo elimina).
     */
    @Nullable
    static LivingEntity objetivoDeBloqueo(JugadorBot bot) {
        if (fase != Fase.JUEGO || !(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity mejor = null;
        double cerca = 6.0 * 6.0;
        for (ServerPlayer jugador : complejo.players()) {
            double d = distanciaPlana(bot, jugador);
            if (d < cerca && esParticipante(jugador) && jugador.getZ() > META_Z - 7.0) {
                cerca = d;
                mejor = jugador;
            }
        }
        if (mejor != null || Math.floorMod(bot.getId(), 10) >= 4) {
            return mejor;
        }
        for (JugadorBot otro : BOTS) {
            double d = distanciaPlana(bot, otro);
            if (d < cerca && esParticipante(otro) && otro.getZ() > META_Z - 7.0) {
                cerca = d;
                mejor = otro;
            }
        }
        return mejor;
    }

    private static double distanciaPlana(LivingEntity a, LivingEntity b) {
        double dx = a.getX() - b.getX();
        double dz = a.getZ() - b.getZ();
        return dx * dx + dz * dz;
    }

    /** Un lugar libre en la zona de llegada (sin meterse en el pedestal del Vigía). */
    static Vec3 lugarEnLaMeta(RandomSource azar) {
        double x = 952.5 + azar.nextInt(96);
        double z = 294.5 + azar.nextInt(11);
        if (x > 988.0 && x < 1011.0 && z > 297.0) {
            z = 294.5 + azar.nextInt(3);
        }
        return new Vec3(x, 100.0, z);
    }

    /** Murió un bot al que le pegó un jugador: los demás le guardan rencor (más bots lo van a querer empujar). */
    static void botMurio(JugadorBot bot, UUID agresor) {
        RENCOR.put(agresor, Math.min(3, RENCOR.getOrDefault(agresor, 0) + 1));
        if (bot.level() instanceof ServerLevel complejo) {
            ServerPlayer jugador = complejo.getServer().getPlayerList().getPlayer(agresor);
            if (jugador != null) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.rencor", bot.nombre())
                        .withStyle(ChatFormatting.RED), true);
            }
        }
    }

    /** El rayo del Vigía: una línea de puntos rojos desde su visor hasta el eliminado (se ve desde lejos). */
    private static void rayo(ServerLevel complejo, LivingEntity quien) {
        Vec3 hasta = quien.position().add(0.0, 1.0, 0.0);
        int puntos = (int) Math.min(200.0, Math.max(2.0, VISOR.distanceTo(hasta) / 1.5));
        DustParticleOptions polvo = new DustParticleOptions(new Vector3f(1.0F, 0.1F, 0.08F), 2.0F);
        List<ServerPlayer> ven = jugadoresEnArena(complejo);
        for (int i = 0; i <= puntos; i++) {
            Vec3 punto = VISOR.lerp(hasta, i / (double) puntos);
            for (ServerPlayer jugador : ven) {
                complejo.sendParticles(jugador, polvo, true, punto.x, punto.y, punto.z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    // ------------------------------------------------------------------ ayudas
    private static void cambiarA(Fase nueva) {
        fase = nueva;
        tiempo = 0;
    }

    private static void limpiarListas() {
        reiniciarMecanicas();
        ENTRAN.clear();
        BOTS_POR_ID.clear();
        LLEGARON.clear();
        ELIMINADOS.clear();
        DISTRAIDOS.clear();
        QUIETOS.clear();
        MIRADAS.clear();
        BOTS.clear();
        ESCOLTA.clear();
    }

    static List<ServerPlayer> jugadoresEnArena(ServerLevel complejo) {
        List<ServerPlayer> lista = new ArrayList<>();
        for (ServerPlayer jugador : complejo.players()) {
            if (estaEnArena(jugador)) {
                lista.add(jugador);
            }
        }
        return lista;
    }

    /** Jugadores (en supervivencia o aventura) y bots que siguen en juego. */
    static List<LivingEntity> participantes(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>();
        for (ServerPlayer jugador : jugadoresEnArena(complejo)) {
            if (jugador.isAlive() && !jugador.isSpectator() && !jugador.isCreative() && !ELIMINADOS.contains(jugador.getUUID())) {
                lista.add(jugador);
            }
        }
        for (JugadorBot bot : BOTS) {
            if (bot.isAlive() && !ELIMINADOS.contains(bot.getUUID())) {
                lista.add(bot);
            }
        }
        return lista;
    }

    private static void mostrarBarra(ServerLevel complejo, float progreso) {
        if (barra == null) {
            return;
        }
        int quedan = 0;
        for (LivingEntity quien : participantes(complejo)) {
            if (!LLEGARON.contains(quien.getUUID())) {
                quedan++;
            }
        }
        if (fase == Fase.JUEGO && numero == 1) {
            barra.setName(Component.translatable("barra.juegosdelpatio.juego",
                    reloj(Math.max(0, DURACION_JUEGO - tiempo)), LLEGARON.size(), quedan));
        }
        barra.setProgress(Math.max(0.0F, Math.min(1.0F, progreso)));
        List<ServerPlayer> enArena = jugadoresEnArena(complejo);
        for (ServerPlayer jugador : List.copyOf(barra.getPlayers())) {
            if (!enArena.contains(jugador) || ELIMINADOS.contains(jugador.getUUID())) {
                barra.removePlayer(jugador);             // se fue, se desconectó o quedó eliminado
            }
        }
        for (ServerPlayer jugador : enArena) {
            if (jugador.isAlive() && !ELIMINADOS.contains(jugador.getUUID())) {
                barra.addPlayer(jugador);
            }
        }
    }

    /** Las sillas musicales ponen su propio texto y color en la barra de arriba. */
    static void barraSillas(ServerLevel complejo, Component nombre, BossEvent.BossBarColor color, float progreso) {
        if (barra != null) {
            barra.setName(nombre);
            barra.setColor(color);
        }
        mostrarBarra(complejo, progreso);
    }

    private static String reloj(int ticks) {
        int segundos = (ticks + 19) / 20;
        return segundos / 60 + ":" + (segundos % 60 < 10 ? "0" : "") + segundos % 60;
    }

    static void decir(ServerLevel complejo, Component texto) {
        MutableComponent mensaje = Component.literal("<").append(Rango.COMANDANTE.nombre())
                .append(Component.literal("> "))
                .append(Component.empty().append(texto).withStyle(ChatFormatting.YELLOW));
        for (ServerPlayer jugador : complejo.players()) {
            jugador.sendSystemMessage(mensaje);
        }
    }

    static void titulo(ServerPlayer jugador, Component titulo, Component subtitulo, int entrada, int queda, int salida) {
        jugador.connection.send(new ClientboundSetTitlesAnimationPacket(entrada, queda, salida));
        jugador.connection.send(new ClientboundSetSubtitleTextPacket(subtitulo));
        jugador.connection.send(new ClientboundSetTitleTextPacket(titulo));
    }

    /** Las luces de las paredes de los costados: apagadas (gris), verdes o rojas. */
    private static void ponerLuces(ServerLevel complejo, int luz) {
        if (EstadoComplejo.de(complejo.getServer()).versionArena() != VERSION_ARENA) {
            return;
        }
        BlockState estado = luz == VERDE ? Blocks.LIME_CONCRETE.defaultBlockState()
                : luz == ROJA ? Blocks.RED_CONCRETE.defaultBlockState() : Blocks.GRAY_CONCRETE.defaultBlockState();
        for (int x : LADOS_X) {
            for (int zc : LADOS_Z) {
                for (int z = zc - 1; z <= zc + 1; z++) {
                    for (int y = LUZ_Y0; y <= LUZ_Y1; y++) {
                        complejo.setBlock(new BlockPos(x, y, z), estado, Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
    }

    /** La barrera invisible de la línea de salida (se saca cuando empieza el juego). */
    private static void ponerBarreraSalida(ServerLevel complejo, boolean poner) {
        BlockState estado = poner ? Blocks.BARRIER.defaultBlockState() : Blocks.AIR.defaultBlockState();
        for (int x = 950; x <= 1049; x++) {
            for (int y = 100; y <= 103; y++) {
                complejo.setBlock(new BlockPos(x, y, 10), estado, Block.UPDATE_CLIENTS);
            }
        }
    }

    /** Mantiene cargados el dormitorio, el pasillo y la torre (en el minuto para ir), o los libera. */
    private static void forzarSala(ServerLevel complejo, boolean forzar) {
        if (forzar == salaForzada) {
            return;
        }
        for (int cx = SALA_CX0; cx <= SALA_CX1; cx++) {
            for (int cz = SALA_CZ0; cz <= SALA_CZ1; cz++) {
                complejo.setChunkForced(cx, cz, forzar);
            }
        }
        salaForzada = forzar;
    }

    /** Mantiene cargada toda la arena mientras se juega (para que los bots de atrás también se muevan). */
    private static void forzarArena(ServerLevel complejo, boolean forzar) {
        if (forzar) {
            FORZADOS.clear();
            int x0 = numero == 2 ? Sillas.X0 : ORIGEN_ARENA.getX();
            int x1 = numero == 2 ? Sillas.X1 : ORIGEN_ARENA.getX() + 101;
            int z0 = numero == 2 ? Sillas.Z0 : ORIGEN_ARENA.getZ();
            int z1 = numero == 2 ? Sillas.Z1 : ORIGEN_ARENA.getZ() + 307;
            for (int cx = x0 >> 4; cx <= x1 >> 4; cx++) {
                for (int cz = z0 >> 4; cz <= z1 >> 4; cz++) {
                    complejo.setChunkForced(cx, cz, true);
                    complejo.getChunk(cx, cz);
                    FORZADOS.add(new long[] {cx, cz});
                }
            }
        } else {
            for (long[] chunk : FORZADOS) {
                complejo.setChunkForced((int) chunk[0], (int) chunk[1], false);
            }
            FORZADOS.clear();
        }
    }
}
