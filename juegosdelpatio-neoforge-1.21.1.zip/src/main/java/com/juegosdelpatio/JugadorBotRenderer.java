package com.juegosdelpatio;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/** Dibuja a los bots con el modelo de jugador y una de las 24 skins con uniforme. */
public class JugadorBotRenderer extends HumanoidMobRenderer<JugadorBot, PlayerModel<JugadorBot>> {
    private static final ResourceLocation[] SKINS = new ResourceLocation[JugadorBot.CANTIDAD_SKINS];

    static {
        for (int i = 0; i < SKINS.length; i++) {
            SKINS[i] = ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID, "textures/entity/jugador/skin_" + i + ".png");
        }
    }

    public JugadorBotRenderer(EntityRendererProvider.Context contexto) {
        super(contexto, new PlayerModel<>(contexto.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        this.addLayer(new HumanoidArmorLayer<>(this, new HumanoidModel<>(contexto.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(contexto.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), contexto.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(JugadorBot bot) {
        return SKINS[Math.floorMod(bot.getSkin(), SKINS.length)];
    }

    @Override
    public void render(JugadorBot bot, float giro, float parcial, PoseStack pose, MultiBufferSource buffers, int luz) {
        this.model.crouching = bot.isCrouching();      // para que se vea agachado como un jugador
        super.render(bot, giro, parcial, pose, buffers, luz);
    }

    @Override
    public Vec3 getRenderOffset(JugadorBot bot, float parcial) {
        return bot.isCrouching() ? new Vec3(0.0, -0.125, 0.0) : super.getRenderOffset(bot, parcial);
    }
}
