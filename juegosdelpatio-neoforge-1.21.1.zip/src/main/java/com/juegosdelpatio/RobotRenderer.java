package com.juegosdelpatio;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Dibuja un robot de El puente de Londres con bloques estirados (como los "block display" del juego): cada parte es un
 * bloque de concreto, del tamaño que haga falta. El visor, la luz del pecho y las de los antebrazos brillan (rojas o
 * azules) aunque esté oscuro: el bloque de color con toda la luz y, encima, el mismo bloque sumado, como los ojos de las
 * arañas. Los brazos salen del hombro y llegan al medio de la calle (donde se dan la mano con el otro robot),
 * levantados o bajados según el robot y suave entre tick y tick, con el codo doblado hacia arriba. Mientras suena la
 * canción, la cabeza gira de a poco, mirando la fila. Las medidas son las mismas que en herramientas/puente_render.py.
 */
public class RobotRenderer extends EntityRenderer<Robot> {
    private static final BlockState NEGRO = Blocks.BLACK_CONCRETE.defaultBlockState();
    private static final BlockState GRIS = Blocks.GRAY_CONCRETE.defaultBlockState();
    private static final BlockState GRIS_CLARO = Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
    /** Las luces: rojas o azules (brillan: se ven igual en la oscuridad). */
    private static final BlockState LUZ_ROJA = Blocks.RED_CONCRETE.defaultBlockState();
    private static final BlockState LUZ_AZUL = Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState();
    /** La mano: el último pedazo del antebrazo. */
    private static final float MANO = 0.9F;
    /** Cuánto gira la cabeza (para cada lado) mientras suena la canción. */
    private static final float GIRO_CABEZA = 14.0F;
    /** El brillo de las luces se suma a lo que hay atrás (como los ojos de las arañas). */
    private static final RenderType BRILLA = RenderType.eyes(InventoryMenu.BLOCK_ATLAS);
    /** El brillo, apenas más grande que la luz (para que no se mezclen). */
    private static final float BORDE_LUZ = 0.01F;

    private final BlockRenderDispatcher bloques;

    public RobotRenderer(EntityRendererProvider.Context contexto) {
        super(contexto);
        this.bloques = contexto.getBlockRenderDispatcher();
        this.shadowRadius = 2.0F;
    }

    @Override
    public void render(Robot robot, float giro, float parcial, PoseStack pose, MultiBufferSource buffers, int luz) {
        BlockState acento = robot.color() == Robot.AZUL ? LUZ_AZUL : LUZ_ROJA;
        float brazos = Mth.lerp(parcial, robot.brazosAntes, robot.brazosAhora);
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-giro));                    // la z del robot, para donde mira
        for (int lado = -1; lado <= 1; lado += 2) {
            caja(pose, buffers, luz, NEGRO, 0.7F * lado, 0.225F, 0.2F, 1.0F, 0.45F, 1.5F);          // pies
            caja(pose, buffers, luz, GRIS, 0.7F * lado, 1.55F, 0.0F, 0.75F, 2.2F, 0.75F);          // canillas
            caja(pose, buffers, luz, NEGRO, 0.7F * lado, 2.75F, 0.08F, 0.9F, 0.4F, 0.9F);          // rodillas
            caja(pose, buffers, luz, GRIS, 0.7F * lado, 3.75F, 0.0F, 0.85F, 1.6F, 0.85F);          // muslos
            caja(pose, buffers, luz, GRIS_CLARO, 1.9F * lado, 7.25F, 0.2F, 1.15F, 0.85F, 1.4F);    // hombreras
            caja(pose, buffers, luz, NEGRO, Robot.HOMBRO_X * lado, Robot.HOMBRO_Y, Robot.HOMBRO_Z, 0.9F, 0.9F, 0.9F);
            brazo(pose, buffers, luz, acento, lado, brazos);
        }
        caja(pose, buffers, luz, NEGRO, 0.0F, 4.7F, 0.0F, 2.2F, 0.6F, 1.2F);                        // cadera
        caja(pose, buffers, luz, GRIS, 0.0F, 5.3F, 0.0F, 1.4F, 0.6F, 1.0F);                         // cintura
        caja(pose, buffers, luz, GRIS, 0.0F, 6.45F, 0.0F, 3.1F, 1.9F, 1.7F);                        // el pecho
        caja(pose, buffers, luz, NEGRO, 0.0F, 6.6F, 0.88F, 2.3F, 1.1F, 0.12F);                      // la placa del pecho
        luz(pose, buffers, acento, 0.0F, 6.15F, 0.95F, 1.5F, 0.16F, 0.06F);                         // la luz del pecho
        caja(pose, buffers, luz, NEGRO, 0.0F, 6.4F, -0.9F, 1.6F, 1.2F, 0.15F);                      // la espalda
        caja(pose, buffers, luz, NEGRO, 0.0F, 7.6F, 0.0F, 0.6F, 0.35F, 0.6F);                       // el cuello
        pose.pushPose();                                                  // la cabeza (gira mirando la fila)
        if (robot.canta()) {
            pose.mulPose(Axis.YP.rotationDegrees(Mth.sin((robot.tickCount + parcial) * 0.07F) * GIRO_CABEZA));
        }
        caja(pose, buffers, luz, GRIS, 0.0F, 8.25F, 0.05F, 1.3F, 1.0F, 1.3F);
        luz(pose, buffers, acento, 0.0F, 8.35F, 0.71F, 1.1F, 0.2F, 0.08F);                         // el visor
        caja(pose, buffers, luz, NEGRO, 0.0F, 8.85F, -0.05F, 0.22F, 0.25F, 1.2F);                   // la cresta
        pose.popPose();
        pose.popPose();
        super.render(robot, giro, parcial, pose, buffers, luz);       // lo de siempre (el nombre, si tuviera)
    }

    /**
     * Un brazo: del hombro al medio de la calle, donde la mano llega a la altura que dice el ángulo (levantado si es
     * positivo, bajado si es negativo). El brazo y el antebrazo miden lo mismo, y el codo queda doblado hacia arriba (lo
     * que haga falta para que la mano llegue justo al medio). En el antebrazo, una línea de luz.
     */
    private void brazo(PoseStack pose, MultiBufferSource buffers, int luz, BlockState acento, int lado, float angulo) {
        float adelante = Robot.AL_MEDIO - Robot.HOMBRO_Z;
        float rad = angulo * Mth.DEG_TO_RAD;
        float largo = adelante / Mth.cos(rad);                           // del hombro a la mano
        float coseno = (Robot.BRAZO * Robot.BRAZO + largo * largo - Robot.ANTEBRAZO * Robot.ANTEBRAZO)
                / (2.0F * Robot.BRAZO * largo);
        float subeBrazo = rad + (float) Math.acos(Mth.clamp(coseno, -1.0F, 1.0F));
        float codoY = Robot.BRAZO * Mth.sin(subeBrazo);
        float codoZ = Robot.BRAZO * Mth.cos(subeBrazo);
        float subeAntebrazo = (float) Math.atan2(largo * Mth.sin(rad) - codoY, largo * Mth.cos(rad) - codoZ);
        float antebrazo = Robot.ANTEBRAZO - MANO;
        pose.pushPose();
        pose.translate(Robot.HOMBRO_X * lado, Robot.HOMBRO_Y, Robot.HOMBRO_Z);
        pose.pushPose();
        pose.mulPose(Axis.XP.rotation(-subeBrazo));
        caja(pose, buffers, luz, GRIS, 0.0F, 0.0F, Robot.BRAZO / 2.0F, 0.75F, 0.75F, Robot.BRAZO);
        pose.popPose();
        pose.translate(0.0F, codoY, codoZ);
        caja(pose, buffers, luz, NEGRO, 0.0F, 0.0F, 0.0F, 0.85F, 0.85F, 0.85F);                     // el codo
        pose.mulPose(Axis.XP.rotation(-subeAntebrazo));
        caja(pose, buffers, luz, GRIS, 0.0F, 0.0F, antebrazo / 2.0F, 0.7F, 0.7F, antebrazo);
        caja(pose, buffers, luz, NEGRO, 0.0F, 0.0F, Robot.ANTEBRAZO - MANO / 2.0F, 0.9F, 0.9F, MANO);   // la mano
        luz(pose, buffers, acento, 0.0F, 0.36F, antebrazo / 2.0F, 0.08F, 0.06F, antebrazo - 0.6F);
        pose.popPose();
    }

    /** Un bloque estirado: centro (cx, cy, cz) y tamaño (sx, sy, sz), en bloques. */
    private void caja(PoseStack pose, MultiBufferSource buffers, int luz, BlockState estado,
                      float cx, float cy, float cz, float sx, float sy, float sz) {
        pose.pushPose();
        pose.translate(cx - sx / 2.0F, cy - sy / 2.0F, cz - sz / 2.0F);
        pose.scale(sx, sy, sz);
        bloques.renderSingleBlock(estado, pose, buffers, luz, OverlayTexture.NO_OVERLAY);
        pose.popPose();
    }

    /**
     * Una luz: el bloque de color con toda la luz y, encima (apenas más grande), el mismo bloque sumado a lo que hay
     * atrás, así brilla aunque esté oscuro.
     */
    @SuppressWarnings("deprecation")                                  // el renderModel de siempre (sin los datos de NeoForge)
    private void luz(PoseStack pose, MultiBufferSource buffers, BlockState estado,
                     float cx, float cy, float cz, float sx, float sy, float sz) {
        caja(pose, buffers, LightTexture.FULL_BRIGHT, estado, cx, cy, cz, sx, sy, sz);
        pose.pushPose();
        pose.translate(cx - sx / 2.0F - BORDE_LUZ, cy - sy / 2.0F - BORDE_LUZ, cz - sz / 2.0F - BORDE_LUZ);
        pose.scale(sx + 2.0F * BORDE_LUZ, sy + 2.0F * BORDE_LUZ, sz + 2.0F * BORDE_LUZ);
        bloques.getModelRenderer().renderModel(pose.last(), buffers.getBuffer(BRILLA), estado, bloques.getBlockModel(estado),
                1.0F, 1.0F, 1.0F, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(Robot robot) {
        return InventoryMenu.BLOCK_ATLAS;
    }
}
