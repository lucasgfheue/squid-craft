package com.juegosdelpatio;

import java.util.function.Supplier;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;

/**
 * Los cuatro rangos de los guardias, de menor a mayor. Cada uno tiene su color (casco y brazalete),
 * su pieza de ajedrez como símbolo (en el pecho, la espalda y el nombre) y su arma.
 *
 * <pre>
 *   Vigilante   ♟ peón     blanco   porra
 *   Guardia     ♞ caballo  azul     pistola
 *   Sargento    ♜ torre    rojo     rifle
 *   Comandante  ♚ rey      dorado   escopeta
 * </pre>
 */
public enum Rango {
    VIGILANTE("vigilante", ChatFormatting.WHITE, 24.0, 2.0, () -> Registro.PORRA.get()),
    GUARDIA("guardia", ChatFormatting.BLUE, 28.0, 4.0, () -> Registro.PISTOLA.get()),
    SARGENTO("sargento", ChatFormatting.RED, 34.0, 6.0, () -> Registro.RIFLE.get()),
    COMANDANTE("comandante", ChatFormatting.GOLD, 50.0, 10.0, () -> Registro.ESCOPETA.get());

    public final String id;
    public final ChatFormatting color;
    public final double vida;
    public final double armadura;
    private final Supplier<Item> arma;

    Rango(String id, ChatFormatting color, double vida, double armadura, Supplier<Item> arma) {
        this.id = id;
        this.color = color;
        this.vida = vida;
        this.armadura = armadura;
        this.arma = arma;
    }

    public Item arma() {
        return arma.get();
    }

    /** "♞ Guardia", en el color del rango (el símbolo viene del archivo de idioma). */
    public Component nombre() {
        return Component.translatable("rango.juegosdelpatio." + id).withStyle(color);
    }

    public static Rango deIndice(int indice) {
        Rango[] todos = values();
        return todos[Math.floorMod(indice, todos.length)];
    }

    /** Rango al azar para los huevos: muchos vigilantes, pocos comandantes. */
    public static Rango alAzar(RandomSource azar) {
        int n = azar.nextInt(10);
        return n < 4 ? VIGILANTE : n < 7 ? GUARDIA : n < 9 ? SARGENTO : COMANDANTE;
    }
}
