package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * El juego 2, "Sálvese quien pueda": en una estación de trenes abandonada, de noche (ver gen_casilleros.py), con un
 * robot gigante, el Cazador ({@link Cazador}), y más de 200 casilleros de metal.
 *
 * <ol>
 *   <li>Todos empiezan repartidos por la estación. El Cazador la recorre caminando, con los ojos apagados: mientras no
 *       suene la alarma, no hace nada. Los casilleros están todos cerrados (luz roja).</li>
 *   <li>Cuando suena la alarma (nadie sabe cuándo: de 15 a 25 segundos), se abren algunos casilleros, los de luz
 *       verde: siempre 3 menos que la gente que queda. Al que se mete en uno se le cierra la puerta, y está a salvo. En
 *       cada casillero entra uno solo.</li>
 *   <li>Con la alarma, al Cazador se le prenden los ojos: camina más rápido y gira la cabeza, buscando. A los 3 segundos
 *       empieza a ver: al que ve afuera de un casillero (a menos de 18 bloques, adelante, y sin nada en el medio), le tira
 *       un rayo y queda eliminado.</li>
 *   <li>A los 20 segundos, el Cazador revisa toda la estación: los que no están en un casillero quedan eliminados. Después
 *       se abren los casilleros, todos salen y vuelve la calma.</li>
 *   <li>Son 5 rondas; los que quedan, pasan. Se vale empujar (clic derecho con la mano vacía); pegar, no.</li>
 * </ol>
 */
public final class Casilleros {
    // ------------------------------------------------------------------ la arena (igual que gen_casilleros.py)
    public static final ResourceLocation ARENA = Complejo.id("casilleros");
    /** Esquina de la plantilla casilleros.nbt (91 x 30 x 133): debajo del piso, en la esquina noroeste. */
    public static final BlockPos ORIGEN = new BlockPos(5955, 98, -18);
    /** La 4 es la estación. Antes, en el mismo lugar, estuvo Fuego cruzado (las torres, la 1 y la 2; la fundición, la 3). */
    static final int VERSION_ARENA = 4;
    /** Lo que ocupa la arena (y lo de antes), para mantenerla cargada mientras se juega y para borrar. */
    static final int X0 = 5955;
    static final int X1 = 6045;
    static final int Z0 = -18;
    static final int Z1 = 114;
    private static final int ABAJO = 39;
    private static final int ARRIBA = 127;
    /** Donde se para la gente: arriba del piso de la estación. */
    static final int PISO = 100;
    /** Por donde se anda: la nave, sin el vestíbulo (al norte) ni el taller del Cazador (al sur). */
    static final int NAVE_X0 = 5961;
    static final int NAVE_X1 = 6039;
    static final int NAVE_Z0 = 3;
    static final int NAVE_Z1 = 103;
    /** El vestíbulo (cerrado con rejas): donde se llega y se escuchan las reglas. */
    private static final int PALCO_X0 = 5977;
    private static final int PALCO_X1 = 6023;
    private static final int PALCO_Z0 = -10;
    private static final int PALCO_Z1 = 0;
    static final Vec3 PODIO = new Vec3(6000.5, 102.0, -13.5);
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(5975.5, 100.0, -0.5), new Vec3(6025.5, 100.0, -0.5),
            new Vec3(5992.5, 100.0, -13.5), new Vec3(6008.5, 100.0, -13.5),
    };
    static final float[] GIROS_SARGENTOS = {0.0F, 0.0F, 0.0F, 0.0F};

    /** Un casillero: la x de la puerta, la de adentro (y la de afuera, enfrente) y la z. */
    record Casillero(int puertaX, int adentroX, int z) {
        int afueraX() {
            return puertaX + (puertaX - adentroX);
        }

        BlockPos puerta() {
            return new BlockPos(puertaX, PISO, z);
        }

        BlockPos luz() {
            return new BlockPos(puertaX, PISO + 2, z);
        }

        Vec3 adentro() {
            return new Vec3(adentroX + 0.5, PISO, z + 0.5);
        }

        Vec3 afuera() {
            return new Vec3(afueraX() + 0.5, PISO, z + 0.5);
        }

        /** Para dónde se mira desde adentro, hacia afuera (grados). */
        float giroAfuera() {
            return puertaX > adentroX ? -90.0F : 90.0F;
        }
    }

    /** Los casilleros: a lo largo de las dos paredes largas y de los dos lados de las dos islas del medio. */
    static final Casillero[] CASILLEROS;
    /** De cada lugar (la puerta y el de adentro, en el piso), de qué casillero es. */
    private static final Map<Long, Integer> CELDAS = new HashMap<>();

    static {
        List<Casillero> lista = new ArrayList<>();
        for (int z = 8; z <= 98; z += 2) {
            lista.add(new Casillero(5960, 5959, z));
            lista.add(new Casillero(6040, 6041, z));
        }
        for (int z = 32; z <= 86; z += 2) {
            lista.add(new Casillero(5984, 5985, z));
            lista.add(new Casillero(5988, 5987, z));
            lista.add(new Casillero(6012, 6013, z));
            lista.add(new Casillero(6016, 6015, z));
        }
        CASILLEROS = lista.toArray(new Casillero[0]);
        for (int i = 0; i < CASILLEROS.length; i++) {
            CELDAS.put(celda(CASILLEROS[i].puertaX(), CASILLEROS[i].z()), i);
            CELDAS.put(celda(CASILLEROS[i].adentroX(), CASILLEROS[i].z()), i);
        }
    }

    /** Por dónde camina el Cazador: un ocho por los tres pasillos (el del medio, dos veces). Y su taller, al sur. */
    static final Vec3[] RECORRIDO = {
            new Vec3(6000.5, PISO, 96.5), new Vec3(6000.5, PISO, 20.5), new Vec3(5972.5, PISO, 20.5),
            new Vec3(5972.5, PISO, 96.5), new Vec3(6000.5, PISO, 96.5), new Vec3(6000.5, PISO, 20.5),
            new Vec3(6028.5, PISO, 20.5), new Vec3(6028.5, PISO, 96.5),
    };
    static final Vec3 TALLER = new Vec3(6000.5, PISO, 108.5);

    // ------------------------------------------------------------------ reglas
    static final int RONDAS = 5;
    /** En cada ronda se abren 3 casilleros menos que la gente que queda (o la mitad, si quedan muy pocos). */
    static final int FALTAN = 3;
    /** La calma dura de 15 a 25 segundos (la primera, 10 más, para conocer la estación); la alarma, 20. */
    private static final int CALMA_MIN = 15 * 20;
    private static final int CALMA_AZAR = 10 * 20;
    private static final int PRIMERA_CALMA = 10 * 20;
    static final int ALARMA = 20 * 20;
    /** Después de la alarma: 3 segundos de revisión y 5 para salir de los casilleros. */
    private static final int REVISION = 3 * 20;
    private static final int SALIR = 5 * 20;
    /**
     * Lo que ve el Cazador: hasta 18 bloques, 35 grados para cada lado de donde mira. Un rayo cada 3/4 de segundo. Con
     * esto (y 3 casilleros menos que la gente, en 5 rondas) quedan eliminados unos 25 en todo el juego (ver el README).
     */
    static final double VISTA = 18.0;
    private static final double ANGULO = 35.0;
    private static final int ENTRE_RAYOS = 15;
    /** Los primeros 3 segundos de la alarma el Cazador todavía no ve (se le están prendiendo los ojos). */
    static final int ARRANQUE = 3 * 20;
    /** Cuánto gira la cabeza para cada lado, buscando; y qué tan rápido camina (bloques por tick), tranquilo y buscando. */
    private static final float GIRO_CABEZA = 50.0F;
    private static final double PASO_CALMA = 0.08;
    private static final double PASO_ALARMA = 0.13;

    private enum Estado { NINGUNO, CALMA, ALARMA, REVISION, SALIR, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int duracion;
    private static int ronda;
    private static int pasaron;
    private static int ultimoRayo;
    /** El Cazador, y por dónde va de su recorrido. */
    @Nullable
    private static Cazador cazador;
    private static int tramo;
    private static final Set<UUID> JUEGAN = new HashSet<>();
    /** Los casilleros abiertos en esta alarma, quién está en cada uno, y en cuál está cada uno. */
    private static final Set<Integer> ABIERTOS = new HashSet<>();
    private static final Map<Integer, UUID> OCUPADOS = new HashMap<>();
    private static final Map<UUID, Integer> ESCONDIDOS = new HashMap<>();
    /** A qué casillero va cada bot (para que no corran todos al mismo): el casillero y el bot, y al revés. */
    private static final Map<Integer, UUID> RESERVADOS = new HashMap<>();
    private static final Map<UUID, Integer> RESERVA_DE = new HashMap<>();

    private Casilleros() {
    }

    private static long celda(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean alarma() {
        return estado == Estado.ALARMA;
    }

    static boolean calma() {
        return estado == Estado.CALMA || estado == Estado.SALIR;
    }

    static int pasaron() {
        return pasaron;
    }

    static boolean juega(LivingEntity quien) {
        return estado != Estado.NINGUNO && JUEGAN.contains(quien.getUUID()) && quien.isAlive() && !Juego.eliminado(quien);
    }

    /** ¿Está metido en un casillero? */
    static boolean escondido(LivingEntity quien) {
        return ESCONDIDOS.containsKey(quien.getUUID());
    }

    @Nullable
    static Cazador cazador() {
        return cazador != null && cazador.isAlive() ? cazador : null;
    }

    /** Por qué quedó eliminado uno que murió en el juego (casi nunca: acá solo elimina el Cazador). */
    static String motivo() {
        return "moriste";
    }

    // ------------------------------------------------------------------ empezar
    static void empezar(ServerLevel complejo, List<LivingEntity> gente) {
        olvidar();
        cerrarTodos(complejo);
        sacarCazadores(complejo);
        cazador = Cazador.poner(complejo, TALLER, 180.0F);
        tramo = 0;
        RandomSource azar = complejo.getRandom();
        for (LivingEntity quien : gente) {
            JUEGAN.add(quien.getUUID());
            llevar(complejo, quien, lugarLibre(complejo, azar), azar.nextFloat() * 360.0F);
        }
        ronda = 1;
        calma(complejo, PRIMERA_CALMA);
    }

    /** Vuelve la calma (o empieza): los casilleros cerrados y, en un rato que nadie sabe, la alarma. */
    private static void calma(ServerLevel complejo, int extra) {
        estado = Estado.CALMA;
        tiempo = 0;
        duracion = extra + CALMA_MIN + complejo.getRandom().nextInt(CALMA_AZAR + 1);
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.casilleros_ronda", ronda, RONDAS));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (juega(jugador)) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.casilleros_ronda", ronda, RONDAS)
                                .withStyle(ChatFormatting.GOLD),
                        Component.translatable("titulo.juegosdelpatio.casilleros_ronda_detalle").withStyle(ChatFormatting.GRAY),
                        5, 50, 10);
            }
        }
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        moverCazador();
        switch (estado) {
            case CALMA -> {
                if (tiempo >= duracion) {
                    sonarAlarma(complejo);
                }
            }
            case ALARMA -> {
                esconder(complejo);
                if (tiempo % 4 == 0) {
                    vigilar(complejo);
                }
                if (tiempo % 20 == 0) {
                    int queda = (ALARMA - tiempo) / 20;
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), SoundSource.MASTER, 1.0F, queda <= 5 ? 1.4F : 0.8F);
                    }
                }
                if (tiempo >= ALARMA) {
                    revisar(complejo);
                }
            }
            case REVISION -> {
                mantenerAdentro(complejo);
                if (tiempo >= REVISION) {
                    abrirOcupados(complejo);
                    estado = Estado.SALIR;
                    tiempo = 0;
                }
            }
            case SALIR -> {
                if (tiempo >= SALIR) {
                    sacarATodos(complejo);
                    List<LivingEntity> vivos = enJuego(complejo);
                    if (ronda >= RONDAS || vivos.size() <= 1) {
                        estado = Estado.TERMINADO;
                        pasaron = vivos.size();
                        if (cazador() != null) {
                            cazador.ponerOjos(false);
                        }
                        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.6F);
                        }
                    } else {
                        ronda++;
                        calma(complejo, 0);
                    }
                }
            }
            default -> {
            }
        }
        if (estado != Estado.TERMINADO) {
            pasaron = enJuego(complejo).size();                       // por si el juego se corta antes
            if (tiempo % 10 == 1) {
                barra(complejo);
            }
        }
        return estado == Estado.TERMINADO;
    }

    private static void barra(ServerLevel complejo) {
        int vivos = enJuego(complejo).size();
        if (estado == Estado.ALARMA) {
            Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.casilleros_alarma", ronda, RONDAS,
                            Juego.reloj(Math.max(0, ALARMA - tiempo)), ABIERTOS.size(), vivos),
                    BossEvent.BossBarColor.RED, Math.max(0, ALARMA - tiempo) / (float) ALARMA);
        } else {
            Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.casilleros_calma", ronda, RONDAS, vivos),
                    BossEvent.BossBarColor.WHITE, 1.0F);
        }
    }

    /** ¡Alarma! Se abren los casilleros (3 menos que la gente) y al Cazador se le prenden los ojos. */
    private static void sonarAlarma(ServerLevel complejo) {
        estado = Estado.ALARMA;
        tiempo = 0;
        ultimoRayo = -ENTRE_RAYOS;
        int gente = enJuego(complejo).size();
        int abiertos = Math.min(CASILLEROS.length, Math.max(gente - FALTAN, (gente + 1) / 2));
        List<Integer> todos = new ArrayList<>();
        for (int i = 0; i < CASILLEROS.length; i++) {
            todos.add(i);
        }
        RandomSource azar = complejo.getRandom();
        for (int i = todos.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            Integer cambio = todos.get(i);
            todos.set(i, todos.get(j));
            todos.set(j, cambio);
        }
        ABIERTOS.clear();
        OCUPADOS.clear();
        ESCONDIDOS.clear();
        RESERVADOS.clear();
        RESERVA_DE.clear();
        for (int i = 0; i < abiertos; i++) {
            ABIERTOS.add(todos.get(i));
            puerta(complejo, todos.get(i), true, false);
        }
        if (cazador() != null) {
            cazador.ponerOjos(true);
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.casilleros_alarma", abiertos, gente, ALARMA / 20));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.RAID_HORN.value(), SoundSource.MASTER, 1.0F, 1.2F);
            if (juega(jugador)) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.alarma").withStyle(ChatFormatting.RED),
                        Component.translatable("titulo.juegosdelpatio.alarma_detalle").withStyle(ChatFormatting.GRAY), 2, 40, 10);
            }
        }
    }

    /** ¿Alguien se metió en un casillero abierto y libre? Se le cierra la puerta. Y los que ya están, se quedan adentro. */
    private static void esconder(ServerLevel complejo) {
        mantenerAdentro(complejo);
        for (LivingEntity quien : enJuego(complejo)) {
            if (escondido(quien) || Math.abs(quien.getY() - PISO) > 0.5) {
                continue;
            }
            Integer i = CELDAS.get(celda(Mth.floor(quien.getX()), Mth.floor(quien.getZ())));
            if (i != null && ABIERTOS.contains(i) && !OCUPADOS.containsKey(i)) {
                meter(complejo, quien, i);
            }
        }
    }

    /** Lo mete en el casillero: adentro, mirando para afuera, y se le cierra la puerta. */
    private static void meter(ServerLevel complejo, LivingEntity quien, int i) {
        Casillero casillero = CASILLEROS[i];
        soltar(quien.getUUID());
        UUID reservo = RESERVADOS.remove(i);                         // (si lo había elegido un bot, que busque otro)
        if (reservo != null) {
            RESERVA_DE.remove(reservo);
        }
        OCUPADOS.put(i, quien.getUUID());
        ESCONDIDOS.put(quien.getUUID(), i);
        llevar(complejo, quien, casillero.adentro(), casillero.giroAfuera());
        puerta(complejo, i, false, true);
        for (LivingEntity otro : enJuego(complejo)) {             // si había otro en la puerta, queda afuera
            Integer suyo = CELDAS.get(celda(Mth.floor(otro.getX()), Mth.floor(otro.getZ())));
            if (otro != quien && !escondido(otro) && suyo != null && suyo == i) {
                llevar(complejo, otro, casillero.afuera(), casillero.giroAfuera());
            }
        }
        if (quien instanceof ServerPlayer jugador) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.a_salvo").withStyle(ChatFormatting.GREEN),
                    Component.translatable("titulo.juegosdelpatio.a_salvo_detalle").withStyle(ChatFormatting.GRAY), 2, 40, 10);
        }
    }

    /** Para los bots: se mete en ese casillero si llegó a la puerta y sigue abierto y libre. true si quedó adentro. */
    static boolean meterBot(JugadorBot bot, int i) {
        if (estado != Estado.ALARMA || !(bot.level() instanceof ServerLevel complejo) || !juega(bot) || escondido(bot)
                || !ABIERTOS.contains(i) || OCUPADOS.containsKey(i)) {
            return false;
        }
        if (bot.position().distanceToSqr(CASILLEROS[i].afuera()) > 2.2 * 2.2 && CELDAS.get(celda(Mth.floor(bot.getX()),
                Mth.floor(bot.getZ()))) == null) {
            return false;
        }
        meter(complejo, bot, i);
        return true;
    }

    /** Los que están en un casillero no salen (si alguno se movió, vuelve adentro). */
    private static void mantenerAdentro(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            Integer i = ESCONDIDOS.get(quien.getUUID());
            if (i != null && quien.position().distanceToSqr(CASILLEROS[i].adentro()) > 0.8) {
                llevar(complejo, quien, CASILLEROS[i].adentro(), CASILLEROS[i].giroAfuera());
            }
        }
    }

    /** El Cazador busca: al que ve afuera de un casillero (cerca, adelante, sin nada en el medio), le tira un rayo. */
    private static void vigilar(ServerLevel complejo) {
        Cazador robot = cazador();
        if (robot == null || tiempo < ARRANQUE || tiempo - ultimoRayo < ENTRE_RAYOS) {
            return;
        }
        Vec3 mirada = robot.mirada();
        LivingEntity visto = null;
        double masCerca = VISTA * VISTA;
        for (LivingEntity quien : enJuego(complejo)) {
            if (escondido(quien)) {
                continue;
            }
            double dx = quien.getX() - robot.getX();
            double dz = quien.getZ() - robot.getZ();
            double d2 = dx * dx + dz * dz;
            if (d2 >= masCerca || d2 < 0.01) {
                continue;
            }
            double coseno = (dx * mirada.x + dz * mirada.z) / Math.sqrt(d2);
            if (coseno < Math.cos(Math.toRadians(ANGULO)) || !quien.hasLineOfSight(robot)) {
                continue;
            }
            masCerca = d2;
            visto = quien;
        }
        if (visto != null) {
            ultimoRayo = tiempo;
            soltar(visto.getUUID());
            rayo(complejo, robot, visto);
            Component aviso = Component.translatable("mensaje.juegosdelpatio.lo_vio_el_cazador", Juego.nombreDe(visto))
                    .withStyle(ChatFormatting.DARK_RED);
            for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                if (jugador != visto) {
                    jugador.sendSystemMessage(aviso);
                }
            }
            Juego.eliminar(complejo, visto, false, "te_vio_el_cazador");
        }
    }

    /** Se terminó la alarma: el Cazador revisa la estación. Los que no están en un casillero, quedan eliminados. */
    private static void revisar(ServerLevel complejo) {
        estado = Estado.REVISION;
        tiempo = 0;
        Cazador robot = cazador();
        int afuera = 0;
        for (LivingEntity quien : enJuego(complejo)) {
            if (escondido(quien)) {
                continue;
            }
            afuera++;
            if (robot != null && robot.distanceToSqr(quien) < 90.0 * 90.0) {
                rayo(complejo, robot, quien);
            }
            Juego.eliminar(complejo, quien, false, "no_te_escondiste");
        }
        for (int i : ABIERTOS) {                                     // los que quedaron libres, se cierran
            if (!OCUPADOS.containsKey(i)) {
                puerta(complejo, i, false, false);
            }
        }
        RESERVADOS.clear();
        RESERVA_DE.clear();
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.casilleros_revision", afuera));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.BEACON_DEACTIVATE, SoundSource.MASTER, 1.0F, 0.6F);
        }
    }

    /** El rayo del Cazador: una línea roja del visor al que vio (y el ruido de un rayo). */
    private static void rayo(ServerLevel complejo, Cazador robot, LivingEntity quien) {
        Vec3 desde = robot.visor();
        Vec3 hasta = quien.position().add(0.0, quien.getBbHeight() * 0.6, 0.0);
        DustParticleOptions rojo = new DustParticleOptions(new Vector3f(1.0F, 0.08F, 0.05F), 1.6F);
        int puntos = Math.min(120, (int) (desde.distanceTo(hasta) * 3.0));
        for (int k = 0; k <= puntos; k++) {
            Vec3 p = desde.lerp(hasta, k / (double) Math.max(1, puntos));
            complejo.sendParticles(rojo, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        complejo.sendParticles(ParticleTypes.LARGE_SMOKE, hasta.x, hasta.y, hasta.z, 8, 0.25, 0.4, 0.25, 0.02);
        complejo.playSound(null, quien.getX(), quien.getY(), quien.getZ(), SoundEvents.GUARDIAN_ATTACK, SoundSource.HOSTILE,
                2.0F, 0.7F);
    }

    /** Después de la revisión se abren los casilleros ocupados: todos salen. */
    private static void abrirOcupados(ServerLevel complejo) {
        for (int i : OCUPADOS.keySet()) {
            puerta(complejo, i, true, false);
        }
        ESCONDIDOS.clear();
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 1.0F, 0.8F);
        }
        if (cazador() != null) {
            cazador.ponerOjos(false);
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (juega(jugador)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.salgan_casilleros")
                        .withStyle(ChatFormatting.GOLD), true);
            }
        }
    }

    /** Se cierran todos los casilleros; el que siguió adentro, sale (a la puerta de afuera). */
    private static void sacarATodos(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            Integer i = CELDAS.get(celda(Mth.floor(quien.getX()), Mth.floor(quien.getZ())));
            if (i != null) {
                Casillero casillero = CASILLEROS[i];
                llevar(complejo, quien, casillero.afuera(), casillero.giroAfuera());
            }
        }
        cerrarTodos(complejo);
        ABIERTOS.clear();
        OCUPADOS.clear();
        ESCONDIDOS.clear();
        RESERVADOS.clear();
        RESERVA_DE.clear();
    }

    // ------------------------------------------------------------------ el Cazador
    /** Camina su recorrido (más rápido con la alarma); con la alarma gira la cabeza buscando; en la revisión, se para. */
    private static void moverCazador() {
        Cazador robot = cazador();
        if (robot == null) {
            return;
        }
        if (estado == Estado.REVISION || estado == Estado.TERMINADO) {
            robot.ponerCabeza(Mth.sin(tiempo * 0.3F) * GIRO_CABEZA);
            return;
        }
        boolean buscando = estado == Estado.ALARMA;
        robot.ponerCabeza(buscando ? Mth.sin(tiempo * 0.12F) * GIRO_CABEZA : 0.0F);
        if (robot.caminarHacia(RECORRIDO[tramo], buscando ? PASO_ALARMA : PASO_CALMA)) {
            tramo = (tramo + 1) % RECORRIDO.length;
        }
    }

    private static void sacarCazadores(ServerLevel complejo) {
        for (Cazador viejo : complejo.getEntitiesOfClass(Cazador.class, zona())) {
            viejo.discard();
        }
        cazador = null;
    }

    // ------------------------------------------------------------------ los casilleros
    /**
     * Abre o cierra la puerta de un casillero (las dos mitades) y le pone la luz: verde si queda abierto y libre. Con
     * {@code sonido}, se oye la puerta (cuando se abren o cierran muchas juntas, no: suena una sola cosa para todos).
     */
    private static void puerta(ServerLevel complejo, int i, boolean abierta, boolean sonido) {
        Casillero casillero = CASILLEROS[i];
        for (int y = 0; y <= 1; y++) {
            BlockPos pos = casillero.puerta().above(y);
            BlockState estadoPuerta = complejo.getBlockState(pos);
            if (estadoPuerta.hasProperty(BlockStateProperties.OPEN) && estadoPuerta.getValue(BlockStateProperties.OPEN) != abierta) {
                complejo.setBlock(pos, estadoPuerta.setValue(BlockStateProperties.OPEN, abierta),
                        Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
            }
        }
        boolean verde = abierta && estado == Estado.ALARMA && !OCUPADOS.containsKey(i);
        BlockState luz = verde ? Blocks.VERDANT_FROGLIGHT.defaultBlockState() : Blocks.RED_CONCRETE.defaultBlockState();
        if (!complejo.getBlockState(casillero.luz()).is(luz.getBlock())) {
            complejo.setBlock(casillero.luz(), luz, Block.UPDATE_CLIENTS);
        }
        if (sonido) {
            complejo.playSound(null, casillero.puerta(), abierta ? SoundEvents.IRON_DOOR_OPEN : SoundEvents.IRON_DOOR_CLOSE,
                    SoundSource.BLOCKS, 0.8F, 1.0F);
        }
    }

    /** Todos los casilleros cerrados, con la luz roja. */
    private static void cerrarTodos(ServerLevel complejo) {
        for (int i = 0; i < CASILLEROS.length; i++) {
            Casillero casillero = CASILLEROS[i];
            for (int y = 0; y <= 1; y++) {
                BlockPos posPuerta = casillero.puerta().above(y);
                BlockState estadoPuerta = complejo.getBlockState(posPuerta);
                if (estadoPuerta.hasProperty(BlockStateProperties.OPEN) && estadoPuerta.getValue(BlockStateProperties.OPEN)) {
                    complejo.setBlock(posPuerta, estadoPuerta.setValue(BlockStateProperties.OPEN, false),
                            Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                }
            }
            if (!complejo.getBlockState(casillero.luz()).is(Blocks.RED_CONCRETE)) {
                complejo.setBlock(casillero.luz(), Blocks.RED_CONCRETE.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
    }

    // ------------------------------------------------------------------ para los bots
    /**
     * El casillero abierto y libre al que conviene ir: el más cerca que no eligió otro bot, pero castigando los que
     * están cerca del Cazador. Queda elegido (los otros bots buscan otro). -1 si no queda ninguno.
     */
    static int casilleroPara(JugadorBot bot) {
        if (estado != Estado.ALARMA) {
            return -1;
        }
        Cazador robot = cazador();
        UUID yo = bot.getUUID();
        int mejor = -1;
        double mejorD = Double.MAX_VALUE;
        for (int i : ABIERTOS) {
            UUID otro = RESERVADOS.get(i);
            if (OCUPADOS.containsKey(i) || otro != null && !otro.equals(yo)) {
                continue;
            }
            Vec3 afuera = CASILLEROS[i].afuera();
            double d = Math.sqrt(afuera.distanceToSqr(bot.position()));
            if (robot != null && Math.sqrt(afuera.distanceToSqr(robot.position())) < 12.0) {
                d += 25.0;                                           // cerca del Cazador: mejor otro
            }
            if (d < mejorD) {
                mejorD = d;
                mejor = i;
            }
        }
        soltar(yo);
        if (mejor >= 0) {
            RESERVADOS.put(mejor, yo);
            RESERVA_DE.put(yo, mejor);
        }
        return mejor;
    }

    /** Ya no va a ese casillero (se metió en uno, lo eliminaron o eligió otro): que lo pueda elegir otro bot. */
    private static void soltar(UUID quien) {
        Integer antes = RESERVA_DE.remove(quien);
        if (antes != null) {
            RESERVADOS.remove(antes, quien);
        }
    }

    /** ¿Ese casillero sigue abierto y libre? */
    static boolean libre(int i) {
        return estado == Estado.ALARMA && ABIERTOS.contains(i) && !OCUPADOS.containsKey(i);
    }

    /**
     * Un lugar adonde pasear en la calma: cerca de algún casillero (los bots no son tontos) que no quede lejos, y lejos
     * del Cazador.
     */
    static Vec3 paseo(JugadorBot bot) {
        RandomSource azar = bot.getRandom();
        Cazador robot = cazador();
        for (int intento = 0; intento < 16; intento++) {
            Vec3 cerca = CASILLEROS[azar.nextInt(CASILLEROS.length)].afuera().add(azar.nextInt(9) - 4, 0.0, azar.nextInt(9) - 4);
            if (cerca.distanceToSqr(bot.position()) > 32.0 * 32.0
                    || robot != null && cerca.distanceToSqr(robot.position()) < 14.0 * 14.0) {
                continue;
            }
            BlockPos pos = BlockPos.containing(cerca);
            if (pos.getX() >= NAVE_X0 && pos.getX() <= NAVE_X1 && pos.getZ() >= NAVE_Z0 && pos.getZ() <= NAVE_Z1
                    && libre(bot.level(), pos)) {
                return new Vec3(pos.getX() + 0.5, PISO, pos.getZ() + 0.5);
            }
        }
        return bot.position();
    }

    /** Adónde se escapa el bot que no consiguió casillero (o al que el Cazador tiene cerca): para el otro lado. */
    static Vec3 huida(JugadorBot bot) {
        Cazador robot = cazador();
        if (robot == null) {
            return paseo(bot);
        }
        double dx = bot.getX() - robot.getX();
        double dz = bot.getZ() - robot.getZ();
        double d = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
        double x = Mth.clamp(bot.getX() + dx / d * 10.0, NAVE_X0 + 1.5, NAVE_X1 - 0.5);
        double z = Mth.clamp(bot.getZ() + dz / d * 10.0, NAVE_Z0 + 1.5, NAVE_Z1 - 0.5);
        return new Vec3(x, PISO, z);
    }

    // ------------------------------------------------------------------ muertes y limpiar
    /** Murió uno que jugaba sin que lo eliminara el Cazador (muy raro): Juego lo anota como eliminado. Acá se avisa. */
    static void alMorir(ServerLevel complejo, LivingEntity muerto) {
        if (!JUEGAN.contains(muerto.getUUID())) {
            return;
        }
        Integer i = ESCONDIDOS.remove(muerto.getUUID());
        if (i != null) {
            OCUPADOS.remove(i);
        }
        soltar(muerto.getUUID());
        Component mensaje = Component.translatable("mensaje.juegosdelpatio.murio", Juego.nombreDe(muerto));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (jugador != muerto) {
                jugador.sendSystemMessage(mensaje.copy().withStyle(ChatFormatting.DARK_RED));
            }
        }
    }

    static void limpiar(ServerLevel complejo) {
        sacarCazadores(complejo);
        if (EstadoComplejo.de(complejo.getServer()).versionCasilleros() == VERSION_ARENA) {
            cerrarTodos(complejo);
        }
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ronda = 0;
        cazador = null;
        tramo = 0;
        JUEGAN.clear();
        ABIERTOS.clear();
        OCUPADOS.clear();
        ESCONDIDOS.clear();
        RESERVADOS.clear();
        RESERVA_DE.clear();
    }

    // ------------------------------------------------------------------ la arena
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(PALCO_X0 + azar.nextInt(PALCO_X1 - PALCO_X0 + 1) + 0.5, PISO,
                PALCO_Z0 + azar.nextInt(PALCO_Z1 - PALCO_Z0 + 1) + 0.5);
    }

    /** Un lugar libre de la nave, lejos del taller del Cazador. */
    static Vec3 lugarLibre(Level nivel, RandomSource azar) {
        for (int intento = 0; intento < 40; intento++) {
            int x = NAVE_X0 + 1 + azar.nextInt(NAVE_X1 - NAVE_X0 - 1);
            int z = NAVE_Z0 + 2 + azar.nextInt(NAVE_Z1 - NAVE_Z0 - 12);
            if (libre(nivel, new BlockPos(x, PISO, z))) {
                return new Vec3(x + 0.5, PISO, z + 0.5);
            }
        }
        return new Vec3(5972.5, PISO, 50.5);
    }

    /** ¿Se puede estar parado ahí (piso abajo y lugar para el cuerpo), afuera de los casilleros? */
    private static boolean libre(Level nivel, BlockPos pos) {
        return !CELDAS.containsKey(celda(pos.getX(), pos.getZ())) && nivel.getBlockState(pos).isAir()
                && nivel.getBlockState(pos.above()).isAir() && !nivel.getBlockState(pos.below()).isAir();
    }

    private static void llevar(ServerLevel complejo, LivingEntity quien, Vec3 lugar, float giro) {
        quien.setDeltaMovement(Vec3.ZERO);
        quien.fallDistance = 0.0F;
        if (quien instanceof ServerPlayer jugador) {
            jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
        } else {
            quien.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            quien.setYHeadRot(giro);
            if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
            }
        }
    }

    private static AABB zona() {
        return new AABB(X0, ABAJO, Z0, X1 + 1, ARRIBA + 1, Z1 + 1);
    }

    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionCasilleros() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        if (estadoComplejo.versionCasilleros() > 0) {              // lo de antes (Fuego cruzado), afuera
            BlockState aire = Blocks.AIR.defaultBlockState();
            for (BlockPos pos : BlockPos.betweenClosed(X0, ABAJO, Z0, X1, ARRIBA, Z1)) {
                if (!complejo.getBlockState(pos).isAir()) {
                    complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
                }
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionCasilleros(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Sálvese quien pueda colocada en {}", ORIGEN);
        return true;
    }

    // ------------------------------------------------------------------ ayudas
    private static List<LivingEntity> enJuego(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : Juego.participantes(complejo)) {
            if (JUEGAN.contains(quien.getUUID())) {
                lista.add(quien);
            }
        }
        return lista;
    }
}
