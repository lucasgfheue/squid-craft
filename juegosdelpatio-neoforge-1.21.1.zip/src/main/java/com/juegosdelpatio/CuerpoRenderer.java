package com.juegosdelpatio;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/** Dibuja el cuerpo de Las escondidas: el modelo de jugador acostado boca arriba, con su skin y su chaleco. */
public class CuerpoRenderer extends EntityRenderer<Cuerpo> {
    private static final ResourceLocation[] SKINS = new ResourceLocation[JugadorBot.CANTIDAD_SKINS];
    private static final ResourceLocation[] CHALECOS = {
            null,
            ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID, "textures/models/armor/chaleco_buscador_layer_1.png"),
            ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID, "textures/models/armor/chaleco_escondido_layer_1.png")};

    static {
        for (int i = 0; i < SKINS.length; i++) {
            SKINS[i] = ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID, "textures/entity/jugador/skin_" + i + ".png");
        }
    }

    private final PlayerModel<LivingEntity> ancho;
    private final PlayerModel<LivingEntity> fino;
    private final HumanoidModel<LivingEntity> chaleco;

    public CuerpoRenderer(EntityRendererProvider.Context contexto) {
        super(contexto);
        this.ancho = new PlayerModel<>(contexto.bakeLayer(ModelLayers.PLAYER), false);
        this.fino = new PlayerModel<>(contexto.bakeLayer(ModelLayers.PLAYER_SLIM), true);
        this.chaleco = new HumanoidModel<>(contexto.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR));
        this.ancho.setAllVisible(true);
        this.fino.setAllVisible(true);
        this.chaleco.setAllVisible(false);
        this.chaleco.body.visible = true;                            // el chaleco no tiene mangas
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(Cuerpo cuerpo, float giro, float parcial, PoseStack pose, MultiBufferSource buffers, int luz) {
        Minecraft minecraft = Minecraft.getInstance();
        if (cuerpo.dueno() >= 0 && minecraft.player != null && cuerpo.dueno() == minecraft.player.getId()
                && minecraft.options.getCameraType().isFirstPerson()) {
            return;                                                  // el que se hace el muerto no se ve a sí mismo
        }
        PlayerSkin skin = skinDe(cuerpo);
        PlayerModel<LivingEntity> modelo = skin != null && skin.model() == PlayerSkin.Model.SLIM ? fino : ancho;
        ResourceLocation textura = skin != null ? skin.texture() : getTextureLocation(cuerpo);
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - cuerpo.getYRot()));
        pose.translate(0.0F, 0.26F, -0.95F);                         // boca arriba, apoyado en el piso
        pose.mulPose(Axis.XP.rotationDegrees(90.0F));
        pose.scale(-1.0F, -1.0F, 1.0F);
        pose.scale(0.9375F, 0.9375F, 0.9375F);
        pose.translate(0.0F, -1.501F, 0.0F);
        modelo.renderToBuffer(pose, buffers.getBuffer(modelo.renderType(textura)), luz, OverlayTexture.NO_OVERLAY);
        int cual = cuerpo.chaleco();
        if (cual > 0 && cual < CHALECOS.length) {
            chaleco.renderToBuffer(pose, buffers.getBuffer(RenderType.armorCutoutNoCull(CHALECOS[cual])), luz,
                    OverlayTexture.NO_OVERLAY);
        }
        pose.popPose();
        super.render(cuerpo, giro, parcial, pose, buffers, luz);
    }

    /** La skin del jugador muerto (la que usa en el servidor), o null si era un bot. */
    private static PlayerSkin skinDe(Cuerpo cuerpo) {
        UUID jugador = cuerpo.jugador();
        if (cuerpo.skin() >= 0 || jugador == null) {
            return null;
        }
        ClientPacketListener conexion = Minecraft.getInstance().getConnection();
        PlayerInfo info = conexion == null ? null : conexion.getPlayerInfo(jugador);
        return info != null ? info.getSkin() : DefaultPlayerSkin.get(jugador);
    }

    @Override
    public ResourceLocation getTextureLocation(Cuerpo cuerpo) {
        return SKINS[Math.floorMod(cuerpo.skin(), SKINS.length)];
    }
}
