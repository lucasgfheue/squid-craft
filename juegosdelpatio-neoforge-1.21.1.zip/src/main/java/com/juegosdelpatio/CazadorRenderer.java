package com.juegosdelpatio;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Dibuja al Cazador de Sálvese quien pueda con bloques estirados, como los robots del puente (ver {@link RobotRenderer}),
 * pero más grande (12 bloques) y caminando: las piernas y los brazos van y vienen según lo que camina. Con los ojos
 * prendidos, el visor, la luz del pecho y las de los antebrazos brillan rojas aunque esté oscuro, y del visor sale un haz
 * de luz roja para donde mira; con los ojos apagados, quedan de un rojo oscuro. La cabeza gira buscando. Las medidas son
 * las mismas que en herramientas/juegos_render.py.
 */
public class CazadorRenderer extends EntityRenderer<Cazador> {
    private static final BlockState NEGRO = Blocks.BLACK_CONCRETE.defaultBlockState();
    private static final BlockState GRIS = Blocks.GRAY_CONCRETE.defaultBlockState();
    private static final BlockState GRIS_CLARO = Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
    private static final BlockState LUZ = Blocks.RED_CONCRETE.defaultBlockState();
    private static final BlockState APAGADA = Blocks.RED_TERRACOTTA.defaultBlockState();
    /** El Cazador es como un robot del puente, pero más grande. */
    private static final float ESCALA = 1.35F;
    /** Cuánto van y vienen las piernas al caminar (grados), y cada cuánto (por bloque caminado). */
    private static final float VAIVEN = 22.0F;
    private static final float RITMO = 0.45F;
    /** El largo del haz de luz del visor (en bloques del dibujo, antes de agrandar). */
    private static final float HAZ = 9.0F;
    private static final RenderType BRILLA = RenderType.eyes(InventoryMenu.BLOCK_ATLAS);
    private static final float BORDE_LUZ = 0.01F;

    private final BlockRenderDispatcher bloques;

    public CazadorRenderer(EntityRendererProvider.Context contexto) {
        super(contexto);
        this.bloques = contexto.getBlockRenderDispatcher();
        this.shadowRadius = 2.5F;
    }

    @Override
    public void render(Cazador cazador, float giro, float parcial, PoseStack pose, MultiBufferSource buffers, int luz) {
        boolean ojos = cazador.ojos();
        float paso = Mth.lerp(parcial, cazador.pasoAntes, cazador.pasoAhora);
        float cabeza = Mth.lerp(parcial, cazador.cabezaAntes, cazador.cabezaAhora);
        float vaiven = Mth.sin(paso * RITMO) * VAIVEN;
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-giro));                    // la z del Cazador, para donde mira
        pose.scale(ESCALA, ESCALA, ESCALA);
        for (int lado = -1; lado <= 1; lado += 2) {
            pose.pushPose();                                              // la pierna: gira en la cadera
            girar(pose, 0.7F * lado, 4.5F, 0.0F, vaiven * lado);
            caja(pose, buffers, luz, NEGRO, 0.7F * lado, 0.225F, 0.2F, 1.0F, 0.45F, 1.5F);          // pie
            caja(pose, buffers, luz, GRIS, 0.7F * lado, 1.55F, 0.0F, 0.75F, 2.2F, 0.75F);          // canilla
            caja(pose, buffers, luz, NEGRO, 0.7F * lado, 2.75F, 0.08F, 0.9F, 0.4F, 0.9F);          // rodilla
            caja(pose, buffers, luz, GRIS, 0.7F * lado, 3.75F, 0.0F, 0.85F, 1.6F, 0.85F);          // muslo
            pose.popPose();
            caja(pose, buffers, luz, GRIS_CLARO, 1.9F * lado, 7.25F, 0.2F, 1.15F, 0.85F, 1.4F);    // hombrera
            pose.pushPose();                                              // el brazo: al revés que la pierna
            girar(pose, 1.95F * lado, 7.0F, 0.2F, -vaiven * lado * 0.8F);
            caja(pose, buffers, luz, GRIS, 1.95F * lado, 5.9F, 0.2F, 0.75F, 2.2F, 0.75F);          // brazo
            caja(pose, buffers, luz, NEGRO, 1.95F * lado, 4.55F, 0.2F, 0.85F, 0.6F, 0.85F);        // codo
            caja(pose, buffers, luz, GRIS, 1.95F * lado, 3.4F, 0.25F, 0.7F, 1.8F, 0.7F);           // antebrazo
            caja(pose, buffers, luz, NEGRO, 1.95F * lado, 2.2F, 0.3F, 0.9F, 0.9F, 0.9F);           // mano
            luz(pose, buffers, ojos, 1.95F * lado + 0.36F * lado, 3.4F, 0.25F, 0.06F, 1.4F, 0.08F);
            pose.popPose();
        }
        caja(pose, buffers, luz, NEGRO, 0.0F, 4.7F, 0.0F, 2.2F, 0.6F, 1.2F);                        // cadera
        caja(pose, buffers, luz, GRIS, 0.0F, 5.3F, 0.0F, 1.4F, 0.6F, 1.0F);                         // cintura
        caja(pose, buffers, luz, GRIS, 0.0F, 6.45F, 0.0F, 3.1F, 1.9F, 1.7F);                        // el pecho
        caja(pose, buffers, luz, NEGRO, 0.0F, 6.6F, 0.88F, 2.3F, 1.1F, 0.12F);                      // la placa del pecho
        luz(pose, buffers, ojos, 0.0F, 6.15F, 0.95F, 1.5F, 0.16F, 0.06F);                           // la luz del pecho
        caja(pose, buffers, luz, NEGRO, 0.0F, 6.4F, -0.9F, 1.6F, 1.2F, 0.15F);                      // la espalda
        caja(pose, buffers, luz, NEGRO, 0.0F, 7.6F, 0.0F, 0.6F, 0.35F, 0.6F);                       // el cuello
        pose.pushPose();                                                  // la cabeza (gira buscando)
        pose.translate(0.0F, 8.0F, 0.0F);
        pose.mulPose(Axis.YP.rotationDegrees(-cabeza));
        pose.translate(0.0F, -8.0F, 0.0F);
        caja(pose, buffers, luz, GRIS, 0.0F, 8.25F, 0.05F, 1.3F, 1.0F, 1.3F);
        luz(pose, buffers, ojos, 0.0F, 8.35F, 0.71F, 1.1F, 0.2F, 0.08F);                           // el visor
        caja(pose, buffers, luz, NEGRO, 0.0F, 8.85F, -0.05F, 0.22F, 0.25F, 1.2F);                   // la cresta
        if (ojos) {                                                       // el haz de luz, para adelante y un poco abajo
            pose.pushPose();
            pose.translate(0.0F, 8.35F, 0.75F);
            pose.mulPose(Axis.XP.rotationDegrees(12.0F));
            suma(pose, buffers, LUZ, 0.0F, 0.0F, HAZ / 2.0F, 0.35F, 0.12F, HAZ);
            pose.popPose();
        }
        pose.popPose();
        pose.popPose();
        super.render(cazador, giro, parcial, pose, buffers, luz);
    }

    /** Gira lo que sigue alrededor del eje x que pasa por (px, py, pz). */
    private static void girar(PoseStack pose, float px, float py, float pz, float grados) {
        pose.translate(px, py, pz);
        pose.mulPose(Axis.XP.rotationDegrees(grados));
        pose.translate(-px, -py, -pz);
    }

    /** Un bloque estirado: centro (cx, cy, cz) y tamaño (sx, sy, sz), en bloques. */
    private void caja(PoseStack pose, MultiBufferSource buffers, int luz, BlockState estado,
                      float cx, float cy, float cz, float sx, float sy, float sz) {
        pose.pushPose();
        pose.translate(cx - sx / 2.0F, cy - sy / 2.0F, cz - sz / 2.0F);
        pose.scale(sx, sy, sz);
        bloques.renderSingleBlock(estado, pose, buffers, luz, OverlayTexture.NO_OVERLAY);
        pose.popPose();
    }

    /** Una luz: prendida, brilla roja aunque esté oscuro (el bloque con toda la luz y, encima, sumado); apagada, rojo oscuro. */
    private void luz(PoseStack pose, MultiBufferSource buffers, boolean prendida,
                     float cx, float cy, float cz, float sx, float sy, float sz) {
        if (!prendida) {
            caja(pose, buffers, LightTexture.pack(2, 2), APAGADA, cx, cy, cz, sx, sy, sz);
            return;
        }
        caja(pose, buffers, LightTexture.FULL_BRIGHT, LUZ, cx, cy, cz, sx, sy, sz);
        suma(pose, buffers, LUZ, cx, cy, cz, sx + 2.0F * BORDE_LUZ, sy + 2.0F * BORDE_LUZ, sz + 2.0F * BORDE_LUZ);
    }

    /** El bloque sumado a lo que hay atrás (brilla, como los ojos de las arañas). */
    @SuppressWarnings("deprecation")                                  // el renderModel de siempre (sin los datos de NeoForge)
    private void suma(PoseStack pose, MultiBufferSource buffers, BlockState estado,
                      float cx, float cy, float cz, float sx, float sy, float sz) {
        pose.pushPose();
        pose.translate(cx - sx / 2.0F, cy - sy / 2.0F, cz - sz / 2.0F);
        pose.scale(sx, sy, sz);
        bloques.getModelRenderer().renderModel(pose.last(), buffers.getBuffer(BRILLA), estado, bloques.getBlockModel(estado),
                1.0F, 1.0F, 1.0F, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(Cazador cazador) {
        return InventoryMenu.BLOCK_ATLAS;
    }
}
