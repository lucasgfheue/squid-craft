package com.juegosdelpatio;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Datos guardados del mundo: qué versión de la sala está construida y qué tanda de bots y de guardias es la actual. */
public class EstadoComplejo extends SavedData {
    private int versionSala;
    private int versionBots;
    private int generacion;
    private int versionGuardias;
    private int generacionGuardias;
    /** Día del mundo normal en que se hizo la última ceremonia de bienvenida (-1 = ninguna). */
    private long ultimaCeremonia = -1;
    /** Si es de noche en el complejo: hasta qué momento (tiempo de juego); -1 = es de día. */
    private long nocheHasta = -1;
    /** Día en que ya se apagaron las luces (para no hacerlo dos veces). */
    private long diaApagado = -1;
    /** Último día que se anunció en la pantalla. */
    private long ultimoDia = -1;
    /** Día en que ya se jugó (para no repetir el juego el mismo día). */
    private long ultimoJuego = -1;
    /** Versión de la arena del juego 1 que está construida (0 = ninguna). */
    private int versionArena;
    /** Versión de la arena del juego 2 (Asientos al vacío) que está construida (0 = ninguna). */
    private int versionSillas;
    private int versionEscuela;
    /** Versión de la plaza de El puente de Londres (juego 4) que está construida (0 = ninguna). */
    private int versionPuente;
    /** Versión de la Torre de los Juegos (con 7 puertas) que está construida (0 = ninguna). */
    private int versionTorre;
    /** Versión de las torres de Fuego cruzado (juego 3) que está construida (0 = ninguna). */
    private int versionFuego;
    /** Versión de las torres de El tejo (juego 4) que está construida (0 = ninguna). */
    private int versionTejo;
    /**
     * Versión de la arena del juego 7 que está construida (0 = ninguna; 1 = el patio de La batalla, el juego 7 de antes;
     * 2 = las torres de Los estandartes). Se guarda con el nombre de antes, para saber que hay que borrar el patio.
     */
    private int versionEstandartes;
    /** El premio acumulado en diamantes (0 = todavía el de base); sube con cada eliminado. */
    private int premio;

    public static EstadoComplejo de(MinecraftServer servidor) {
        return servidor.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(EstadoComplejo::new, EstadoComplejo::cargar, null), "juegosdelpatio_estado");
    }

    private static EstadoComplejo cargar(CompoundTag datos, HolderLookup.Provider registros) {
        EstadoComplejo estado = new EstadoComplejo();
        estado.versionSala = datos.getInt("VersionSala");
        estado.versionBots = datos.getInt("VersionBots");
        estado.generacion = datos.getInt("Generacion");
        estado.versionGuardias = datos.getInt("VersionGuardias");
        estado.generacionGuardias = datos.getInt("GeneracionGuardias");
        estado.ultimaCeremonia = datos.contains("UltimaCeremonia") ? datos.getLong("UltimaCeremonia") : -1;
        estado.nocheHasta = datos.contains("NocheHasta") ? datos.getLong("NocheHasta") : -1;
        estado.diaApagado = datos.contains("DiaApagado") ? datos.getLong("DiaApagado") : -1;
        estado.ultimoDia = datos.contains("UltimoDia") ? datos.getLong("UltimoDia") : -1;
        estado.ultimoJuego = datos.contains("UltimoJuego") ? datos.getLong("UltimoJuego") : -1;
        estado.versionArena = datos.getInt("VersionArena");
        estado.versionSillas = datos.getInt("VersionSillas");
        estado.versionEscuela = datos.getInt("VersionEscuela");
        estado.versionPuente = datos.getInt("VersionPuente");
        estado.versionTorre = datos.getInt("VersionTorre");
        estado.versionFuego = datos.getInt("VersionFuego");
        estado.versionTejo = datos.getInt("VersionTejo");
        estado.versionEstandartes = datos.getInt("VersionBatalla");
        estado.premio = datos.getInt("Premio");
        return estado;
    }

    @Override
    public CompoundTag save(CompoundTag datos, HolderLookup.Provider registros) {
        datos.putInt("VersionSala", versionSala);
        datos.putInt("VersionBots", versionBots);
        datos.putInt("Generacion", generacion);
        datos.putInt("VersionGuardias", versionGuardias);
        datos.putInt("GeneracionGuardias", generacionGuardias);
        datos.putLong("UltimaCeremonia", ultimaCeremonia);
        datos.putLong("NocheHasta", nocheHasta);
        datos.putLong("DiaApagado", diaApagado);
        datos.putLong("UltimoDia", ultimoDia);
        datos.putLong("UltimoJuego", ultimoJuego);
        datos.putInt("VersionArena", versionArena);
        datos.putInt("VersionSillas", versionSillas);
        datos.putInt("VersionEscuela", versionEscuela);
        datos.putInt("VersionPuente", versionPuente);
        datos.putInt("VersionTorre", versionTorre);
        datos.putInt("VersionFuego", versionFuego);
        datos.putInt("VersionTejo", versionTejo);
        datos.putInt("VersionBatalla", versionEstandartes);
        datos.putInt("Premio", premio);
        return datos;
    }

    public int versionSala() {
        return versionSala;
    }

    public void setVersionSala(int version) {
        this.versionSala = version;
        setDirty();
    }

    public int versionBots() {
        return versionBots;
    }

    public void setVersionBots(int version) {
        this.versionBots = version;
        setDirty();
    }

    public int generacion() {
        return generacion;
    }

    public int nuevaGeneracion() {
        generacion++;
        setDirty();
        return generacion;
    }

    public int versionGuardias() {
        return versionGuardias;
    }

    public void setVersionGuardias(int version) {
        this.versionGuardias = version;
        setDirty();
    }

    public int generacionGuardias() {
        return generacionGuardias;
    }

    public int nuevaGeneracionGuardias() {
        generacionGuardias++;
        setDirty();
        return generacionGuardias;
    }

    public long ultimaCeremonia() {
        return ultimaCeremonia;
    }

    public void setUltimaCeremonia(long dia) {
        this.ultimaCeremonia = dia;
        setDirty();
    }

    public long nocheHasta() {
        return nocheHasta;
    }

    public void setNocheHasta(long momento) {
        this.nocheHasta = momento;
        setDirty();
    }

    public long diaApagado() {
        return diaApagado;
    }

    public void setDiaApagado(long dia) {
        this.diaApagado = dia;
        setDirty();
    }

    public long ultimoDia() {
        return ultimoDia;
    }

    public void setUltimoDia(long dia) {
        this.ultimoDia = dia;
        setDirty();
    }

    public long ultimoJuego() {
        return ultimoJuego;
    }

    public void setUltimoJuego(long dia) {
        this.ultimoJuego = dia;
        setDirty();
    }

    public int versionArena() {
        return versionArena;
    }

    public int versionSillas() {
        return versionSillas;
    }

    public void setVersionSillas(int version) {
        this.versionSillas = version;
        setDirty();
    }

    /** Qué versión de la escuela de Las escondidas está construida (0 = ninguna). */
    public int versionEscuela() {
        return versionEscuela;
    }

    public void setVersionEscuela(int version) {
        this.versionEscuela = version;
        setDirty();
    }

    /** Qué versión de la plaza de El puente de Londres está construida (0 = ninguna). */
    public int versionPuente() {
        return versionPuente;
    }

    public void setVersionPuente(int version) {
        this.versionPuente = version;
        setDirty();
    }

    /** Qué versión de la Torre de los Juegos (con 7 puertas) está construida (0 = ninguna). */
    public int versionTorre() {
        return versionTorre;
    }

    public void setVersionTorre(int version) {
        this.versionTorre = version;
        setDirty();
    }

    /** Qué versión de las torres de Fuego cruzado (juego 3) está construida (0 = ninguna). */
    public int versionFuego() {
        return versionFuego;
    }

    public void setVersionFuego(int version) {
        this.versionFuego = version;
        setDirty();
    }

    /** Qué versión de las torres de El tejo (juego 4) está construida (0 = ninguna). */
    public int versionTejo() {
        return versionTejo;
    }

    public void setVersionTejo(int version) {
        this.versionTejo = version;
        setDirty();
    }

    /** Qué versión de la arena del juego 7 está construida (0 = ninguna). */
    public int versionEstandartes() {
        return versionEstandartes;
    }

    public void setVersionEstandartes(int version) {
        this.versionEstandartes = version;
        setDirty();
    }

    public void setVersionArena(int version) {
        this.versionArena = version;
        setDirty();
    }

    public int premio() {
        return premio > 0 ? premio : Complejo.PREMIO_DIAMANTES;
    }

    public void sumarPremio(int diamantes) {
        this.premio = premio() + diamantes;
        setDirty();
    }

    public void setPremio(int diamantes) {
        this.premio = diamantes;
        setDirty();
    }
}
