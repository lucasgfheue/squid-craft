package com.juegosdelpatio;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Datos guardados del mundo: qué versión de la sala está construida y qué tanda de bots y de guardias es la actual. */
public class EstadoComplejo extends SavedData {
    private int versionSala;
    private int versionBots;
    private int generacion;
    private int versionGuardias;
    private int generacionGuardias;
    /** Día del mundo normal en que se hizo la última ceremonia de bienvenida (-1 = ninguna). */
    private long ultimaCeremonia = -1;
    /** Si es de noche en el complejo: hasta qué momento (tiempo de juego); -1 = es de día. */
    private long nocheHasta = -1;
    /** Día en que ya se apagaron las luces (para no hacerlo dos veces). */
    private long diaApagado = -1;
    /** Último día que se anunció en la pantalla. */
    private long ultimoDia = -1;
    /** Día en que ya se jugó (para no repetir el juego el mismo día). */
    private long ultimoJuego = -1;
    /** Versión de la arena del juego 1 que está construida (0 = ninguna). */
    private int versionArena;

    public static EstadoComplejo de(MinecraftServer servidor) {
        return servidor.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(EstadoComplejo::new, EstadoComplejo::cargar, null), "juegosdelpatio_estado");
    }

    private static EstadoComplejo cargar(CompoundTag datos, HolderLookup.Provider registros) {
        EstadoComplejo estado = new EstadoComplejo();
        estado.versionSala = datos.getInt("VersionSala");
        estado.versionBots = datos.getInt("VersionBots");
        estado.generacion = datos.getInt("Generacion");
        estado.versionGuardias = datos.getInt("VersionGuardias");
        estado.generacionGuardias = datos.getInt("GeneracionGuardias");
        estado.ultimaCeremonia = datos.contains("UltimaCeremonia") ? datos.getLong("UltimaCeremonia") : -1;
        estado.nocheHasta = datos.contains("NocheHasta") ? datos.getLong("NocheHasta") : -1;
        estado.diaApagado = datos.contains("DiaApagado") ? datos.getLong("DiaApagado") : -1;
        estado.ultimoDia = datos.contains("UltimoDia") ? datos.getLong("UltimoDia") : -1;
        estado.ultimoJuego = datos.contains("UltimoJuego") ? datos.getLong("UltimoJuego") : -1;
        estado.versionArena = datos.getInt("VersionArena");
        return estado;
    }

    @Override
    public CompoundTag save(CompoundTag datos, HolderLookup.Provider registros) {
        datos.putInt("VersionSala", versionSala);
        datos.putInt("VersionBots", versionBots);
        datos.putInt("Generacion", generacion);
        datos.putInt("VersionGuardias", versionGuardias);
        datos.putInt("GeneracionGuardias", generacionGuardias);
        datos.putLong("UltimaCeremonia", ultimaCeremonia);
        datos.putLong("NocheHasta", nocheHasta);
        datos.putLong("DiaApagado", diaApagado);
        datos.putLong("UltimoDia", ultimoDia);
        datos.putLong("UltimoJuego", ultimoJuego);
        datos.putInt("VersionArena", versionArena);
        return datos;
    }

    public int versionSala() {
        return versionSala;
    }

    public void setVersionSala(int version) {
        this.versionSala = version;
        setDirty();
    }

    public int versionBots() {
        return versionBots;
    }

    public void setVersionBots(int version) {
        this.versionBots = version;
        setDirty();
    }

    public int generacion() {
        return generacion;
    }

    public int nuevaGeneracion() {
        generacion++;
        setDirty();
        return generacion;
    }

    public int versionGuardias() {
        return versionGuardias;
    }

    public void setVersionGuardias(int version) {
        this.versionGuardias = version;
        setDirty();
    }

    public int generacionGuardias() {
        return generacionGuardias;
    }

    public int nuevaGeneracionGuardias() {
        generacionGuardias++;
        setDirty();
        return generacionGuardias;
    }

    public long ultimaCeremonia() {
        return ultimaCeremonia;
    }

    public void setUltimaCeremonia(long dia) {
        this.ultimaCeremonia = dia;
        setDirty();
    }

    public long nocheHasta() {
        return nocheHasta;
    }

    public void setNocheHasta(long momento) {
        this.nocheHasta = momento;
        setDirty();
    }

    public long diaApagado() {
        return diaApagado;
    }

    public void setDiaApagado(long dia) {
        this.diaApagado = dia;
        setDirty();
    }

    public long ultimoDia() {
        return ultimoDia;
    }

    public void setUltimoDia(long dia) {
        this.ultimoDia = dia;
        setDirty();
    }

    public long ultimoJuego() {
        return ultimoJuego;
    }

    public void setUltimoJuego(long dia) {
        this.ultimoJuego = dia;
        setDirty();
    }

    public int versionArena() {
        return versionArena;
    }

    public void setVersionArena(int version) {
        this.versionArena = version;
        setDirty();
    }
}
