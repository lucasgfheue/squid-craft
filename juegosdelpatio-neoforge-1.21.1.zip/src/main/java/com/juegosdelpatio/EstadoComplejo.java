package com.juegosdelpatio;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Datos guardados del mundo: qué versión de la sala está construida y qué tanda de bots y de guardias es la actual. */
public class EstadoComplejo extends SavedData {
    private int versionSala;
    private int versionBots;
    private int generacion;
    private int versionGuardias;
    private int generacionGuardias;
    /** Día del mundo normal en que se hizo la última ceremonia de bienvenida (-1 = ninguna). */
    private long ultimaCeremonia = -1;

    public static EstadoComplejo de(MinecraftServer servidor) {
        return servidor.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(EstadoComplejo::new, EstadoComplejo::cargar, null), "juegosdelpatio_estado");
    }

    private static EstadoComplejo cargar(CompoundTag datos, HolderLookup.Provider registros) {
        EstadoComplejo estado = new EstadoComplejo();
        estado.versionSala = datos.getInt("VersionSala");
        estado.versionBots = datos.getInt("VersionBots");
        estado.generacion = datos.getInt("Generacion");
        estado.versionGuardias = datos.getInt("VersionGuardias");
        estado.generacionGuardias = datos.getInt("GeneracionGuardias");
        estado.ultimaCeremonia = datos.contains("UltimaCeremonia") ? datos.getLong("UltimaCeremonia") : -1;
        return estado;
    }

    @Override
    public CompoundTag save(CompoundTag datos, HolderLookup.Provider registros) {
        datos.putInt("VersionSala", versionSala);
        datos.putInt("VersionBots", versionBots);
        datos.putInt("Generacion", generacion);
        datos.putInt("VersionGuardias", versionGuardias);
        datos.putInt("GeneracionGuardias", generacionGuardias);
        datos.putLong("UltimaCeremonia", ultimaCeremonia);
        return datos;
    }

    public int versionSala() {
        return versionSala;
    }

    public void setVersionSala(int version) {
        this.versionSala = version;
        setDirty();
    }

    public int versionBots() {
        return versionBots;
    }

    public void setVersionBots(int version) {
        this.versionBots = version;
        setDirty();
    }

    public int generacion() {
        return generacion;
    }

    public int nuevaGeneracion() {
        generacion++;
        setDirty();
        return generacion;
    }

    public int versionGuardias() {
        return versionGuardias;
    }

    public void setVersionGuardias(int version) {
        this.versionGuardias = version;
        setDirty();
    }

    public int generacionGuardias() {
        return generacionGuardias;
    }

    public int nuevaGeneracionGuardias() {
        generacionGuardias++;
        setDirty();
        return generacionGuardias;
    }

    public long ultimaCeremonia() {
        return ultimaCeremonia;
    }

    public void setUltimaCeremonia(long dia) {
        this.ultimaCeremonia = dia;
        setDirty();
    }
}
