package com.juegosdelpatio;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Datos guardados del mundo: qué versión de la sala está construida y qué tanda de bots es la actual. */
public class EstadoComplejo extends SavedData {
    private int versionSala;
    private int versionBots;
    private int generacion;

    public static EstadoComplejo de(MinecraftServer servidor) {
        return servidor.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(EstadoComplejo::new, EstadoComplejo::cargar, null), "juegosdelpatio_estado");
    }

    private static EstadoComplejo cargar(CompoundTag datos, HolderLookup.Provider registros) {
        EstadoComplejo estado = new EstadoComplejo();
        estado.versionSala = datos.getInt("VersionSala");
        estado.versionBots = datos.getInt("VersionBots");
        estado.generacion = datos.getInt("Generacion");
        return estado;
    }

    @Override
    public CompoundTag save(CompoundTag datos, HolderLookup.Provider registros) {
        datos.putInt("VersionSala", versionSala);
        datos.putInt("VersionBots", versionBots);
        datos.putInt("Generacion", generacion);
        return datos;
    }

    public int versionSala() {
        return versionSala;
    }

    public void setVersionSala(int version) {
        this.versionSala = version;
        setDirty();
    }

    public int versionBots() {
        return versionBots;
    }

    public void setVersionBots(int version) {
        this.versionBots = version;
        setDirty();
    }

    public int generacion() {
        return generacion;
    }

    public int nuevaGeneracion() {
        generacion++;
        setDirty();
        return generacion;
    }
}
