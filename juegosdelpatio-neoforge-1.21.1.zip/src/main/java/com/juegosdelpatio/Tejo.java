package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.joml.Vector3f;

/**
 * El juego 5, "La papa caliente": en un valle de noche, con colinas, pinos, rocas y montañas con túneles (ver
 * gen_tejo.py; la clase se sigue llamando Tejo, como el juego que había antes en este lugar).
 *
 * <ol>
 *   <li>Todos empiezan repartidos por lo bajo del valle. En cada ronda, el comandante les da una papa caliente a cinco,
 *       al azar: brillan, humean y van un poco más rápido.</li>
 *   <li>El que tiene la papa se la pasa a otro pegándole (al que se la acaba de pasar no se la puede devolver
 *       enseguida, y al que ya tiene una, tampoco). Ningún golpe lastima.</li>
 *   <li>A los 15 segundos, las papas explotan: los que las tienen en ese momento quedan eliminados.</li>
 *   <li>Son 3 rondas: quedan eliminados 15, cinco por ronda (menos, si quedan muy pocos). Nadie más: en el valle no
 *       lastima nada más (ni los golpes ni las caídas).</li>
 * </ol>
 */
public final class Tejo {
    // ------------------------------------------------------------------ la arena (igual que gen_tejo.py)
    public static final ResourceLocation ARENA = Complejo.id("tejo");
    /** Esquina de la plantilla tejo.nbt (131 x 52 x 141): abajo de todo, en la esquina noroeste. */
    public static final BlockPos ORIGEN = new BlockPos(6935, 74, -20);
    /** La 2 es el valle. La 1 era una rayuela de torres altísimas, en el mismo lugar: se borra. */
    static final int VERSION_ARENA = 2;
    /** Toda la plantilla: lo que se mantiene cargado mientras se juega. */
    static final int X0 = 6935;
    static final int X1 = 7065;
    static final int Z0 = -20;
    static final int Z1 = 120;
    private static final int ABAJO = 74;
    private static final int ARRIBA = 125;
    /** Lo que ocupaban las torres de antes (x0, x1, z0, z1, y0, y1): se borra antes de poner el valle. */
    private static final int[] VIEJA = {6969, 7031, -17, 85, 39, 118};
    /** Donde se para la gente en lo llano del valle (y en los túneles). */
    static final int PISO = 100;
    /** Donde se juega: el valle, adentro de la barrera del borde. */
    static final int VALLE_X0 = 6946;
    static final int VALLE_X1 = 7054;
    static final int VALLE_Z0 = 7;
    static final int VALLE_Z1 = 115;
    /** El palco del comandante, al norte, más alto y separado del valle: el piso en y = 111. */
    private static final int PALCO_X0 = 6980;
    private static final int PALCO_X1 = 7020;
    private static final int PALCO_Z0 = -11;
    private static final int PALCO_Z1 = -4;
    static final Vec3 PODIO = new Vec3(7000.5, 114.0, -13.5);
    /** Los sargentos, en el palco: dos adelante, en las esquinas, y dos junto al podio. */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(6980.5, 112.0, -4.5), new Vec3(7020.5, 112.0, -4.5),
            new Vec3(6992.5, 112.0, -13.5), new Vec3(7008.5, 112.0, -13.5),
    };
    static final float[] GIROS_SARGENTOS = {0.0F, 0.0F, 0.0F, 0.0F};

    // ------------------------------------------------------------------ reglas
    static final int RONDAS = 3;
    /** Cuántas papas hay en cada ronda (si quedan pocos, una menos que la gente que queda). */
    static final int PAPAS = 5;
    /** A los 15 segundos, las papas explotan. Antes, 3 segundos para ver quién la tiene; después, 4 de pausa. */
    static final int RONDA = 15 * 20;
    private static final int REPARTIR = 60;
    private static final int PAUSA = 80;
    /** Al que acaba de pasar la papa no se la pueden devolver por 3 segundos. */
    private static final int INMUNE = 60;
    /** El pase empuja un poco al que recibe la papa. */
    private static final double EMPUJON = 0.35;

    private enum Estado { NINGUNO, REPARTIR, CORRER, PAUSA, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int ronda;
    private static int pasaron;
    private static final Set<UUID> JUEGAN = new HashSet<>();
    /** Los que tienen la papa, y hasta cuándo no se la pueden devolver a cada uno. */
    private static final Set<UUID> TIENEN = new HashSet<>();
    private static final Map<UUID, Integer> INMUNES = new HashMap<>();
    @Nullable
    private static List<LivingEntity> enJuegoCache;
    private static long enJuegoTick = -1;

    private Tejo() {
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean corriendo() {
        return estado == Estado.CORRER;
    }

    static int pasaron() {
        return pasaron;
    }

    static boolean juega(LivingEntity quien) {
        return estado != Estado.NINGUNO && JUEGAN.contains(quien.getUUID()) && quien.isAlive() && !Juego.eliminado(quien);
    }

    static boolean tienePapa(LivingEntity quien) {
        return TIENEN.contains(quien.getUUID());
    }

    /** En la papa caliente, los bots no se chocan con nadie (si no, se amontonan y se trancan entre ellos). */
    static boolean sinChoques(LivingEntity quien) {
        return estado != Estado.NINGUNO && JUEGAN.contains(quien.getUUID());
    }

    /** Por qué quedó eliminado el que murió en el juego: le explotó la papa (o, muy raro, murió de otra cosa). */
    static String motivo(LivingEntity muerto) {
        return tienePapa(muerto) ? "te_exploto_la_papa" : "moriste";
    }

    // ------------------------------------------------------------------ empezar
    static void empezar(ServerLevel complejo, List<LivingEntity> gente) {
        olvidar();
        RandomSource azar = complejo.getRandom();
        for (LivingEntity quien : gente) {
            JUEGAN.add(quien.getUUID());
            llevar(complejo, quien, lugarLibre(complejo, azar), azar.nextFloat() * 360.0F);
        }
        nuevaRonda(complejo);
    }

    /** Un lugar libre en lo bajo del valle (no arriba de las montañas, ni en un pino ni en una roca). */
    static Vec3 lugarLibre(Level nivel, RandomSource azar) {
        for (int intento = 0; intento < 60; intento++) {
            int x = VALLE_X0 + 2 + azar.nextInt(VALLE_X1 - VALLE_X0 - 3);
            int z = VALLE_Z0 + 2 + azar.nextInt(VALLE_Z1 - VALLE_Z0 - 3);
            int y = alturaDePie(nivel, x, z);
            if (y != Integer.MIN_VALUE && y <= PISO + 8) {
                return new Vec3(x + 0.5, y, z + 0.5);
            }
        }
        return new Vec3(7000.5, PISO + 1, 25.5);
    }

    /**
     * A qué altura se para uno en (x, z) del valle: arriba del pasto, la tierra, la piedra, la grava o la nieve.
     * Integer.MIN_VALUE si ahí no se puede (un pino, una roca, un farol).
     */
    static int alturaDePie(Level nivel, int x, int z) {
        for (int y = ARRIBA; y >= PISO - 4; y--) {
            BlockState abajo = nivel.getBlockState(new BlockPos(x, y - 1, z));
            if (abajo.isAir() || abajo.is(Blocks.LIGHT) || abajo.is(Blocks.BARRIER)) {
                continue;
            }
            boolean piso = abajo.is(Blocks.GRASS_BLOCK) || abajo.is(Blocks.DIRT) || abajo.is(Blocks.COARSE_DIRT)
                    || abajo.is(Blocks.STONE) || abajo.is(Blocks.ANDESITE) || abajo.is(Blocks.GRAVEL) || abajo.is(Blocks.SNOW_BLOCK);
            boolean lugar = nivel.getBlockState(new BlockPos(x, y, z)).isAir() && nivel.getBlockState(new BlockPos(x, y + 1, z)).isAir();
            return piso && lugar ? y : Integer.MIN_VALUE;
        }
        return Integer.MIN_VALUE;
    }

    private static void llevar(ServerLevel complejo, LivingEntity quien, Vec3 lugar, float giro) {
        quien.setDeltaMovement(Vec3.ZERO);
        quien.fallDistance = 0.0F;
        if (quien instanceof ServerPlayer jugador) {
            jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
        } else {
            quien.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            quien.setYHeadRot(giro);
            if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
            }
        }
    }

    /** Una ronda nueva: el comandante les da la papa a cinco, al azar. */
    private static void nuevaRonda(ServerLevel complejo) {
        ronda++;
        RandomSource azar = complejo.getRandom();
        List<LivingEntity> vivos = enJuego(complejo);
        int papas = Math.max(1, Math.min(PAPAS, vivos.size() - 1));
        TIENEN.clear();
        INMUNES.clear();
        for (int i = vivos.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            LivingEntity cambio = vivos.get(i);
            vivos.set(i, vivos.get(j));
            vivos.set(j, cambio);
        }
        for (int i = 0; i < papas && i < vivos.size(); i++) {
            darPapa(vivos.get(i));
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.tejo_ronda", ronda, RONDAS, papas, RONDA / 20));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!juega(jugador)) {
                continue;
            }
            boolean la = tienePapa(jugador);
            Juego.titulo(jugador, Component.translatable(la ? "titulo.juegosdelpatio.tienes_tejo" : "titulo.juegosdelpatio.tejo_ronda",
                            ronda, RONDAS).withStyle(la ? ChatFormatting.RED : ChatFormatting.GOLD),
                    Component.translatable(la ? "titulo.juegosdelpatio.tienes_tejo_detalle" : "titulo.juegosdelpatio.tejo_ronda_detalle",
                            papas).withStyle(ChatFormatting.GRAY), 5, 50, 10);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.MASTER, 1.0F, la ? 0.6F : 1.0F);
        }
        estado = Estado.REPARTIR;
        tiempo = 0;
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        switch (estado) {
            case REPARTIR -> {
                marcar(complejo);
                if (tiempo >= REPARTIR) {
                    estado = Estado.CORRER;
                    tiempo = 0;
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 2.0F);
                    }
                }
            }
            case CORRER -> {
                marcar(complejo);
                reloj(complejo);
                if (tiempo % 10 == 5) {
                    avisar(complejo);
                }
                if (tiempo >= RONDA) {
                    explotar(complejo);
                }
            }
            case PAUSA -> {
                if (tiempo >= PAUSA) {
                    List<LivingEntity> vivos = enJuego(complejo);
                    if (ronda >= RONDAS || vivos.size() <= 1) {
                        estado = Estado.TERMINADO;
                        pasaron = vivos.size();
                        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.6F);
                        }
                    } else {
                        nuevaRonda(complejo);
                    }
                }
            }
            default -> {
            }
        }
        if (tiempo % 2 == 0 && estado != Estado.TERMINADO) {
            rescatar(complejo);
        }
        if (tiempo % 10 == 1) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    private static void barra(ServerLevel complejo) {
        int queda = estado == Estado.CORRER ? Math.max(0, RONDA - tiempo) : estado == Estado.REPARTIR ? RONDA : 0;
        Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.tejo", Math.min(ronda, RONDAS), RONDAS,
                        Juego.reloj(queda), TIENEN.size()),
                estado == Estado.CORRER ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.WHITE, queda / (float) RONDA);
    }

    /** Los que tienen la papa brillan, van un poco más rápido, humean y largan chispas rojas. */
    private static void marcar(ServerLevel complejo) {
        if (tiempo % 20 != 1) {
            return;
        }
        DustParticleOptions chispa = new DustParticleOptions(new Vector3f(0.95F, 0.30F, 0.08F), 1.2F);
        for (LivingEntity quien : enJuego(complejo)) {
            if (!tienePapa(quien)) {
                continue;
            }
            quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
            quien.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 0, false, false));
            complejo.sendParticles(chispa, quien.getX(), quien.getY() + 2.2, quien.getZ(), 6, 0.25, 0.15, 0.25, 0.0);
            complejo.sendParticles(ParticleTypes.SMOKE, quien.getX(), quien.getY() + 1.6, quien.getZ(), 4, 0.15, 0.2, 0.15, 0.01);
            if (quien instanceof ServerPlayer jugador && jugador.getInventory().countItem(Registro.TEJO_ITEM.get()) == 0) {
                darItem(jugador);
            }
        }
    }

    /** El reloj de la ronda: un tic cada segundo, y en los últimos 5 segundos, cada vez más seguido. */
    private static void reloj(ServerLevel complejo) {
        int queda = RONDA - tiempo;
        int cada = queda <= 60 ? 5 : queda <= 100 ? 10 : 20;
        if (tiempo % cada != 0) {
            return;
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 0.7F, queda <= 100 ? 1.9F : 1.5F);
        }
    }

    private static void avisar(ServerLevel complejo) {
        int segundos = Math.max(0, (RONDA - tiempo + 19) / 20);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!juega(jugador)) {
                continue;
            }
            jugador.displayClientMessage(tienePapa(jugador)
                    ? Component.translatable("mensaje.juegosdelpatio.tienes_el_tejo", segundos).withStyle(ChatFormatting.RED)
                    : Component.translatable("mensaje.juegosdelpatio.lejos_del_tejo", TIENEN.size(), segundos)
                            .withStyle(ChatFormatting.GOLD),
                    true);
        }
    }

    /** ¡Explotan las papas! Los que las tienen quedan eliminados (con la explosión, que no rompe nada ni lastima a otros). */
    private static void explotar(ServerLevel complejo) {
        int explotan = 0;
        for (LivingEntity quien : enJuego(complejo)) {
            if (!tienePapa(quien)) {
                continue;
            }
            explotan++;
            complejo.sendParticles(ParticleTypes.EXPLOSION_EMITTER, quien.getX(), quien.getY() + 1.0, quien.getZ(), 1, 0.0,
                    0.0, 0.0, 0.0);
            complejo.sendParticles(ParticleTypes.FLAME, quien.getX(), quien.getY() + 1.0, quien.getZ(), 30, 0.4, 0.6, 0.4, 0.08);
            complejo.playSound(null, quien.getX(), quien.getY(), quien.getZ(), SoundEvents.GENERIC_EXPLODE.value(),
                    SoundSource.PLAYERS, 2.0F, 1.0F);
            quitarPapa(quien);
            Juego.eliminar(complejo, quien, false, "te_exploto_la_papa");
        }
        TIENEN.clear();
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.tejo_explotan", explotan));
        estado = Estado.PAUSA;
        tiempo = 0;
    }

    /** Si alguien se sale del valle de alguna forma (no debería poder), vuelve a lo bajo del valle sin lastimarse. */
    private static void rescatar(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getY() < PISO - 6 || quien.getX() < VALLE_X0 - 1 || quien.getX() > VALLE_X1 + 2
                    || quien.getZ() < VALLE_Z0 - 1 || quien.getZ() > VALLE_Z1 + 2) {
                llevar(complejo, quien, lugarLibre(complejo, complejo.getRandom()), quien.getYRot());
            }
        }
    }

    // ------------------------------------------------------------------ la papa
    private static void darPapa(LivingEntity quien) {
        TIENEN.add(quien.getUUID());
        quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
        quien.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 0, false, false));
        if (quien instanceof ServerPlayer jugador) {
            darItem(jugador);
        } else if (quien instanceof JugadorBot bot) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Registro.TEJO_ITEM.get()));
            bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        }
    }

    private static void darItem(ServerPlayer jugador) {
        ItemStack papa = new ItemStack(Registro.TEJO_ITEM.get());
        if (jugador.getMainHandItem().isEmpty()) {
            jugador.setItemInHand(InteractionHand.MAIN_HAND, papa);
        } else if (!jugador.getInventory().add(papa)) {
            jugador.drop(papa, false);
        }
    }

    private static void quitarPapa(LivingEntity quien) {
        TIENEN.remove(quien.getUUID());
        quien.removeEffect(MobEffects.GLOWING);
        quien.removeEffect(MobEffects.MOVEMENT_SPEED);
        if (quien instanceof ServerPlayer jugador) {
            sacarPapas(jugador.getInventory());
        } else if (quien instanceof JugadorBot bot && bot.getMainHandItem().is(Registro.TEJO_ITEM.get())) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
    }

    /**
     * En la papa caliente no lastima nada (ni los golpes, ni las caídas, ni nada): solo la papa. Si el que pega tiene la
     * papa y el otro no (y no se la acaba de pasar), se la pasa, con un empujoncito.
     */
    static void alRecibirGolpe(LivingIncomingDamageEvent evento) {
        LivingEntity victima = evento.getEntity();
        evento.setCanceled(true);
        Entity fuente = evento.getSource().getEntity();
        if (!(fuente instanceof LivingEntity atacante) || atacante == victima) {
            return;
        }
        if (estado != Estado.CORRER || !juega(victima) || !juega(atacante) || !tienePapa(atacante) || tienePapa(victima)) {
            return;
        }
        if (INMUNES.getOrDefault(victima.getUUID(), 0) > tiempo) {
            if (atacante instanceof ServerPlayer jugador) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.tejo_no_devolver")
                        .withStyle(ChatFormatting.YELLOW), true);
            }
            return;
        }
        pasar(atacante, victima);
    }

    private static void pasar(LivingEntity desde, LivingEntity hacia) {
        quitarPapa(desde);
        darPapa(hacia);
        INMUNES.put(desde.getUUID(), tiempo + INMUNE);
        double dx = hacia.getX() - desde.getX();
        double dz = hacia.getZ() - desde.getZ();
        double largo = Math.sqrt(dx * dx + dz * dz);
        if (largo > 1.0E-3) {
            hacia.knockback(EMPUJON, -dx / largo, -dz / largo);
            hacia.hurtMarked = true;
        }
        hacia.level().playSound(null, hacia.getX(), hacia.getY(), hacia.getZ(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS,
                0.8F, 1.6F);
        if (hacia instanceof ServerPlayer jugador) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.tienes_tejo", ronda, RONDAS)
                            .withStyle(ChatFormatting.RED),
                    Component.translatable("titulo.juegosdelpatio.te_lo_paso", Juego.nombreDe(desde)).withStyle(ChatFormatting.GRAY),
                    0, 25, 8);
        }
        if (desde instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.se_lo_pasaste", Juego.nombreDe(hacia))
                    .withStyle(ChatFormatting.GREEN), true);
        }
    }

    // ------------------------------------------------------------------ para los bots
    /** Para el bot que tiene la papa: a quién perseguir (el más cerca que no la tenga y se la pueda pasar), o null. */
    @Nullable
    static LivingEntity presa(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity mejor = null;
        double mejorD = Double.MAX_VALUE;
        for (LivingEntity otro : enJuego(complejo)) {
            if (otro == bot || tienePapa(otro) || INMUNES.getOrDefault(otro.getUUID(), 0) > tiempo) {
                continue;
            }
            double d = bot.distanceToSqr(otro);
            if (d < mejorD) {
                mejorD = d;
                mejor = otro;
            }
        }
        return mejor;
    }

    /** Para el que no tiene la papa: el que la tiene más cerca (o null si no hay ninguno). */
    @Nullable
    static LivingEntity peligro(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity mejor = null;
        double mejorD = Double.MAX_VALUE;
        for (LivingEntity otro : enJuego(complejo)) {
            if (otro != bot && tienePapa(otro)) {
                double d = bot.distanceToSqr(otro);
                if (d < mejorD) {
                    mejorD = d;
                    mejor = otro;
                }
            }
        }
        return mejor;
    }

    /**
     * Adónde se escapa el bot del que tiene la papa: unos bloques para el lado contrario, donde se pueda estar parado y
     * sin subir ni bajar mucho (por las colinas sí; a la punta de una montaña, no).
     */
    static Vec3 huida(JugadorBot bot, LivingEntity peligro) {
        RandomSource azar = bot.getRandom();
        double base = Math.atan2(bot.getZ() - peligro.getZ(), bot.getX() - peligro.getX());
        Vec3 mejor = null;
        double mejorD = -1.0;
        for (int i = 0; i < 6; i++) {
            double angulo = base + (azar.nextDouble() - 0.5) * 2.0;
            Vec3 lugar = lugarCerca(bot, bot.getX() + Math.cos(angulo) * 9.0, bot.getZ() + Math.sin(angulo) * 9.0);
            if (lugar == null) {
                continue;
            }
            double lejos = lugar.distanceToSqr(peligro.position());
            if (lejos > mejorD) {
                mejorD = lejos;
                mejor = lugar;
            }
        }
        return mejor != null ? mejor : bot.position();
    }

    /** Un lugar cerca (a menos de 12 bloques) adonde pasear. */
    static Vec3 paseo(JugadorBot bot) {
        RandomSource azar = bot.getRandom();
        for (int intento = 0; intento < 10; intento++) {
            Vec3 lugar = lugarCerca(bot, bot.getX() + azar.nextInt(25) - 12, bot.getZ() + azar.nextInt(25) - 12);
            if (lugar != null) {
                return lugar;
            }
        }
        return bot.position();
    }

    /** El lugar donde se para uno en (x, z), adentro del valle y a menos de 6 bloques de altura del bot; o null. */
    @Nullable
    private static Vec3 lugarCerca(JugadorBot bot, double x, double z) {
        int bx = (int) Math.floor(Math.max(VALLE_X0 + 1, Math.min(VALLE_X1 - 1, x)));
        int bz = (int) Math.floor(Math.max(VALLE_Z0 + 1, Math.min(VALLE_Z1 - 1, z)));
        int y = alturaDePie(bot.level(), bx, bz);
        if (y == Integer.MIN_VALUE || Math.abs(y - bot.getY()) > 6.0) {
            return null;
        }
        return new Vec3(bx + 0.5, y, bz + 0.5);
    }

    // ------------------------------------------------------------------ muertes y limpiar
    /** Murió uno que jugaba sin que le explotara la papa (muy raro): Juego lo anota como eliminado. Acá se avisa. */
    static void alMorir(ServerLevel complejo, LivingEntity muerto) {
        if (!JUEGAN.contains(muerto.getUUID())) {
            return;
        }
        TIENEN.remove(muerto.getUUID());
        Component mensaje = Component.translatable("mensaje.juegosdelpatio.murio", Juego.nombreDe(muerto));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (jugador != muerto) {
                jugador.sendSystemMessage(mensaje.copy().withStyle(ChatFormatting.DARK_RED));
            }
        }
    }

    static void limpiar(ServerLevel complejo) {
        for (ServerPlayer jugador : complejo.players()) {
            sacarPapas(jugador.getInventory());
            if (JUEGAN.contains(jugador.getUUID())) {
                jugador.removeEffect(MobEffects.GLOWING);
                jugador.removeEffect(MobEffects.MOVEMENT_SPEED);
            }
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> JUEGAN.contains(bot.getUUID()))) {
            bot.removeEffect(MobEffects.GLOWING);
            bot.removeEffect(MobEffects.MOVEMENT_SPEED);
            if (bot.getMainHandItem().is(Registro.TEJO_ITEM.get())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
        }
        for (ItemEntity tirada : complejo.getEntitiesOfClass(ItemEntity.class, new AABB(X0, ABAJO - 40, Z0, X1 + 1, ARRIBA + 1, Z1 + 1),
                tirada -> tirada.getItem().is(Registro.TEJO_ITEM.get()))) {
            tirada.discard();
        }
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ronda = 0;
        JUEGAN.clear();
        TIENEN.clear();
        INMUNES.clear();
        enJuegoCache = null;
        enJuegoTick = -1;
    }

    private static void sacarPapas(Inventory inventario) {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            if (inventario.getItem(i).is(Registro.TEJO_ITEM.get())) {
                inventario.setItem(i, ItemStack.EMPTY);
            }
        }
    }

    // ------------------------------------------------------------------ la arena
    /** Dónde aparece quien llega: en el palco, delante del podio. */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(PALCO_X0 + azar.nextInt(PALCO_X1 - PALCO_X0 + 1) + 0.5, 112.0,
                PALCO_Z0 + azar.nextInt(PALCO_Z1 - PALCO_Z0 + 1) + 0.5);
    }

    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionTejo() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        if (estadoComplejo.versionTejo() > 0) {                    // las torres de antes, afuera
            BlockState aire = Blocks.AIR.defaultBlockState();
            for (BlockPos pos : BlockPos.betweenClosed(VIEJA[0], VIEJA[4], VIEJA[2], VIEJA[1], VIEJA[5], VIEJA[3])) {
                if (!complejo.getBlockState(pos).isAir()) {
                    complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
                }
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionTejo(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de La papa caliente colocada en {}", ORIGEN);
        return true;
    }

    /** Los que siguen jugando (vivos y sin eliminar). Se arma una vez por tick: los bots lo piden todo el tiempo. */
    private static List<LivingEntity> enJuego(ServerLevel complejo) {
        long ahora = complejo.getGameTime();
        if (ahora == enJuegoTick && enJuegoCache != null) {
            List<LivingEntity> vivos = new ArrayList<>();
            for (LivingEntity quien : enJuegoCache) {
                if (quien.isAlive() && !Juego.eliminado(quien)) {
                    vivos.add(quien);
                }
            }
            return vivos;
        }
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : Juego.participantes(complejo)) {
            if (JUEGAN.contains(quien.getUUID())) {
                lista.add(quien);
            }
        }
        enJuegoCache = lista;
        enJuegoTick = ahora;
        return new ArrayList<>(lista);
    }
}
