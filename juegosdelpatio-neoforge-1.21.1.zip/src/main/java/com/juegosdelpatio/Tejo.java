package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.joml.Vector3f;

/**
 * El juego 4, "El tejo": una rayuela de torres altísimas (ver gen_tejo.py). Un juego nuevo, con un guiño a la rayuela
 * (el tejo es la piedra que se tira en la rayuela).
 *
 * <ol>
 *   <li>Todos empiezan repartidos por las torres. En cada ronda, el comandante les da el tejo a algunos (uno cada 10
 *       que quedan): brillan, y van un poco más rápido.</li>
 *   <li>El que tiene el tejo se lo pasa a otro pegándole (al que se lo acaba de pasar no se lo puede devolver enseguida).
 *       Se persiguen saltando de torre en torre: entre una y otra hay vacío.</li>
 *   <li>Nadie sabe cuándo suena la campana (de 30 a 45 segundos). Cuando suena, el que tiene el tejo cae con él: se
 *       abre un agujero debajo de él (de 3 x 3) que se lleva también a los que estén al lado. Los agujeros quedan.</li>
 *   <li>Son 4 rondas. El que se cae (por el tejo, por un agujero o por un mal salto) queda eliminado.</li>
 * </ol>
 */
public final class Tejo {
    // ------------------------------------------------------------------ la arena (igual que gen_tejo.py)
    public static final ResourceLocation ARENA = Complejo.id("tejo");
    /** Esquina de la plantilla tejo.nbt (63 x 78 x 103): abajo de todo, en el patio. */
    public static final BlockPos ORIGEN = new BlockPos(6969, 40, -17);
    static final int VERSION_ARENA = 1;
    static final int X0 = 6969;
    static final int X1 = 7031;
    static final int Z0 = -17;
    static final int Z1 = 85;
    static final int PISO = 100;
    static final int SUELO = 41;
    /** La largada (0), las torres del 1 al 10 y el cielo (11): x0, x1, z0, z1 de arriba de cada una. */
    static final int LARGADA = 0;
    static final int CIELO = 11;
    static final int[][] TORRES = {
            {6975, 7025, -16, 8},
            {6997, 7003, 11, 17}, {6997, 7003, 20, 26},
            {6992, 6998, 29, 35}, {7002, 7008, 29, 35},
            {6997, 7003, 38, 44},
            {6992, 6998, 47, 53}, {7002, 7008, 47, 53},
            {6997, 7003, 56, 62},
            {6992, 6998, 65, 71}, {7002, 7008, 65, 71},
            {6990, 7010, 74, 84},
    };
    static final int[][] VECINOS = {
            {1}, {0, 2}, {1, 3, 4}, {2, 4, 5}, {2, 3, 5}, {3, 4, 6, 7}, {5, 7, 8}, {5, 6, 8}, {6, 7, 9, 10},
            {8, 10, 11}, {8, 9, 11}, {9, 10},
    };
    /** El cielo: medio círculo de radio 10,5 con centro en el bloque (7000, 74). */
    private static final int CIELO_X = 7000;
    private static final int CIELO_Z = 74;
    private static final double CIELO_R = 10.5;
    /** De la largada se sale (y se llega) solo por la abertura de la baranda, frente a la torre 1. */
    static final CampoDeTorres CAMPO = new CampoDeTorres(PISO, TORRES, VECINOS,
            new int[][] {{6997, 7003}, null, null, null, null, null, null, null, null, null, null, null},
            (x, z) -> z < CIELO_Z || Math.hypot(x - CIELO_X, z - CIELO_Z) <= CIELO_R);
    static final Vec3 PODIO = new Vec3(7000.5, 102.0, -13.5);
    /** Los sargentos, en la largada: dos en las esquinas del fondo y dos junto al podio. */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(6978.5, 100.0, -13.5), new Vec3(7022.5, 100.0, -13.5),
            new Vec3(6992.5, 100.0, -13.5), new Vec3(7008.5, 100.0, -13.5),
    };
    static final float[] GIROS_SARGENTOS = {0.0F, 0.0F, 0.0F, 0.0F};

    // ------------------------------------------------------------------ reglas
    static final int RONDAS = 4;
    /** Un tejo cada 10 que quedan (uno por lo menos). */
    static final int GENTE_POR_TEJO = 10;
    /** Antes de correr, 3 segundos (para ver quién lo tiene); cada ronda dura de 30 a 45 segundos; después, 4 de pausa. */
    private static final int REPARTIR = 60;
    static final int RONDA_MIN = 30 * 20;
    static final int RONDA_AZAR = 15 * 20;
    private static final int PAUSA = 80;
    /** Al que acaba de pasar el tejo no se lo pueden devolver por 3 segundos. */
    private static final int INMUNE = 60;
    /** El pase empuja un poco al que recibe el tejo. */
    private static final double EMPUJON = 0.35;

    private enum Estado { NINGUNO, REPARTIR, CORRER, PAUSA, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int ronda;
    private static int duracionRonda;
    private static int pasaron;
    private static final Set<UUID> JUEGAN = new HashSet<>();
    /** Los que tienen el tejo; hasta cuándo no se lo pueden devolver a cada uno; y los que cayeron con él. */
    private static final Set<UUID> TIENEN = new HashSet<>();
    private static final Map<UUID, Integer> INMUNES = new HashMap<>();
    private static final Set<UUID> CONDENADOS = new HashSet<>();
    /** Los bloques que se cayeron (para ponerlos de nuevo al final). */
    private static final Map<BlockPos, BlockState> AGUJEROS = new LinkedHashMap<>();
    @Nullable
    private static List<LivingEntity> enJuegoCache;
    private static long enJuegoTick = -1;

    private Tejo() {
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean corriendo() {
        return estado == Estado.CORRER;
    }

    static int pasaron() {
        return pasaron;
    }

    static boolean juega(LivingEntity quien) {
        return estado != Estado.NINGUNO && JUEGAN.contains(quien.getUUID()) && quien.isAlive() && !Juego.eliminado(quien);
    }

    static boolean tieneTejo(LivingEntity quien) {
        return TIENEN.contains(quien.getUUID());
    }

    /** En el tejo, los bots no se chocan con nadie (si no, en una torre llena se tirarían unos a otros). */
    static boolean sinChoques(LivingEntity quien) {
        return estado != Estado.NINGUNO && JUEGAN.contains(quien.getUUID());
    }

    /** Por qué quedó eliminado el que murió en el tejo: cayó con el tejo, o se cayó. */
    static String motivo(LivingEntity muerto) {
        return CONDENADOS.contains(muerto.getUUID()) ? "te_quedaste_el_tejo" : "te_caiste";
    }

    // ------------------------------------------------------------------ empezar
    static void empezar(ServerLevel complejo, List<LivingEntity> gente) {
        olvidar();
        if (hayAgujeros(complejo)) {                                // de un juego que se cortó: la arena, de nuevo
            EstadoComplejo.de(complejo.getServer()).setVersionTejo(0);
            prepararArena(complejo);
        }
        RandomSource azar = complejo.getRandom();
        for (LivingEntity quien : gente) {
            JUEGAN.add(quien.getUUID());
            llevar(complejo, quien, lugarLibre(complejo, azar.nextInt(CAMPO.cuantas()), azar), azar.nextFloat() * 360.0F);
        }
        nuevaRonda(complejo);
    }

    /** A cuántos bloques del borde se elige un lugar en cada torre (en la largada y el cielo hay baranda). */
    static int margen(int torre) {
        return torre == LARGADA || torre == CIELO ? 2 : 1;
    }

    /** Un lugar arriba de una torre donde se puede estar parado (sin podio, faroles ni agujeros). */
    static Vec3 lugarLibre(ServerLevel complejo, int torre, RandomSource azar) {
        Vec3 lugar = CAMPO.lugarEn(torre, azar, margen(torre));
        for (int intento = 0; intento < 20; intento++) {
            BlockPos pos = BlockPos.containing(lugar.x, PISO, lugar.z);
            if (complejo.getBlockState(pos).isAir() && complejo.getBlockState(pos.above()).isAir()
                    && !complejo.getBlockState(pos.below()).isAir()) {
                return lugar;
            }
            lugar = CAMPO.lugarEn(torre, azar, margen(torre));
        }
        return CAMPO.lugarEn(1, azar, 1);
    }

    /** ¿Quedó algún agujero arriba de las torres (de un juego que se cortó sin taparlos)? */
    private static boolean hayAgujeros(ServerLevel complejo) {
        if (EstadoComplejo.de(complejo.getServer()).versionTejo() != VERSION_ARENA) {
            return false;
        }
        for (int t = 1; t <= 10; t++) {
            int[] r = TORRES[t];
            for (int x = r[0]; x <= r[1]; x++) {
                for (int z = r[2]; z <= r[3]; z++) {
                    if (complejo.getBlockState(new BlockPos(x, PISO - 1, z)).isAir()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void llevar(ServerLevel complejo, LivingEntity quien, Vec3 lugar, float giro) {
        quien.setDeltaMovement(Vec3.ZERO);
        quien.fallDistance = 0.0F;
        if (quien instanceof ServerPlayer jugador) {
            jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
        } else {
            quien.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            quien.setYHeadRot(giro);
            if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
            }
        }
    }

    /** Una ronda nueva: el comandante les da el tejo a algunos, al azar. */
    private static void nuevaRonda(ServerLevel complejo) {
        ronda++;
        RandomSource azar = complejo.getRandom();
        List<LivingEntity> vivos = enJuego(complejo);
        int tejos = Math.max(1, Math.min(vivos.size() - 1, Math.round(vivos.size() / (float) GENTE_POR_TEJO)));
        TIENEN.clear();
        INMUNES.clear();
        for (int i = vivos.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            LivingEntity cambio = vivos.get(i);
            vivos.set(i, vivos.get(j));
            vivos.set(j, cambio);
        }
        for (int i = 0; i < tejos && i < vivos.size(); i++) {
            darTejo(vivos.get(i));
        }
        duracionRonda = RONDA_MIN + azar.nextInt(RONDA_AZAR + 1);
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.tejo_ronda", ronda, RONDAS, tejos));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!juega(jugador)) {
                continue;
            }
            boolean lo = tieneTejo(jugador);
            Juego.titulo(jugador, Component.translatable(lo ? "titulo.juegosdelpatio.tienes_tejo" : "titulo.juegosdelpatio.tejo_ronda",
                            ronda, RONDAS).withStyle(lo ? ChatFormatting.RED : ChatFormatting.GOLD),
                    Component.translatable(lo ? "titulo.juegosdelpatio.tienes_tejo_detalle" : "titulo.juegosdelpatio.tejo_ronda_detalle",
                            tejos).withStyle(ChatFormatting.GRAY), 5, 50, 10);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.MASTER, 1.0F, lo ? 0.6F : 1.0F);
        }
        estado = Estado.REPARTIR;
        tiempo = 0;
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        switch (estado) {
            case REPARTIR -> {
                marcar(complejo);
                if (tiempo >= REPARTIR) {
                    estado = Estado.CORRER;
                    tiempo = 0;
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, 2.0F);
                    }
                }
            }
            case CORRER -> {
                marcar(complejo);
                reloj(complejo);
                if (tiempo % 10 == 0) {
                    caidos(complejo);
                }
                if (tiempo % 10 == 5) {
                    avisar(complejo);
                }
                if (tiempo >= duracionRonda) {
                    campana(complejo);
                }
            }
            case PAUSA -> {
                if (tiempo >= PAUSA) {
                    for (LivingEntity quien : enJuego(complejo)) {
                        if (CONDENADOS.contains(quien.getUUID())) {
                            Juego.eliminar(complejo, quien, false, "te_quedaste_el_tejo");   // cayó con el tejo
                        }
                    }
                    List<LivingEntity> vivos = enJuego(complejo);
                    if (ronda >= RONDAS || vivos.size() <= 1) {
                        estado = Estado.TERMINADO;
                        pasaron = vivos.size();
                        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.6F);
                        }
                    } else {
                        nuevaRonda(complejo);
                    }
                }
            }
            default -> {
            }
        }
        if (tiempo % 10 == 1) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    private static void barra(ServerLevel complejo) {
        int gente = enJuego(complejo).size();
        Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.tejo", Math.min(ronda, RONDAS), RONDAS,
                        TIENEN.size(), gente),
                estado == Estado.CORRER ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.WHITE, 1.0F);
    }

    /** Los que tienen el tejo brillan, van un poco más rápido y largan chispas rojas. */
    private static void marcar(ServerLevel complejo) {
        if (tiempo % 20 != 1) {
            return;
        }
        DustParticleOptions chispa = new DustParticleOptions(new Vector3f(0.95F, 0.12F, 0.08F), 1.2F);
        for (LivingEntity quien : enJuego(complejo)) {
            if (!tieneTejo(quien)) {
                continue;
            }
            quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
            quien.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 0, false, false));
            complejo.sendParticles(chispa, quien.getX(), quien.getY() + 2.2, quien.getZ(), 6, 0.25, 0.15, 0.25, 0.0);
            if (quien instanceof ServerPlayer jugador && jugador.getInventory().countItem(Registro.TEJO_ITEM.get()) == 0) {
                darItem(jugador);
            }
        }
    }

    /**
     * El reloj de la ronda: un tic cada segundo, y cada vez más seguido a medida que pasa la ronda (nadie sabe cuánto
     * dura, pero se nota que se acaba).
     */
    private static void reloj(ServerLevel complejo) {
        int cada = tiempo > duracionRonda - 200 ? 7 : tiempo > duracionRonda / 2 ? 14 : 20;
        if (tiempo % cada != 0) {
            return;
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 0.6F, 1.6F);
        }
    }

    private static void avisar(ServerLevel complejo) {
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!juega(jugador)) {
                continue;
            }
            jugador.displayClientMessage(tieneTejo(jugador)
                    ? Component.translatable("mensaje.juegosdelpatio.tienes_el_tejo").withStyle(ChatFormatting.RED)
                    : Component.translatable("mensaje.juegosdelpatio.lejos_del_tejo", TIENEN.size()).withStyle(ChatFormatting.GOLD),
                    true);
        }
    }

    /**
     * Suena la campana: los que tienen el tejo caen con él. Debajo de cada uno se abre un agujero de 3 x 3 (se lleva
     * también a los que estén al lado). Los que estaban en el aire, al final de la pausa quedan eliminados igual.
     */
    private static void campana(ServerLevel complejo) {
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.2F, 0.5F);
        }
        int caen = 0;
        for (LivingEntity quien : enJuego(complejo)) {
            if (!tieneTejo(quien)) {
                continue;
            }
            caen++;
            CONDENADOS.add(quien.getUUID());
            int cx = (int) Math.floor(quien.getX());
            int cz = (int) Math.floor(quien.getZ());
            for (int x = cx - 1; x <= cx + 1; x++) {
                for (int z = cz - 1; z <= cz + 1; z++) {
                    BlockPos pos = new BlockPos(x, PISO - 1, z);
                    BlockState antes = complejo.getBlockState(pos);
                    if (CAMPO.torreEn(x + 0.5, z + 0.5) < 0 || antes.isAir()) {
                        continue;
                    }
                    AGUJEROS.putIfAbsent(pos, antes);
                    complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    complejo.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, antes), x + 0.5, PISO - 0.5,
                            z + 0.5, 6, 0.3, 0.2, 0.3, 0.05);
                }
            }
            complejo.playSound(null, quien.getX(), PISO, quien.getZ(), SoundEvents.DEEPSLATE_BREAK, SoundSource.BLOCKS,
                    2.0F, 0.5F);
            quitarTejo(quien);
            if (quien instanceof ServerPlayer jugador) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.caes_con_tejo").withStyle(ChatFormatting.DARK_RED),
                        Component.empty(), 2, 30, 10);
            }
        }
        TIENEN.clear();
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.tejo_campana", caen));
        estado = Estado.PAUSA;
        tiempo = 0;
    }

    /** El que se cayó y no murió (aterrizó vivo allá abajo), queda eliminado igual. */
    private static void caidos(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getY() < PISO - 20 && quien.onGround()) {
                Juego.eliminar(complejo, quien, false, motivo(quien));
            }
        }
    }

    // ------------------------------------------------------------------ el tejo
    private static void darTejo(LivingEntity quien) {
        TIENEN.add(quien.getUUID());
        quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
        quien.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 0, false, false));
        if (quien instanceof ServerPlayer jugador) {
            darItem(jugador);
        } else if (quien instanceof JugadorBot bot) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Registro.TEJO_ITEM.get()));
            bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        }
    }

    private static void darItem(ServerPlayer jugador) {
        ItemStack tejo = new ItemStack(Registro.TEJO_ITEM.get());
        if (jugador.getMainHandItem().isEmpty()) {
            jugador.setItemInHand(InteractionHand.MAIN_HAND, tejo);
        } else if (!jugador.getInventory().add(tejo)) {
            jugador.drop(tejo, false);
        }
    }

    private static void quitarTejo(LivingEntity quien) {
        TIENEN.remove(quien.getUUID());
        quien.removeEffect(MobEffects.GLOWING);
        quien.removeEffect(MobEffects.MOVEMENT_SPEED);
        if (quien instanceof ServerPlayer jugador) {
            sacarTejos(jugador.getInventory());
        } else if (quien instanceof JugadorBot bot && bot.getMainHandItem().is(Registro.TEJO_ITEM.get())) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
    }

    /**
     * Pegar en el tejo no lastima a nadie (ningún golpe lastima): si el que pega tiene el tejo y el otro no (y no se lo
     * acaba de pasar), se lo pasa, con un empujoncito.
     */
    static void alRecibirGolpe(LivingIncomingDamageEvent evento) {
        LivingEntity victima = evento.getEntity();
        Entity fuente = evento.getSource().getEntity();
        if (!(fuente instanceof LivingEntity atacante) || atacante == victima) {
            return;                                                    // caídas y demás: lo de siempre
        }
        evento.setCanceled(true);
        if (estado != Estado.CORRER || !juega(victima) || !juega(atacante) || !tieneTejo(atacante) || tieneTejo(victima)) {
            return;
        }
        if (INMUNES.getOrDefault(victima.getUUID(), 0) > tiempo) {
            if (atacante instanceof ServerPlayer jugador) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.tejo_no_devolver")
                        .withStyle(ChatFormatting.YELLOW), true);
            }
            return;
        }
        pasar(atacante, victima);
    }

    private static void pasar(LivingEntity desde, LivingEntity hacia) {
        quitarTejo(desde);
        darTejo(hacia);
        INMUNES.put(desde.getUUID(), tiempo + INMUNE);
        double dx = hacia.getX() - desde.getX();
        double dz = hacia.getZ() - desde.getZ();
        double largo = Math.sqrt(dx * dx + dz * dz);
        if (largo > 1.0E-3) {
            hacia.knockback(EMPUJON, -dx / largo, -dz / largo);
            hacia.hurtMarked = true;
        }
        hacia.level().playSound(null, hacia.getX(), hacia.getY(), hacia.getZ(), SoundEvents.STONE_HIT, SoundSource.PLAYERS,
                1.2F, 0.7F);
        if (hacia instanceof ServerPlayer jugador) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.tienes_tejo", ronda, RONDAS)
                            .withStyle(ChatFormatting.RED),
                    Component.translatable("titulo.juegosdelpatio.te_lo_paso", Juego.nombreDe(desde)).withStyle(ChatFormatting.GRAY),
                    0, 25, 8);
        }
        if (desde instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.se_lo_pasaste", Juego.nombreDe(hacia))
                    .withStyle(ChatFormatting.GREEN), true);
        }
    }

    // ------------------------------------------------------------------ para los bots
    /** Para el bot que tiene el tejo: a quién perseguir (el más cerca que no lo tenga y se lo pueda pasar), o null. */
    @Nullable
    static LivingEntity presa(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        int aca = CAMPO.torreDe(bot);
        LivingEntity mejor = null;
        double mejorCosto = Double.MAX_VALUE;
        for (LivingEntity otro : enJuego(complejo)) {
            if (otro == bot || tieneTejo(otro) || INMUNES.getOrDefault(otro.getUUID(), 0) > tiempo) {
                continue;
            }
            int alla = CAMPO.torreDe(otro);
            double saltos = aca < 0 || alla < 0 ? 4 : CAMPO.saltos(aca, alla);
            double costo = saltos * 14.0 + Math.sqrt(bot.distanceToSqr(otro));
            if (costo < mejorCosto) {
                mejorCosto = costo;
                mejor = otro;
            }
        }
        return mejor;
    }

    /** Para el que no tiene el tejo: el que lo tiene más cerca, y a cuántos saltos (o null si no hay ninguno). */
    @Nullable
    static LivingEntity peligro(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity mejor = null;
        double mejorD = Double.MAX_VALUE;
        for (LivingEntity otro : enJuego(complejo)) {
            if (otro != bot && tieneTejo(otro)) {
                double d = bot.distanceToSqr(otro);
                if (d < mejorD) {
                    mejorD = d;
                    mejor = otro;
                }
            }
        }
        return mejor;
    }

    /**
     * Adónde se escapa el bot: la torre (de las de al lado, o la misma) que queda más lejos de todos los que tienen el
     * tejo (contando saltos); si da igual, la más grande.
     */
    static int huida(JugadorBot bot) {
        int aca = CAMPO.torreDe(bot);
        if (aca < 0 || !(bot.level() instanceof ServerLevel complejo)) {
            return -1;
        }
        List<Integer> donde = new ArrayList<>();
        for (LivingEntity otro : enJuego(complejo)) {
            if (tieneTejo(otro)) {
                int t = CAMPO.torreDe(otro);
                if (t >= 0) {
                    donde.add(t);
                }
            }
        }
        int mejor = aca;
        double mejorPuntaje = -Double.MAX_VALUE;
        List<Integer> opciones = new ArrayList<>();
        opciones.add(aca);
        for (int v : CAMPO.vecinos[aca]) {
            opciones.add(v);
        }
        for (int t : opciones) {
            int lejos = 99;
            for (int d : donde) {
                lejos = Math.min(lejos, CAMPO.saltos(t, d));
            }
            int[] r = TORRES[t];
            double puntaje = lejos * 10.0 + (r[1] - r[0]) * (r[3] - r[2]) / 100.0 + bot.getRandom().nextDouble();
            if (puntaje > mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = t;
            }
        }
        return mejor;
    }

    /** La probabilidad de que a un bot le salga mal un salto (casi nunca: más en los de 3 y en los más torpes). */
    static double riesgo(JugadorBot bot, int desde, int hacia) {
        double base = CAMPO.hueco(desde, hacia) >= 3 ? 0.02 : 0.005;
        return base * (0.5 + Math.floorMod(bot.getUUID().getMostSignificantBits(), 100) * 0.012);
    }

    // ------------------------------------------------------------------ muertes y limpiar
    /** Murió uno que jugaba: Juego lo anota como eliminado. Acá se avisa. */
    static void alMorir(ServerLevel complejo, LivingEntity muerto) {
        if (!JUEGAN.contains(muerto.getUUID())) {
            return;
        }
        boolean conTejo = CONDENADOS.contains(muerto.getUUID()) || tieneTejo(muerto);
        TIENEN.remove(muerto.getUUID());
        Component mensaje = Component.translatable(conTejo ? "mensaje.juegosdelpatio.cayo_con_tejo"
                : "mensaje.juegosdelpatio.se_cayo", Juego.nombreDe(muerto));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (jugador != muerto) {
                jugador.sendSystemMessage(mensaje.copy().withStyle(ChatFormatting.DARK_RED));
            }
        }
    }

    static void limpiar(ServerLevel complejo) {
        for (ServerPlayer jugador : complejo.players()) {
            sacarTejos(jugador.getInventory());
            if (JUEGAN.contains(jugador.getUUID())) {
                jugador.removeEffect(MobEffects.GLOWING);
                jugador.removeEffect(MobEffects.MOVEMENT_SPEED);
            }
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> JUEGAN.contains(bot.getUUID()))) {
            bot.removeEffect(MobEffects.GLOWING);
            bot.removeEffect(MobEffects.MOVEMENT_SPEED);
            if (bot.getMainHandItem().is(Registro.TEJO_ITEM.get())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
        }
        for (ItemEntity tirada : complejo.getEntitiesOfClass(ItemEntity.class, new AABB(X0, SUELO - 2, Z0, X1 + 1, PISO + 12, Z1 + 1),
                tirada -> tirada.getItem().is(Registro.TEJO_ITEM.get()))) {
            tirada.discard();
        }
        for (Map.Entry<BlockPos, BlockState> agujero : AGUJEROS.entrySet()) {
            if (complejo.getBlockState(agujero.getKey()).isAir()) {
                complejo.setBlock(agujero.getKey(), agujero.getValue(), Block.UPDATE_CLIENTS);
            }
        }
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ronda = 0;
        duracionRonda = 0;
        JUEGAN.clear();
        TIENEN.clear();
        INMUNES.clear();
        CONDENADOS.clear();
        AGUJEROS.clear();
        enJuegoCache = null;
        enJuegoTick = -1;
    }

    private static void sacarTejos(Inventory inventario) {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            if (inventario.getItem(i).is(Registro.TEJO_ITEM.get())) {
                inventario.setItem(i, ItemStack.EMPTY);
            }
        }
    }

    // ------------------------------------------------------------------ la arena
    /** Dónde aparece quien llega: en la largada, delante del podio. */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(6980.5 + azar.nextInt(41), PISO, -10.5 + azar.nextInt(10));
    }

    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionTejo() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        if (estadoComplejo.versionTejo() > 0) {
            BlockState aire = Blocks.AIR.defaultBlockState();
            for (BlockPos pos : BlockPos.betweenClosed(X0, SUELO - 1, Z0, X1, PISO + 17, Z1)) {
                if (!complejo.getBlockState(pos).isAir()) {
                    complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
                }
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionTejo(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de El tejo colocada en {}", ORIGEN);
        return true;
    }

    /** Los que siguen jugando (vivos y sin eliminar). Se arma una vez por tick: los bots lo piden todo el tiempo. */
    private static List<LivingEntity> enJuego(ServerLevel complejo) {
        long ahora = complejo.getGameTime();
        if (ahora == enJuegoTick && enJuegoCache != null) {
            List<LivingEntity> vivos = new ArrayList<>();
            for (LivingEntity quien : enJuegoCache) {
                if (quien.isAlive() && !Juego.eliminado(quien)) {
                    vivos.add(quien);
                }
            }
            return vivos;
        }
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : Juego.participantes(complejo)) {
            if (JUEGAN.contains(quien.getUUID())) {
                lista.add(quien);
            }
        }
        enJuegoCache = lista;
        enJuegoTick = ahora;
        return new ArrayList<>(lista);
    }
}
