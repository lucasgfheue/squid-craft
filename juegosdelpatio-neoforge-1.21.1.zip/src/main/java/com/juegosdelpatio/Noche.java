package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.neoforged.neoforge.event.entity.player.CanPlayerSleepEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * El día y la noche del complejo.
 *
 * <ul>
 *   <li>Un minuto después de que termina la ceremonia (o al anochecer del mundo normal, los otros días) se apagan
 *       algunas luces del salón: las del techo, las de arriba de las columnas y la mayoría de las del piso; los
 *       faroles quedan con una luz azul tenue. Los bots se acuestan en las literas de abajo.</li>
 *   <li>La noche dura 5 minutos. Después se prenden las luces, los bots se levantan y empieza el día siguiente:
 *       el reloj del mundo normal salta a la mañana.</li>
 *   <li>Dormir no adelanta nada; en el complejo solo se puede dormir con las luces apagadas.</li>
 *   <li>Cada día nuevo aparece en la pantalla: "Día N" y qué toca ese día.</li>
 * </ul>
 */
public final class Noche {
    /** Los días sin ceremonia, a esta hora del mundo normal se apagan las luces. */
    public static final long HORA_DORMIR = 13000L;
    /** Cuánto dura la noche del complejo: 5 minutos. */
    public static final int DURACION = 5 * 60 * 20;
    /** Cuánto después de la ceremonia se apagan las luces: 1 minuto. */
    public static final int ESPERA_TRAS_CEREMONIA = 60 * 20;

    /** Copia de EstadoComplejo.nocheHasta() >= 0, para que los bots la consulten rápido. */
    private static boolean deNoche;
    /** Momento (tiempo de juego) en que terminó la última ceremonia, o -1. */
    private static long finCeremonia = -1;
    /** Cama que eligió cada bot esta noche, para que no vayan dos a la misma. */
    private static final Map<BlockPos, Integer> RESERVAS = new HashMap<>();
    @Nullable
    private static List<BlockPos> luces;
    @Nullable
    private static List<BlockPos> camas;

    private Noche() {
    }

    public static boolean esDeNoche() {
        return deNoche;
    }

    /** La llama la ceremonia cuando el portón termina de cerrarse. */
    static void ceremoniaTerminada(MinecraftServer servidor) {
        finCeremonia = servidor.overworld().getGameTime();
    }

    /** La sala se volvió a construir: hay que volver a buscar las luces y las camas. */
    static void olvidarSala() {
        luces = null;
        camas = null;
        RESERVAS.clear();
    }

    // ------------------------------------------------------------------ eventos
    static void alTick(ServerTickEvent.Post evento) {
        MinecraftServer servidor = evento.getServer();
        if (servidor.getTickCount() % 20 != 0) {
            return;
        }
        ServerLevel complejo = servidor.getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        EstadoComplejo estado = EstadoComplejo.de(servidor);
        deNoche = estado.nocheHasta() >= 0;
        if (estado.versionSala() != Complejo.VERSION_SALA) {
            return;                                     // la sala todavía no existe
        }
        long reloj = servidor.overworld().getDayTime();
        long dia = reloj / 24000L;
        long hora = reloj % 24000L;
        long ahora = servidor.overworld().getGameTime();
        boolean hayGente = !complejo.players().isEmpty();

        // ¿Empezó un día nuevo? (porque terminó la noche corta o porque el reloj llegó solo)
        if (dia != estado.ultimoDia()) {
            boolean primeraVez = estado.ultimoDia() < 0;
            estado.setUltimoDia(dia);
            if (deNoche) {
                amanecer(complejo, estado);
            }
            if (!primeraVez && hayGente) {
                anunciarDia(complejo, dia);
            }
            return;
        }
        if (deNoche) {
            if (ahora >= estado.nocheHasta()) {
                if (hayGente) {
                    servidor.overworld().setDayTime((dia + 1) * 24000L);   // fin de la noche: mañana del día siguiente
                } else {
                    amanecer(complejo, estado);         // no quedó nadie: solo se prenden las luces
                }
            }
            return;
        }
        // ¿Hora de dormir?
        if (!hayGente || estado.diaApagado() == dia || Ceremonia.enCurso()) {
            return;
        }
        boolean esperando = finCeremonia >= 0 && ahora < finCeremonia + ESPERA_TRAS_CEREMONIA;
        boolean trasCeremonia = finCeremonia >= 0 && !esperando;
        if (trasCeremonia || hora >= HORA_DORMIR && !esperando) {
            anochecer(complejo, estado, dia, ahora);
        }
    }

    /** En el complejo solo se puede dormir con las luces apagadas (igual no adelanta el día). */
    static void alAcostarse(CanPlayerSleepEvent evento) {
        if (evento.getLevel().dimension().equals(Complejo.DIMENSION) && !deNoche && evento.getProblem() == null) {
            evento.setProblem(Player.BedSleepingProblem.NOT_POSSIBLE_NOW);
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        deNoche = false;
        finCeremonia = -1;
        olvidarSala();
    }

    // ------------------------------------------------------------------ noche y día
    private static void anochecer(ServerLevel complejo, EstadoComplejo estado, long dia, long ahora) {
        estado.setDiaApagado(dia);
        estado.setNocheHasta(ahora + DURACION);
        deNoche = true;
        finCeremonia = -1;
        RESERVAS.clear();
        cambiarLuces(complejo, false);
        titulo(complejo, Component.translatable("titulo.juegosdelpatio.luces").withStyle(ChatFormatting.DARK_AQUA),
                Component.translatable("titulo.juegosdelpatio.a_dormir").withStyle(ChatFormatting.GRAY));
        sonar(complejo, SoundEvents.BEACON_DEACTIVATE, 0.8F);
    }

    private static void amanecer(ServerLevel complejo, EstadoComplejo estado) {
        estado.setNocheHasta(-1);
        deNoche = false;
        RESERVAS.clear();
        cambiarLuces(complejo, true);
        sonar(complejo, SoundEvents.BEACON_ACTIVATE, 1.0F);
    }

    private static void anunciarDia(ServerLevel complejo, long dia) {
        long cicloDia = dia % Complejo.CICLO_DIAS;
        Component detalle;
        if (cicloDia == 0) {
            detalle = Component.translatable("titulo.juegosdelpatio.dia_entrada");
        } else if (cicloDia <= Complejo.JUEGOS) {
            detalle = Component.translatable("titulo.juegosdelpatio.dia_juego", cicloDia, Complejo.JUEGOS);
        } else {
            detalle = Component.translatable("titulo.juegosdelpatio.dia_libre");
        }
        titulo(complejo, Component.translatable("titulo.juegosdelpatio.dia", dia).withStyle(ChatFormatting.GOLD),
                Component.empty().append(detalle).withStyle(ChatFormatting.GRAY));
        sonar(complejo, SoundEvents.BELL_BLOCK, 1.0F);
    }

    /**
     * De noche se apagan las lámparas del techo, las de arriba de las columnas y la mayoría de las luces del piso
     * (quedan las del pasillo central y algunas de la plaza), y los faroles pasan a dar una luz azul más tenue.
     * Las lámparas de abajo de las columnas y las del portón quedan prendidas.
     */
    private static void cambiarLuces(ServerLevel complejo, boolean prender) {
        for (BlockPos pos : buscarLuces(complejo)) {
            BlockState actual = complejo.getBlockState(pos);
            BlockState nuevo = actual;
            if (actual.is(Blocks.WAXED_COPPER_BULB)) {
                nuevo = actual.setValue(BlockStateProperties.LIT, prender);
            } else if (!prender && actual.is(Blocks.LANTERN)) {
                nuevo = Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, actual.getValue(LanternBlock.HANGING));
            } else if (prender && actual.is(Blocks.SOUL_LANTERN)) {
                nuevo = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, actual.getValue(LanternBlock.HANGING));
            } else if (!prender && actual.is(Blocks.SEA_LANTERN)) {
                nuevo = Blocks.PRISMARINE_BRICKS.defaultBlockState();          // luz del piso apagada
            } else if (prender && actual.is(Blocks.PRISMARINE_BRICKS)) {
                nuevo = Blocks.SEA_LANTERN.defaultBlockState();
            }
            if (nuevo != actual) {
                complejo.setBlock(pos, nuevo, Block.UPDATE_CLIENTS);
            }
        }
    }

    /** Recorre el salón una vez y anota las luces que se apagan de noche y las camas de abajo de las literas. */
    private static List<BlockPos> buscarLuces(ServerLevel complejo) {
        if (luces == null || camas == null) {
            List<BlockPos> nuevasLuces = new ArrayList<>();
            List<BlockPos> nuevasCamas = new ArrayList<>();
            for (BlockPos pos : BlockPos.betweenClosed(-32, 64, -4, 32, 84, 68)) {
                BlockState estado = complejo.getBlockState(pos);
                int y = pos.getY();
                if (estado.is(Blocks.WAXED_COPPER_BULB) ? (y == 84 || y == 76)
                        : estado.is(Blocks.LANTERN) || estado.is(Blocks.SOUL_LANTERN)) {
                    nuevasLuces.add(pos.immutable());
                } else if (y == 64 && (estado.is(Blocks.SEA_LANTERN) || estado.is(Blocks.PRISMARINE_BRICKS))
                        && !quedaPrendida(pos.getX() + 32, pos.getZ() + 4)) {
                    nuevasLuces.add(pos.immutable());
                } else if (y == 65 && estado.getBlock() instanceof BedBlock && estado.getValue(BedBlock.PART) == BedPart.HEAD) {
                    nuevasCamas.add(pos.immutable());
                }
            }
            luces = nuevasLuces;
            camas = nuevasCamas;
        }
        return luces;
    }

    /** Luces del piso que siguen prendidas de noche (coordenadas del salón): el pasillo central y algunas de la plaza. */
    private static boolean quedaPrendida(int x, int z) {
        return x == 32 || (x == 18 || x == 46) && Math.floorMod(z - 8, 12) == 0;
    }

    // ------------------------------------------------------------------ camas para los bots
    /** Reserva para el bot la cama libre de abajo más cercana. null si no queda ninguna. */
    @Nullable
    static BlockPos reservarCama(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel nivel)) {
            return null;
        }
        buscarLuces(nivel);
        List<BlockPos> lista = camas;
        if (lista == null) {
            return null;
        }
        BlockPos mejor = null;
        double menor = Double.MAX_VALUE;
        for (BlockPos cama : lista) {
            if (RESERVAS.containsKey(cama)) {
                continue;
            }
            double distancia = bot.distanceToSqr(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5);
            if (distancia < menor) {
                BlockState estado = nivel.getBlockState(cama);
                if (estado.getBlock() instanceof BedBlock && !estado.getValue(BedBlock.OCCUPIED)) {
                    mejor = cama;
                    menor = distancia;
                }
            }
        }
        if (mejor != null) {
            RESERVAS.put(mejor, bot.getId());
        }
        return mejor;
    }

    static void liberarCama(BlockPos cama) {
        RESERVAS.remove(cama);
    }

    // ------------------------------------------------------------------ ayudas
    private static void titulo(ServerLevel complejo, Component titulo, Component subtitulo) {
        for (ServerPlayer jugador : complejo.players()) {
            jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
            jugador.connection.send(new ClientboundSetSubtitleTextPacket(subtitulo));
            jugador.connection.send(new ClientboundSetTitleTextPacket(titulo));
        }
    }

    private static void sonar(ServerLevel complejo, SoundEvent sonido, float tono) {
        for (ServerPlayer jugador : complejo.players()) {
            jugador.playNotifySound(sonido, SoundSource.AMBIENT, 1.0F, tono);
        }
    }
}
