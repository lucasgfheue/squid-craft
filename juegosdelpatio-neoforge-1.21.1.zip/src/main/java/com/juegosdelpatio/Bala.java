package com.juegosdelpatio;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Bala rápida, casi sin caída. Desaparece al chocar o a los 4 segundos. */
public class Bala extends ThrowableItemProjectile {
    private float danio = 4.0F;

    public Bala(EntityType<? extends Bala> tipo, Level nivel) {
        super(tipo, nivel);
    }

    public Bala(Level nivel, LivingEntity tirador, float danio) {
        super(Registro.BALA.get(), tirador, nivel);
        this.danio = danio;
    }

    @Override
    protected Item getDefaultItem() {
        return Registro.BALA_ITEM.get();
    }

    @Override
    protected double getDefaultGravity() {
        return 0.002;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide() && this.tickCount > 80) {
            discard();
        }
    }

    /** Las balas de los guardias atraviesan a otros guardias y a los jugadores del dormitorio. */
    @Override
    protected boolean canHitEntity(Entity objetivo) {
        if (getOwner() instanceof Guardia && (objetivo instanceof Guardia || objetivo instanceof JugadorBot)) {
            return false;
        }
        return super.canHitEntity(objetivo);
    }

    @Override
    protected void onHitEntity(EntityHitResult resultado) {
        super.onHitEntity(resultado);
        Entity golpeado = resultado.getEntity();
        LivingEntity tirador = getOwner() instanceof LivingEntity vivo ? vivo : null;
        golpeado.invulnerableTime = 0;                  // para que cuenten todos los perdigones de la escopeta
        golpeado.hurt(damageSources().mobProjectile(this, tirador), danio);
    }

    @Override
    protected void onHit(HitResult resultado) {
        super.onHit(resultado);
        if (level() instanceof ServerLevel servidor) {
            servidor.sendParticles(ParticleTypes.SMOKE, getX(), getY(), getZ(), 2, 0.02, 0.02, 0.02, 0.0);
            discard();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag datos) {
        super.addAdditionalSaveData(datos);
        datos.putFloat("Danio", danio);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag datos) {
        super.readAdditionalSaveData(datos);
        if (datos.contains("Danio")) {
            danio = datos.getFloat("Danio");
        }
    }
}
