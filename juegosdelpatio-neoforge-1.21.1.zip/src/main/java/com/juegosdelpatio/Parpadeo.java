package com.juegosdelpatio;

import io.netty.buffer.ByteBuf;
import java.util.Arrays;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Del servidor al cliente: en las sillas musicales, cuando para la música las luces del salón parpadean unos segundos
 * mientras todos corren a sentarse. El servidor solo avisa que empieza (con cuántos ticks dura; 0 = se corta). Cada
 * cliente lo dibuja siguiendo {@link #PATRON} (ver ClienteLuces) y el servidor hace sonar los clics de las luces al
 * mismo ritmo.
 */
public record Parpadeo(int ticks) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<Parpadeo> TIPO = new CustomPacketPayload.Type<>(Complejo.id("parpadeo"));
    public static final StreamCodec<ByteBuf, Parpadeo> CODEC = StreamCodec.composite(ByteBufCodecs.VAR_INT, Parpadeo::ticks,
            Parpadeo::new);

    /**
     * Cuántos ticks quedan las luces apagadas, prendidas, apagadas, prendidas... como una luz que falla. Cada apagón y
     * la luz que le sigue duran por lo menos 7 ticks juntos: nunca más de 3 destellos por segundo.
     */
    static final int[] PATRON = {6, 4, 4, 3, 5, 4, 3, 5, 6, 3, 4, 4, 5, 3, 4, 5, 6, 6};
    /** Todo el parpadeo: 80 ticks (4 segundos). */
    static final int DURACION = Arrays.stream(PATRON).sum();

    /** En el cliente: cuántos ticks lleva el parpadeo (-1 = no hay) y cuánto dura. */
    static int tiempoCliente = -1;
    static int largoCliente;

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TIPO;
    }

    /** ¿En el tick {@code t} del parpadeo las luces están apagadas? (después de {@link #DURACION} vuelve a empezar) */
    static boolean apagadas(int t) {
        int resto = Math.floorMod(t, DURACION);
        for (int i = 0; i < PATRON.length; i++) {
            if (resto < PATRON[i]) {
                return i % 2 == 0;
            }
            resto -= PATRON[i];
        }
        return false;
    }

    /** Se anota el paquete (del servidor al cliente). */
    static void registrar(RegisterPayloadHandlersEvent evento) {
        PayloadRegistrar registro = evento.registrar("1");
        registro.playToClient(TIPO, CODEC, Parpadeo::recibir);
    }

    private static void recibir(Parpadeo paquete, IPayloadContext contexto) {
        contexto.enqueueWork(() -> {
            largoCliente = paquete.ticks();
            tiempoCliente = paquete.ticks() > 0 ? 0 : -1;
        });
    }
}
