package com.juegosdelpatio;

import io.netty.buffer.ByteBuf;
import java.util.Arrays;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Del servidor al cliente: las luces parpadean. En las sillas musicales, cuando para la música, unos segundos mientras
 * todos corren a sentarse; en la noche del pastel, los 2 minutos de la masacre. El servidor solo avisa que empieza (con
 * cuántos ticks dura, 0 = se corta, y cuál de los dos parpadeos es). Cada cliente lo dibuja siguiendo el patrón (ver
 * ClienteLuces) y el servidor hace sonar los clics de las luces al mismo ritmo.
 */
public record Parpadeo(int ticks, int tipo) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<Parpadeo> TIPO = new CustomPacketPayload.Type<>(Complejo.id("parpadeo"));
    public static final StreamCodec<ByteBuf, Parpadeo> CODEC = StreamCodec.composite(ByteBufCodecs.VAR_INT, Parpadeo::ticks,
            ByteBufCodecs.VAR_INT, Parpadeo::tipo, Parpadeo::new);
    /** Los dos parpadeos: el de las sillas ({@link #PATRON}) y el de la masacre ({@link #PATRON_MASACRE}). */
    static final int SILLAS = 0;
    static final int MASACRE = 1;

    /**
     * Cuántos ticks quedan las luces apagadas, prendidas, apagadas, prendidas... como una luz que falla. Cada apagón y
     * la luz que le sigue duran por lo menos 7 ticks juntos: nunca más de 3 destellos por segundo.
     */
    static final int[] PATRON = {6, 4, 4, 3, 5, 4, 3, 5, 6, 3, 4, 4, 5, 3, 4, 5, 6, 6};
    /** Todo el parpadeo: 80 ticks (4 segundos). */
    static final int DURACION = Arrays.stream(PATRON).sum();
    /**
     * La masacre: casi siempre prendidas, con apagones de golpe de vez en cuando (se repite cada 17 segundos). También
     * acá cada apagón y la luz que le sigue duran por lo menos 7 ticks juntos.
     */
    static final int[] PATRON_MASACRE = {8, 46, 5, 9, 4, 70, 12, 34, 6, 10, 3, 58, 9, 26, 5, 40};

    /** En el cliente: cuántos ticks lleva el parpadeo (-1 = no hay), cuánto dura y cuál es. */
    static int tiempoCliente = -1;
    static int largoCliente;
    static int tipoCliente;

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TIPO;
    }

    /** ¿En el tick {@code t} del parpadeo de las sillas las luces están apagadas? (después de {@link #DURACION} vuelve a empezar) */
    static boolean apagadas(int t) {
        return apagadas(t, SILLAS);
    }

    /** ¿En el tick {@code t} del parpadeo {@code tipo} las luces están apagadas? (el patrón se repite) */
    static boolean apagadas(int t, int tipo) {
        int[] patron = tipo == MASACRE ? PATRON_MASACRE : PATRON;
        int resto = Math.floorMod(t, Arrays.stream(patron).sum());
        for (int i = 0; i < patron.length; i++) {
            if (resto < patron[i]) {
                return i % 2 == 0;
            }
            resto -= patron[i];
        }
        return false;
    }

    /** Se anota el paquete (del servidor al cliente). */
    static void registrar(RegisterPayloadHandlersEvent evento) {
        PayloadRegistrar registro = evento.registrar("1");
        registro.playToClient(TIPO, CODEC, Parpadeo::recibir);
    }

    private static void recibir(Parpadeo paquete, IPayloadContext contexto) {
        contexto.enqueueWork(() -> {
            largoCliente = paquete.ticks();
            tipoCliente = paquete.tipo();
            tiempoCliente = paquete.ticks() > 0 ? 0 : -1;
        });
    }
}
