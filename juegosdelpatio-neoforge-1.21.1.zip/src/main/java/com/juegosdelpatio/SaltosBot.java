package com.juegosdelpatio;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * Para los bots de los juegos en torres: ir de una torre a otra saltando. Camina hasta el borde que da a la próxima
 * torre del camino, se para, mira y salta; en el aire va derecho adonde apuntó (como un salto con carrera). Si el
 * salto le sale mal (ver {@link Riesgo}), apunta corto: cae en el vacío. Y si le pegan en el aire (en Los estandartes),
 * el golpe lo saca del salto: sigue volando como lo empujaron.
 */
final class SaltosBot {
    /** Lo que tarda un salto en volver a la misma altura (ticks). */
    private static final int VUELO = 12;

    /** La probabilidad de que un salto de una torre a otra le salga mal. */
    interface Riesgo {
        double de(int desde, int hacia);
    }

    private final JugadorBot bot;
    private int desde = -1;
    private int hacia = -1;
    @Nullable
    private Vec3 salida;
    @Nullable
    private Vec3 llegada;
    private Vec3 apuntado = Vec3.ZERO;
    private boolean enElAire;
    /** Le pegaron en el aire: ya no va adonde apuntó. */
    private boolean desviado;
    private int golpeAntes;
    private int vuelo;
    private int quieto;
    private int espera;
    private int intentos;

    SaltosBot(JugadorBot bot) {
        this.bot = bot;
    }

    boolean enElAire() {
        return enElAire;
    }

    /** Se olvida del salto que tenía pensado (lo llevaron a otro lado, o cambió de idea). */
    void olvidar() {
        salida = null;
        llegada = null;
        desde = -1;
        hacia = -1;
        enElAire = false;
    }

    /** Si está en el aire, sigue el vuelo y devuelve true (ese tick no hay que hacer nada más). */
    boolean volando() {
        if (!enElAire) {
            return false;
        }
        vuelo++;
        if (vuelo > 2 && bot.onGround() || vuelo > 400 || !bot.isAlive()) {
            enElAire = false;                                       // cayó (en la otra torre, o allá abajo)
            salida = null;
            return false;
        }
        if (bot.hurtTime > golpeAntes) {
            desviado = true;                                        // ¡le pegaron en el aire!
        }
        golpeAntes = bot.hurtTime;
        if (desviado) {
            return true;                                            // vuela como lo empujó el golpe
        }
        Vec3 m = bot.getDeltaMovement();
        if (vuelo < VUELO) {
            double quedan = VUELO - vuelo;
            bot.setDeltaMovement((apuntado.x - bot.getX()) / quedan, m.y, (apuntado.z - bot.getZ()) / quedan);
        } else {
            bot.setDeltaMovement(m.x * 0.3, m.y, m.z * 0.3);       // sin piso abajo: se cae derecho
        }
        return true;
    }

    /**
     * Un tick de camino a la torre {@code destino}: true si ya está ahí. Si no, va hasta el borde que da a la próxima
     * torre del camino (por donde haya piso: puede haber agujeros), se para, mira y salta.
     */
    boolean ir(CampoDeTorres campo, int destino, double velocidad, Riesgo riesgo) {
        int aca = campo.torreDe(bot);
        if (aca < 0 || !bot.onGround()) {
            return false;
        }
        if (aca == destino) {
            salida = null;
            return true;
        }
        int proximo = campo.proximo(aca, destino);
        if (proximo < 0) {
            return false;
        }
        if (salida == null || desde != aca || hacia != proximo || ++intentos > 160) {
            planear(campo, aca, proximo);
            if (salida == null) {
                bot.getNavigation().stop();                          // no hay por dónde (agujeros): espera
                return false;
            }
        }
        double dx = salida.x - bot.getX();
        double dz = salida.z - bot.getZ();
        double d2 = dx * dx + dz * dz;
        if (d2 > 0.03) {                                             // hasta el borde: lejos, con caminos; cerca, derecho
            if (d2 > 2.25 || !derecho(campo, salida)) {
                if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                    bot.getNavigation().moveTo(salida.x, salida.y, salida.z, velocidad);
                }
            } else {
                bot.getNavigation().stop();
                bot.getMoveControl().setWantedPosition(salida.x, salida.y, salida.z, 0.45);
            }
            quieto = 0;
            return false;
        }
        bot.getNavigation().stop();
        float giro = (float) (Math.atan2(llegada.z - bot.getZ(), llegada.x - bot.getX()) * (180.0 / Math.PI)) - 90.0F;
        bot.setYRot(giro);
        bot.setYBodyRot(giro);
        bot.setYHeadRot(giro);
        bot.getLookControl().setLookAt(llegada.x, llegada.y + 0.5, llegada.z);
        if (++quieto < espera) {
            return false;                                            // se para y mira...
        }
        saltar(riesgo.de(desde, hacia));                             // ...y salta
        return false;
    }

    /** Elige de dónde saltar y dónde caer: los dos lugares con piso (prueba unas cuantas veces). */
    private void planear(CampoDeTorres campo, int aca, int proximo) {
        desde = aca;
        hacia = proximo;
        intentos = 0;
        quieto = 0;
        espera = 4 + bot.getRandom().nextInt(8);
        salida = null;
        for (int prueba = 0; prueba < 8; prueba++) {
            Vec3[] salto = campo.salto(aca, proximo, bot.getRandom());
            if (firme(campo, salto[0]) && firme(campo, salto[1]) && firme(campo, salto[1].add(0.6, 0.0, 0.6))
                    && firme(campo, salto[1].add(-0.6, 0.0, -0.6))) {
                salida = salto[0];
                llegada = salto[1];
                return;
            }
        }
    }

    private void saltar(double riesgo) {
        if (bot.getRandom().nextDouble() < riesgo) {
            Vec3 medio = salida.add(llegada).scale(0.5);             // le salió corto: cae en el medio del vacío
            apuntado = new Vec3(medio.x, medio.y, medio.z);
        } else {
            apuntado = llegada;
        }
        bot.setDeltaMovement((apuntado.x - bot.getX()) / VUELO, 0.42, (apuntado.z - bot.getZ()) / VUELO);
        bot.hasImpulse = true;
        enElAire = true;
        desviado = false;
        golpeAntes = bot.hurtTime;
        vuelo = 0;
    }

    /** ¿Hay piso (un bloque) debajo de ese lugar? */
    private boolean firme(CampoDeTorres campo, Vec3 lugar) {
        return !bot.level().getBlockState(BlockPos.containing(lugar.x, campo.piso - 1, lugar.z)).isAir();
    }

    /** ¿Se puede ir caminando derecho hasta ahí sin pisar un agujero? */
    private boolean derecho(CampoDeTorres campo, Vec3 hasta) {
        double dx = hasta.x - bot.getX();
        double dz = hasta.z - bot.getZ();
        int pasos = (int) Math.ceil(Math.sqrt(dx * dx + dz * dz) / 0.25);
        for (int i = 1; i <= pasos; i++) {
            if (!firme(campo, new Vec3(bot.getX() + dx * i / pasos, campo.piso, bot.getZ() + dz * i / pasos))) {
                return false;
            }
        }
        return true;
    }
}
