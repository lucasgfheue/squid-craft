package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * El reparto de comida: después de que la mayoría votó por seguir y el comandante se fue, aparecen tres
 * vigilantes detrás del mostrador del comedor y le dan la comida a cada uno (jugadores y bots, que se la comen
 * ahí mismo): un filete, salvo después del segundo juego, que hay una zanahoria y una papa cruda. Cuando todos
 * tienen su comida (o pasa un minuto y medio), los vigilantes se van y al minuto se apagan las luces: todos a
 * dormir hasta el día siguiente.
 */
final class Comida {
    /** Los tres vigilantes, detrás del mostrador del comedor, mirando hacia el salón. */
    static final Vec3[] PUESTOS = {new Vec3(14.5, 65.0, -29.5), new Vec3(20.5, 65.0, -29.5), new Vec3(26.5, 65.0, -29.5)};
    /** Hasta dónde llega un vigilante para darte la comida por encima del mostrador. */
    private static final double ALCANCE = 5.0;
    /** Si en un minuto y medio no vinieron todos, a los que faltan se la llevan igual. */
    private static final int DURACION_MAX = 90 * 20;

    private static boolean activa;
    private static int tiempo;
    /**
     * Lo que toca hoy (depende del juego que se jugó): 1 = un filete; 2 = una zanahoria y una papa cruda; 3 = un pastel
     * y una espada para cortarlo (y después de comer, empieza la noche del pastel: ver {@link Masacre}).
     */
    private static int menu = 1;
    private static final Set<UUID> RECIBIERON = new HashSet<>();
    private static final List<Guardia> VIGILANTES = new ArrayList<>();
    @Nullable
    private static ServerBossEvent barra;

    private Comida() {
    }

    static boolean enCurso() {
        return activa;
    }

    static boolean yaComio(LivingEntity quien) {
        return RECIBIERON.contains(quien.getUUID());
    }

    /**
     * Aparecen los tres vigilantes en el comedor y empieza el reparto de la comida que toca después del juego
     * {@code juego}. false si ya estaba repartiendo.
     */
    static boolean empezar(ServerLevel complejo, int juego) {
        if (activa) {
            return false;
        }
        menu = juego == 3 ? 3 : juego == 2 ? 2 : 1;
        VIGILANTES.clear();
        RECIBIERON.clear();
        for (Vec3 puesto : PUESTOS) {
            Guardia vigilante = Complejo.invocarGuardia(complejo, puesto, 0.0F, Rango.VIGILANTE, -1);
            if (vigilante != null) {
                vigilante.hacerEscoltaFija(puesto);                  // quieto en el mostrador; se va al terminar
                vigilante.setItemSlot(EquipmentSlot.MAINHAND, comida().get(0));
                vigilante.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
                VIGILANTES.add(vigilante);
            }
        }
        activa = true;
        tiempo = 0;
        barra = new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);
        decir(complejo, Component.translatable("comida.juegosdelpatio.a_comer", que()));
        for (ServerPlayer jugador : complejo.players()) {
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 1.4F);
        }
        actualizarBarra(complejo);
        return true;
    }

    static void alTick(ServerTickEvent.Post evento) {
        if (!activa) {
            return;
        }
        MinecraftServer servidor = evento.getServer();
        ServerLevel complejo = servidor.getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        tiempo++;
        if (tiempo % 5 == 0) {
            servir(complejo);
        }
        if (tiempo % 20 == 0) {
            actualizarBarra(complejo);
            if (faltan(complejo) == 0 || tiempo >= DURACION_MAX) {
                terminar(complejo);
                return;
            }
        }
        if (tiempo % 400 == 0) {                                     // a los que no vinieron, se les vuelve a avisar
            for (ServerPlayer jugador : complejo.players()) {
                if (!RECIBIERON.contains(jugador.getUUID())) {
                    jugador.displayClientMessage(Component.translatable("comida.juegosdelpatio.recordatorio")
                            .withStyle(ChatFormatting.YELLOW), true);
                }
            }
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        activa = false;
        menu = 1;
        RECIBIERON.clear();
        VIGILANTES.clear();
        barra = null;
    }

    /** La comida de hoy, una cosa por cada lugar del inventario. */
    private static List<ItemStack> comida() {
        return menu == 3 ? List.of(Masacre.pastel(), Masacre.espadaPastel())
                : menu == 2 ? List.of(new ItemStack(Items.CARROT), new ItemStack(Items.POTATO))
                : List.of(new ItemStack(Items.COOKED_BEEF));
    }

    /** Cómo se dice lo que toca hoy ("un filete", "una zanahoria y una papa cruda"). */
    private static Component que() {
        return Component.translatable("comida.juegosdelpatio.menu_" + menu);
    }

    /** El bot se come todo lo que le dieron, una cosa después de la otra. */
    private static void darABot(JugadorBot bot) {
        for (ItemStack cosa : comida()) {
            if (!Masacre.esEspadaPastel(cosa)) {
                bot.comer(cosa);                                     // (la espada no se come: la guarda)
            }
        }
    }

    /** Cada vigilante le da la comida a los que tiene cerca (los jugadores la guardan; los bots se la comen). */
    private static void servir(ServerLevel complejo) {
        for (Guardia vigilante : VIGILANTES) {
            if (!vigilante.isAlive()) {
                continue;
            }
            for (ServerPlayer jugador : complejo.players()) {
                if (puedeRecibir(jugador) && jugador.distanceToSqr(vigilante) <= ALCANCE * ALCANCE) {
                    darAJugador(jugador, false);
                    vigilante.swing(InteractionHand.MAIN_HAND);
                }
            }
            for (JugadorBot bot : complejo.getEntitiesOfClass(JugadorBot.class, vigilante.getBoundingBox().inflate(ALCANCE),
                    bot -> bot.isAlive() && !RECIBIERON.contains(bot.getUUID()))) {
                RECIBIERON.add(bot.getUUID());
                darABot(bot);
                vigilante.swing(InteractionHand.MAIN_HAND);
            }
        }
    }

    private static boolean puedeRecibir(ServerPlayer jugador) {
        return jugador.isAlive() && !jugador.isSpectator() && !RECIBIERON.contains(jugador.getUUID());
    }

    private static void darAJugador(ServerPlayer jugador, boolean selaTrajeron) {
        RECIBIERON.add(jugador.getUUID());
        for (ItemStack cosa : comida()) {
            if (!jugador.getInventory().add(cosa)) {
                jugador.drop(cosa, false);
            }
        }
        jugador.playNotifySound(SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.8F, 1.0F);
        jugador.displayClientMessage(Component.translatable(selaTrajeron ? "comida.juegosdelpatio.te_la_trajeron"
                : "comida.juegosdelpatio.te_dieron", que()).withStyle(ChatFormatting.GREEN), true);
    }

    /** Cuántos jugadores y bots del complejo todavía no tienen su comida. */
    private static int faltan(ServerLevel complejo) {
        int faltan = 0;
        for (ServerPlayer jugador : complejo.players()) {
            if (puedeRecibir(jugador)) {
                faltan++;
            }
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive())) {
            if (!RECIBIERON.contains(bot.getUUID())) {
                faltan++;
            }
        }
        return faltan;
    }

    /** Ya tienen todos (a los que no vinieron se la llevan): los vigilantes se van y en un minuto se apagan las luces. */
    private static void terminar(ServerLevel complejo) {
        for (ServerPlayer jugador : complejo.players()) {
            if (puedeRecibir(jugador)) {
                darAJugador(jugador, true);
            }
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive())) {
            if (RECIBIERON.add(bot.getUUID())) {
                darABot(bot);
            }
        }
        for (Guardia vigilante : VIGILANTES) {
            vigilante.discard();
        }
        VIGILANTES.clear();
        if (barra != null) {
            barra.removeAllPlayers();
            barra = null;
        }
        activa = false;
        if (menu == 3 && Masacre.empezar(complejo)) {
            return;                                                  // la noche del pastel: dos se empiezan a pelear
        }
        decir(complejo, Component.translatable("comida.juegosdelpatio.a_dormir"));
        Noche.ceremoniaTerminada(complejo.getServer());              // en 1 minuto se apagan las luces
    }

    private static void actualizarBarra(ServerLevel complejo) {
        if (barra == null) {
            return;
        }
        int faltan = faltan(complejo);
        int total = RECIBIERON.size() + faltan;
        barra.setName(Component.translatable("comida.juegosdelpatio.barra", RECIBIERON.size(), total));
        barra.setProgress(total == 0 ? 1.0F : RECIBIERON.size() / (float) total);
        for (ServerPlayer jugador : List.copyOf(barra.getPlayers())) {
            if (jugador.level() != complejo) {
                barra.removePlayer(jugador);                         // salió del complejo
            }
        }
        for (ServerPlayer jugador : complejo.players()) {
            barra.addPlayer(jugador);
        }
    }

    private static void decir(ServerLevel complejo, Component texto) {
        MutableComponent mensaje = Component.literal("<").append(Rango.VIGILANTE.nombre())
                .append(Component.literal("> "))
                .append(Component.empty().append(texto).withStyle(ChatFormatting.WHITE));
        for (ServerPlayer jugador : complejo.players()) {
            jugador.sendSystemMessage(mensaje);
        }
    }
}
