package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

/**
 * Un "jugador" controlado por el juego (hasta 150 en el complejo): pasea por el complejo, saluda, charla con otros
 * usando emoticones, se agacha y salta como un jugador, y a veces se acuesta en una litera.
 */
public class JugadorBot extends PathfinderMob {
    public static final int CANTIDAD_SKINS = 48;
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(JugadorBot.class, EntityDataSerializers.INT);
    /** En El puente de Londres: va enganchado en la fila (se dibuja con las manos en los hombros del de adelante). */
    private static final EntityDataAccessor<Boolean> ENGANCHADO =
            SynchedEntityData.defineId(JugadorBot.class, EntityDataSerializers.BOOLEAN);

    private String nombre = "Jugador";
    private int generacion;
    @Nullable
    private Emote emote;
    private int tiempoEmote;
    int tiempoAgacharse;
    int esperaSaludo;
    /** Lo marca el comportamiento de dormir; si el bot aparece dormido sin él (al recargar el mundo), se levanta. */
    boolean enCama;
    /** Saltitos en el lugar que le quedan por dar. */
    int saltitos;
    private boolean corriendo;
    /** El último jugador que le pegó (si este bot muere, los demás le guardan rencor) y cuánto se acuerda. */
    @Nullable
    private UUID agresor;
    private int memoriaAgresor;
    /** Mientras está enojado, persigue y le pega a quien le pegó. */
    private int enojo;
    /** Ticks que le faltan para terminar de comer (tiene la comida en la mano), y lo que le queda para después. */
    private int comiendo;
    private final List<ItemStack> porComer = new ArrayList<>();

    public JugadorBot(EntityType<? extends JugadorBot> tipo, Level nivel) {
        super(tipo, nivel);
        if (this.getNavigation() instanceof GroundPathNavigation navegacion) {
            navegacion.setCanOpenDoors(true);
        }
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.ATTACK_DAMAGE, 2.0)
                .add(Attributes.ATTACK_KNOCKBACK, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        super.defineSynchedData(datos);
        datos.define(SKIN, 0);
        datos.define(ENGANCHADO, false);
    }

    /** En El puente de Londres: va enganchado en la fila (con las manos en los hombros del de adelante). */
    void enganchar(boolean si) {
        if (si != entityData.get(ENGANCHADO)) {
            entityData.set(ENGANCHADO, si);
        }
    }

    public boolean enganchado() {
        return entityData.get(ENGANCHADO);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new EscucharGoal(this));
        this.goalSelector.addGoal(0, new DormirDeNocheGoal(this));
        this.goalSelector.addGoal(0, new IrAlJuegoGoal(this));
        this.goalSelector.addGoal(0, new JugarGoal(this));
        this.goalSelector.addGoal(0, new MetaGoal(this));
        this.goalSelector.addGoal(0, new BloquearMetaGoal(this));
        this.goalSelector.addGoal(0, new CabezaQuietaGoal(this));
        this.goalSelector.addGoal(0, new IrAComerGoal(this));
        this.goalSelector.addGoal(0, new SillasGoal(this));
        this.goalSelector.addGoal(0, new EscondidasGoal(this));
        this.goalSelector.addGoal(0, new PuenteGoal(this));
        this.goalSelector.addGoal(0, new CasillerosGoal(this));
        this.goalSelector.addGoal(0, new TejoGoal(this));
        this.goalSelector.addGoal(0, new EstandartesGoal(this));
        this.goalSelector.addGoal(1, new PelearGoal(this));     // si le pegan, devuelve el golpe
        this.goalSelector.addGoal(1, new DormirEnLiteraGoal(this));
        this.goalSelector.addGoal(2, new SaludarJugadorGoal(this));
        this.goalSelector.addGoal(3, new CharlarGoal(this));
        this.goalSelector.addGoal(4, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(5, new IrALugarGoal(this));
        this.goalSelector.addGoal(5, new CorrerGoal(this));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, JugadorBot.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    // ------------------------------------------------------------------ datos
    public int getSkin() {
        return this.entityData.get(SKIN);
    }

    public void setSkin(int skin) {
        this.entityData.set(SKIN, Math.floorMod(skin, CANTIDAD_SKINS));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag datos) {
        super.addAdditionalSaveData(datos);
        datos.putInt("Skin", getSkin());
        datos.putString("Nombre", nombre);
        datos.putInt("Generacion", generacion);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag datos) {
        super.readAdditionalSaveData(datos);
        setSkin(datos.getInt("Skin"));
        if (datos.contains("Nombre")) {
            nombre = datos.getString("Nombre");
        }
        generacion = datos.getInt("Generacion");
        emote = null;
        actualizarNombre();
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor nivel, DifficultyInstance dificultad,
                                        MobSpawnType tipo, @Nullable SpawnGroupData datos) {
        setSkin(this.random.nextInt(CANTIDAD_SKINS));
        nombre = Nombres.alAzar(this.random);
        generacion = EstadoComplejo.de(nivel.getLevel().getServer()).generacion();
        setCustomNameVisible(true);
        actualizarNombre();
        return super.finalizeSpawn(nivel, dificultad, tipo, datos);
    }

    @Override
    public boolean removeWhenFarAway(double distancia) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (fuente.is(DamageTypes.CRAMMING)) {
            return false;                               // con tantos bots, que no se lastimen al amontonarse
        }
        if (!level().isClientSide() && fuente.getEntity() instanceof Player jugador && !Juego.sinPeleas(this)) {
            agresor = jugador.getUUID();                // antes del golpe: si este lo mata, también cuenta
            memoriaAgresor = 6000;                      // se acuerda 5 minutos de quién le pegó
        }
        boolean herido = super.hurt(fuente, cantidad);
        if (herido && !level().isClientSide() && isAlive() && fuente.getEntity() instanceof Player jugador
                && !jugador.isCreative() && !jugador.isSpectator() && !Juego.sinPeleas(this)) {
            if (getTarget() != jugador) {
                mostrarEmote(Emote.ENOJO);
            }
            setTarget(jugador);                         // al que le pegó, le devuelve el golpe
            enojo = 400;
        }
        return herido;
    }

    /**
     * En las torres (Asientos al vacío, El tejo y Los estandartes) no se choca con nadie: en una torre llena se
     * tirarían abajo.
     */
    @Override
    public boolean isPushable() {
        return super.isPushable() && !Sillas.sinChoques(this) && !Tejo.sinChoques(this) && !Estandartes.sinChoques(this);
    }

    @Override
    protected void doPush(net.minecraft.world.entity.Entity otro) {
        if (!Sillas.sinChoques(this) && !Tejo.sinChoques(this) && !Estandartes.sinChoques(this)) {
            super.doPush(otro);
        }
    }

    @Override
    public void die(DamageSource fuente) {
        super.die(fuente);
        // en las escondidas y en los estandartes, que lo maten es el juego: nadie le guarda rencor por eso (pero al
        // que lo tiró de una torre con un empujón, sí)
        if (!level().isClientSide() && agresor != null && memoriaAgresor > 0
                && !((Juego.numero() == Juego.ESCONDIDAS || Juego.numero() == Juego.ESTANDARTES) && Juego.enArena())) {
            Juego.botMurio(this, agresor);              // los demás no se olvidan de quién le pegó
        }
    }

    /** Lo empujó un jugador (clic derecho): se enoja como si le hubiera pegado, y si muere, los demás le guardan rencor. */
    public void empujadoPor(Player jugador) {
        agresor = jugador.getUUID();
        memoriaAgresor = 6000;
        if (isAlive() && !jugador.isCreative() && !jugador.isSpectator()) {
            if (getTarget() != jugador) {
                mostrarEmote(Emote.ENOJO);
            }
            setTarget(jugador);
            enojo = 400;
        }
    }

    /**
     * Le dieron comida: la agarra y se la come (unos 2 segundos, con ruido y migas), y se cura un poco. Si ya
     * estaba comiendo algo, esto se lo come después.
     */
    public void comer(ItemStack comida) {
        if (comiendo > 0) {
            porComer.add(comida);
            return;
        }
        setItemSlot(EquipmentSlot.MAINHAND, comida);
        setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        comiendo = 40;
    }

    private void seguirComiendo() {
        comiendo--;
        ItemStack enMano = getMainHandItem();
        if (comiendo % 4 == 0 && !enMano.isEmpty() && level() instanceof ServerLevel nivel) {
            Vec3 boca = getEyePosition().add(getLookAngle().scale(0.35)).add(0.0, -0.2, 0.0);
            nivel.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, enMano), boca.x, boca.y, boca.z, 3,
                    0.05, 0.05, 0.05, 0.03);
            playSound(SoundEvents.GENERIC_EAT, 0.6F, 0.9F + this.random.nextFloat() * 0.2F);
        }
        if (comiendo == 0) {
            setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            heal(4.0F);
            if (!porComer.isEmpty()) {
                comer(porComer.remove(0));                           // ahora lo otro que le dieron
            } else {
                playSound(SoundEvents.PLAYER_BURP, 0.5F, 0.9F + this.random.nextFloat() * 0.2F);
            }
        }
    }

    /** Está persiguiendo a alguien que le pegó. */
    public boolean enojado() {
        LivingEntity objetivo = getTarget();
        return objetivo != null && objetivo.isAlive();
    }

    public String nombre() {
        return nombre;
    }

    // ------------------------------------------------------------------ correr y saltar
    void empezarACorrer() {
        corriendo = true;
        setSprinting(true);
    }

    void dejarDeCorrer() {
        if (corriendo) {
            corriendo = false;
            setSprinting(false);
        }
    }

    // ------------------------------------------------------------------ emoticones
    public void mostrarEmote(Emote nuevo) {
        this.emote = nuevo;
        this.tiempoEmote = 60;
        actualizarNombre();
        if (this.level() instanceof ServerLevel servidor) {
            SimpleParticleType particula = nuevo.particula();
            if (particula != null) {
                servidor.sendParticles(particula, getX(), getY() + 2.3, getZ(), 3, 0.3, 0.2, 0.3, 0.02);
            }
        }
        if (nuevo.saludo) {
            this.swing(InteractionHand.MAIN_HAND);
            this.tiempoAgacharse = 24;
        }
    }

    private void actualizarNombre() {
        MutableComponent texto = Component.literal(nombre);
        if (emote != null) {
            texto.append(Component.literal("  " + emote.texto).withStyle(emote.color));
        }
        setCustomName(texto);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (comiendo > 0) {
            seguirComiendo();
        }
        if (memoriaAgresor > 0 && --memoriaAgresor == 0) {
            agresor = null;
        }
        LivingEntity objetivo = getTarget();
        if (objetivo != null && (--enojo <= 0 || !objetivo.isAlive() || objetivo.level() != level()
                || distanceToSqr(objetivo) > 40.0 * 40.0
                || objetivo instanceof Player jugador && (jugador.isCreative() || jugador.isSpectator()))) {
            setTarget(null);                            // se le pasó el enojo (o el otro se fue)
            enojo = 0;
        }
        if (tiempoEmote > 0 && --tiempoEmote == 0) {
            emote = null;
            actualizarNombre();
        }
        if (esperaSaludo > 0) {
            esperaSaludo--;
        }
        if (isSleeping() && !enCama) {
            stopSleeping();
        }
        if (!isSleeping()) {
            if (tiempoAgacharse > 0) {
                tiempoAgacharse--;
                setPose(tiempoAgacharse > 0 && (tiempoAgacharse / 3) % 2 == 0 ? Pose.CROUCHING : Pose.STANDING);
            }
            boolean moviendose = getNavigation().isInProgress();
            if (Juego.enArena() && Juego.estaEnArena(this) && !Juego.luzVerde()) {
                saltitos = 0;                            // con luz roja (o esperando) ni se le ocurre saltar
            } else if (Juego.caminando() && !Juego.estaEnArena(this)) {
                saltitos = 0;                            // subiendo a la torre, con todos apretados, tampoco
            } else {
                if (corriendo) {
                    if (!moviendose) {
                        dejarDeCorrer();
                    } else if (onGround() && this.random.nextInt(14) == 0) {
                        getJumpControl().jump();         // salta mientras corre, como un jugador
                    }
                } else if (onGround() && moviendose && this.random.nextInt(140) == 0) {
                    getJumpControl().jump();
                }
                if (!moviendose && onGround()) {
                    if (saltitos > 0) {
                        saltitos--;
                        getJumpControl().jump();         // saltitos en el lugar
                    } else if (this.random.nextInt(1200) == 0) {
                        saltitos = 2 + this.random.nextInt(3);
                    }
                }
            }
        }
        // Si se pidió una tanda nueva de bots, los viejos se van solos
        if (this.tickCount % 40 == 0 && this.level() instanceof ServerLevel servidor
                && servidor.dimension().equals(Complejo.DIMENSION)
                && generacion != EstadoComplejo.de(servidor.getServer()).generacion()) {
            discard();
        }
    }

    // ================================================================== comportamientos

    /**
     * Día de juego, en el minuto para ir: sigue al comandante por el portón, el pasillo y la escalera de la torre
     * hasta la puerta del juego de hoy, y entra al portal (que lo lleva a la arena). No salen todos juntos: cada uno
     * espera un rato distinto, y mientras suben no saltan. Si alguno se cae al hueco de la torre (en la sala, el
     * pasillo y la torre las caídas no lastiman), vuelve a subir desde el pie de la escalera. Los que no llegan pasan
     * solos cuando se termina el minuto.
     */
    static class IrAlJuegoGoal extends Goal {
        /** Frente al portón y el pasillo; después sigue el camino del comandante por la torre (Juego.caminoDeLaTorre). */
        static final Vec3[] HASTA_LA_TORRE = {new Vec3(0.5, 65.0, 1.5), new Vec3(0.5, 65.0, -20.5)};
        /** A qué altura se pisa el piso del pasillo y de la torre. */
        private static final double PISO_TORRE = 65.0;
        private final JugadorBot bot;
        private Vec3[] recorrido = HASTA_LA_TORRE;
        private int paso;
        private int espera;
        private double desvio;
        private double velocidad;

        IrAlJuegoGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Juego.caminando() && bot.level().dimension().equals(Complejo.DIMENSION) && !Juego.estaEnArena(bot)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            Vec3[] torre = Juego.caminoDeLaTorre(Juego.numero());
            recorrido = new Vec3[HASTA_LA_TORRE.length + torre.length];
            System.arraycopy(HASTA_LA_TORRE, 0, recorrido, 0, HASTA_LA_TORRE.length);
            System.arraycopy(torre, 0, recorrido, HASTA_LA_TORRE.length, torre.length);
            paso = dondeEsta();
            espera = 10 + bot.getRandom().nextInt(180);           // van detrás del comandante, cada uno a su tiempo
            desvio = bot.getRandom().nextDouble() * 6.0 - 3.0;     // que no vayan todos por el mismo lugar
            velocidad = 0.95 + bot.getRandom().nextDouble() * 0.15;
            if (bot.isSleeping()) {
                bot.stopSleeping();                                   // llamaron al juego: se levanta
            }
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
        }

        /**
         * Por dónde sigue según dónde está: en la sala, desde el portón; en la primera mitad del pasillo, desde el
         * medio del pasillo; más allá o en el piso de la torre, desde el pie de la escalera; y en la escalera, desde el
         * próximo descanso (el que está a su altura o más arriba).
         */
        private int dondeEsta() {
            int pie = HASTA_LA_TORRE.length;                          // el pie de la escalera
            if (bot.getZ() > Complejo.PORTON_Z + 0.5) {
                return 0;
            }
            if (bot.getZ() > HASTA_LA_TORRE[1].z) {
                return 1;
            }
            if (bot.getY() < PISO_TORRE + 2.0) {
                return pie;
            }
            for (int i = pie + 1; i < recorrido.length; i++) {
                if (recorrido[i].y >= bot.getY() - 4.0) {
                    return i;
                }
            }
            return recorrido.length;                                  // ya está arriba: derecho al portal
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
                return;
            }
            if (paso > HASTA_LA_TORRE.length && paso <= recorrido.length && bot.onGround()
                    && bot.getY() < recorrido[paso - 1].y - 3.0) {
                paso = dondeEsta();                                   // se cayó al hueco de la torre: a subir de nuevo
                bot.getNavigation().stop();
            }
            if (paso < recorrido.length) {
                Vec3 punto = paso < HASTA_LA_TORRE.length ? recorrido[paso].add(desvio, 0.0, 0.0) : recorrido[paso];
                double cerca = paso == 0 ? 9.0 : paso > HASTA_LA_TORRE.length ? 2.25 : 4.0;
                if (bot.distanceToSqr(punto) < cerca) {
                    paso++;                                           // sigue con el próximo tramo
                    bot.getNavigation().stop();
                } else if (bot.getNavigation().isDone() || bot.tickCount % 30 == 0) {
                    bot.getNavigation().moveTo(punto.x, punto.y, punto.z, velocidad);
                }
            } else if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                Path camino = bot.getNavigation().createPath(Juego.portal(Juego.numero()), 0);
                bot.getNavigation().moveTo(camino, velocidad);        // hasta adentro del portal
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /**
     * En la arena: con luz verde avanza hacia la meta (o, si es de los que empujan, se le pega a su víctima) y con
     * luz roja se queda quieto (salvo si se distrae). Mientras espera que empiece el juego, se queda en el lugar.
     */
    static class JugarGoal extends Goal {
        private final JugadorBot bot;
        private double velocidad = 1.0;
        private boolean corre;

        JugarGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 1 && (Juego.enArena() || Juego.caminando()) && Juego.estaEnArena(bot)
                    && !Juego.llego(bot) && !bot.enojado();
        }

        @Override
        public void start() {
            // como los jugadores: de ~2,5 m/s (los lentos, que quizás no lleguen) a ~5,6 m/s (los que corren).
            // Corriendo, la velocidad sube un 30 %, así que se compensa para que no vuelen.
            double ritmo = 0.8 + bot.getRandom().nextDouble() * 0.4;
            corre = ritmo > 1.1;
            velocidad = corre ? ritmo / 1.3 : ritmo;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            boolean avanzar = Juego.jugando() && (Juego.luzVerde() || Juego.distraido(bot));
            if (!avanzar) {
                bot.getNavigation().stop();                           // quieto
                bot.dejarDeCorrer();
                return;
            }
            LivingEntity victima = Juego.victimaDe(bot);
            if (victima != null && !Juego.distraido(bot)) {
                // de los que empujan: se acerca a su víctima y se queda a un paso, esperando la luz roja.
                // Si la víctima corre, corre también (si no, se le escapa y en la luz roja queda lejos).
                boolean persigue = victima.isSprinting() && bot.distanceToSqr(victima) > 1.5 * 1.5;
                if (persigue) {
                    bot.empezarACorrer();
                } else {
                    bot.dejarDeCorrer();
                }
                if (bot.tickCount % (persigue ? 5 : 10) == 0 || bot.getNavigation().isDone()) {
                    Vec3 donde = victima.position();
                    if (persigue) {
                        // adonde va a estar en un rato, con lo que se movió en el último tick (a los jugadores el
                        // servidor no les lleva la velocidad, así que se mira cuánto cambió la posición)
                        double dx = victima.getX() - victima.xo;
                        double dz = victima.getZ() - victima.zo;
                        if (dx * dx + dz * dz < 1.0) {
                            donde = donde.add(dx * 6.0, 0.0, dz * 6.0);
                        }
                    }
                    Vec3 desde = bot.position().subtract(donde);
                    Vec3 lugar = desde.lengthSqr() > 1.0E-4 ? donde.add(desde.normalize().scale(1.2)) : donde;
                    // corriendo: un poco más rápido que alguien que corre (~6 m/s), para alcanzarlo; caminando,
                    // al menos un poco más rápido que alguien que camina (~4,6 m/s contra 4,3)
                    bot.getNavigation().moveTo(lugar.x, 100.0, lugar.z, persigue ? 0.95 : Math.max(velocidad + 0.1, 1.08));
                }
                return;
            }
            if (bot.tickCount % 20 == 0 || bot.getNavigation().isDone()) {
                double z = Math.min(bot.getZ() + 18.0, Juego.META_Z + 8.0);
                double x = Math.max(951.5, Math.min(1047.5, bot.getX() + (bot.getRandom().nextDouble() - 0.5) * 3.0));
                bot.getNavigation().moveTo(x, 100.0, z, velocidad);
                if (corre) {
                    bot.empezarACorrer();
                }
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            bot.dejarDeCorrer();
        }
    }

    /**
     * Devuelve los golpes a quien le pegó (en el juego, como ahí no se pega, devuelve empujones). Con la luz roja no
     * camina (moverse lo eliminaría): solo empuja si lo tiene al lado.
     */
    static class PelearGoal extends MeleeAttackGoal {
        private final JugadorBot bot;

        PelearGoal(JugadorBot bot) {
            super(bot, 1.2, true);
            this.bot = bot;
        }

        @Override
        public void start() {
            super.start();
            if (Juego.debeQuedarseQuieto(bot)) {
                bot.getNavigation().stop();
            }
        }

        @Override
        public void tick() {
            super.tick();
            if (Juego.debeQuedarseQuieto(bot)) {
                bot.getNavigation().stop();                           // quieto: no lo persigue
            }
        }
    }

    /**
     * Con la luz roja, a la vista del Vigía, tampoco mueve la cabeza (ocupa la mirada para que nadie más la mueva:
     * la cabeza vuelve a quedar derecha y ahí se queda).
     */
    static class CabezaQuietaGoal extends Goal {
        private final JugadorBot bot;

        CabezaQuietaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.debeQuedarseQuieto(bot) && !bot.enojado() && !Juego.esBloqueador(bot)
                    && !Juego.distraido(bot);
        }
    }

    /**
     * Asientos al vacío: con la música anda por las torres (a veces salta a otra); cuando para, se da cuenta enseguida,
     * elige la silla libre que le queda más cerca (si otro bot más cerca va por la misma, se la deja), va saltando de
     * torre en torre hasta esa y se sienta. Sentado, festeja.
     */
    static class SillasGoal extends Goal {
        private static final Emote[] FESTEJOS = {Emote.FELIZ, Emote.GG, Emote.RISA, Emote.PAZ, Emote.XD};
        private final JugadorBot bot;
        private final SaltosBot saltos;
        @Nullable
        private BlockPos silla;
        private int buscar;
        private int destino = -1;
        @Nullable
        private Vec3 paseo;
        private int cambiar;
        private int espera;

        SillasGoal(JugadorBot bot) {
            this.bot = bot;
            this.saltos = new SaltosBot(bot);
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == Juego.SILLAS && Juego.enArena() && Sillas.participa(bot);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;                                             // los saltos se controlan tick a tick
        }

        @Override
        public void start() {
            silla = null;
            destino = -1;
            paseo = null;
            cambiar = 20 + bot.getRandom().nextInt(60);
            saltos.olvidar();
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (saltos.volando()) {
                return;
            }
            if (bot.isPassenger()) {
                festejar();                                          // sentado
                return;
            }
            if (Sillas.hayQueSentarse() && Sillas.reacciono(bot)) {
                aLaSilla();
                return;
            }
            silla = null;
            if (!Sillas.suenaMusica()) {
                bot.getNavigation().stop();                          // se cae el piso: nada que hacer
                return;
            }
            pasear();
        }

        /** Con la música: anda por su torre y, cada tanto, salta a una de al lado. */
        private void pasear() {
            if (destino >= 0) {
                if (saltos.ir(Sillas.CAMPO, destino, 0.9, (a, b) -> Sillas.riesgo(bot))) {
                    destino = -1;
                    paseo = null;
                }
                return;
            }
            if (--cambiar > 0 && paseo != null) {
                return;
            }
            cambiar = 60 + bot.getRandom().nextInt(140);
            int aca = Sillas.CAMPO.torreDe(bot);
            if (aca >= 0 && bot.getRandom().nextInt(100) < 35) {
                int[] vecinos = Sillas.CAMPO.vecinos[aca];
                destino = vecinos[bot.getRandom().nextInt(vecinos.length)];
                return;
            }
            if (aca >= 0) {
                paseo = Sillas.CAMPO.lugarEn(aca, bot.getRandom(), 1);
                bot.getNavigation().moveTo(paseo.x, paseo.y, paseo.z, 0.7 + bot.getRandom().nextDouble() * 0.2);
            }
        }

        /** Paró la música: a la silla libre más cerca, saltando de torre en torre, y a sentarse. */
        private void aLaSilla() {
            destino = -1;
            if (silla == null || --buscar <= 0 || !(bot.level().getBlockState(silla).getBlock() instanceof SillaBlock)) {
                silla = Sillas.sillaPara(bot);
                buscar = 20;
                saltos.olvidar();
            }
            if (silla == null) {
                bot.getNavigation().stop();
                return;
            }
            int torre = Sillas.torreDe(silla);
            if (torre < 0 || !saltos.ir(Sillas.CAMPO, torre, 1.15, (a, b) -> Sillas.riesgo(bot))) {
                return;
            }
            double dx = silla.getX() + 0.5 - bot.getX();
            double dz = silla.getZ() + 0.5 - bot.getZ();
            if (dx * dx + dz * dz <= Sillas.ALCANCE_BOT * Sillas.ALCANCE_BOT) {
                bot.getNavigation().stop();
                if (!Sillas.sentarBot(bot, silla)) {
                    silla = null;                                    // se la ganaron: a buscar otra
                }
                return;
            }
            if (bot.getNavigation().isDone() || bot.tickCount % 10 == 0) {
                bot.getNavigation().moveTo(silla.getX() + 0.5, silla.getY(), silla.getZ() + 0.5, 1.15);
            }
        }

        private void festejar() {
            if (espera > 0) {
                espera--;
                return;
            }
            espera = 40 + bot.getRandom().nextInt(80);
            if (bot.getRandom().nextInt(3) == 0) {
                bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
            }
        }

        @Override
        public void stop() {
            silla = null;
            saltos.olvidar();
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
        }
    }

    /**
     * Las escondidas. El bot que se esconde: en el minuto para esconderse corre a un escondite libre y se agacha ahí.
     * Cuando salen los buscadores, algunos (uno de cada tres, más o menos) se animan a buscar la salida: van de salida
     * en salida hasta encontrar la abierta. Si un buscador lo vio, está cerca o le pega, sale disparado (muy rápido,
     * unos segundos; después queda cansado) a otro escondite lejos y para el otro lado (o a la salida, si ya sabe cuál
     * es). El bot que busca: espera en la sala de profesores; después recorre la escuela (salas, pasillos y
     * escondites) mirando para los costados y, cuando se para, para todos lados. Ve desde muy lejos (menos a oscuras
     * y a los agachados); si ve a alguien escondido avisa a los otros buscadores, lo persigue y le pega con la espada;
     * si se le pierde, va adonde lo vio (u oyó correr) por última vez y revisa los escondites de alrededor.
     */
    /**
     * Juego 4, El puente de Londres: con la canción camina en la fila por la calle, alrededor, pasando por debajo del
     * puente (sin pasar al de adelante: si lo tiene cerca va más despacio, y si lo tiene encima, frena). Cuando cae el
     * puente, la fila se para y mira al encerrado; si el encerrado es él, mira a un robot y al otro (no sabe cuál
     * elegir: elige al azar, ver Puente). Mientras explican las reglas, quieto.
     */
    /**
     * El puente de Londres: va enganchado en la fila (con las manos en los hombros del de adelante) y la fila lo lleva:
     * siempre en su lugar, al paso de la fila. Cuando se cae el puente, se queda quieto mirando; si quedó atrapado,
     * mira a los robots.
     */
    static class PuenteGoal extends Goal {
        private final JugadorBot bot;

        PuenteGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == Juego.PUENTE && (Juego.enArena() || Juego.caminando()) && Juego.estaEnArena(bot);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;                                             // la fila avanza parejo (sin tirones)
        }

        @Override
        public void start() {
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (!bot.getNavigation().isDone()) {
                bot.getNavigation().stop();                          // en la fila no hay caminos: la fila lo lleva
            }
            bot.dejarDeCorrer();
            bot.enganchar(Puente.participa(bot) && !Puente.encerrado(bot));
            if (!Puente.participa(bot)) {
                return;
            }
            if (Puente.encerrado(bot)) {
                Vec3 robot = (bot.tickCount / 25) % 2 == 0 ? Puente.ROBOT_ADENTRO : Puente.ROBOT_AFUERA;
                bot.getLookControl().setLookAt(robot.x, robot.y + 7.5, robot.z);   // atrapado: no hay salida
                return;
            }
            if (Puente.filaQuieta()) {
                Vec3 mira = Puente.aDondeMirar();
                bot.getLookControl().setLookAt(mira.x, mira.y, mira.z);   // se cayó el puente: todos quietos, mirando
                return;
            }
            Puente.llevar(bot);
        }

        @Override
        public void stop() {
            bot.enganchar(false);
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
        }
    }

    static class EscondidasGoal extends Goal {
        /**
         * Correr detrás de alguien: casi como un jugador corriendo (5,3 contra 5,6 bloques por segundo); al que corre
         * bien se le escapa... pero avisa a los otros, y lo busca donde se le perdió.
         */
        private static final double PERSIGUE = 0.9;
        private static final double CAMINA = 1.0;
        /** El escondido al que descubren sale disparado: unos 9 bloques y medio por segundo, de 2 y medio a 3 y medio segundos... */
        private static final double DISPARADO = 1.2;
        private static final int RAFAGA = 50;
        /** ...y después queda cansado de 7 a 9 segundos: si tiene que escaparse otra vez, corre más lento (4,2 por segundo). */
        private static final double CANSADO = 0.8;
        private static final int DESCANSO = 140;
        /** Al que persigue lo sigue oyendo correr un ratito aunque no lo vea (si no va agachado); después lo da por perdido. */
        private static final int OYE_PASOS = 30;
        private static final int SE_LE_PIERDE = 50;
        private static final Emote[] FESTEJOS = {Emote.FELIZ, Emote.GG, Emote.PAZ};
        private final JugadorBot bot;
        @Nullable
        private BlockPos destino;
        @Nullable
        private LivingEntity presa;
        @Nullable
        private Vec3 ultimoVisto;
        /** Dónde está revisando (donde se le perdió alguien, o donde avisó otro) y cuántos escondites le quedan ahí. */
        @Nullable
        private Vec3 zona;
        @Nullable
        private Vec3 ultimaPista;
        private int rastreo;
        /** Va corriendo (adonde avisaron, o adonde se le perdió alguien). */
        private boolean apurado;
        @Nullable
        private Vec3 mirarA;
        private int mirando;
        private int otraMirada;
        private int perdido;
        /** El que busca: un ratito mirando para todos lados. El que se esconde: cuánto falta para animarse a salir. */
        private int espera;
        private int esperaSalida;
        private int ataque;
        private int huye;
        private int disparado;
        private int cansado;
        private int sinAvanzar;
        private double distanciaAntes;
        private int salidaBuscada = -1;
        private int salidasVistas;
        private boolean vaALaSalida;
        private boolean conoceSalida;
        private boolean escondido;
        private boolean festejo;
        /** El buscador de espaldas al que se le está acercando por atrás para quitarle la espada (o null). */
        @Nullable
        private LivingEntity acecho;

        EscondidasGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == Juego.ESCONDIDAS && Juego.enArena() && Escondidas.estaEnLaEscuela(bot)
                    && (!Escondidas.enCurso() || Escondidas.esBuscador(bot) || Escondidas.esEscondido(bot)
                    || Escondidas.salio(bot));
        }

        @Override
        public void start() {
            destino = null;
            presa = null;
            ultimoVisto = null;
            zona = null;
            ultimaPista = null;
            rastreo = 0;
            apurado = false;
            mirarA = null;
            mirando = 0;
            otraMirada = 0;
            perdido = 0;
            ataque = 0;
            huye = 0;
            disparado = 0;
            cansado = 0;
            sinAvanzar = 0;
            distanciaAntes = Double.MAX_VALUE;
            salidaBuscada = -1;
            salidasVistas = 0;
            escondido = false;
            festejo = false;
            acecho = null;
            conoceSalida = false;
            espera = 0;
            vaALaSalida = Math.floorMod(bot.getId() * 37 + 11, 100) < 35;  // los que se animan a buscar la salida
            esperaSalida = bot.getRandom().nextInt(70 * 20);                 // y cuándo se animan
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (!Escondidas.enCurso()) {
                bot.getNavigation().stop();                          // escuchando las reglas, en el hall
                bot.dejarDeCorrer();
                return;
            }
            if (Escondidas.cambiando()) {
                cambiando();                                         // el minuto para cambiarse de equipo
                return;
            }
            if (Escondidas.salio(bot)) {
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                if (!festejo) {
                    festejo = true;
                    bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
                }
            } else if (Escondidas.esBuscador(bot)) {
                buscar();
            } else if (Escondidas.esEscondido(bot)) {
                esconderse();
            }
        }

        /** En el hall, el minuto de los cambios: va hasta el jugador al que le pidió cambiarse, o lo espera mirándolo. */
        private void cambiando() {
            bot.dejarDeCorrer();
            LivingEntity con = Escondidas.cambioCon(bot);
            if (con == null) {
                bot.getNavigation().stop();
                return;
            }
            bot.getLookControl().setLookAt(con, 30.0F, 30.0F);
            if (bot.distanceToSqr(con) > 2.5 * 2.5) {
                if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                    bot.getNavigation().moveTo(con, CAMINA);
                }
            } else {
                bot.getNavigation().stop();
            }
        }

        // ------------------------------------------------------------------ el que busca
        private void buscar() {
            if (!Escondidas.buscando()) {
                bot.getNavigation().stop();                          // contando, con los ojos cerrados
                bot.dejarDeCorrer();
                return;
            }
            if (ataque > 0) {
                ataque--;
            }
            boolean armado = Escondidas.tieneEspada(bot);
            if (!armado) {
                presa = null;                                        // le quitaron la espada: sin espada no atrapa
            }
            if (bot.tickCount % 4 == 0) {
                LivingEntity visto = Escondidas.aQuienVe(bot);
                if (visto != null && !armado) {
                    if (ultimoVisto == null || ultimoVisto.distanceToSqr(visto.position()) > 6.0 * 6.0) {
                        bot.mostrarEmote(Emote.VISTO);
                        ultimoVisto = visto.position();
                        Escondidas.loVi(bot, visto);                 // igual avisa a los otros buscadores
                    }
                } else if (visto != null) {
                    if (presa != visto) {
                        bot.getNavigation().stop();
                        bot.mostrarEmote(Emote.VISTO);               // "¡!": lo vio
                    }
                    presa = visto;
                    perdido = 0;
                    ultimoVisto = visto.position();
                    Escondidas.loVi(bot, visto);                     // y avisa a los otros buscadores
                }
            }
            if (presa != null && (!presa.isAlive() || !Escondidas.esEscondido(presa))) {
                presa = null;                                        // lo encontró otro, o salió
                apurado = false;
            }
            if (presa != null) {
                perseguir(presa);
                return;
            }
            if (rastreo == 0 && bot.tickCount % 10 == 0) {
                Vec3 pista = Escondidas.pistaCerca(bot);              // ¿otro buscador vio a alguien por acá?
                if (pista != null && (ultimaPista == null || ultimaPista.distanceToSqr(pista) > 8.0 * 8.0)) {
                    ultimaPista = pista;
                    irA(pista, 2);
                }
            }
            if (apurado || Escondidas.desesperado(bot)) {
                bot.empezarACorrer();                                // (en el último minuto, sin haber atrapado a nadie)
            } else {
                bot.dejarDeCorrer();
            }
            if (espera > 0) {
                espera--;
                mirarAlrededor(true);
                return;
            }
            if (destino == null) {
                apurado = false;
                if (rastreo > 0 && zona != null) {
                    rastreo--;                                       // los escondites de alrededor, uno por uno
                    destino = Escondidas.esconditeCerca(bot, zona, 12.0, false);
                    apurado = destino != null;
                }
                if (destino == null) {
                    rastreo = 0;
                    zona = null;
                    destino = Escondidas.paraRevisar(bot);
                }
                distanciaAntes = Double.MAX_VALUE;
                sinAvanzar = 0;
                if (destino == null) {
                    return;
                }
                bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5, ritmo());
            }
            mirarAlrededor(false);
            double d2 = bot.distanceToSqr(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5);
            if (d2 < 2.0 * 2.0 || trabado(d2)) {
                Escondidas.revisado(bot, destino);
                destino = null;
                apurado = false;
                espera = rastreo > 0 ? 8 + bot.getRandom().nextInt(10) : 15 + bot.getRandom().nextInt(25);
                bot.getNavigation().stop();
            } else if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5, ritmo());
            }
        }

        /** Caminando, o corriendo si está apurado (o desesperado: último minuto y todavía no atrapó a nadie). */
        private double ritmo() {
            return apurado || Escondidas.desesperado(bot) ? PERSIGUE : CAMINA;
        }

        /** Va corriendo a un lugar (donde avisaron, o donde se le perdió alguien) y revisa los escondites de ahí. */
        private void irA(Vec3 donde, int revisar) {
            Escondidas.dejarDeRevisar(bot);
            destino = BlockPos.containing(donde);
            zona = donde;
            rastreo = revisar;
            apurado = true;
            espera = 0;
            distanciaAntes = Double.MAX_VALUE;
            sinAvanzar = 0;
            bot.getNavigation().moveTo(donde.x, donde.y, donde.z, PERSIGUE);
        }

        private void perseguir(LivingEntity objetivo) {
            if (Escondidas.seHaceElMuerto(objetivo) && !Escondidas.vioCaer(bot, objetivo)) {
                presa = null;                                        // parece un cuerpo más: lo da por perdido
                if (ultimoVisto != null) {
                    irA(ultimoVisto, 3);
                }
                return;
            }
            boolean loVe = Escondidas.hayVista(bot, objetivo);
            if (loVe) {
                perdido = 0;
                ultimoVisto = objetivo.position();
            } else {
                perdido++;
                if (perdido <= OYE_PASOS && !objetivo.isShiftKeyDown() && bot.distanceToSqr(objetivo) < 20.0 * 20.0) {
                    ultimoVisto = objetivo.position();               // no lo ve, pero lo oye correr
                }
                if (perdido > SE_LE_PIERDE) {
                    presa = null;                                    // se le perdió: adonde lo vio (u oyó) por última vez
                    if (ultimoVisto != null) {
                        irA(ultimoVisto, 3);                         // y revisa los escondites de por ahí
                    }
                    return;
                }
            }
            if (loVe) {
                bot.getLookControl().setLookAt(objetivo, 30.0F, 30.0F);
            } else if (ultimoVisto != null) {
                bot.getLookControl().setLookAt(ultimoVisto.x, ultimoVisto.y + 1.4, ultimoVisto.z);
            }
            bot.empezarACorrer();
            // pegarle, solo si no hay nada en el medio (ni un vidrio ni una reja)
            if (loVe && ataque <= 0 && bot.distanceToSqr(objetivo) < 2.5 * 2.5 && bot.hasLineOfSight(objetivo)) {
                bot.swing(InteractionHand.MAIN_HAND);
                bot.doHurtTarget(objetivo);                          // con la espada
                ataque = 12;
            }
            if (bot.tickCount % 5 == 0 || bot.getNavigation().isDone()) {
                Vec3 donde = ultimoVisto != null ? ultimoVisto : objetivo.position();
                bot.getNavigation().moveTo(donde.x, donde.y, donde.z, PERSIGUE);
            }
        }

        /**
         * Mientras camina, mira para los costados; cuando está quieto, para todos lados (también para atrás). Así ve
         * mucho más que lo que tiene adelante.
         */
        private void mirarAlrededor(boolean quieto) {
            if (mirando > 0 && mirarA != null) {
                mirando--;
                bot.getLookControl().setLookAt(mirarA.x, mirarA.y, mirarA.z);
                return;
            }
            if (--otraMirada > 0) {
                return;
            }
            RandomSource azar = bot.getRandom();
            otraMirada = quieto ? 2 + azar.nextInt(4) : 12 + azar.nextInt(16);
            double giro = quieto ? azar.nextDouble() * 360.0
                    : bot.getYRot() + (azar.nextBoolean() ? 1 : -1) * (40.0 + azar.nextInt(36));
            double rad = Math.toRadians(giro);
            mirarA = new Vec3(bot.getX() - Math.sin(rad) * 6.0, bot.getEyeY() - 0.3, bot.getZ() + Math.cos(rad) * 6.0);
            mirando = quieto ? 10 + azar.nextInt(8) : 8 + azar.nextInt(8);
        }

        // ------------------------------------------------------------------ el que se esconde
        private void esconderse() {
            if (cansado > 0 && disparado == 0) {
                cansado--;
            }
            if (Escondidas.seHaceElMuerto(bot)) {
                bot.getNavigation().stop();                          // tirado en el piso, quieto, como un cuerpo
                bot.dejarDeCorrer();
                return;
            }
            LivingEntity agarrado = Escondidas.agarradoPor(bot);
            if (agarrado != null) {
                forcejear(agarrado);                                 // tiene a un buscador agarrado por la espalda
                return;
            }
            LivingEntity peligro = Escondidas.susto(bot);                 // le pegaron: sale corriendo siempre
            if (peligro == null && huye == 0 && Escondidas.buscando() && acechar()) {
                return;                                              // se le acerca por atrás a un buscador
            }
            if (peligro == null && !escondido && Escondidas.buscando() && bot.tickCount % 10 == 0
                    && Math.floorMod(bot.getId() * 7 + 3, 100) < 60 && bot.getRandom().nextInt(100) < 35
                    && Escondidas.convieneHacerseElMuerto(bot)) {
                acecho = null;                                       // a la vista, y viene uno que todavía no lo vio:
                huye = 0;
                Escondidas.tirarse(bot);                             // se tira al piso y se hace el muerto
                return;
            }
            if (peligro == null && huye == 0 && Escondidas.buscando() && bot.tickCount % 4 == 0) {
                peligro = Escondidas.peligro(bot, escondido ? 5.0 : 9.0);   // lo vieron, o hay un buscador cerca
            }
            if (peligro != null) {
                acecho = null;
                huir(peligro);
            }
            if (huye > 0) {
                huye--;
                bot.empezarACorrer();
                boolean seCanso = disparado > 0 && --disparado == 0;
                if (seCanso) {
                    cansado = DESCANSO + bot.getRandom().nextInt(41);
                }
                if (destino != null && (seCanso || bot.getNavigation().isDone() || bot.tickCount % 10 == 0)) {
                    bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5,
                            disparado > 0 ? DISPARADO : CANSADO);
                }
                return;
            }
            if (Escondidas.buscando() && vaALaSalida) {
                if (esperaSalida > 0) {
                    esperaSalida--;
                } else {
                    irALaSalida();
                    return;
                }
            }
            if (escondido) {
                bot.getNavigation().stop();
                Escondidas.agacharse(bot);
                return;
            }
            if (destino == null) {
                destino = Escondidas.reservarEscondite(bot, null);
                distanciaAntes = Double.MAX_VALUE;
                sinAvanzar = 0;
                if (destino == null) {
                    escondido = true;                                // no queda ninguno libre: se agacha donde está
                    return;
                }
            }
            double x = destino.getX() + 0.5;
            double z = destino.getZ() + 0.5;
            double d2 = bot.distanceToSqr(x, destino.getY(), z);
            if (Escondidas.escondiendose()) {
                bot.empezarACorrer();                                // hay que llegar antes de que salgan
            } else {
                bot.dejarDeCorrer();
            }
            if (d2 < 0.5 * 0.5) {
                escondido = true;
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                Escondidas.agacharse(bot);
            } else if (d2 < 1.6 * 1.6) {
                if (!bot.getNavigation().isDone()) {
                    bot.getNavigation().stop();
                }
                bot.getMoveControl().setWantedPosition(x, destino.getY(), z, 0.8);   // el último paso, derecho
            } else if (trabado(d2)) {
                destino = null;                                      // no llega: busca otro
            } else if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                // hasta el escondite mismo (adentro del ropero, del cubículo...), no "más o menos cerca"
                Path camino = bot.getNavigation().createPath(destino, 0);
                if (camino == null || !bot.getNavigation().moveTo(camino, CAMINA)) {
                    bot.getNavigation().moveTo(x, destino.getY(), z, CAMINA);
                }
            }
        }

        /**
         * Los que se animan (uno de cada tres, más o menos): si un buscador con espada pasa cerca de espaldas y no lo
         * vio, se le acerca agachado por atrás y, bien cerca, lo agarra para quitarle la espada. true si está en eso.
         */
        private boolean acechar() {
            if (Math.floorMod(bot.getId() * 13 + 7, 100) >= 30) {
                return false;                                        // este no se anima
            }
            if (acecho == null && bot.tickCount % 10 == 0 && Escondidas.loVieron(bot) == null) {
                acecho = Escondidas.buscadorDeEspaldas(bot, 6.0);
            }
            if (acecho == null) {
                return false;
            }
            if (!acecho.isAlive() || !Escondidas.esBuscador(acecho) || !Escondidas.tieneEspada(acecho)
                    || Escondidas.loVieron(bot) != null || bot.distanceToSqr(acecho) > 8.0 * 8.0
                    || !Escondidas.leDaLaEspalda(acecho, bot) || Escondidas.ve(acecho, bot)) {
                acecho = null;                                       // se dio vuelta, o se fue: mejor no
                return false;
            }
            if (Escondidas.deEspaldas(bot, acecho)) {
                Escondidas.forcejear(bot, acecho);                   // ¡lo agarra!
                return true;
            }
            escondido = false;
            Escondidas.soltarEscondite(bot.getUUID());
            destino = null;
            Escondidas.agacharse(bot);                               // agachado, sin hacer ruido
            Vec3 mira = acecho.getViewVector(1.0F);
            Vec3 atras = new Vec3(acecho.getX() - mira.x * 0.9, acecho.getY(), acecho.getZ() - mira.z * 0.9);
            if (bot.getNavigation().isDone() || bot.tickCount % 5 == 0) {
                bot.getNavigation().moveTo(atras.x, atras.y, atras.z, CAMINA);
            }
            return true;
        }

        /** Tiene agarrado a un buscador: no se le despega y tira (como si mantuviera el clic derecho). */
        private void forcejear(LivingEntity buscador) {
            acecho = null;
            bot.dejarDeCorrer();
            bot.getLookControl().setLookAt(buscador, 30.0F, 30.0F);
            if (bot.distanceToSqr(buscador) > 1.0) {
                bot.getNavigation().moveTo(buscador, CAMINA);
            } else {
                bot.getNavigation().stop();
            }
            if (bot.tickCount % 5 == 0) {
                Escondidas.forcejear(bot, buscador);                 // 4 tirones por segundo
            }
        }

        /**
         * Sale corriendo, disparado si no está cansado: a la salida abierta si ya la vio; si no, a otro escondite lejos
         * del buscador y para el otro lado (no pasa al lado de él).
         */
        private void huir(LivingEntity peligro) {
            if (disparado == 0 && cansado == 0) {
                disparado = RAFAGA + bot.getRandom().nextInt(21);
            }
            huye = disparado + 30 + bot.getRandom().nextInt(30);
            escondido = false;
            Escondidas.pararse(bot);
            int abierta = Escondidas.salidaAbierta();
            if (abierta >= 0 && conoceSalida) {
                destino = BlockPos.containing(Escondidas.centroSalida(abierta));   // ya sabe cuál es: ¡a salir!
            } else {
                destino = Escondidas.reservarEscondite(bot, peligro.position());
            }
            distanciaAntes = Double.MAX_VALUE;
            sinAvanzar = 0;
            bot.getNavigation().stop();
            bot.empezarACorrer();
            if (destino != null) {
                bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5,
                        disparado > 0 ? DISPARADO : CANSADO);
            }
        }

        /** Va de salida en salida (la más cercana que todavía no vio) hasta encontrar la abierta, y la cruza. */
        private void irALaSalida() {
            if (escondido) {
                escondido = false;
                Escondidas.pararse(bot);
                Escondidas.soltarEscondite(bot.getUUID());
            }
            int abierta = Escondidas.salidaAbierta();
            if (salidaBuscada < 0 || (salidasVistas & (1 << salidaBuscada)) != 0) {
                salidaBuscada = -1;
                double cerca = Double.MAX_VALUE;
                for (int i = 0; i < Escondidas.cantidadSalidas(); i++) {
                    double d = bot.distanceToSqr(Escondidas.frenteSalida(i));
                    if ((salidasVistas & (1 << i)) == 0 && d < cerca) {
                        cerca = d;
                        salidaBuscada = i;
                    }
                }
                if (salidaBuscada < 0) {
                    vaALaSalida = false;                             // las vio todas (no debería pasar)
                    return;
                }
                bot.getNavigation().stop();
            }
            Vec3 frente = Escondidas.frenteSalida(salidaBuscada);
            double d2 = bot.distanceToSqr(frente);
            if (d2 < 8.0 * 8.0) {                                    // ya la ve: ¿está abierta?
                if (salidaBuscada != abierta) {
                    salidasVistas |= 1 << salidaBuscada;             // cerrada: a otra
                    return;
                }
                conoceSalida = true;
                Vec3 centro = Escondidas.centroSalida(abierta);
                bot.empezarACorrer();
                if (d2 < 3.0 * 3.0) {
                    if (!bot.getNavigation().isDone()) {
                        bot.getNavigation().stop();
                    }
                    bot.getMoveControl().setWantedPosition(centro.x, centro.y, centro.z, 1.0);
                } else if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                    bot.getNavigation().moveTo(centro.x, centro.y, centro.z, CAMINA);
                }
                return;
            }
            bot.dejarDeCorrer();
            if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                bot.getNavigation().moveTo(frente.x, frente.y, frente.z, CAMINA);
            }
        }

        /** Hace 10 segundos que no se acerca a donde va (se trabó en algún lado). */
        private boolean trabado(double d2) {
            if (d2 < distanciaAntes - 1.0) {
                distanciaAntes = d2;
                sinAvanzar = 0;
                return false;
            }
            return ++sinAvanzar > 200;
        }

        @Override
        public void stop() {
            if (destino != null) {
                Escondidas.soltarEscondite(bot.getUUID());
            }
            Escondidas.dejarDeRevisar(bot);
            destino = null;
            presa = null;
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
            Escondidas.pararse(bot);
        }
    }

    /** Después de votar seguir: va al comedor y hace la fila en el mostrador, donde un vigilante le da su comida. */
    static class IrAComerGoal extends Goal {
        /** Frente a la puerta del comedor (del lado del salón) y el pasillo del medio del comedor. */
        private static final Vec3[] RUTA_COMEDOR = {new Vec3(20.5, 65.0, -1.5), new Vec3(20.5, 65.0, -12.5)};
        /** La fila, delante del mostrador: a lo largo de x FILA_X0..FILA_X0+20. */
        private static final double FILA_Z = -26.5;
        private static final double FILA_X0 = 10.5;
        private final JugadorBot bot;
        private int paso;
        private int espera;
        private double filaX;

        IrAComerGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Comida.enCurso() && !Comida.yaComio(bot) && bot.level().dimension().equals(Complejo.DIMENSION)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            boolean enElComedor = bot.getX() > 8.0 && bot.getZ() < -4.5;
            paso = enElComedor ? RUTA_COMEDOR.length : 0;
            espera = bot.getRandom().nextInt(100);                     // no van todos al mismo tiempo
            filaX = FILA_X0 + bot.getRandom().nextInt(21);
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
                return;
            }
            Vec3 punto = paso < RUTA_COMEDOR.length ? RUTA_COMEDOR[paso] : new Vec3(filaX, 65.0, FILA_Z);
            // con tanta gente amontonada en la puerta, alcanza con llegar cerca (o con ya haber pasado)
            boolean llego = paso == 0 ? bot.distanceToSqr(punto) < 16.0 || bot.getZ() < -4.5
                    : paso == 1 && (bot.distanceToSqr(punto) < 9.0 || bot.getZ() < -15.0);
            if (llego) {
                paso++;
                bot.getNavigation().stop();
            } else if (bot.getNavigation().isDone() || bot.tickCount % 30 == 0) {
                bot.getNavigation().moveTo(punto.x, punto.y, punto.z, 1.0);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /** Los que ya cruzaron la meta: pasean por la zona de llegada, miran a la gente y festejan. */
    static class MetaGoal extends Goal {
        private static final Emote[] FESTEJOS = {Emote.FELIZ, Emote.GG, Emote.RISA, Emote.PAZ, Emote.XD, Emote.CARITA};
        private final JugadorBot bot;
        private int espera;

        MetaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 1 && Juego.enArena() && Juego.estaEnArena(bot) && Juego.llego(bot)
                    && (!Juego.esBloqueador(bot) || !Juego.jugando()) && !bot.enojado();
        }

        @Override
        public void start() {
            espera = 0;
            bot.dejarDeCorrer();
            bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
        }

        @Override
        public void tick() {
            if (!bot.getNavigation().isDone()) {
                return;
            }
            if (espera > 0) {
                espera--;
                return;
            }
            espera = 60 + bot.getRandom().nextInt(160);
            Vec3 lugar = Juego.lugarEnLaMeta(bot.getRandom());
            bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 0.75);
            if (bot.getRandom().nextInt(5) == 0) {
                bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /** Algunos de los que ya cruzaron no dejan pasar a los demás: les pegan desde la meta para que no crucen. */
    static class BloquearMetaGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private LivingEntity objetivo;
        private int espera;

        BloquearMetaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 1 && Juego.jugando() && Juego.estaEnArena(bot) && Juego.esBloqueador(bot)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            espera = 0;
            objetivo = null;
            bot.mostrarEmote(Emote.ENOJO);
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
            }
            if (objetivo != null && (!Juego.esParticipante(objetivo) || objetivo.getZ() < Juego.META_Z - 8.0
                    || bot.distanceToSqr(objetivo) > 8.0 * 8.0)) {
                objetivo = null;                                      // cruzó, quedó eliminado o se alejó
            }
            if (objetivo == null && bot.tickCount % 5 == 0) {
                objetivo = Juego.objetivoDeBloqueo(bot);
            }
            boolean quieto = Juego.debeQuedarseQuieto(bot);          // con la luz roja, si quedó en la cancha, no camina
            if (quieto) {
                bot.getNavigation().stop();
            }
            if (objetivo != null) {
                bot.getLookControl().setLookAt(objetivo, 30.0F, 30.0F);
                if (bot.distanceToSqr(objetivo) <= 4.0) {
                    bot.getNavigation().stop();
                    if (espera == 0) {
                        Juego.empujar(bot, objetivo, true);           // un empujón fuerte para que no cruce
                        espera = 20;
                    }
                } else if (!quieto && bot.tickCount % 5 == 0) {
                    // con la luz verde se mete un poco en la cancha; con la roja no pisa la cancha (lo eliminarían)
                    double minimo = Juego.luzVerde() ? Juego.META_Z - 3.0 : Juego.META_Z + 0.6;
                    double z = Math.max(objetivo.getZ() + 0.9, minimo);
                    bot.getNavigation().moveTo(objetivo.getX(), 100.0, z, 1.15);
                }
                return;
            }
            double x = Juego.puestoBloqueo(bot);
            double z = Juego.META_Z + 2.5;
            if (quieto) {
                return;
            }
            if (bot.distanceToSqr(x, 100.0, z) > 1.5) {
                if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                    bot.getNavigation().moveTo(x, 100.0, z, 0.9);
                }
            } else {
                bot.getNavigation().stop();
                bot.getLookControl().setLookAt(x, 101.6, Juego.META_Z - 25.0);   // vigila la cancha
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            objetivo = null;
        }
    }

    /** Con las luces apagadas: busca una cama libre de abajo, se acuesta y duerme hasta que se prenden. */
    static class DormirDeNocheGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private BlockPos cama;
        private int tiempo;

        DormirDeNocheGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            // no todos a la vez: cada bot sale para su cama en uno o dos segundos
            if (!Noche.esDeNoche() || !bot.level().dimension().equals(Complejo.DIMENSION) || bot.enojado()
                    || bot.getRandom().nextInt(20) != 0) {
                return false;
            }
            cama = Noche.reservarCama(bot);
            return cama != null;
        }

        @Override
        public boolean canContinueToUse() {
            return Noche.esDeNoche() && cama != null && !bot.enojado();
        }

        @Override
        public void start() {
            tiempo = 0;
            bot.dejarDeCorrer();
            caminar();
        }

        private void caminar() {
            if (cama != null) {
                bot.getNavigation().moveTo(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5, 1.0);
            }
        }

        @Override
        public void tick() {
            if (cama == null || bot.isSleeping()) {
                return;
            }
            tiempo++;
            if (bot.distanceToSqr(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5) < 12.0) {   // al lado de la cama
                BlockState estado = bot.level().getBlockState(cama);
                if (estado.getBlock() instanceof BedBlock && !estado.getValue(BedBlock.OCCUPIED)) {
                    bot.getNavigation().stop();
                    bot.enCama = true;
                    bot.startSleeping(cama);
                } else {
                    Noche.liberarCama(cama);              // la ocupó alguien: buscará otra
                    cama = null;
                }
            } else if (tiempo > 600) {
                Noche.liberarCama(cama);                  // no llega: probará con otra
                cama = null;
            } else if (tiempo % 40 == 0 && bot.getNavigation().isDone()) {
                caminar();
            }
        }

        @Override
        public void stop() {
            if (cama != null) {
                Noche.liberarCama(cama);
            }
            cama = null;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.enCama = false;
        }
    }

    /** En la ceremonia de bienvenida: deja lo que esté haciendo, se acerca al frente y mira al comandante. */
    static class EscucharGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Vec3 lugar;

        EscucharGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            // no todos a la vez: cada bot reacciona en uno o dos segundos
            return Ceremonia.hayPublico() && bot.level().dimension().equals(Complejo.DIMENSION) && !bot.enojado()
                    && bot.getRandom().nextInt(30) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return Ceremonia.hayPublico() && !bot.enojado();
        }

        @Override
        public void start() {
            lugar = Ceremonia.lugarDelPublico(bot.getRandom());
            bot.dejarDeCorrer();
            bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 1.0);
        }

        @Override
        public void tick() {
            Vec3 escenario = Ceremonia.ESCENARIO;
            bot.getLookControl().setLookAt(escenario.x, escenario.y + 1.6, escenario.z);
            if (lugar != null && bot.tickCount % 40 == 0 && bot.getNavigation().isDone() && bot.distanceToSqr(lugar) > 4.0) {
                bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 1.0);   // si se trabó, vuelve a intentar
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            lugar = null;
        }
    }

    /** Saluda a los jugadores de verdad que se acercan. */
    static class SaludarJugadorGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Player jugador;
        private int tiempo;

        SaludarJugadorGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.esperaSaludo > 0) {
                return false;
            }
            Player cercano = bot.level().getNearestPlayer(bot, 5.0);
            if (cercano == null || cercano.isSpectator()) {
                return false;
            }
            jugador = cercano;
            return true;
        }

        @Override
        public void start() {
            bot.getNavigation().stop();
            tiempo = 40;
            bot.mostrarEmote(Emote.HOLA);
            bot.esperaSaludo = 600 + bot.getRandom().nextInt(600);
        }

        @Override
        public boolean canContinueToUse() {
            return tiempo > 0 && jugador != null && jugador.isAlive() && !bot.isSleeping();
        }

        @Override
        public void tick() {
            tiempo--;
            if (jugador != null) {
                bot.getLookControl().setLookAt(jugador, 30.0F, 30.0F);
            }
        }

        @Override
        public void stop() {
            jugador = null;
        }
    }

    /** Busca a otro bot, se acerca y charlan con emoticones. */
    static class CharlarGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private JugadorBot amigo;
        private int tiempo;
        private int proximoEmote;

        CharlarGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(300) != 0) {
                return false;
            }
            List<JugadorBot> cerca = bot.level().getEntitiesOfClass(JugadorBot.class,
                    bot.getBoundingBox().inflate(12.0), otro -> otro != bot && !otro.isSleeping());
            if (cerca.isEmpty()) {
                return false;
            }
            amigo = cerca.get(bot.getRandom().nextInt(cerca.size()));
            return true;
        }

        @Override
        public void start() {
            tiempo = 300;
            proximoEmote = 0;
            if (amigo != null) {
                bot.getNavigation().moveTo(amigo, 1.0);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return tiempo > 0 && amigo != null && amigo.isAlive() && !amigo.isSleeping() && !bot.isSleeping();
        }

        @Override
        public void tick() {
            if (amigo == null) {
                return;
            }
            tiempo--;
            bot.getLookControl().setLookAt(amigo, 30.0F, 30.0F);
            if (bot.distanceToSqr(amigo) > 6.0) {
                if (tiempo % 10 == 0) {
                    bot.getNavigation().moveTo(amigo, 1.0);
                }
                return;
            }
            bot.getNavigation().stop();
            amigo.getNavigation().stop();
            amigo.getLookControl().setLookAt(bot, 30.0F, 30.0F);
            if (tiempo > 160) {
                tiempo = 160;                           // una vez juntos, la charla dura unos 8 segundos
            }
            if (--proximoEmote <= 0) {
                JugadorBot quien = bot.getRandom().nextBoolean() ? bot : amigo;
                Emote dicho = Emote.alAzar(bot.getRandom());
                quien.mostrarEmote(dicho);
                if (dicho.alegre() && bot.getRandom().nextInt(3) == 0) {
                    quien.saltitos = 2 + bot.getRandom().nextInt(2);     // salta de alegría
                } else if (bot.getRandom().nextInt(4) == 0) {
                    quien.tiempoAgacharse = 18;
                }
                proximoEmote = 40 + bot.getRandom().nextInt(40);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            amigo = null;
        }
    }

    /** Camina hasta algún lugar del complejo: la plaza, el comedor, los baños, las literas... */
    static class IrALugarGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Path camino;

        IrALugarGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(500) != 0
                    || !bot.level().dimension().equals(Complejo.DIMENSION)) {
                return false;
            }
            Vec3 destino = Complejo.lugarAlAzar(bot.getRandom());
            camino = bot.getNavigation().createPath(destino.x, destino.y, destino.z, 1);
            return camino != null;
        }

        @Override
        public void start() {
            boolean correr = bot.getRandom().nextInt(100) < 35;
            if (correr) {
                bot.empezarACorrer();
            }
            bot.getNavigation().moveTo(camino, correr ? 1.35 : 1.0);
        }

        @Override
        public boolean canContinueToUse() {
            return !bot.getNavigation().isDone() && !bot.isSleeping();
        }

        @Override
        public void stop() {
            bot.dejarDeCorrer();
            camino = null;
        }
    }

    /** De vez en cuando sale corriendo hacia algún punto cercano. */
    static class CorrerGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Vec3 destino;

        CorrerGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(700) != 0) {
                return false;
            }
            destino = DefaultRandomPos.getPos(bot, 20, 4);
            return destino != null;
        }

        @Override
        public void start() {
            if (destino != null) {
                bot.empezarACorrer();
                bot.getNavigation().moveTo(destino.x, destino.y, destino.z, 1.35);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return !bot.getNavigation().isDone() && !bot.isSleeping();
        }

        @Override
        public void stop() {
            bot.dejarDeCorrer();
            destino = null;
        }
    }

    /** De vez en cuando busca una litera libre de abajo y se acuesta un rato. */
    static class DormirEnLiteraGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private BlockPos cama;
        private int tiempo;
        private boolean durmiendo;

        DormirEnLiteraGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (bot.enojado() || bot.getRandom().nextInt(3000) != 0) {
                return false;
            }
            cama = buscarCama();
            return cama != null;
        }

        @Nullable
        private BlockPos buscarCama() {
            BlockPos base = bot.blockPosition();
            List<BlockPos> libres = new ArrayList<>();
            for (BlockPos p : BlockPos.betweenClosed(base.offset(-14, 0, -14), base.offset(14, 0, 14))) {
                BlockState estado = bot.level().getBlockState(p);
                if (estado.getBlock() instanceof BedBlock
                        && estado.getValue(BedBlock.PART) == BedPart.HEAD
                        && !estado.getValue(BedBlock.OCCUPIED)) {
                    libres.add(p.immutable());
                }
            }
            return libres.isEmpty() ? null : libres.get(bot.getRandom().nextInt(libres.size()));
        }

        @Override
        public void start() {
            tiempo = 400;
            durmiendo = false;
            irALaCama();
        }

        private void irALaCama() {
            if (cama != null) {
                bot.getNavigation().moveTo(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5, 1.0);
            }
        }

        @Override
        public boolean canContinueToUse() {
            if (durmiendo && !bot.isSleeping() || bot.enojado()) {
                return false;                           // lo despertaron (por ejemplo, de un golpe)
            }
            return tiempo > 0 && cama != null;
        }

        @Override
        public void tick() {
            if (cama == null) {
                return;
            }
            tiempo--;
            if (durmiendo) {
                if (tiempo % 60 == 0) {
                    bot.mostrarEmote(Emote.DORMIDO);
                }
                return;
            }
            double dx = bot.getX() - (cama.getX() + 0.5);
            double dz = bot.getZ() - (cama.getZ() + 0.5);
            if (dx * dx + dz * dz < 6.5 && Math.abs(bot.getY() - cama.getY()) < 1.5) {
                BlockState estado = bot.level().getBlockState(cama);
                if (estado.getBlock() instanceof BedBlock && !estado.getValue(BedBlock.OCCUPIED)) {
                    bot.getNavigation().stop();
                    bot.enCama = true;
                    bot.startSleeping(cama);
                    durmiendo = true;
                    tiempo = 400 + bot.getRandom().nextInt(600);
                } else {
                    tiempo = 0;
                }
            } else if (bot.getNavigation().isDone() && tiempo % 20 == 0) {
                irALaCama();
            }
        }

        @Override
        public void stop() {
            bot.enCama = false;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            cama = null;
            durmiendo = false;
        }
    }

    // ================================================================== Sálvese quien pueda, La papa caliente y Los estandartes

    /**
     * Sálvese quien pueda: en la calma pasea cerca de los casilleros y lejos del Cazador. Con la alarma, después de un
     * momento (lo que tarda en darse cuenta), corre al casillero abierto y libre que le conviene (el más cerca, que no esté
     * al lado del Cazador) y se mete. Si se lo gana otro, busca otro; si no queda ninguno, se escapa del Cazador. Metido
     * en el casillero, se queda quieto mirando la puerta.
     */
    static class CasillerosGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Vec3 paseo;
        private int cambiar;
        private int casillero = -1;
        private int buscar;
        private int reaccion;
        private boolean enAlarma;
        private int huir;
        /** Al casillero, corriendo (un poco más despacio que un jugador que corre). */
        private static final double CORRER = 1.15;

        CasillerosGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == Juego.CASILLEROS && Casilleros.juega(bot);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
            paseo = null;
            casillero = -1;
            enAlarma = false;
            huir = 0;
        }

        @Override
        public void tick() {
            Cazador cazador = Casilleros.cazador();
            if (Casilleros.escondido(bot)) {                         // adentro: quieto, mirando la puerta
                bot.getNavigation().stop();
                casillero = -1;
                return;
            }
            if (!Casilleros.alarma()) {
                enAlarma = false;
                casillero = -1;
                if (!Casilleros.calma()) {
                    bot.getNavigation().stop();                      // la revisión: nadie se mueve
                    if (cazador != null) {
                        bot.getLookControl().setLookAt(cazador.getX(), cazador.getY() + 8.0, cazador.getZ());
                    }
                    return;
                }
                if (cazador != null && bot.distanceToSqr(cazador) < 12.0 * 12.0) {
                    escapar(cazador, 0.9);                           // tan cerca, ni con los ojos apagados
                    return;
                }
                pasear(0.65 + bot.getRandom().nextDouble() * 0.15);
                return;
            }
            if (!enAlarma) {                                          // ¡sonó la alarma!
                enAlarma = true;
                reaccion = 4 + bot.getRandom().nextInt(28);
                casillero = -1;
                bot.getNavigation().stop();
            }
            if (reaccion > 0) {
                reaccion--;
                if (cazador != null) {
                    bot.getLookControl().setLookAt(cazador.getX(), cazador.getY() + 8.0, cazador.getZ());
                }
                return;
            }
            if (casillero < 0 || !Casilleros.libre(casillero) || --buscar <= 0) {
                int antes = casillero;
                casillero = Casilleros.casilleroPara(bot);
                buscar = 20;
                if (casillero < 0) {                                  // no queda ninguno: lejos del Cazador
                    if (cazador != null) {
                        escapar(cazador, 1.2);
                    }
                    return;
                }
                if (casillero != antes || bot.getNavigation().isDone()) {
                    Vec3 puerta = Casilleros.CASILLEROS[casillero].afuera();
                    bot.getNavigation().moveTo(puerta.x, puerta.y, puerta.z, CORRER);
                }
            }
            Casilleros.Casillero elegido = Casilleros.CASILLEROS[casillero];
            Vec3 puerta = elegido.afuera();
            if (bot.position().distanceToSqr(puerta) < 1.6 * 1.6 && Casilleros.meterBot(bot, casillero)) {
                casillero = -1;                                       // ¡adentro!
                return;
            }
            if (bot.getNavigation().isDone() && bot.tickCount % 5 == 0) {
                bot.getNavigation().moveTo(puerta.x, puerta.y, puerta.z, CORRER);
            }
        }

        /** Se aleja del Cazador (para el otro lado), a {@code velocidad}. */
        private void escapar(Cazador cazador, double velocidad) {
            if (--huir > 0 && !bot.getNavigation().isDone()) {
                return;
            }
            Vec3 lejos = Casilleros.huida(bot);
            bot.getNavigation().moveTo(lejos.x, lejos.y, lejos.z, velocidad);
            huir = 10 + bot.getRandom().nextInt(10);
            paseo = null;
        }

        private void pasear(double velocidad) {
            if (--cambiar > 0 && paseo != null && !bot.getNavigation().isDone()) {
                return;
            }
            cambiar = 60 + bot.getRandom().nextInt(120);
            paseo = Casilleros.paseo(bot);
            bot.getNavigation().moveTo(paseo.x, paseo.y, paseo.z, velocidad);
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            casillero = -1;
        }
    }

    /**
     * La papa caliente: si tiene la papa, persigue al más cerca que se la puedan pasar y le pega; si no la tiene, pasea
     * por el patio y, si uno que la tiene se le acerca, se escapa para el otro lado.
     */
    static class TejoGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private LivingEntity presa;
        private int buscar;
        private int golpe;
        @Nullable
        private Vec3 paseo;
        private int cambiar;
        private int huir;

        TejoGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == Juego.TEJO && Tejo.juega(bot);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
            presa = null;
            paseo = null;
            huir = 0;
        }

        @Override
        public void tick() {
            if (golpe > 0) {
                golpe--;
            }
            if (!Tejo.corriendo()) {
                pasear(0.6);
                return;
            }
            if (Tejo.tienePapa(bot)) {
                perseguir();
                return;
            }
            presa = null;
            LivingEntity peligro = Tejo.peligro(bot);
            if (peligro != null && bot.distanceToSqr(peligro) < 14.0 * 14.0) {
                if (--huir <= 0) {                                   // ¡se escapa!
                    Vec3 lejos = Tejo.huida(bot, peligro);
                    bot.getNavigation().moveTo(lejos.x, lejos.y, lejos.z, 1.25);
                    huir = 8 + bot.getRandom().nextInt(6);
                    paseo = null;
                }
                bot.getLookControl().setLookAt(peligro, 30.0F, 30.0F);
                return;
            }
            pasear(0.8);
        }

        /** Tiene la papa: al más cerca (que se la puedan pasar), y le pega. */
        private void perseguir() {
            if (presa == null || !Tejo.juega(presa) || Tejo.tienePapa(presa) || --buscar <= 0) {
                presa = Tejo.presa(bot);
                buscar = 20;
            }
            if (presa == null) {
                pasear(0.8);
                return;
            }
            bot.getLookControl().setLookAt(presa, 30.0F, 30.0F);
            double d2 = bot.distanceToSqr(presa);
            if (bot.getNavigation().isDone() || bot.tickCount % 8 == 0) {
                bot.getNavigation().moveTo(presa, 1.25);
            }
            if (golpe <= 0 && d2 <= 6.0 && bot.hasLineOfSight(presa)) {
                bot.swing(InteractionHand.MAIN_HAND);
                bot.doHurtTarget(presa);                             // ¡se la pasa!
                golpe = 10 + bot.getRandom().nextInt(6);
                presa = null;
            }
        }

        private void pasear(double velocidad) {
            if (--cambiar > 0 && paseo != null && !bot.getNavigation().isDone()) {
                return;
            }
            cambiar = 60 + bot.getRandom().nextInt(100);
            paseo = Tejo.paseo(bot);
            bot.getNavigation().moveTo(paseo.x, paseo.y, paseo.z, velocidad);
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            presa = null;
        }
    }

    /**
     * Los estandartes, en el campo largo partido por la grieta: los que cuidan se quedan cerca de su estandarte y le
     * pegan al que llegue; los demás van a buscar el del otro equipo: cruzan el campo (de a tramos, porque es largo),
     * saltan por las torres de su camino (el del medio, el del norte o el del sur) y van hasta el estandarte. El que lo
     * agarra vuelve a su lado por el camino más cerca, sin pelear, y los de su equipo que están cerca lo acompañan. Si
     * les roban el suyo, persiguen al que lo lleva. Al del otro equipo que tengan cerca (y al que puedan llegar), le
     * pegan con la espada.
     */
    static class EstandartesGoal extends Goal {
        /** Adónde miran mientras esperan: a la grieta. */
        private static final Vec3 GRIETA = new Vec3(8000.5, Estandartes.PISO + 1.0, 46.5);
        private final JugadorBot bot;
        private final SaltosBot saltos;
        @Nullable
        private Vec3 paseo;
        private int cambiar;
        private int golpe;
        /** Para darse cuenta de que se trancó caminando (contra una ruina): de dónde salió y cuánto falta para mirar. */
        private Vec3 antes = Vec3.ZERO;
        private int mirar;
        private int desvio;
        private double desvioX;
        private double desvioZ;

        EstandartesGoal(JugadorBot bot) {
            this.bot = bot;
            this.saltos = new SaltosBot(bot);
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == Juego.ESTANDARTES && Estandartes.juega(bot);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
            saltos.olvidar();
            paseo = null;
            golpe = 10;
            antes = bot.position();
            mirar = 60;
            desvio = 0;
        }

        @Override
        public void tick() {
            if (saltos.volando()) {
                return;
            }
            if (golpe > 0) {
                golpe--;
            }
            if (!Estandartes.peleando() || !(bot.level() instanceof ServerLevel complejo)) {
                bot.getNavigation().stop();                          // la cuenta (o ya terminó): quieto, mirando
                bot.getLookControl().setLookAt(GRIETA.x, GRIETA.y, GRIETA.z);
                return;
            }
            boolean rojo = Estandartes.esRojo(bot);
            int papel = Estandartes.papel(bot);
            if (Estandartes.lleva(bot)) {
                volverConEstandarte(rojo);                           // a su lado, sin pelear
                return;
            }
            LivingEntity cerca = Estandartes.enemigoCerca(bot, papel == Estandartes.DEFENSOR ? 12.0 : 7.0);
            if (cerca != null) {
                pelear(cerca);
                return;
            }
            LivingEntity ladron = Estandartes.portador(complejo, rojo);
            if (ladron != null && (papel == Estandartes.DEFENSOR || bot.distanceToSqr(ladron) < 30.0 * 30.0)) {
                perseguir(ladron);                                   // ¡se llevan el suyo!
                return;
            }
            LivingEntity companero = Estandartes.portador(complejo, !rojo);
            if (companero != null && papel != Estandartes.DEFENSOR && bot.distanceToSqr(companero) < 24.0 * 24.0
                    && Estandartes.juntos(bot, companero)) {
                acompaniar(companero);                               // uno de los suyos lo lleva: lo acompaña
                return;
            }
            if (papel == Estandartes.DEFENSOR) {
                cuidar(complejo, rojo);
            } else {
                atacar(rojo, papel);
            }
        }

        /** Un tick de camino a esa torre (o borde) de su camino, saltando: true si ya está ahí. */
        private boolean ir(int torre, double velocidad) {
            return saltos.ir(Estandartes.CAMPO, torre, velocidad, (a, b) -> Estandartes.riesgo(bot, a, b));
        }

        /**
         * Un tick de camino al lado {@code meta} de la grieta (-1 el oeste, 1 el este): si está en una torre, sigue
         * saltando por su camino; si está del otro lado, camina hasta el borde del camino {@code ruta}. true si ya está.
         */
        private boolean irAlLado(int meta, int ruta) {
            if (Estandartes.lado(bot) == meta) {
                return true;
            }
            int aca = Estandartes.CAMPO.torreDe(bot);
            int camino = aca >= 0 ? Estandartes.caminoDe(aca) : ruta;
            int llegada = Estandartes.CAMINOS[camino][meta < 0 ? 0 : 1];
            if (aca >= 0) {
                ir(llegada, 1.2);                                   // en su camino: salta hasta el borde de enfrente
                return false;
            }
            if (Estandartes.lado(bot) == 0) {
                return false;                                        // en el aire (o cayéndose): nada que hacer
            }
            caminar(Estandartes.centro(Estandartes.CAMINOS[ruta][meta < 0 ? 1 : 0]), 1.2);   // hasta el borde de este lado
            return false;
        }

        /**
         * Camina hacia un lugar que puede estar lejos (el campo es largo y el camino no llega a más de unos 40 bloques):
         * de a tramos. Si se trancó (contra una ruina), se corre un poco para el costado y sigue.
         */
        private void caminar(Vec3 destino, double velocidad) {
            saltos.olvidar();
            double dx = destino.x - bot.getX();
            double dz = destino.z - bot.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (--mirar <= 0) {
                if (bot.position().distanceToSqr(antes) < 2.0 && d > 2.0) {
                    desvio = 40;                                     // se trancó: un poco para el costado
                    double lado = bot.getRandom().nextBoolean() ? 1.0 : -1.0;
                    desvioX = -dz / Math.max(d, 0.01) * 6.0 * lado;
                    desvioZ = dx / Math.max(d, 0.01) * 6.0 * lado;
                }
                antes = bot.position();
                mirar = 60;
            }
            Vec3 meta = destino;
            if (desvio > 0) {
                desvio--;
                meta = new Vec3(bot.getX() + dx / Math.max(d, 0.01) * 4.0 + desvioX, bot.getY(),
                        bot.getZ() + dz / Math.max(d, 0.01) * 4.0 + desvioZ);
            } else if (d > 30.0) {
                meta = new Vec3(bot.getX() + dx / d * 26.0, bot.getY(), bot.getZ() + dz / d * 26.0);
            }
            if (bot.getNavigation().isDone() || bot.tickCount % 30 == 0) {
                bot.getNavigation().moveTo(meta.x, meta.y, meta.z, velocidad);
            }
        }

        /** Al del otro equipo (al que puede llegar): se le acerca y le pega con la espada cada tanto. */
        private void pelear(LivingEntity otro) {
            saltos.olvidar();
            bot.getLookControl().setLookAt(otro, 30.0F, 30.0F);
            double d2 = bot.distanceToSqr(otro);
            if (bot.getNavigation().isDone() || bot.tickCount % 8 == 0) {
                bot.getNavigation().moveTo(otro, d2 > 16.0 ? 1.2 : 1.0);
            }
            if (golpe <= 0 && d2 <= 6.25 && bot.hasLineOfSight(otro)) {
                bot.swing(InteractionHand.MAIN_HAND);
                bot.doHurtTarget(otro);                              // con la espada
                golpe = 12 + bot.getRandom().nextInt(9);
            }
        }

        /** Persigue al que se lleva su estandarte: si puede llegar, le pega; si no, va a cortarle el paso. */
        private void perseguir(LivingEntity ladron) {
            if (Estandartes.juntos(bot, ladron)) {
                pelear(ladron);
                return;
            }
            int alla = Estandartes.CAMPO.torreDe(ladron);
            int aca = Estandartes.CAMPO.torreDe(bot);
            if (alla >= 0) {                                         // va por las torres: detrás de él, por su camino
                int camino = Estandartes.caminoDe(alla);
                if (aca >= 0 && Estandartes.caminoDe(aca) == camino) {
                    ir(alla, 1.3);
                } else if (Estandartes.lado(bot) != 0) {
                    caminar(Estandartes.centro(Estandartes.CAMINOS[camino][Estandartes.lado(bot) < 0 ? 0 : 1]), 1.3);
                }
                return;
            }
            int suLado = Estandartes.lado(ladron);
            if (suLado == 0) {
                return;                                              // se está cayendo
            }
            if (irAlLado(suLado, Estandartes.caminoCerca(ladron.getZ()))) {
                caminar(ladron.position(), 1.3);
            }
        }

        /** Acompaña a uno de los suyos que lleva el estandarte (de cerca, sin pisarle los talones). */
        private void acompaniar(LivingEntity companero) {
            saltos.olvidar();
            bot.getLookControl().setLookAt(companero, 30.0F, 30.0F);
            if (bot.distanceToSqr(companero) > 9.0 && (bot.getNavigation().isDone() || bot.tickCount % 10 == 0)) {
                bot.getNavigation().moveTo(companero, 1.2);
            }
        }

        /** Lleva el estandarte del otro equipo: de vuelta a su lado por el camino más cerca, y hasta su estandarte. */
        private void volverConEstandarte(boolean rojo) {
            if (!irAlLado(Estandartes.ladoDe(rojo), Estandartes.caminoCerca(bot.getZ()))) {
                return;
            }
            BlockPos pie = Estandartes.pedestal(rojo);
            caminar(new Vec3(pie.getX() + 0.5, Estandartes.PISO, pie.getZ() + 0.5), 1.25);
        }

        /** Va a buscar el estandarte del otro equipo: por su camino, al otro lado, y hasta tocarlo. */
        private void atacar(boolean rojo, int papel) {
            if (!irAlLado(Estandartes.ladoDe(!rojo), Estandartes.ruta(papel))) {
                return;
            }
            BlockPos pie = Estandartes.pedestal(!rojo);
            caminar(new Vec3(pie.getX() + 0.5, Estandartes.PISO, pie.getZ() + 0.5), 1.2);
        }

        /** Cuida su estandarte: en su fortín, cerca del estandarte, mirando a la grieta. */
        private void cuidar(ServerLevel complejo, boolean rojo) {
            if (!irAlLado(Estandartes.ladoDe(rojo), Estandartes.caminoCerca(bot.getZ()))) {
                return;
            }
            BlockPos pie = Estandartes.pedestal(rojo);
            double dx = bot.getX() - (pie.getX() + 0.5);
            double dz = bot.getZ() - (pie.getZ() + 0.5);
            if (dx * dx + dz * dz > 14.0 * 14.0) {
                caminar(new Vec3(pie.getX() + 0.5, Estandartes.PISO, pie.getZ() + 0.5), 1.1);   // lejos: de vuelta al fortín
                paseo = null;
                return;
            }
            if (paseo == null || --cambiar <= 0) {
                paseo = Estandartes.lugarEnFortin(complejo, rojo, bot.getRandom());
                cambiar = 60 + bot.getRandom().nextInt(80);
                bot.getNavigation().moveTo(paseo.x, paseo.y, paseo.z, 0.8);
            }
            if (bot.getNavigation().isDone()) {
                bot.getLookControl().setLookAt(GRIETA.x, GRIETA.y, GRIETA.z);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            saltos.olvidar();
            paseo = null;
        }
    }
}
