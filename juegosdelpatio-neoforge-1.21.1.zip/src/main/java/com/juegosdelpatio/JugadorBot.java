package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

/**
 * Un "jugador" controlado por el juego (hasta 150 en el complejo): pasea por el complejo, saluda, charla con otros
 * usando emoticones, se agacha y salta como un jugador, y a veces se acuesta en una litera.
 */
public class JugadorBot extends PathfinderMob {
    public static final int CANTIDAD_SKINS = 48;
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(JugadorBot.class, EntityDataSerializers.INT);

    private String nombre = "Jugador";
    private int generacion;
    @Nullable
    private Emote emote;
    private int tiempoEmote;
    int tiempoAgacharse;
    int esperaSaludo;
    /** Lo marca el comportamiento de dormir; si el bot aparece dormido sin él (al recargar el mundo), se levanta. */
    boolean enCama;
    /** Saltitos en el lugar que le quedan por dar. */
    int saltitos;
    private boolean corriendo;
    /** El último jugador que le pegó (si este bot muere, los demás le guardan rencor) y cuánto se acuerda. */
    @Nullable
    private UUID agresor;
    private int memoriaAgresor;
    /** Mientras está enojado, persigue y le pega a quien le pegó. */
    private int enojo;
    /** Ticks que le faltan para terminar de comer (tiene la comida en la mano), y lo que le queda para después. */
    private int comiendo;
    private final List<ItemStack> porComer = new ArrayList<>();

    public JugadorBot(EntityType<? extends JugadorBot> tipo, Level nivel) {
        super(tipo, nivel);
        if (this.getNavigation() instanceof GroundPathNavigation navegacion) {
            navegacion.setCanOpenDoors(true);
        }
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.ATTACK_DAMAGE, 2.0)
                .add(Attributes.ATTACK_KNOCKBACK, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        super.defineSynchedData(datos);
        datos.define(SKIN, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new EscucharGoal(this));
        this.goalSelector.addGoal(0, new DormirDeNocheGoal(this));
        this.goalSelector.addGoal(0, new IrAlJuegoGoal(this));
        this.goalSelector.addGoal(0, new JugarGoal(this));
        this.goalSelector.addGoal(0, new MetaGoal(this));
        this.goalSelector.addGoal(0, new BloquearMetaGoal(this));
        this.goalSelector.addGoal(0, new CabezaQuietaGoal(this));
        this.goalSelector.addGoal(0, new IrAComerGoal(this));
        this.goalSelector.addGoal(0, new SillasGoal(this));
        this.goalSelector.addGoal(0, new EscondidasGoal(this));
        this.goalSelector.addGoal(1, new PelearGoal(this));     // si le pegan, devuelve el golpe
        this.goalSelector.addGoal(1, new DormirEnLiteraGoal(this));
        this.goalSelector.addGoal(2, new SaludarJugadorGoal(this));
        this.goalSelector.addGoal(3, new CharlarGoal(this));
        this.goalSelector.addGoal(4, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(5, new IrALugarGoal(this));
        this.goalSelector.addGoal(5, new CorrerGoal(this));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, JugadorBot.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    // ------------------------------------------------------------------ datos
    public int getSkin() {
        return this.entityData.get(SKIN);
    }

    public void setSkin(int skin) {
        this.entityData.set(SKIN, Math.floorMod(skin, CANTIDAD_SKINS));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag datos) {
        super.addAdditionalSaveData(datos);
        datos.putInt("Skin", getSkin());
        datos.putString("Nombre", nombre);
        datos.putInt("Generacion", generacion);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag datos) {
        super.readAdditionalSaveData(datos);
        setSkin(datos.getInt("Skin"));
        if (datos.contains("Nombre")) {
            nombre = datos.getString("Nombre");
        }
        generacion = datos.getInt("Generacion");
        emote = null;
        actualizarNombre();
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor nivel, DifficultyInstance dificultad,
                                        MobSpawnType tipo, @Nullable SpawnGroupData datos) {
        setSkin(this.random.nextInt(CANTIDAD_SKINS));
        nombre = Nombres.alAzar(this.random);
        generacion = EstadoComplejo.de(nivel.getLevel().getServer()).generacion();
        setCustomNameVisible(true);
        actualizarNombre();
        return super.finalizeSpawn(nivel, dificultad, tipo, datos);
    }

    @Override
    public boolean removeWhenFarAway(double distancia) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (fuente.is(DamageTypes.CRAMMING)) {
            return false;                               // con tantos bots, que no se lastimen al amontonarse
        }
        if (!level().isClientSide() && fuente.getEntity() instanceof Player jugador && !Juego.sinPeleas(this)) {
            agresor = jugador.getUUID();                // antes del golpe: si este lo mata, también cuenta
            memoriaAgresor = 6000;                      // se acuerda 5 minutos de quién le pegó
        }
        boolean herido = super.hurt(fuente, cantidad);
        if (herido && !level().isClientSide() && isAlive() && fuente.getEntity() instanceof Player jugador
                && !jugador.isCreative() && !jugador.isSpectator() && !Juego.sinPeleas(this)) {
            if (getTarget() != jugador) {
                mostrarEmote(Emote.ENOJO);
            }
            setTarget(jugador);                         // al que le pegó, le devuelve el golpe
            enojo = 400;
        }
        return herido;
    }

    @Override
    public void die(DamageSource fuente) {
        super.die(fuente);
        // en las escondidas, que el buscador lo encuentre es el juego: nadie le guarda rencor por eso
        if (!level().isClientSide() && agresor != null && memoriaAgresor > 0 && !(Juego.numero() == 3 && Juego.enArena())) {
            Juego.botMurio(this, agresor);              // los demás no se olvidan de quién le pegó
        }
    }

    /** Lo empujó un jugador (clic derecho): se enoja como si le hubiera pegado, y si muere, los demás le guardan rencor. */
    public void empujadoPor(Player jugador) {
        agresor = jugador.getUUID();
        memoriaAgresor = 6000;
        if (isAlive() && !jugador.isCreative() && !jugador.isSpectator()) {
            if (getTarget() != jugador) {
                mostrarEmote(Emote.ENOJO);
            }
            setTarget(jugador);
            enojo = 400;
        }
    }

    /**
     * Le dieron comida: la agarra y se la come (unos 2 segundos, con ruido y migas), y se cura un poco. Si ya
     * estaba comiendo algo, esto se lo come después.
     */
    public void comer(ItemStack comida) {
        if (comiendo > 0) {
            porComer.add(comida);
            return;
        }
        setItemSlot(EquipmentSlot.MAINHAND, comida);
        setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        comiendo = 40;
    }

    private void seguirComiendo() {
        comiendo--;
        ItemStack enMano = getMainHandItem();
        if (comiendo % 4 == 0 && !enMano.isEmpty() && level() instanceof ServerLevel nivel) {
            Vec3 boca = getEyePosition().add(getLookAngle().scale(0.35)).add(0.0, -0.2, 0.0);
            nivel.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, enMano), boca.x, boca.y, boca.z, 3,
                    0.05, 0.05, 0.05, 0.03);
            playSound(SoundEvents.GENERIC_EAT, 0.6F, 0.9F + this.random.nextFloat() * 0.2F);
        }
        if (comiendo == 0) {
            setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            heal(4.0F);
            if (!porComer.isEmpty()) {
                comer(porComer.remove(0));                           // ahora lo otro que le dieron
            } else {
                playSound(SoundEvents.PLAYER_BURP, 0.5F, 0.9F + this.random.nextFloat() * 0.2F);
            }
        }
    }

    /** Está persiguiendo a alguien que le pegó. */
    public boolean enojado() {
        LivingEntity objetivo = getTarget();
        return objetivo != null && objetivo.isAlive();
    }

    public String nombre() {
        return nombre;
    }

    // ------------------------------------------------------------------ correr y saltar
    void empezarACorrer() {
        corriendo = true;
        setSprinting(true);
    }

    void dejarDeCorrer() {
        if (corriendo) {
            corriendo = false;
            setSprinting(false);
        }
    }

    // ------------------------------------------------------------------ emoticones
    public void mostrarEmote(Emote nuevo) {
        this.emote = nuevo;
        this.tiempoEmote = 60;
        actualizarNombre();
        if (this.level() instanceof ServerLevel servidor) {
            SimpleParticleType particula = nuevo.particula();
            if (particula != null) {
                servidor.sendParticles(particula, getX(), getY() + 2.3, getZ(), 3, 0.3, 0.2, 0.3, 0.02);
            }
        }
        if (nuevo.saludo) {
            this.swing(InteractionHand.MAIN_HAND);
            this.tiempoAgacharse = 24;
        }
    }

    private void actualizarNombre() {
        MutableComponent texto = Component.literal(nombre);
        if (emote != null) {
            texto.append(Component.literal("  " + emote.texto).withStyle(emote.color));
        }
        setCustomName(texto);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (comiendo > 0) {
            seguirComiendo();
        }
        if (memoriaAgresor > 0 && --memoriaAgresor == 0) {
            agresor = null;
        }
        LivingEntity objetivo = getTarget();
        if (objetivo != null && (--enojo <= 0 || !objetivo.isAlive() || objetivo.level() != level()
                || distanceToSqr(objetivo) > 40.0 * 40.0
                || objetivo instanceof Player jugador && (jugador.isCreative() || jugador.isSpectator()))) {
            setTarget(null);                            // se le pasó el enojo (o el otro se fue)
            enojo = 0;
        }
        if (tiempoEmote > 0 && --tiempoEmote == 0) {
            emote = null;
            actualizarNombre();
        }
        if (esperaSaludo > 0) {
            esperaSaludo--;
        }
        if (isSleeping() && !enCama) {
            stopSleeping();
        }
        if (!isSleeping()) {
            if (tiempoAgacharse > 0) {
                tiempoAgacharse--;
                setPose(tiempoAgacharse > 0 && (tiempoAgacharse / 3) % 2 == 0 ? Pose.CROUCHING : Pose.STANDING);
            }
            boolean moviendose = getNavigation().isInProgress();
            if (Juego.enArena() && Juego.estaEnArena(this) && !Juego.luzVerde()) {
                saltitos = 0;                            // con luz roja (o esperando) ni se le ocurre saltar
            } else {
                if (corriendo) {
                    if (!moviendose) {
                        dejarDeCorrer();
                    } else if (onGround() && this.random.nextInt(14) == 0) {
                        getJumpControl().jump();         // salta mientras corre, como un jugador
                    }
                } else if (onGround() && moviendose && this.random.nextInt(140) == 0) {
                    getJumpControl().jump();
                }
                if (!moviendose && onGround()) {
                    if (saltitos > 0) {
                        saltitos--;
                        getJumpControl().jump();         // saltitos en el lugar
                    } else if (this.random.nextInt(1200) == 0) {
                        saltitos = 2 + this.random.nextInt(3);
                    }
                }
            }
        }
        // Si se pidió una tanda nueva de bots, los viejos se van solos
        if (this.tickCount % 40 == 0 && this.level() instanceof ServerLevel servidor
                && servidor.dimension().equals(Complejo.DIMENSION)
                && generacion != EstadoComplejo.de(servidor.getServer()).generacion()) {
            discard();
        }
    }

    // ================================================================== comportamientos

    /**
     * Día de juego, en el minuto para ir: sigue al comandante por el portón, el pasillo y la escalera de la torre
     * hasta la puerta del juego de hoy, y entra al portal (que lo lleva a la arena). No salen todos juntos.
     */
    static class IrAlJuegoGoal extends Goal {
        /** Frente al portón, el pasillo, el pie de la escalera de la torre y el descanso de la puerta 1. */
        static final Vec3[] CAMINO = {
                new Vec3(0.5, 65.0, 1.5), new Vec3(0.5, 65.0, -20.5),
                new Vec3(-8.5, 65.0, -35.5), new Vec3(-8.5, 73.0, -46.5),
        };
        /** A la puerta 2: lo mismo, y después la esquina de la torre y el descanso de la puerta 2 (un tramo más arriba). */
        static final Vec3[] CAMINO_2 = {
                new Vec3(0.5, 65.0, 1.5), new Vec3(0.5, 65.0, -20.5),
                new Vec3(-8.5, 65.0, -35.5), new Vec3(-8.5, 73.0, -46.5),
                new Vec3(-7.5, 73.0, -51.5), new Vec3(4.5, 81.0, -51.5),
        };
        /** A la puerta 3: lo mismo que a la 2, y después la otra esquina y el tramo del lado este. */
        static final Vec3[] CAMINO_3 = {
                new Vec3(0.5, 65.0, 1.5), new Vec3(0.5, 65.0, -20.5),
                new Vec3(-8.5, 65.0, -35.5), new Vec3(-8.5, 73.0, -46.5),
                new Vec3(-7.5, 73.0, -51.5), new Vec3(4.5, 81.0, -51.5),
                new Vec3(8.5, 81.0, -51.5), new Vec3(8.5, 89.0, -41.5),
        };
        /** La celda del medio del portal de la puerta 1, la de la puerta 2 y la de la puerta 3. */
        static final BlockPos PORTAL = new BlockPos(-10, 73, -48);
        static final BlockPos PORTAL_2 = new BlockPos(4, 81, -54);
        static final BlockPos PORTAL_3 = new BlockPos(10, 89, -40);
        private final JugadorBot bot;
        private int paso;
        private int espera;
        private double desvio;
        private double velocidad;

        IrAlJuegoGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Juego.caminando() && bot.level().dimension().equals(Complejo.DIMENSION) && !Juego.estaEnArena(bot)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            double z = bot.getZ();
            int juego = Juego.numero();
            paso = bot.getY() > 85.0 && juego == 3 ? 7 : bot.getY() > 77.0 && juego >= 2 ? 5
                    : bot.getY() > 69.0 ? 3 : z < -30.0 ? 2 : z < -3.0 ? 1 : 0;
            espera = 10 + bot.getRandom().nextInt(180);           // van detrás del comandante, cada uno a su tiempo
            desvio = bot.getRandom().nextDouble() * 6.0 - 3.0;     // que no vayan todos por el mismo lugar
            velocidad = 0.95 + bot.getRandom().nextDouble() * 0.15;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
                return;
            }
            Vec3[] recorrido = Juego.numero() == 3 ? CAMINO_3 : Juego.numero() == 2 ? CAMINO_2 : CAMINO;
            if (paso < recorrido.length) {
                Vec3 punto = paso <= 1 ? recorrido[paso].add(desvio, 0.0, 0.0) : recorrido[paso];
                double cerca = paso == 0 ? 9.0 : paso >= 3 ? 2.25 : 4.0;
                if (bot.distanceToSqr(punto) < cerca) {
                    paso++;                                           // sigue con el próximo tramo
                    bot.getNavigation().stop();
                } else if (bot.getNavigation().isDone() || bot.tickCount % 30 == 0) {
                    bot.getNavigation().moveTo(punto.x, punto.y, punto.z, velocidad);
                }
            } else if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                Path camino = bot.getNavigation().createPath(Juego.numero() == 3 ? PORTAL_3
                        : Juego.numero() == 2 ? PORTAL_2 : PORTAL, 0);
                bot.getNavigation().moveTo(camino, velocidad);        // hasta adentro del portal
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /**
     * En la arena: con luz verde avanza hacia la meta (o, si es de los que empujan, se le pega a su víctima) y con
     * luz roja se queda quieto (salvo si se distrae). Mientras espera que empiece el juego, se queda en el lugar.
     */
    static class JugarGoal extends Goal {
        private final JugadorBot bot;
        private double velocidad = 1.0;
        private boolean corre;

        JugarGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 1 && (Juego.enArena() || Juego.caminando()) && Juego.estaEnArena(bot)
                    && !Juego.llego(bot) && !bot.enojado();
        }

        @Override
        public void start() {
            // como los jugadores: de ~2,5 m/s (los lentos, que quizás no lleguen) a ~5,6 m/s (los que corren).
            // Corriendo, la velocidad sube un 30 %, así que se compensa para que no vuelen.
            double ritmo = 0.8 + bot.getRandom().nextDouble() * 0.4;
            corre = ritmo > 1.1;
            velocidad = corre ? ritmo / 1.3 : ritmo;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            boolean avanzar = Juego.jugando() && (Juego.luzVerde() || Juego.distraido(bot));
            if (!avanzar) {
                bot.getNavigation().stop();                           // quieto
                bot.dejarDeCorrer();
                return;
            }
            LivingEntity victima = Juego.victimaDe(bot);
            if (victima != null && !Juego.distraido(bot)) {
                // de los que empujan: se acerca a su víctima y se queda a un paso, esperando la luz roja.
                // Si la víctima corre, corre también (si no, se le escapa y en la luz roja queda lejos).
                boolean persigue = victima.isSprinting() && bot.distanceToSqr(victima) > 1.5 * 1.5;
                if (persigue) {
                    bot.empezarACorrer();
                } else {
                    bot.dejarDeCorrer();
                }
                if (bot.tickCount % (persigue ? 5 : 10) == 0 || bot.getNavigation().isDone()) {
                    Vec3 donde = victima.position();
                    if (persigue) {
                        // adonde va a estar en un rato, con lo que se movió en el último tick (a los jugadores el
                        // servidor no les lleva la velocidad, así que se mira cuánto cambió la posición)
                        double dx = victima.getX() - victima.xo;
                        double dz = victima.getZ() - victima.zo;
                        if (dx * dx + dz * dz < 1.0) {
                            donde = donde.add(dx * 6.0, 0.0, dz * 6.0);
                        }
                    }
                    Vec3 desde = bot.position().subtract(donde);
                    Vec3 lugar = desde.lengthSqr() > 1.0E-4 ? donde.add(desde.normalize().scale(1.2)) : donde;
                    // corriendo: un poco más rápido que alguien que corre (~6 m/s), para alcanzarlo; caminando,
                    // al menos un poco más rápido que alguien que camina (~4,6 m/s contra 4,3)
                    bot.getNavigation().moveTo(lugar.x, 100.0, lugar.z, persigue ? 0.95 : Math.max(velocidad + 0.1, 1.08));
                }
                return;
            }
            if (bot.tickCount % 20 == 0 || bot.getNavigation().isDone()) {
                double z = Math.min(bot.getZ() + 18.0, Juego.META_Z + 8.0);
                double x = Math.max(951.5, Math.min(1047.5, bot.getX() + (bot.getRandom().nextDouble() - 0.5) * 3.0));
                bot.getNavigation().moveTo(x, 100.0, z, velocidad);
                if (corre) {
                    bot.empezarACorrer();
                }
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            bot.dejarDeCorrer();
        }
    }

    /**
     * Devuelve los golpes a quien le pegó (en el juego, como ahí no se pega, devuelve empujones). Con la luz roja no
     * camina (moverse lo eliminaría): solo empuja si lo tiene al lado.
     */
    static class PelearGoal extends MeleeAttackGoal {
        private final JugadorBot bot;

        PelearGoal(JugadorBot bot) {
            super(bot, 1.2, true);
            this.bot = bot;
        }

        @Override
        public void start() {
            super.start();
            if (Juego.debeQuedarseQuieto(bot)) {
                bot.getNavigation().stop();
            }
        }

        @Override
        public void tick() {
            super.tick();
            if (Juego.debeQuedarseQuieto(bot)) {
                bot.getNavigation().stop();                           // quieto: no lo persigue
            }
        }
    }

    /**
     * Con la luz roja, a la vista del Vigía, tampoco mueve la cabeza (ocupa la mirada para que nadie más la mueva:
     * la cabeza vuelve a quedar derecha y ahí se queda).
     */
    static class CabezaQuietaGoal extends Goal {
        private final JugadorBot bot;

        CabezaQuietaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.debeQuedarseQuieto(bot) && !bot.enojado() && !Juego.esBloqueador(bot)
                    && !Juego.distraido(bot);
        }
    }

    /**
     * Juego 2, las sillas musicales: con la música camina por la pista, cerca de las paredes, alrededor de todo el
     * salón (como las agujas del reloj); cuando para, después de un instante corre al centro, a la silla libre más
     * cercana (esquivando las otras sillas; si otro está por sentarse en esa, a veces lo empuja) y se sienta. De vez
     * en cuando empuja al que tiene al lado, por molestar. Si pasó, festeja. Mientras explican las reglas, quieto.
     */
    static class SillasGoal extends Goal {
        private static final Emote[] FESTEJOS = {Emote.FELIZ, Emote.GG, Emote.RISA, Emote.PAZ, Emote.XD};
        /** A menos de esto del frente de la silla, va derecho (sin camino). */
        private static final double CERCA_DE_LA_SILLA = 2.0;
        private final JugadorBot bot;
        @Nullable
        private BlockPos silla;
        @Nullable
        private LivingEntity victima;
        private double ritmo;
        private int espera;
        private int esperaTiron;

        SillasGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 2 && (Juego.enArena() || Juego.caminando()) && Juego.estaEnArena(bot);
        }

        @Override
        public void start() {
            silla = null;
            espera = 0;
            ritmo = 0.85 + bot.getRandom().nextDouble() * 0.2;
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (bot.isPassenger()) {
                return;                                              // sentado: a salvo hasta que termine la ronda
            }
            if (!Sillas.participa(bot)) {
                silla = null;
                bot.dejarDeCorrer();
                if (Sillas.paso(bot)) {
                    festejar();
                } else {
                    bot.getNavigation().stop();                      // las reglas, o entre ronda y ronda
                }
                return;
            }
            if (Sillas.suenaMusica() || Sillas.hayQueSentarse() && !Sillas.reacciono(bot)) {
                caminar();
            } else if (Sillas.hayQueSentarse()) {
                correrALaSilla();
            } else {
                silla = null;
                bot.dejarDeCorrer();
                bot.getNavigation().stop();                          // entre ronda y ronda, quieto en la pista
            }
        }

        private void caminar() {
            silla = null;
            bot.dejarDeCorrer();
            if (!bot.getNavigation().isDone()) {
                bot.getNavigation().stop();                          // camina derecho por la pista (sin caminos)
            }
            Vec3 punto = Sillas.adondeCaminar(bot);
            double velocidad = Sillas.alguienAdelante(bot) ? ritmo * 0.6 : ritmo;
            bot.getMoveControl().setWantedPosition(punto.x, punto.y, punto.z, velocidad);
            if (Sillas.suenaMusica() && bot.tickCount % 20 == 0) {
                LivingEntity molesto = Sillas.alLado(bot, 2.0);      // por molestar (a los jugadores, bastante más)
                if (molesto != null && bot.getRandom().nextInt(100)
                        < (molesto instanceof Player ? Sillas.EMPUJA_JUGADOR_POR_CIENTO : 3)) {
                    Juego.empujar(bot, molesto, false);
                }
            }
        }

        /**
         * Corre a una silla libre y se sienta apenas tiene una a mano (cualquiera que le quede al lado). Lejos, va por
         * el camino que esquiva las otras sillas; cerca, derecho a la silla (el camino a veces termina a un bloque y
         * se quedaba parado al lado sin sentarse).
         */
        private void correrALaSilla() {
            if (Sillas.sentarseAMano(bot)) {
                silla = null;
                victima = null;
                bot.dejarDeCorrer();
                return;
            }
            boolean otra = false;
            if (silla == null || bot.tickCount % 5 == 0) {
                BlockPos antes = silla;
                silla = Sillas.sillaPara(bot);
                otra = silla != null && !silla.equals(antes);
            }
            if (silla == null) {
                sacarAAlguien();                                     // no quedan sillas libres: a sacar a alguien
                return;
            }
            victima = null;
            LivingEntity rival = Sillas.rivalPorLaSilla(bot, silla);
            if (rival == null && bot.enojado() && bot.getTarget() != null && bot.distanceToSqr(bot.getTarget()) < 2.3 * 2.3) {
                rival = bot.getTarget();                             // y si es el que lo empujó, mejor
            }
            if (rival != null && (rival instanceof Player || bot.getRandom().nextInt(3) == 0)) {
                Juego.empujar(bot, rival, false);                    // se la quiere ganar (al jugador, siempre que puede)
            }
            Vec3 frente = Sillas.frenteDe(bot.level(), silla);
            bot.empezarACorrer();
            double dx = frente.x - bot.getX();
            double dz = frente.z - bot.getZ();
            if (dx * dx + dz * dz < CERCA_DE_LA_SILLA * CERCA_DE_LA_SILLA) {
                if (!bot.getNavigation().isDone()) {
                    bot.getNavigation().stop();
                }
                bot.getMoveControl().setWantedPosition(frente.x, frente.y, frente.z, Sillas.CORRIDA_BOT);   // derecho
            } else if (otra || bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                // al centro, esquivando sillas, hasta el bloque justo delante de la silla (no "más o menos cerca")
                Path camino = bot.getNavigation().createPath(frente.x, frente.y, frente.z, 0);
                if (camino == null || !bot.getNavigation().moveTo(camino, Sillas.CORRIDA_BOT)) {
                    bot.getNavigation().moveTo(frente.x, frente.y, frente.z, Sillas.CORRIDA_BOT);
                }
            }
        }

        /** Va al lado de uno que está sentado (primero, los jugadores) y tira de él (5 a 7 tirones por segundo). */
        private void sacarAAlguien() {
            if (victima == null || !Sillas.estaSentado(victima) || bot.tickCount % 20 == 0) {
                victima = Sillas.aQuienSacar(bot);
            }
            if (victima == null) {
                bot.getNavigation().stop();
                return;
            }
            bot.getLookControl().setLookAt(victima, 30.0F, 30.0F);
            if (bot.distanceToSqr(victima) > 2.4 * 2.4) {
                if (bot.getNavigation().isDone() || bot.tickCount % 10 == 0) {
                    Vec3 lugar = Sillas.alLadoDe(bot.level(), victima);
                    bot.empezarACorrer();
                    bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, Sillas.CORRIDA_BOT);
                }
                return;
            }
            bot.getNavigation().stop();
            bot.dejarDeCorrer();
            if (--esperaTiron <= 0) {
                esperaTiron = 3 + bot.getRandom().nextInt(2);
                Sillas.tirar(bot, victima);
            }
        }

        private void festejar() {
            bot.getNavigation().stop();
            if (espera > 0) {
                espera--;
                return;
            }
            espera = 40 + bot.getRandom().nextInt(80);
            if (bot.getRandom().nextInt(3) == 0) {
                bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
            }
        }

        @Override
        public void stop() {
            silla = null;
            victima = null;
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
        }
    }

    /**
     * Las escondidas. El bot que se esconde: en el minuto para esconderse corre a un escondite libre y se agacha ahí.
     * Cuando salen los buscadores, algunos (uno de cada tres, más o menos) se animan a buscar la salida: van de salida
     * en salida hasta encontrar la abierta. Si un buscador lo vio, está cerca o le pega, sale disparado (muy rápido,
     * unos segundos; después queda cansado) a otro escondite lejos y para el otro lado (o a la salida, si ya sabe cuál
     * es). El bot que busca: espera en la sala de profesores; después recorre la escuela (salas, pasillos y
     * escondites) mirando para los costados y, cuando se para, para todos lados. Ve desde muy lejos (menos a oscuras
     * y a los agachados); si ve a alguien escondido avisa a los otros buscadores, lo persigue y le pega con la espada;
     * si se le pierde, va adonde lo vio (u oyó correr) por última vez y revisa los escondites de alrededor.
     */
    static class EscondidasGoal extends Goal {
        /**
         * Correr detrás de alguien: casi como un jugador corriendo (5,3 contra 5,6 bloques por segundo); al que corre
         * bien se le escapa... pero avisa a los otros, y lo busca donde se le perdió.
         */
        private static final double PERSIGUE = 0.9;
        private static final double CAMINA = 1.0;
        /** El escondido al que descubren sale disparado: unos 9 bloques y medio por segundo, de 2 y medio a 3 y medio segundos... */
        private static final double DISPARADO = 1.2;
        private static final int RAFAGA = 50;
        /** ...y después queda cansado de 7 a 9 segundos: si tiene que escaparse otra vez, corre más lento (4,2 por segundo). */
        private static final double CANSADO = 0.8;
        private static final int DESCANSO = 140;
        /** Al que persigue lo sigue oyendo correr un ratito aunque no lo vea (si no va agachado); después lo da por perdido. */
        private static final int OYE_PASOS = 30;
        private static final int SE_LE_PIERDE = 50;
        private static final Emote[] FESTEJOS = {Emote.FELIZ, Emote.GG, Emote.PAZ};
        private final JugadorBot bot;
        @Nullable
        private BlockPos destino;
        @Nullable
        private LivingEntity presa;
        @Nullable
        private Vec3 ultimoVisto;
        /** Dónde está revisando (donde se le perdió alguien, o donde avisó otro) y cuántos escondites le quedan ahí. */
        @Nullable
        private Vec3 zona;
        @Nullable
        private Vec3 ultimaPista;
        private int rastreo;
        /** Va corriendo (adonde avisaron, o adonde se le perdió alguien). */
        private boolean apurado;
        @Nullable
        private Vec3 mirarA;
        private int mirando;
        private int otraMirada;
        private int perdido;
        /** El que busca: un ratito mirando para todos lados. El que se esconde: cuánto falta para animarse a salir. */
        private int espera;
        private int esperaSalida;
        private int ataque;
        private int huye;
        private int disparado;
        private int cansado;
        private int sinAvanzar;
        private double distanciaAntes;
        private int salidaBuscada = -1;
        private int salidasVistas;
        private boolean vaALaSalida;
        private boolean conoceSalida;
        private boolean escondido;
        private boolean festejo;
        /** El buscador de espaldas al que se le está acercando por atrás para quitarle la espada (o null). */
        @Nullable
        private LivingEntity acecho;

        EscondidasGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 3 && Juego.enArena() && Escondidas.estaEnLaEscuela(bot)
                    && (!Escondidas.enCurso() || Escondidas.esBuscador(bot) || Escondidas.esEscondido(bot)
                    || Escondidas.salio(bot));
        }

        @Override
        public void start() {
            destino = null;
            presa = null;
            ultimoVisto = null;
            zona = null;
            ultimaPista = null;
            rastreo = 0;
            apurado = false;
            mirarA = null;
            mirando = 0;
            otraMirada = 0;
            perdido = 0;
            ataque = 0;
            huye = 0;
            disparado = 0;
            cansado = 0;
            sinAvanzar = 0;
            distanciaAntes = Double.MAX_VALUE;
            salidaBuscada = -1;
            salidasVistas = 0;
            escondido = false;
            festejo = false;
            acecho = null;
            conoceSalida = false;
            espera = 0;
            vaALaSalida = Math.floorMod(bot.getId() * 37 + 11, 100) < 35;  // los que se animan a buscar la salida
            esperaSalida = bot.getRandom().nextInt(70 * 20);                 // y cuándo se animan
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (!Escondidas.enCurso()) {
                bot.getNavigation().stop();                          // escuchando las reglas, en el hall
                bot.dejarDeCorrer();
                return;
            }
            if (Escondidas.salio(bot)) {
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                if (!festejo) {
                    festejo = true;
                    bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
                }
            } else if (Escondidas.esBuscador(bot)) {
                buscar();
            } else if (Escondidas.esEscondido(bot)) {
                esconderse();
            }
        }

        // ------------------------------------------------------------------ el que busca
        private void buscar() {
            if (!Escondidas.buscando()) {
                bot.getNavigation().stop();                          // contando, con los ojos cerrados
                bot.dejarDeCorrer();
                return;
            }
            if (ataque > 0) {
                ataque--;
            }
            boolean armado = Escondidas.tieneEspada(bot);
            if (!armado) {
                presa = null;                                        // le quitaron la espada: sin espada no atrapa
            }
            if (bot.tickCount % 4 == 0) {
                LivingEntity visto = Escondidas.aQuienVe(bot);
                if (visto != null && !armado) {
                    if (ultimoVisto == null || ultimoVisto.distanceToSqr(visto.position()) > 6.0 * 6.0) {
                        bot.mostrarEmote(Emote.VISTO);
                        ultimoVisto = visto.position();
                        Escondidas.loVi(bot, visto);                 // igual avisa a los otros buscadores
                    }
                } else if (visto != null) {
                    if (presa != visto) {
                        bot.getNavigation().stop();
                        bot.mostrarEmote(Emote.VISTO);               // "¡!": lo vio
                    }
                    presa = visto;
                    perdido = 0;
                    ultimoVisto = visto.position();
                    Escondidas.loVi(bot, visto);                     // y avisa a los otros buscadores
                }
            }
            if (presa != null && (!presa.isAlive() || !Escondidas.esEscondido(presa))) {
                presa = null;                                        // lo encontró otro, o salió
                apurado = false;
            }
            if (presa != null) {
                perseguir(presa);
                return;
            }
            if (rastreo == 0 && bot.tickCount % 10 == 0) {
                Vec3 pista = Escondidas.pistaCerca(bot);              // ¿otro buscador vio a alguien por acá?
                if (pista != null && (ultimaPista == null || ultimaPista.distanceToSqr(pista) > 8.0 * 8.0)) {
                    ultimaPista = pista;
                    irA(pista, 2);
                }
            }
            if (apurado || Escondidas.desesperado(bot)) {
                bot.empezarACorrer();                                // (en el último minuto, sin haber atrapado a nadie)
            } else {
                bot.dejarDeCorrer();
            }
            if (espera > 0) {
                espera--;
                mirarAlrededor(true);
                return;
            }
            if (destino == null) {
                apurado = false;
                if (rastreo > 0 && zona != null) {
                    rastreo--;                                       // los escondites de alrededor, uno por uno
                    destino = Escondidas.esconditeCerca(bot, zona, 12.0, false);
                    apurado = destino != null;
                }
                if (destino == null) {
                    rastreo = 0;
                    zona = null;
                    destino = Escondidas.paraRevisar(bot);
                }
                distanciaAntes = Double.MAX_VALUE;
                sinAvanzar = 0;
                if (destino == null) {
                    return;
                }
                bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5, ritmo());
            }
            mirarAlrededor(false);
            double d2 = bot.distanceToSqr(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5);
            if (d2 < 2.0 * 2.0 || trabado(d2)) {
                Escondidas.revisado(bot, destino);
                destino = null;
                apurado = false;
                espera = rastreo > 0 ? 8 + bot.getRandom().nextInt(10) : 15 + bot.getRandom().nextInt(25);
                bot.getNavigation().stop();
            } else if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5, ritmo());
            }
        }

        /** Caminando, o corriendo si está apurado (o desesperado: último minuto y todavía no atrapó a nadie). */
        private double ritmo() {
            return apurado || Escondidas.desesperado(bot) ? PERSIGUE : CAMINA;
        }

        /** Va corriendo a un lugar (donde avisaron, o donde se le perdió alguien) y revisa los escondites de ahí. */
        private void irA(Vec3 donde, int revisar) {
            Escondidas.dejarDeRevisar(bot);
            destino = BlockPos.containing(donde);
            zona = donde;
            rastreo = revisar;
            apurado = true;
            espera = 0;
            distanciaAntes = Double.MAX_VALUE;
            sinAvanzar = 0;
            bot.getNavigation().moveTo(donde.x, donde.y, donde.z, PERSIGUE);
        }

        private void perseguir(LivingEntity objetivo) {
            if (Escondidas.seHaceElMuerto(objetivo) && !Escondidas.vioCaer(bot, objetivo)) {
                presa = null;                                        // parece un cuerpo más: lo da por perdido
                if (ultimoVisto != null) {
                    irA(ultimoVisto, 3);
                }
                return;
            }
            boolean loVe = Escondidas.hayVista(bot, objetivo);
            if (loVe) {
                perdido = 0;
                ultimoVisto = objetivo.position();
            } else {
                perdido++;
                if (perdido <= OYE_PASOS && !objetivo.isShiftKeyDown() && bot.distanceToSqr(objetivo) < 20.0 * 20.0) {
                    ultimoVisto = objetivo.position();               // no lo ve, pero lo oye correr
                }
                if (perdido > SE_LE_PIERDE) {
                    presa = null;                                    // se le perdió: adonde lo vio (u oyó) por última vez
                    if (ultimoVisto != null) {
                        irA(ultimoVisto, 3);                         // y revisa los escondites de por ahí
                    }
                    return;
                }
            }
            if (loVe) {
                bot.getLookControl().setLookAt(objetivo, 30.0F, 30.0F);
            } else if (ultimoVisto != null) {
                bot.getLookControl().setLookAt(ultimoVisto.x, ultimoVisto.y + 1.4, ultimoVisto.z);
            }
            bot.empezarACorrer();
            // pegarle, solo si no hay nada en el medio (ni un vidrio ni una reja)
            if (loVe && ataque <= 0 && bot.distanceToSqr(objetivo) < 2.5 * 2.5 && bot.hasLineOfSight(objetivo)) {
                bot.swing(InteractionHand.MAIN_HAND);
                bot.doHurtTarget(objetivo);                          // con la espada
                ataque = 12;
            }
            if (bot.tickCount % 5 == 0 || bot.getNavigation().isDone()) {
                Vec3 donde = ultimoVisto != null ? ultimoVisto : objetivo.position();
                bot.getNavigation().moveTo(donde.x, donde.y, donde.z, PERSIGUE);
            }
        }

        /**
         * Mientras camina, mira para los costados; cuando está quieto, para todos lados (también para atrás). Así ve
         * mucho más que lo que tiene adelante.
         */
        private void mirarAlrededor(boolean quieto) {
            if (mirando > 0 && mirarA != null) {
                mirando--;
                bot.getLookControl().setLookAt(mirarA.x, mirarA.y, mirarA.z);
                return;
            }
            if (--otraMirada > 0) {
                return;
            }
            RandomSource azar = bot.getRandom();
            otraMirada = quieto ? 2 + azar.nextInt(4) : 12 + azar.nextInt(16);
            double giro = quieto ? azar.nextDouble() * 360.0
                    : bot.getYRot() + (azar.nextBoolean() ? 1 : -1) * (40.0 + azar.nextInt(36));
            double rad = Math.toRadians(giro);
            mirarA = new Vec3(bot.getX() - Math.sin(rad) * 6.0, bot.getEyeY() - 0.3, bot.getZ() + Math.cos(rad) * 6.0);
            mirando = quieto ? 10 + azar.nextInt(8) : 8 + azar.nextInt(8);
        }

        // ------------------------------------------------------------------ el que se esconde
        private void esconderse() {
            if (cansado > 0 && disparado == 0) {
                cansado--;
            }
            if (Escondidas.seHaceElMuerto(bot)) {
                bot.getNavigation().stop();                          // tirado en el piso, quieto, como un cuerpo
                bot.dejarDeCorrer();
                return;
            }
            LivingEntity agarrado = Escondidas.agarradoPor(bot);
            if (agarrado != null) {
                forcejear(agarrado);                                 // tiene a un buscador agarrado por la espalda
                return;
            }
            LivingEntity peligro = Escondidas.susto(bot);                 // le pegaron: sale corriendo siempre
            if (peligro == null && huye == 0 && Escondidas.buscando() && acechar()) {
                return;                                              // se le acerca por atrás a un buscador
            }
            if (peligro == null && !escondido && Escondidas.buscando() && bot.tickCount % 10 == 0
                    && Math.floorMod(bot.getId() * 7 + 3, 100) < 60 && bot.getRandom().nextInt(100) < 35
                    && Escondidas.convieneHacerseElMuerto(bot)) {
                acecho = null;                                       // a la vista, y viene uno que todavía no lo vio:
                huye = 0;
                Escondidas.tirarse(bot);                             // se tira al piso y se hace el muerto
                return;
            }
            if (peligro == null && huye == 0 && Escondidas.buscando() && bot.tickCount % 4 == 0) {
                peligro = Escondidas.peligro(bot, escondido ? 5.0 : 9.0);   // lo vieron, o hay un buscador cerca
            }
            if (peligro != null) {
                acecho = null;
                huir(peligro);
            }
            if (huye > 0) {
                huye--;
                bot.empezarACorrer();
                boolean seCanso = disparado > 0 && --disparado == 0;
                if (seCanso) {
                    cansado = DESCANSO + bot.getRandom().nextInt(41);
                }
                if (destino != null && (seCanso || bot.getNavigation().isDone() || bot.tickCount % 10 == 0)) {
                    bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5,
                            disparado > 0 ? DISPARADO : CANSADO);
                }
                return;
            }
            if (Escondidas.buscando() && vaALaSalida) {
                if (esperaSalida > 0) {
                    esperaSalida--;
                } else {
                    irALaSalida();
                    return;
                }
            }
            if (escondido) {
                bot.getNavigation().stop();
                Escondidas.agacharse(bot);
                return;
            }
            if (destino == null) {
                destino = Escondidas.reservarEscondite(bot, null);
                distanciaAntes = Double.MAX_VALUE;
                sinAvanzar = 0;
                if (destino == null) {
                    escondido = true;                                // no queda ninguno libre: se agacha donde está
                    return;
                }
            }
            double x = destino.getX() + 0.5;
            double z = destino.getZ() + 0.5;
            double d2 = bot.distanceToSqr(x, destino.getY(), z);
            if (Escondidas.escondiendose()) {
                bot.empezarACorrer();                                // hay que llegar antes de que salgan
            } else {
                bot.dejarDeCorrer();
            }
            if (d2 < 0.5 * 0.5) {
                escondido = true;
                bot.getNavigation().stop();
                bot.dejarDeCorrer();
                Escondidas.agacharse(bot);
            } else if (d2 < 1.6 * 1.6) {
                if (!bot.getNavigation().isDone()) {
                    bot.getNavigation().stop();
                }
                bot.getMoveControl().setWantedPosition(x, destino.getY(), z, 0.8);   // el último paso, derecho
            } else if (trabado(d2)) {
                destino = null;                                      // no llega: busca otro
            } else if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                // hasta el escondite mismo (adentro del ropero, del cubículo...), no "más o menos cerca"
                Path camino = bot.getNavigation().createPath(destino, 0);
                if (camino == null || !bot.getNavigation().moveTo(camino, CAMINA)) {
                    bot.getNavigation().moveTo(x, destino.getY(), z, CAMINA);
                }
            }
        }

        /**
         * Los que se animan (uno de cada tres, más o menos): si un buscador con espada pasa cerca de espaldas y no lo
         * vio, se le acerca agachado por atrás y, bien cerca, lo agarra para quitarle la espada. true si está en eso.
         */
        private boolean acechar() {
            if (Math.floorMod(bot.getId() * 13 + 7, 100) >= 30) {
                return false;                                        // este no se anima
            }
            if (acecho == null && bot.tickCount % 10 == 0 && Escondidas.loVieron(bot) == null) {
                acecho = Escondidas.buscadorDeEspaldas(bot, 6.0);
            }
            if (acecho == null) {
                return false;
            }
            if (!acecho.isAlive() || !Escondidas.esBuscador(acecho) || !Escondidas.tieneEspada(acecho)
                    || Escondidas.loVieron(bot) != null || bot.distanceToSqr(acecho) > 8.0 * 8.0
                    || !Escondidas.leDaLaEspalda(acecho, bot) || Escondidas.ve(acecho, bot)) {
                acecho = null;                                       // se dio vuelta, o se fue: mejor no
                return false;
            }
            if (Escondidas.deEspaldas(bot, acecho)) {
                Escondidas.forcejear(bot, acecho);                   // ¡lo agarra!
                return true;
            }
            escondido = false;
            Escondidas.soltarEscondite(bot.getUUID());
            destino = null;
            Escondidas.agacharse(bot);                               // agachado, sin hacer ruido
            Vec3 mira = acecho.getViewVector(1.0F);
            Vec3 atras = new Vec3(acecho.getX() - mira.x * 0.9, acecho.getY(), acecho.getZ() - mira.z * 0.9);
            if (bot.getNavigation().isDone() || bot.tickCount % 5 == 0) {
                bot.getNavigation().moveTo(atras.x, atras.y, atras.z, CAMINA);
            }
            return true;
        }

        /** Tiene agarrado a un buscador: no se le despega y tira (como si mantuviera el clic derecho). */
        private void forcejear(LivingEntity buscador) {
            acecho = null;
            bot.dejarDeCorrer();
            bot.getLookControl().setLookAt(buscador, 30.0F, 30.0F);
            if (bot.distanceToSqr(buscador) > 1.0) {
                bot.getNavigation().moveTo(buscador, CAMINA);
            } else {
                bot.getNavigation().stop();
            }
            if (bot.tickCount % 5 == 0) {
                Escondidas.forcejear(bot, buscador);                 // 4 tirones por segundo
            }
        }

        /**
         * Sale corriendo, disparado si no está cansado: a la salida abierta si ya la vio; si no, a otro escondite lejos
         * del buscador y para el otro lado (no pasa al lado de él).
         */
        private void huir(LivingEntity peligro) {
            if (disparado == 0 && cansado == 0) {
                disparado = RAFAGA + bot.getRandom().nextInt(21);
            }
            huye = disparado + 30 + bot.getRandom().nextInt(30);
            escondido = false;
            Escondidas.pararse(bot);
            int abierta = Escondidas.salidaAbierta();
            if (abierta >= 0 && conoceSalida) {
                destino = BlockPos.containing(Escondidas.centroSalida(abierta));   // ya sabe cuál es: ¡a salir!
            } else {
                destino = Escondidas.reservarEscondite(bot, peligro.position());
            }
            distanciaAntes = Double.MAX_VALUE;
            sinAvanzar = 0;
            bot.getNavigation().stop();
            bot.empezarACorrer();
            if (destino != null) {
                bot.getNavigation().moveTo(destino.getX() + 0.5, destino.getY(), destino.getZ() + 0.5,
                        disparado > 0 ? DISPARADO : CANSADO);
            }
        }

        /** Va de salida en salida (la más cercana que todavía no vio) hasta encontrar la abierta, y la cruza. */
        private void irALaSalida() {
            if (escondido) {
                escondido = false;
                Escondidas.pararse(bot);
                Escondidas.soltarEscondite(bot.getUUID());
            }
            int abierta = Escondidas.salidaAbierta();
            if (salidaBuscada < 0 || (salidasVistas & (1 << salidaBuscada)) != 0) {
                salidaBuscada = -1;
                double cerca = Double.MAX_VALUE;
                for (int i = 0; i < Escondidas.cantidadSalidas(); i++) {
                    double d = bot.distanceToSqr(Escondidas.frenteSalida(i));
                    if ((salidasVistas & (1 << i)) == 0 && d < cerca) {
                        cerca = d;
                        salidaBuscada = i;
                    }
                }
                if (salidaBuscada < 0) {
                    vaALaSalida = false;                             // las vio todas (no debería pasar)
                    return;
                }
                bot.getNavigation().stop();
            }
            Vec3 frente = Escondidas.frenteSalida(salidaBuscada);
            double d2 = bot.distanceToSqr(frente);
            if (d2 < 8.0 * 8.0) {                                    // ya la ve: ¿está abierta?
                if (salidaBuscada != abierta) {
                    salidasVistas |= 1 << salidaBuscada;             // cerrada: a otra
                    return;
                }
                conoceSalida = true;
                Vec3 centro = Escondidas.centroSalida(abierta);
                bot.empezarACorrer();
                if (d2 < 3.0 * 3.0) {
                    if (!bot.getNavigation().isDone()) {
                        bot.getNavigation().stop();
                    }
                    bot.getMoveControl().setWantedPosition(centro.x, centro.y, centro.z, 1.0);
                } else if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                    bot.getNavigation().moveTo(centro.x, centro.y, centro.z, CAMINA);
                }
                return;
            }
            bot.dejarDeCorrer();
            if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                bot.getNavigation().moveTo(frente.x, frente.y, frente.z, CAMINA);
            }
        }

        /** Hace 10 segundos que no se acerca a donde va (se trabó en algún lado). */
        private boolean trabado(double d2) {
            if (d2 < distanciaAntes - 1.0) {
                distanciaAntes = d2;
                sinAvanzar = 0;
                return false;
            }
            return ++sinAvanzar > 200;
        }

        @Override
        public void stop() {
            if (destino != null) {
                Escondidas.soltarEscondite(bot.getUUID());
            }
            Escondidas.dejarDeRevisar(bot);
            destino = null;
            presa = null;
            bot.dejarDeCorrer();
            bot.getNavigation().stop();
            Escondidas.pararse(bot);
        }
    }

    /** Después de votar seguir: va al comedor y hace la fila en el mostrador, donde un vigilante le da su comida. */
    static class IrAComerGoal extends Goal {
        /** Frente a la puerta del comedor (del lado del salón) y el pasillo del medio del comedor. */
        private static final Vec3[] RUTA_COMEDOR = {new Vec3(20.5, 65.0, -1.5), new Vec3(20.5, 65.0, -12.5)};
        /** La fila, delante del mostrador: a lo largo de x FILA_X0..FILA_X0+20. */
        private static final double FILA_Z = -26.5;
        private static final double FILA_X0 = 10.5;
        private final JugadorBot bot;
        private int paso;
        private int espera;
        private double filaX;

        IrAComerGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Comida.enCurso() && !Comida.yaComio(bot) && bot.level().dimension().equals(Complejo.DIMENSION)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            boolean enElComedor = bot.getX() > 8.0 && bot.getZ() < -4.5;
            paso = enElComedor ? RUTA_COMEDOR.length : 0;
            espera = bot.getRandom().nextInt(100);                     // no van todos al mismo tiempo
            filaX = FILA_X0 + bot.getRandom().nextInt(21);
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
                return;
            }
            Vec3 punto = paso < RUTA_COMEDOR.length ? RUTA_COMEDOR[paso] : new Vec3(filaX, 65.0, FILA_Z);
            // con tanta gente amontonada en la puerta, alcanza con llegar cerca (o con ya haber pasado)
            boolean llego = paso == 0 ? bot.distanceToSqr(punto) < 16.0 || bot.getZ() < -4.5
                    : paso == 1 && (bot.distanceToSqr(punto) < 9.0 || bot.getZ() < -15.0);
            if (llego) {
                paso++;
                bot.getNavigation().stop();
            } else if (bot.getNavigation().isDone() || bot.tickCount % 30 == 0) {
                bot.getNavigation().moveTo(punto.x, punto.y, punto.z, 1.0);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /** Los que ya cruzaron la meta: pasean por la zona de llegada, miran a la gente y festejan. */
    static class MetaGoal extends Goal {
        private static final Emote[] FESTEJOS = {Emote.FELIZ, Emote.GG, Emote.RISA, Emote.PAZ, Emote.XD, Emote.CARITA};
        private final JugadorBot bot;
        private int espera;

        MetaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 1 && Juego.enArena() && Juego.estaEnArena(bot) && Juego.llego(bot)
                    && (!Juego.esBloqueador(bot) || !Juego.jugando()) && !bot.enojado();
        }

        @Override
        public void start() {
            espera = 0;
            bot.dejarDeCorrer();
            bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
        }

        @Override
        public void tick() {
            if (!bot.getNavigation().isDone()) {
                return;
            }
            if (espera > 0) {
                espera--;
                return;
            }
            espera = 60 + bot.getRandom().nextInt(160);
            Vec3 lugar = Juego.lugarEnLaMeta(bot.getRandom());
            bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 0.75);
            if (bot.getRandom().nextInt(5) == 0) {
                bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /** Algunos de los que ya cruzaron no dejan pasar a los demás: les pegan desde la meta para que no crucen. */
    static class BloquearMetaGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private LivingEntity objetivo;
        private int espera;

        BloquearMetaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.numero() == 1 && Juego.jugando() && Juego.estaEnArena(bot) && Juego.esBloqueador(bot)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            espera = 0;
            objetivo = null;
            bot.mostrarEmote(Emote.ENOJO);
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
            }
            if (objetivo != null && (!Juego.esParticipante(objetivo) || objetivo.getZ() < Juego.META_Z - 8.0
                    || bot.distanceToSqr(objetivo) > 8.0 * 8.0)) {
                objetivo = null;                                      // cruzó, quedó eliminado o se alejó
            }
            if (objetivo == null && bot.tickCount % 5 == 0) {
                objetivo = Juego.objetivoDeBloqueo(bot);
            }
            boolean quieto = Juego.debeQuedarseQuieto(bot);          // con la luz roja, si quedó en la cancha, no camina
            if (quieto) {
                bot.getNavigation().stop();
            }
            if (objetivo != null) {
                bot.getLookControl().setLookAt(objetivo, 30.0F, 30.0F);
                if (bot.distanceToSqr(objetivo) <= 4.0) {
                    bot.getNavigation().stop();
                    if (espera == 0) {
                        Juego.empujar(bot, objetivo, true);           // un empujón fuerte para que no cruce
                        espera = 20;
                    }
                } else if (!quieto && bot.tickCount % 5 == 0) {
                    // con la luz verde se mete un poco en la cancha; con la roja no pisa la cancha (lo eliminarían)
                    double minimo = Juego.luzVerde() ? Juego.META_Z - 3.0 : Juego.META_Z + 0.6;
                    double z = Math.max(objetivo.getZ() + 0.9, minimo);
                    bot.getNavigation().moveTo(objetivo.getX(), 100.0, z, 1.15);
                }
                return;
            }
            double x = Juego.puestoBloqueo(bot);
            double z = Juego.META_Z + 2.5;
            if (quieto) {
                return;
            }
            if (bot.distanceToSqr(x, 100.0, z) > 1.5) {
                if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                    bot.getNavigation().moveTo(x, 100.0, z, 0.9);
                }
            } else {
                bot.getNavigation().stop();
                bot.getLookControl().setLookAt(x, 101.6, Juego.META_Z - 25.0);   // vigila la cancha
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            objetivo = null;
        }
    }

    /** Con las luces apagadas: busca una cama libre de abajo, se acuesta y duerme hasta que se prenden. */
    static class DormirDeNocheGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private BlockPos cama;
        private int tiempo;

        DormirDeNocheGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            // no todos a la vez: cada bot sale para su cama en uno o dos segundos
            if (!Noche.esDeNoche() || !bot.level().dimension().equals(Complejo.DIMENSION) || bot.enojado()
                    || bot.getRandom().nextInt(20) != 0) {
                return false;
            }
            cama = Noche.reservarCama(bot);
            return cama != null;
        }

        @Override
        public boolean canContinueToUse() {
            return Noche.esDeNoche() && cama != null && !bot.enojado();
        }

        @Override
        public void start() {
            tiempo = 0;
            bot.dejarDeCorrer();
            caminar();
        }

        private void caminar() {
            if (cama != null) {
                bot.getNavigation().moveTo(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5, 1.0);
            }
        }

        @Override
        public void tick() {
            if (cama == null || bot.isSleeping()) {
                return;
            }
            tiempo++;
            if (bot.distanceToSqr(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5) < 12.0) {   // al lado de la cama
                BlockState estado = bot.level().getBlockState(cama);
                if (estado.getBlock() instanceof BedBlock && !estado.getValue(BedBlock.OCCUPIED)) {
                    bot.getNavigation().stop();
                    bot.enCama = true;
                    bot.startSleeping(cama);
                } else {
                    Noche.liberarCama(cama);              // la ocupó alguien: buscará otra
                    cama = null;
                }
            } else if (tiempo > 600) {
                Noche.liberarCama(cama);                  // no llega: probará con otra
                cama = null;
            } else if (tiempo % 40 == 0 && bot.getNavigation().isDone()) {
                caminar();
            }
        }

        @Override
        public void stop() {
            if (cama != null) {
                Noche.liberarCama(cama);
            }
            cama = null;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.enCama = false;
        }
    }

    /** En la ceremonia de bienvenida: deja lo que esté haciendo, se acerca al frente y mira al comandante. */
    static class EscucharGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Vec3 lugar;

        EscucharGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            // no todos a la vez: cada bot reacciona en uno o dos segundos
            return Ceremonia.hayPublico() && bot.level().dimension().equals(Complejo.DIMENSION) && !bot.enojado()
                    && bot.getRandom().nextInt(30) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return Ceremonia.hayPublico() && !bot.enojado();
        }

        @Override
        public void start() {
            lugar = Ceremonia.lugarDelPublico(bot.getRandom());
            bot.dejarDeCorrer();
            bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 1.0);
        }

        @Override
        public void tick() {
            Vec3 escenario = Ceremonia.ESCENARIO;
            bot.getLookControl().setLookAt(escenario.x, escenario.y + 1.6, escenario.z);
            if (lugar != null && bot.tickCount % 40 == 0 && bot.getNavigation().isDone() && bot.distanceToSqr(lugar) > 4.0) {
                bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 1.0);   // si se trabó, vuelve a intentar
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            lugar = null;
        }
    }

    /** Saluda a los jugadores de verdad que se acercan. */
    static class SaludarJugadorGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Player jugador;
        private int tiempo;

        SaludarJugadorGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.esperaSaludo > 0) {
                return false;
            }
            Player cercano = bot.level().getNearestPlayer(bot, 5.0);
            if (cercano == null || cercano.isSpectator()) {
                return false;
            }
            jugador = cercano;
            return true;
        }

        @Override
        public void start() {
            bot.getNavigation().stop();
            tiempo = 40;
            bot.mostrarEmote(Emote.HOLA);
            bot.esperaSaludo = 600 + bot.getRandom().nextInt(600);
        }

        @Override
        public boolean canContinueToUse() {
            return tiempo > 0 && jugador != null && jugador.isAlive() && !bot.isSleeping();
        }

        @Override
        public void tick() {
            tiempo--;
            if (jugador != null) {
                bot.getLookControl().setLookAt(jugador, 30.0F, 30.0F);
            }
        }

        @Override
        public void stop() {
            jugador = null;
        }
    }

    /** Busca a otro bot, se acerca y charlan con emoticones. */
    static class CharlarGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private JugadorBot amigo;
        private int tiempo;
        private int proximoEmote;

        CharlarGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(300) != 0) {
                return false;
            }
            List<JugadorBot> cerca = bot.level().getEntitiesOfClass(JugadorBot.class,
                    bot.getBoundingBox().inflate(12.0), otro -> otro != bot && !otro.isSleeping());
            if (cerca.isEmpty()) {
                return false;
            }
            amigo = cerca.get(bot.getRandom().nextInt(cerca.size()));
            return true;
        }

        @Override
        public void start() {
            tiempo = 300;
            proximoEmote = 0;
            if (amigo != null) {
                bot.getNavigation().moveTo(amigo, 1.0);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return tiempo > 0 && amigo != null && amigo.isAlive() && !amigo.isSleeping() && !bot.isSleeping();
        }

        @Override
        public void tick() {
            if (amigo == null) {
                return;
            }
            tiempo--;
            bot.getLookControl().setLookAt(amigo, 30.0F, 30.0F);
            if (bot.distanceToSqr(amigo) > 6.0) {
                if (tiempo % 10 == 0) {
                    bot.getNavigation().moveTo(amigo, 1.0);
                }
                return;
            }
            bot.getNavigation().stop();
            amigo.getNavigation().stop();
            amigo.getLookControl().setLookAt(bot, 30.0F, 30.0F);
            if (tiempo > 160) {
                tiempo = 160;                           // una vez juntos, la charla dura unos 8 segundos
            }
            if (--proximoEmote <= 0) {
                JugadorBot quien = bot.getRandom().nextBoolean() ? bot : amigo;
                Emote dicho = Emote.alAzar(bot.getRandom());
                quien.mostrarEmote(dicho);
                if (dicho.alegre() && bot.getRandom().nextInt(3) == 0) {
                    quien.saltitos = 2 + bot.getRandom().nextInt(2);     // salta de alegría
                } else if (bot.getRandom().nextInt(4) == 0) {
                    quien.tiempoAgacharse = 18;
                }
                proximoEmote = 40 + bot.getRandom().nextInt(40);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            amigo = null;
        }
    }

    /** Camina hasta algún lugar del complejo: la plaza, el comedor, los baños, las literas... */
    static class IrALugarGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Path camino;

        IrALugarGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(500) != 0
                    || !bot.level().dimension().equals(Complejo.DIMENSION)) {
                return false;
            }
            Vec3 destino = Complejo.lugarAlAzar(bot.getRandom());
            camino = bot.getNavigation().createPath(destino.x, destino.y, destino.z, 1);
            return camino != null;
        }

        @Override
        public void start() {
            boolean correr = bot.getRandom().nextInt(100) < 35;
            if (correr) {
                bot.empezarACorrer();
            }
            bot.getNavigation().moveTo(camino, correr ? 1.35 : 1.0);
        }

        @Override
        public boolean canContinueToUse() {
            return !bot.getNavigation().isDone() && !bot.isSleeping();
        }

        @Override
        public void stop() {
            bot.dejarDeCorrer();
            camino = null;
        }
    }

    /** De vez en cuando sale corriendo hacia algún punto cercano. */
    static class CorrerGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Vec3 destino;

        CorrerGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(700) != 0) {
                return false;
            }
            destino = DefaultRandomPos.getPos(bot, 20, 4);
            return destino != null;
        }

        @Override
        public void start() {
            if (destino != null) {
                bot.empezarACorrer();
                bot.getNavigation().moveTo(destino.x, destino.y, destino.z, 1.35);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return !bot.getNavigation().isDone() && !bot.isSleeping();
        }

        @Override
        public void stop() {
            bot.dejarDeCorrer();
            destino = null;
        }
    }

    /** De vez en cuando busca una litera libre de abajo y se acuesta un rato. */
    static class DormirEnLiteraGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private BlockPos cama;
        private int tiempo;
        private boolean durmiendo;

        DormirEnLiteraGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (bot.enojado() || bot.getRandom().nextInt(3000) != 0) {
                return false;
            }
            cama = buscarCama();
            return cama != null;
        }

        @Nullable
        private BlockPos buscarCama() {
            BlockPos base = bot.blockPosition();
            List<BlockPos> libres = new ArrayList<>();
            for (BlockPos p : BlockPos.betweenClosed(base.offset(-14, 0, -14), base.offset(14, 0, 14))) {
                BlockState estado = bot.level().getBlockState(p);
                if (estado.getBlock() instanceof BedBlock
                        && estado.getValue(BedBlock.PART) == BedPart.HEAD
                        && !estado.getValue(BedBlock.OCCUPIED)) {
                    libres.add(p.immutable());
                }
            }
            return libres.isEmpty() ? null : libres.get(bot.getRandom().nextInt(libres.size()));
        }

        @Override
        public void start() {
            tiempo = 400;
            durmiendo = false;
            irALaCama();
        }

        private void irALaCama() {
            if (cama != null) {
                bot.getNavigation().moveTo(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5, 1.0);
            }
        }

        @Override
        public boolean canContinueToUse() {
            if (durmiendo && !bot.isSleeping() || bot.enojado()) {
                return false;                           // lo despertaron (por ejemplo, de un golpe)
            }
            return tiempo > 0 && cama != null;
        }

        @Override
        public void tick() {
            if (cama == null) {
                return;
            }
            tiempo--;
            if (durmiendo) {
                if (tiempo % 60 == 0) {
                    bot.mostrarEmote(Emote.DORMIDO);
                }
                return;
            }
            double dx = bot.getX() - (cama.getX() + 0.5);
            double dz = bot.getZ() - (cama.getZ() + 0.5);
            if (dx * dx + dz * dz < 6.5 && Math.abs(bot.getY() - cama.getY()) < 1.5) {
                BlockState estado = bot.level().getBlockState(cama);
                if (estado.getBlock() instanceof BedBlock && !estado.getValue(BedBlock.OCCUPIED)) {
                    bot.getNavigation().stop();
                    bot.enCama = true;
                    bot.startSleeping(cama);
                    durmiendo = true;
                    tiempo = 400 + bot.getRandom().nextInt(600);
                } else {
                    tiempo = 0;
                }
            } else if (bot.getNavigation().isDone() && tiempo % 20 == 0) {
                irALaCama();
            }
        }

        @Override
        public void stop() {
            bot.enCama = false;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            cama = null;
            durmiendo = false;
        }
    }
}
