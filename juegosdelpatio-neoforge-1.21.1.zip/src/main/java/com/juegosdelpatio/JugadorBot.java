package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

/**
 * Un "jugador" controlado por el juego (hasta 150 en el complejo): pasea por el complejo, saluda, charla con otros
 * usando emoticones, se agacha y salta como un jugador, y a veces se acuesta en una litera.
 */
public class JugadorBot extends PathfinderMob {
    public static final int CANTIDAD_SKINS = 48;
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(JugadorBot.class, EntityDataSerializers.INT);

    private String nombre = "Jugador";
    private int generacion;
    @Nullable
    private Emote emote;
    private int tiempoEmote;
    int tiempoAgacharse;
    int esperaSaludo;
    /** Lo marca el comportamiento de dormir; si el bot aparece dormido sin él (al recargar el mundo), se levanta. */
    boolean enCama;
    /** Saltitos en el lugar que le quedan por dar. */
    int saltitos;
    private boolean corriendo;
    /** El último jugador que le pegó (si este bot muere, los demás le guardan rencor) y cuánto se acuerda. */
    @Nullable
    private UUID agresor;
    private int memoriaAgresor;
    /** Mientras está enojado, persigue y le pega a quien le pegó. */
    private int enojo;

    public JugadorBot(EntityType<? extends JugadorBot> tipo, Level nivel) {
        super(tipo, nivel);
        if (this.getNavigation() instanceof GroundPathNavigation navegacion) {
            navegacion.setCanOpenDoors(true);
        }
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder crearAtributos() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.ATTACK_DAMAGE, 2.0)
                .add(Attributes.ATTACK_KNOCKBACK, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
        super.defineSynchedData(datos);
        datos.define(SKIN, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new EscucharGoal(this));
        this.goalSelector.addGoal(0, new DormirDeNocheGoal(this));
        this.goalSelector.addGoal(0, new IrAlJuegoGoal(this));
        this.goalSelector.addGoal(0, new JugarGoal(this));
        this.goalSelector.addGoal(0, new MetaGoal(this));
        this.goalSelector.addGoal(0, new BloquearMetaGoal(this));
        this.goalSelector.addGoal(1, new PelearGoal(this));     // si le pegan, devuelve el golpe
        this.goalSelector.addGoal(1, new DormirEnLiteraGoal(this));
        this.goalSelector.addGoal(2, new SaludarJugadorGoal(this));
        this.goalSelector.addGoal(3, new CharlarGoal(this));
        this.goalSelector.addGoal(4, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(5, new IrALugarGoal(this));
        this.goalSelector.addGoal(5, new CorrerGoal(this));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, JugadorBot.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    // ------------------------------------------------------------------ datos
    public int getSkin() {
        return this.entityData.get(SKIN);
    }

    public void setSkin(int skin) {
        this.entityData.set(SKIN, Math.floorMod(skin, CANTIDAD_SKINS));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag datos) {
        super.addAdditionalSaveData(datos);
        datos.putInt("Skin", getSkin());
        datos.putString("Nombre", nombre);
        datos.putInt("Generacion", generacion);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag datos) {
        super.readAdditionalSaveData(datos);
        setSkin(datos.getInt("Skin"));
        if (datos.contains("Nombre")) {
            nombre = datos.getString("Nombre");
        }
        generacion = datos.getInt("Generacion");
        emote = null;
        actualizarNombre();
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor nivel, DifficultyInstance dificultad,
                                        MobSpawnType tipo, @Nullable SpawnGroupData datos) {
        setSkin(this.random.nextInt(CANTIDAD_SKINS));
        nombre = Nombres.alAzar(this.random);
        generacion = EstadoComplejo.de(nivel.getLevel().getServer()).generacion();
        setCustomNameVisible(true);
        actualizarNombre();
        return super.finalizeSpawn(nivel, dificultad, tipo, datos);
    }

    @Override
    public boolean removeWhenFarAway(double distancia) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (fuente.is(DamageTypes.CRAMMING)) {
            return false;                               // con tantos bots, que no se lastimen al amontonarse
        }
        if (!level().isClientSide() && fuente.getEntity() instanceof Player jugador && !Juego.sinPeleas(this)) {
            agresor = jugador.getUUID();                // antes del golpe: si este lo mata, también cuenta
            memoriaAgresor = 6000;                      // se acuerda 5 minutos de quién le pegó
        }
        boolean herido = super.hurt(fuente, cantidad);
        if (herido && !level().isClientSide() && isAlive() && fuente.getEntity() instanceof Player jugador
                && !jugador.isCreative() && !jugador.isSpectator()) {
            if (getTarget() != jugador) {
                mostrarEmote(Emote.ENOJO);
            }
            setTarget(jugador);                         // al que le pegó, le devuelve el golpe
            enojo = 400;
        }
        return herido;
    }

    @Override
    public void die(DamageSource fuente) {
        super.die(fuente);
        if (!level().isClientSide() && agresor != null && memoriaAgresor > 0) {
            Juego.botMurio(this, agresor);              // los demás no se olvidan de quién le pegó
        }
    }

    /** Lo empujó un jugador (clic derecho): se enoja como si le hubiera pegado, y si muere, los demás le guardan rencor. */
    public void empujadoPor(Player jugador) {
        agresor = jugador.getUUID();
        memoriaAgresor = 6000;
        if (isAlive() && !jugador.isCreative() && !jugador.isSpectator()) {
            if (getTarget() != jugador) {
                mostrarEmote(Emote.ENOJO);
            }
            setTarget(jugador);
            enojo = 400;
        }
    }

    /** Está persiguiendo a alguien que le pegó. */
    public boolean enojado() {
        LivingEntity objetivo = getTarget();
        return objetivo != null && objetivo.isAlive();
    }

    public String nombre() {
        return nombre;
    }

    // ------------------------------------------------------------------ correr y saltar
    void empezarACorrer() {
        corriendo = true;
        setSprinting(true);
    }

    void dejarDeCorrer() {
        if (corriendo) {
            corriendo = false;
            setSprinting(false);
        }
    }

    // ------------------------------------------------------------------ emoticones
    public void mostrarEmote(Emote nuevo) {
        this.emote = nuevo;
        this.tiempoEmote = 60;
        actualizarNombre();
        if (this.level() instanceof ServerLevel servidor) {
            SimpleParticleType particula = nuevo.particula();
            if (particula != null) {
                servidor.sendParticles(particula, getX(), getY() + 2.3, getZ(), 3, 0.3, 0.2, 0.3, 0.02);
            }
        }
        if (nuevo.saludo) {
            this.swing(InteractionHand.MAIN_HAND);
            this.tiempoAgacharse = 24;
        }
    }

    private void actualizarNombre() {
        MutableComponent texto = Component.literal(nombre);
        if (emote != null) {
            texto.append(Component.literal("  " + emote.texto).withStyle(emote.color));
        }
        setCustomName(texto);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (memoriaAgresor > 0 && --memoriaAgresor == 0) {
            agresor = null;
        }
        LivingEntity objetivo = getTarget();
        if (objetivo != null && (--enojo <= 0 || !objetivo.isAlive() || objetivo.level() != level()
                || distanceToSqr(objetivo) > 40.0 * 40.0
                || objetivo instanceof Player jugador && (jugador.isCreative() || jugador.isSpectator()))) {
            setTarget(null);                            // se le pasó el enojo (o el otro se fue)
            enojo = 0;
        }
        if (tiempoEmote > 0 && --tiempoEmote == 0) {
            emote = null;
            actualizarNombre();
        }
        if (esperaSaludo > 0) {
            esperaSaludo--;
        }
        if (isSleeping() && !enCama) {
            stopSleeping();
        }
        if (!isSleeping()) {
            if (tiempoAgacharse > 0) {
                tiempoAgacharse--;
                setPose(tiempoAgacharse > 0 && (tiempoAgacharse / 3) % 2 == 0 ? Pose.CROUCHING : Pose.STANDING);
            }
            boolean moviendose = getNavigation().isInProgress();
            if (Juego.enArena() && Juego.estaEnArena(this) && !Juego.luzVerde()) {
                saltitos = 0;                            // con luz roja (o esperando) ni se le ocurre saltar
            } else {
                if (corriendo) {
                    if (!moviendose) {
                        dejarDeCorrer();
                    } else if (onGround() && this.random.nextInt(14) == 0) {
                        getJumpControl().jump();         // salta mientras corre, como un jugador
                    }
                } else if (onGround() && moviendose && this.random.nextInt(140) == 0) {
                    getJumpControl().jump();
                }
                if (!moviendose && onGround()) {
                    if (saltitos > 0) {
                        saltitos--;
                        getJumpControl().jump();         // saltitos en el lugar
                    } else if (this.random.nextInt(1200) == 0) {
                        saltitos = 2 + this.random.nextInt(3);
                    }
                }
            }
        }
        // Si se pidió una tanda nueva de bots, los viejos se van solos
        if (this.tickCount % 40 == 0 && this.level() instanceof ServerLevel servidor
                && servidor.dimension().equals(Complejo.DIMENSION)
                && generacion != EstadoComplejo.de(servidor.getServer()).generacion()) {
            discard();
        }
    }

    // ================================================================== comportamientos

    /**
     * Día de juego, en el minuto para ir: sigue al comandante por el portón, el pasillo y la escalera de la torre
     * hasta la puerta 1, y entra al portal (que lo lleva a la arena). No salen todos juntos.
     */
    static class IrAlJuegoGoal extends Goal {
        /** Frente al portón, el pasillo, el pie de la escalera de la torre y el descanso de la puerta 1. */
        static final Vec3[] CAMINO = {
                new Vec3(0.5, 65.0, 1.5), new Vec3(0.5, 65.0, -20.5),
                new Vec3(-8.5, 65.0, -35.5), new Vec3(-8.5, 73.0, -46.5),
        };
        /** La celda del medio del portal de la puerta 1. */
        static final BlockPos PORTAL = new BlockPos(-10, 73, -48);
        private final JugadorBot bot;
        private int paso;
        private int espera;
        private double desvio;
        private double velocidad;

        IrAlJuegoGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Juego.caminando() && bot.level().dimension().equals(Complejo.DIMENSION) && !Juego.estaEnArena(bot)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            double z = bot.getZ();
            paso = bot.getY() > 69.0 ? 3 : z < -30.0 ? 2 : z < -3.0 ? 1 : 0;
            espera = 10 + bot.getRandom().nextInt(180);           // van detrás del comandante, cada uno a su tiempo
            desvio = bot.getRandom().nextDouble() * 6.0 - 3.0;     // que no vayan todos por el mismo lugar
            velocidad = 0.95 + bot.getRandom().nextDouble() * 0.15;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
                return;
            }
            if (paso < CAMINO.length) {
                Vec3 punto = paso <= 1 ? CAMINO[paso].add(desvio, 0.0, 0.0) : CAMINO[paso];
                double cerca = paso == 0 ? 9.0 : paso == 3 ? 2.25 : 4.0;
                if (bot.distanceToSqr(punto) < cerca) {
                    paso++;                                           // sigue con el próximo tramo
                    bot.getNavigation().stop();
                } else if (bot.getNavigation().isDone() || bot.tickCount % 30 == 0) {
                    bot.getNavigation().moveTo(punto.x, punto.y, punto.z, velocidad);
                }
            } else if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                Path camino = bot.getNavigation().createPath(PORTAL, 0);
                bot.getNavigation().moveTo(camino, velocidad);        // hasta adentro del portal
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /**
     * En la arena: con luz verde avanza hacia la meta (o, si es de los que empujan, se le pega a su víctima) y con
     * luz roja se queda quieto (salvo si se distrae). Mientras espera que empiece el juego, se queda en el lugar.
     */
    static class JugarGoal extends Goal {
        private final JugadorBot bot;
        private double velocidad = 1.0;
        private boolean corre;

        JugarGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return (Juego.enArena() || Juego.caminando()) && Juego.estaEnArena(bot) && !Juego.llego(bot)
                    && !bot.enojado();
        }

        @Override
        public void start() {
            // como los jugadores: de ~2,5 m/s (los lentos, que quizás no lleguen) a ~5,6 m/s (los que corren).
            // Corriendo, la velocidad sube un 30 %, así que se compensa para que no vuelen.
            double ritmo = 0.8 + bot.getRandom().nextDouble() * 0.4;
            corre = ritmo > 1.1;
            velocidad = corre ? ritmo / 1.3 : ritmo;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            boolean avanzar = Juego.jugando() && (Juego.luzVerde() || Juego.distraido(bot));
            if (!avanzar) {
                bot.getNavigation().stop();                           // quieto
                bot.dejarDeCorrer();
                return;
            }
            Vec3 victima = Juego.victimaDe(bot);
            if (victima != null && !Juego.distraido(bot)) {
                // de los que empujan: se acerca a su víctima y se queda a un paso, esperando la luz roja
                if (bot.tickCount % 10 == 0 || bot.getNavigation().isDone()) {
                    Vec3 desde = bot.position().subtract(victima);
                    Vec3 lugar = desde.lengthSqr() > 1.0E-4 ? victima.add(desde.normalize().scale(1.2)) : victima;
                    bot.getNavigation().moveTo(lugar.x, 100.0, lugar.z, velocidad + 0.1);
                }
                return;
            }
            if (bot.tickCount % 20 == 0 || bot.getNavigation().isDone()) {
                double z = Math.min(bot.getZ() + 18.0, Juego.META_Z + 8.0);
                double x = Math.max(951.5, Math.min(1047.5, bot.getX() + (bot.getRandom().nextDouble() - 0.5) * 3.0));
                bot.getNavigation().moveTo(x, 100.0, z, velocidad);
                if (corre) {
                    bot.empezarACorrer();
                }
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            bot.dejarDeCorrer();
        }
    }

    /**
     * Devuelve los golpes a quien le pegó (en el juego, como ahí no se pega, devuelve empujones). Con la luz roja no
     * camina (moverse lo eliminaría): solo empuja si lo tiene al lado.
     */
    static class PelearGoal extends MeleeAttackGoal {
        private final JugadorBot bot;

        PelearGoal(JugadorBot bot) {
            super(bot, 1.2, true);
            this.bot = bot;
        }

        @Override
        public void start() {
            super.start();
            if (Juego.debeQuedarseQuieto(bot)) {
                bot.getNavigation().stop();
            }
        }

        @Override
        public void tick() {
            super.tick();
            if (Juego.debeQuedarseQuieto(bot)) {
                bot.getNavigation().stop();                           // quieto: no lo persigue
            }
        }
    }

    /** Los que ya cruzaron la meta: pasean por la zona de llegada, miran a la gente y festejan. */
    static class MetaGoal extends Goal {
        private static final Emote[] FESTEJOS = {Emote.FELIZ, Emote.GG, Emote.RISA, Emote.PAZ, Emote.XD, Emote.CARITA};
        private final JugadorBot bot;
        private int espera;

        MetaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return Juego.enArena() && Juego.estaEnArena(bot) && Juego.llego(bot)
                    && (!Juego.esBloqueador(bot) || !Juego.jugando()) && !bot.enojado();
        }

        @Override
        public void start() {
            espera = 0;
            bot.dejarDeCorrer();
            bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
        }

        @Override
        public void tick() {
            if (!bot.getNavigation().isDone()) {
                return;
            }
            if (espera > 0) {
                espera--;
                return;
            }
            espera = 60 + bot.getRandom().nextInt(160);
            Vec3 lugar = Juego.lugarEnLaMeta(bot.getRandom());
            bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 0.75);
            if (bot.getRandom().nextInt(5) == 0) {
                bot.mostrarEmote(FESTEJOS[bot.getRandom().nextInt(FESTEJOS.length)]);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
        }
    }

    /** Algunos de los que ya cruzaron no dejan pasar a los demás: les pegan desde la meta para que no crucen. */
    static class BloquearMetaGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private LivingEntity objetivo;
        private int espera;

        BloquearMetaGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return Juego.jugando() && Juego.estaEnArena(bot) && Juego.esBloqueador(bot) && !bot.enojado();
        }

        @Override
        public void start() {
            espera = 0;
            objetivo = null;
            bot.mostrarEmote(Emote.ENOJO);
        }

        @Override
        public void tick() {
            if (espera > 0) {
                espera--;
            }
            if (objetivo != null && (!Juego.esParticipante(objetivo) || objetivo.getZ() < Juego.META_Z - 8.0
                    || bot.distanceToSqr(objetivo) > 8.0 * 8.0)) {
                objetivo = null;                                      // cruzó, quedó eliminado o se alejó
            }
            if (objetivo == null && bot.tickCount % 5 == 0) {
                objetivo = Juego.objetivoDeBloqueo(bot);
            }
            if (objetivo != null) {
                bot.getLookControl().setLookAt(objetivo, 30.0F, 30.0F);
                if (bot.distanceToSqr(objetivo) <= 4.0) {
                    bot.getNavigation().stop();
                    if (espera == 0) {
                        Juego.empujar(bot, objetivo, true);           // un empujón fuerte para que no cruce
                        espera = 20;
                    }
                } else if (bot.tickCount % 5 == 0) {
                    double z = Math.max(objetivo.getZ() + 0.9, Juego.META_Z - 3.0);   // sin meterse en la cancha
                    bot.getNavigation().moveTo(objetivo.getX(), 100.0, z, 1.15);
                }
                return;
            }
            double x = Juego.puestoBloqueo(bot);
            double z = Juego.META_Z + 2.5;
            if (bot.distanceToSqr(x, 100.0, z) > 1.5) {
                if (bot.getNavigation().isDone() || bot.tickCount % 40 == 0) {
                    bot.getNavigation().moveTo(x, 100.0, z, 0.9);
                }
            } else {
                bot.getNavigation().stop();
                bot.getLookControl().setLookAt(x, 101.6, Juego.META_Z - 25.0);   // vigila la cancha
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            objetivo = null;
        }
    }

    /** Con las luces apagadas: busca una cama libre de abajo, se acuesta y duerme hasta que se prenden. */
    static class DormirDeNocheGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private BlockPos cama;
        private int tiempo;

        DormirDeNocheGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            // no todos a la vez: cada bot sale para su cama en uno o dos segundos
            if (!Noche.esDeNoche() || !bot.level().dimension().equals(Complejo.DIMENSION) || bot.enojado()
                    || bot.getRandom().nextInt(20) != 0) {
                return false;
            }
            cama = Noche.reservarCama(bot);
            return cama != null;
        }

        @Override
        public boolean canContinueToUse() {
            return Noche.esDeNoche() && cama != null && !bot.enojado();
        }

        @Override
        public void start() {
            tiempo = 0;
            bot.dejarDeCorrer();
            caminar();
        }

        private void caminar() {
            if (cama != null) {
                bot.getNavigation().moveTo(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5, 1.0);
            }
        }

        @Override
        public void tick() {
            if (cama == null || bot.isSleeping()) {
                return;
            }
            tiempo++;
            if (bot.distanceToSqr(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5) < 12.0) {   // al lado de la cama
                BlockState estado = bot.level().getBlockState(cama);
                if (estado.getBlock() instanceof BedBlock && !estado.getValue(BedBlock.OCCUPIED)) {
                    bot.getNavigation().stop();
                    bot.enCama = true;
                    bot.startSleeping(cama);
                } else {
                    Noche.liberarCama(cama);              // la ocupó alguien: buscará otra
                    cama = null;
                }
            } else if (tiempo > 600) {
                Noche.liberarCama(cama);                  // no llega: probará con otra
                cama = null;
            } else if (tiempo % 40 == 0 && bot.getNavigation().isDone()) {
                caminar();
            }
        }

        @Override
        public void stop() {
            if (cama != null) {
                Noche.liberarCama(cama);
            }
            cama = null;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            bot.enCama = false;
        }
    }

    /** En la ceremonia de bienvenida: deja lo que esté haciendo, se acerca al frente y mira al comandante. */
    static class EscucharGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Vec3 lugar;

        EscucharGoal(JugadorBot bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            // no todos a la vez: cada bot reacciona en uno o dos segundos
            return Ceremonia.hayPublico() && bot.level().dimension().equals(Complejo.DIMENSION) && !bot.enojado()
                    && bot.getRandom().nextInt(30) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return Ceremonia.hayPublico() && !bot.enojado();
        }

        @Override
        public void start() {
            lugar = Ceremonia.lugarDelPublico(bot.getRandom());
            bot.dejarDeCorrer();
            bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 1.0);
        }

        @Override
        public void tick() {
            Vec3 escenario = Ceremonia.ESCENARIO;
            bot.getLookControl().setLookAt(escenario.x, escenario.y + 1.6, escenario.z);
            if (lugar != null && bot.tickCount % 40 == 0 && bot.getNavigation().isDone() && bot.distanceToSqr(lugar) > 4.0) {
                bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 1.0);   // si se trabó, vuelve a intentar
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            lugar = null;
        }
    }

    /** Saluda a los jugadores de verdad que se acercan. */
    static class SaludarJugadorGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Player jugador;
        private int tiempo;

        SaludarJugadorGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.esperaSaludo > 0) {
                return false;
            }
            Player cercano = bot.level().getNearestPlayer(bot, 5.0);
            if (cercano == null || cercano.isSpectator()) {
                return false;
            }
            jugador = cercano;
            return true;
        }

        @Override
        public void start() {
            bot.getNavigation().stop();
            tiempo = 40;
            bot.mostrarEmote(Emote.HOLA);
            bot.esperaSaludo = 600 + bot.getRandom().nextInt(600);
        }

        @Override
        public boolean canContinueToUse() {
            return tiempo > 0 && jugador != null && jugador.isAlive() && !bot.isSleeping();
        }

        @Override
        public void tick() {
            tiempo--;
            if (jugador != null) {
                bot.getLookControl().setLookAt(jugador, 30.0F, 30.0F);
            }
        }

        @Override
        public void stop() {
            jugador = null;
        }
    }

    /** Busca a otro bot, se acerca y charlan con emoticones. */
    static class CharlarGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private JugadorBot amigo;
        private int tiempo;
        private int proximoEmote;

        CharlarGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(300) != 0) {
                return false;
            }
            List<JugadorBot> cerca = bot.level().getEntitiesOfClass(JugadorBot.class,
                    bot.getBoundingBox().inflate(12.0), otro -> otro != bot && !otro.isSleeping());
            if (cerca.isEmpty()) {
                return false;
            }
            amigo = cerca.get(bot.getRandom().nextInt(cerca.size()));
            return true;
        }

        @Override
        public void start() {
            tiempo = 300;
            proximoEmote = 0;
            if (amigo != null) {
                bot.getNavigation().moveTo(amigo, 1.0);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return tiempo > 0 && amigo != null && amigo.isAlive() && !amigo.isSleeping() && !bot.isSleeping();
        }

        @Override
        public void tick() {
            if (amigo == null) {
                return;
            }
            tiempo--;
            bot.getLookControl().setLookAt(amigo, 30.0F, 30.0F);
            if (bot.distanceToSqr(amigo) > 6.0) {
                if (tiempo % 10 == 0) {
                    bot.getNavigation().moveTo(amigo, 1.0);
                }
                return;
            }
            bot.getNavigation().stop();
            amigo.getNavigation().stop();
            amigo.getLookControl().setLookAt(bot, 30.0F, 30.0F);
            if (tiempo > 160) {
                tiempo = 160;                           // una vez juntos, la charla dura unos 8 segundos
            }
            if (--proximoEmote <= 0) {
                JugadorBot quien = bot.getRandom().nextBoolean() ? bot : amigo;
                Emote dicho = Emote.alAzar(bot.getRandom());
                quien.mostrarEmote(dicho);
                if (dicho.alegre() && bot.getRandom().nextInt(3) == 0) {
                    quien.saltitos = 2 + bot.getRandom().nextInt(2);     // salta de alegría
                } else if (bot.getRandom().nextInt(4) == 0) {
                    quien.tiempoAgacharse = 18;
                }
                proximoEmote = 40 + bot.getRandom().nextInt(40);
            }
        }

        @Override
        public void stop() {
            bot.getNavigation().stop();
            amigo = null;
        }
    }

    /** Camina hasta algún lugar del complejo: la plaza, el comedor, los baños, las literas... */
    static class IrALugarGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Path camino;

        IrALugarGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(500) != 0
                    || !bot.level().dimension().equals(Complejo.DIMENSION)) {
                return false;
            }
            Vec3 destino = Complejo.lugarAlAzar(bot.getRandom());
            camino = bot.getNavigation().createPath(destino.x, destino.y, destino.z, 1);
            return camino != null;
        }

        @Override
        public void start() {
            boolean correr = bot.getRandom().nextInt(100) < 35;
            if (correr) {
                bot.empezarACorrer();
            }
            bot.getNavigation().moveTo(camino, correr ? 1.35 : 1.0);
        }

        @Override
        public boolean canContinueToUse() {
            return !bot.getNavigation().isDone() && !bot.isSleeping();
        }

        @Override
        public void stop() {
            bot.dejarDeCorrer();
            camino = null;
        }
    }

    /** De vez en cuando sale corriendo hacia algún punto cercano. */
    static class CorrerGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private Vec3 destino;

        CorrerGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (bot.isSleeping() || bot.getRandom().nextInt(700) != 0) {
                return false;
            }
            destino = DefaultRandomPos.getPos(bot, 20, 4);
            return destino != null;
        }

        @Override
        public void start() {
            if (destino != null) {
                bot.empezarACorrer();
                bot.getNavigation().moveTo(destino.x, destino.y, destino.z, 1.35);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return !bot.getNavigation().isDone() && !bot.isSleeping();
        }

        @Override
        public void stop() {
            bot.dejarDeCorrer();
            destino = null;
        }
    }

    /** De vez en cuando busca una litera libre de abajo y se acuesta un rato. */
    static class DormirEnLiteraGoal extends Goal {
        private final JugadorBot bot;
        @Nullable
        private BlockPos cama;
        private int tiempo;
        private boolean durmiendo;

        DormirEnLiteraGoal(JugadorBot bot) {
            this.bot = bot;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (bot.enojado() || bot.getRandom().nextInt(3000) != 0) {
                return false;
            }
            cama = buscarCama();
            return cama != null;
        }

        @Nullable
        private BlockPos buscarCama() {
            BlockPos base = bot.blockPosition();
            List<BlockPos> libres = new ArrayList<>();
            for (BlockPos p : BlockPos.betweenClosed(base.offset(-14, 0, -14), base.offset(14, 0, 14))) {
                BlockState estado = bot.level().getBlockState(p);
                if (estado.getBlock() instanceof BedBlock
                        && estado.getValue(BedBlock.PART) == BedPart.HEAD
                        && !estado.getValue(BedBlock.OCCUPIED)) {
                    libres.add(p.immutable());
                }
            }
            return libres.isEmpty() ? null : libres.get(bot.getRandom().nextInt(libres.size()));
        }

        @Override
        public void start() {
            tiempo = 400;
            durmiendo = false;
            irALaCama();
        }

        private void irALaCama() {
            if (cama != null) {
                bot.getNavigation().moveTo(cama.getX() + 0.5, cama.getY(), cama.getZ() + 0.5, 1.0);
            }
        }

        @Override
        public boolean canContinueToUse() {
            if (durmiendo && !bot.isSleeping() || bot.enojado()) {
                return false;                           // lo despertaron (por ejemplo, de un golpe)
            }
            return tiempo > 0 && cama != null;
        }

        @Override
        public void tick() {
            if (cama == null) {
                return;
            }
            tiempo--;
            if (durmiendo) {
                if (tiempo % 60 == 0) {
                    bot.mostrarEmote(Emote.DORMIDO);
                }
                return;
            }
            double dx = bot.getX() - (cama.getX() + 0.5);
            double dz = bot.getZ() - (cama.getZ() + 0.5);
            if (dx * dx + dz * dz < 6.5 && Math.abs(bot.getY() - cama.getY()) < 1.5) {
                BlockState estado = bot.level().getBlockState(cama);
                if (estado.getBlock() instanceof BedBlock && !estado.getValue(BedBlock.OCCUPIED)) {
                    bot.getNavigation().stop();
                    bot.enCama = true;
                    bot.startSleeping(cama);
                    durmiendo = true;
                    tiempo = 400 + bot.getRandom().nextInt(600);
                } else {
                    tiempo = 0;
                }
            } else if (bot.getNavigation().isDone() && tiempo % 20 == 0) {
                irALaCama();
            }
        }

        @Override
        public void stop() {
            bot.enCama = false;
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            cama = null;
            durmiendo = false;
        }
    }
}
