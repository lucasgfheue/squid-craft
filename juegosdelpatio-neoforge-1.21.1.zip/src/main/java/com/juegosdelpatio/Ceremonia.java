package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Ceremonia de bienvenida.
 *
 * El día de entrada (0, 6, 12...), al atardecer del mundo normal (hora 12500), se abre el portón y entra el
 * comandante escoltado por cuatro sargentos, dos de cada lado. Se paran frente a la sala y el comandante da la
 * bienvenida, se presenta y explica las reglas: cuántos juegos hay, el premio, que se puede votar para salir y
 * que el premio se reparte entre todos. Después vuelven al pasillo y el portón se cierra.
 * Mientras tanto los bots se juntan a escuchar y los guardias de la sala se quedan quietos en sus puestos.
 */
public final class Ceremonia {
    private enum Fase { NINGUNA, ABRIENDO, MARCHANDO, DISCURSO, SALIENDO, CERRANDO }

    /** Un guardia del desfile y su lugar en la formación (0 = comandante). */
    private record Escolta(Guardia guardia, int lugar) {
    }

    /** Dónde se para el comandante para hablar (los bots miran hacia acá). */
    public static final Vec3 ESCENARIO = new Vec3(0.5, 65, 8.5);
    /** Dónde espera el desfile, en el pasillo detrás del portón. */
    private static final Vec3 PASILLO = new Vec3(0.5, 65, -20.5);
    /** Comandante adelante y dos sargentos de cada lado, un paso atrás ({x, z} respecto del comandante). */
    private static final double[][] FORMACION = {{0, 0}, {-1.6, -1}, {-3.2, -1}, {1.6, -1}, {3.2, -1}};
    /** Frases del discurso, en orden (el texto está en los archivos de idioma). */
    private static final String[] DISCURSO = {"bienvenida", "presentacion", "invitados", "juegos", "premio",
            "votacion", "reparto", "descanso"};
    private static final int TICKS_POR_PASO = 6;       // velocidad del portón
    private static final int TICKS_POR_FRASE = 80;     // 4 segundos entre frase y frase
    private static final double VELOCIDAD_MARCHA = 0.6;

    private static Fase fase = Fase.NINGUNA;
    private static int tiempo;
    private static int frase;
    private static final List<Escolta> DESFILE = new ArrayList<>();

    private Ceremonia() {
    }

    /** true mientras dura la ceremonia: los guardias de la sala no patrullan. */
    public static boolean enCurso() {
        return fase != Fase.NINGUNA;
    }

    /** true mientras el comandante entra y habla: los bots se juntan a escuchar. */
    public static boolean hayPublico() {
        return fase == Fase.ABRIENDO || fase == Fase.MARCHANDO || fase == Fase.DISCURSO;
    }

    /** Un lugar al azar frente al escenario para un bot del público. */
    public static Vec3 lugarDelPublico(RandomSource azar) {
        return new Vec3(-12.5 + azar.nextInt(26), 65, 14.5 + azar.nextInt(15));
    }

    // ------------------------------------------------------------------ eventos
    static void alTick(ServerTickEvent.Post evento) {
        MinecraftServer servidor = evento.getServer();
        ServerLevel complejo = servidor.getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        if (fase == Fase.NINGUNA) {
            if (servidor.getTickCount() % 20 == 0) {
                revisarReloj(servidor, complejo);
            }
            return;
        }
        tiempo++;
        switch (fase) {
            case ABRIENDO -> abrir(complejo);
            case MARCHANDO -> marchar();
            case DISCURSO -> hablar(complejo);
            case SALIENDO -> volver(complejo);
            case CERRANDO -> cerrar(complejo);
            default -> {
            }
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        fase = Fase.NINGUNA;
        DESFILE.clear();
    }

    /** Cada segundo: ¿es el día de entrada y ya atardeció en el mundo normal? */
    private static void revisarReloj(MinecraftServer servidor, ServerLevel complejo) {
        EstadoComplejo estado = EstadoComplejo.de(servidor);
        if (estado.versionSala() == Complejo.VERSION_SALA && !Complejo.portonCerrado(complejo)) {
            Complejo.ponerPorton(complejo, 0);          // quedó abierto (se cerró el juego en plena ceremonia)
        }
        long reloj = servidor.overworld().getDayTime();
        long dia = reloj / 24000L;
        long hora = reloj % 24000L;
        if (!Complejo.esDiaDeEntrada(dia) || hora < Complejo.HORA_CEREMONIA || hora >= Complejo.FIN_CEREMONIA) {
            return;
        }
        if (estado.ultimaCeremonia() == dia || complejo.players().isEmpty()) {
            return;                                     // ya se hizo hoy, o no hay nadie para escucharla
        }
        if (empezar(complejo)) {
            estado.setUltimaCeremonia(dia);
        }
    }

    // ------------------------------------------------------------------ fases
    /** Empieza la ceremonia ahora (también con /juegosdelpatio ceremonia). false si ya había una en curso. */
    public static boolean empezar(ServerLevel complejo) {
        if (fase != Fase.NINGUNA || !Complejo.prepararComplejo(complejo, false)) {
            return false;
        }
        DESFILE.clear();
        for (int i = 0; i < FORMACION.length; i++) {
            Rango rango = i == 0 ? Rango.COMANDANTE : Rango.SARGENTO;
            Guardia guardia = Complejo.invocarGuardia(complejo, enFormacion(PASILLO, i), 0.0F, rango, -1);
            if (guardia != null) {
                guardia.hacerEscolta();
                if (i == 0) {
                    guardia.setCustomNameVisible(true);
                }
                DESFILE.add(new Escolta(guardia, i));
            }
        }
        if (DESFILE.isEmpty()) {
            return false;
        }
        cambiarA(Fase.ABRIENDO);
        frase = 0;
        for (ServerPlayer jugador : complejo.players()) {
            jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 50, 15));
            jugador.connection.send(new ClientboundSetSubtitleTextPacket(
                    Component.translatable("titulo.juegosdelpatio.porton").withStyle(ChatFormatting.GRAY)));
            jugador.connection.send(new ClientboundSetTitleTextPacket(
                    Component.literal("♚").withStyle(ChatFormatting.GOLD)));
        }
        sonar(complejo, SoundEvents.BELL_BLOCK, 3.0F, 0.6F);
        return true;
    }

    /** El portón sube de a una fila. */
    private static void abrir(ServerLevel complejo) {
        if (tiempo % TICKS_POR_PASO != 0) {
            return;
        }
        int subida = Math.min(tiempo / TICKS_POR_PASO, Complejo.PORTON_ALTO);
        Complejo.ponerPorton(complejo, subida);
        sonar(complejo, SoundEvents.PISTON_EXTEND, 1.5F, 0.5F + 0.03F * subida);
        if (subida >= Complejo.PORTON_ALTO) {
            sonar(complejo, SoundEvents.IRON_DOOR_OPEN, 2.0F, 0.5F);
            cambiarA(Fase.MARCHANDO);
        }
    }

    /** El desfile camina en formación hasta el escenario. */
    private static void marchar() {
        Guardia jefe = jefe();
        if (jefe == null) {
            cambiarA(Fase.SALIENDO);                    // sin comandante no hay discurso
            return;
        }
        if (tiempo % 10 == 1) {
            moverDesfile(ESCENARIO);
        }
        if (jefe.distanceToSqr(ESCENARIO) < 2.0 || tiempo > 600) {
            for (Escolta escolta : DESFILE) {
                escolta.guardia().getNavigation().stop();
            }
            cambiarA(Fase.DISCURSO);
        }
    }

    /** Una frase cada 4 segundos. */
    private static void hablar(ServerLevel complejo) {
        if (jefe() == null) {
            cambiarA(Fase.SALIENDO);
            return;
        }
        if (tiempo < 20 || (tiempo - 20) % TICKS_POR_FRASE != 0) {
            return;
        }
        if (frase < DISCURSO.length) {
            decir(complejo, DISCURSO[frase]);
            frase++;
        } else {
            cambiarA(Fase.SALIENDO);
        }
    }

    private static void decir(ServerLevel complejo, String parte) {
        String clave = "ceremonia.juegosdelpatio." + parte;
        Component texto = switch (parte) {
            case "juegos" -> Component.translatable(clave, Complejo.JUEGOS);
            case "premio" -> Component.translatable(clave, Complejo.PREMIO_DIAMANTES);
            default -> Component.translatable(clave);
        };
        MutableComponent mensaje = Component.literal("<").append(Rango.COMANDANTE.nombre())
                .append(Component.literal("> "))
                .append(Component.empty().append(texto).withStyle(ChatFormatting.YELLOW));
        for (ServerPlayer jugador : complejo.players()) {
            jugador.sendSystemMessage(mensaje);
        }
    }

    /** Vuelven al pasillo; cuando están todos adentro, desaparecen y se cierra el portón. */
    private static void volver(ServerLevel complejo) {
        if (tiempo % 10 == 1) {
            moverDesfile(PASILLO);
        }
        boolean adentro = true;
        for (Escolta escolta : DESFILE) {
            if (escolta.guardia().isAlive() && escolta.guardia().getZ() > -10.0) {
                adentro = false;
            }
        }
        if (adentro || tiempo > 600) {
            for (Escolta escolta : DESFILE) {
                escolta.guardia().discard();
            }
            DESFILE.clear();
            despejarPasillo(complejo);
            cambiarA(Fase.CERRANDO);
        }
    }

    /** El portón baja de a una fila. */
    private static void cerrar(ServerLevel complejo) {
        if (tiempo % TICKS_POR_PASO != 0) {
            return;
        }
        int subida = Math.max(Complejo.PORTON_ALTO - tiempo / TICKS_POR_PASO, 0);
        if (subida <= 2) {
            despejarPasillo(complejo);                  // que nadie quede atrapado debajo
        }
        Complejo.ponerPorton(complejo, subida);
        sonar(complejo, SoundEvents.PISTON_CONTRACT, 1.5F, 0.5F + 0.03F * subida);
        if (subida == 0) {
            sonar(complejo, SoundEvents.IRON_DOOR_CLOSE, 2.0F, 0.5F);
            cambiarA(Fase.NINGUNA);
        }
    }

    // ------------------------------------------------------------------ ayudas
    private static void cambiarA(Fase nueva) {
        fase = nueva;
        tiempo = 0;
    }

    @Nullable
    private static Guardia jefe() {
        for (Escolta escolta : DESFILE) {
            if (escolta.lugar() == 0 && escolta.guardia().isAlive()) {
                return escolta.guardia();
            }
        }
        return null;
    }

    private static Vec3 enFormacion(Vec3 centro, int lugar) {
        return centro.add(FORMACION[lugar][0], 0.0, FORMACION[lugar][1]);
    }

    private static void moverDesfile(Vec3 centro) {
        for (Escolta escolta : DESFILE) {
            if (escolta.guardia().isAlive()) {
                escolta.guardia().marcharA(enFormacion(centro, escolta.lugar()), VELOCIDAD_MARCHA);
            }
        }
    }

    /** Saca a jugadores y bots que se metieron en el pasillo o debajo del portón. */
    private static void despejarPasillo(ServerLevel complejo) {
        AABB pasillo = new AABB(Complejo.PORTON_X0 - 1, 64, -34, Complejo.PORTON_X1 + 2, 76, Complejo.PORTON_Z + 1);
        for (LivingEntity quien : complejo.getEntitiesOfClass(LivingEntity.class, pasillo)) {
            if (quien instanceof Guardia guardia && guardia.esEscolta()) {
                continue;
            }
            double x = Math.max(Complejo.PORTON_X0 + 0.5, Math.min(Complejo.PORTON_X1 + 0.5, quien.getX()));
            if (quien instanceof ServerPlayer jugador) {
                jugador.teleportTo(complejo, x, 65.0, -2.5, jugador.getYRot(), jugador.getXRot());
            } else {
                quien.teleportTo(x, 65.0, -2.5);
            }
        }
    }

    private static void sonar(ServerLevel complejo, SoundEvent sonido, float volumen, float tono) {
        complejo.playSound(null, 0.5, 69.0, -4.0, sonido, SoundSource.BLOCKS, volumen, tono);
    }
}
