package com.juegosdelpatio;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Del servidor al cliente: el jugador se está haciendo el muerto (o ya se levantó). Mientras tanto el cliente lo deja
 * acostado (si no, la cámara saltaría entre parado y acostado en cada tick).
 */
public record MuertoFingido(boolean tirado) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<MuertoFingido> TIPO = new CustomPacketPayload.Type<>(Complejo.id("muerto_fingido"));
    public static final StreamCodec<ByteBuf, MuertoFingido> CODEC = StreamCodec.composite(ByteBufCodecs.BOOL,
            MuertoFingido::tirado, MuertoFingido::new);

    /** En el cliente: ¿el jugador está tirado en el piso haciéndose el muerto? */
    static boolean enCliente;

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TIPO;
    }

    static void registrar(RegisterPayloadHandlersEvent evento) {
        PayloadRegistrar registro = evento.registrar("1");
        registro.playToClient(TIPO, CODEC, MuertoFingido::recibir);
    }

    private static void recibir(MuertoFingido paquete, IPayloadContext contexto) {
        contexto.enqueueWork(() -> enCliente = paquete.tirado());
    }
}
