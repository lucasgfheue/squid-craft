package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * El juego 3, "Fuego cruzado": dos equipos, cada uno arriba de su torre (ver gen_fuego.py). Un juego nuevo, con un
 * guiño al quemado.
 *
 * <ol>
 *   <li>Se reparten dos equipos al azar, cada uno con su chaleco: los rojos arriba de la torre roja y los azules
 *       arriba de la azul. Entre las dos torres hay un abismo: nadie pasa al otro lado.</li>
 *   <li>Cada uno tiene una bola de fuego (clic derecho para tirarla; la nueva llega a los 2 segundos). La que pega en
 *       alguien del otro equipo lo empuja y lo quema un poco; la que pega en el piso lo quema: se vuelve magma (que
 *       quema al que la pisa) y, si le vuelven a pegar, se rompe y queda un agujero.</li>
 *   <li>Las torres no tienen baranda: el que se cae por el borde o por un agujero se mata contra el suelo y queda
 *       eliminado (y el que se quema, también).</li>
 *   <li>A los 4 minutos (o si un equipo se queda sin nadie) se termina: los que quedan en pie, pasan.</li>
 * </ol>
 */
public final class Fuego {
    // ------------------------------------------------------------------ la arena (igual que gen_fuego.py)
    public static final ResourceLocation ARENA = Complejo.id("fuego");
    /** Esquina de la plantilla fuego.nbt (63 x 78 x 70): abajo de todo, en el suelo. */
    public static final BlockPos ORIGEN = new BlockPos(5969, 40, -17);
    static final int VERSION_ARENA = 1;
    /** Lo que ocupa la arena, para mantenerla cargada mientras se juega. */
    static final int X0 = 5969;
    static final int X1 = 6031;
    static final int Z0 = -17;
    static final int Z1 = 52;
    /** Donde se para la gente: arriba de las torres. El suelo, allá abajo, en y = 41. */
    static final int PISO = 100;
    static final int SUELO = 41;
    /** Las dos torres: de x 5986 a 6014; la roja de z 8 a 24 y la azul de z 33 a 49 (arriba). */
    static final int TORRE_X0 = 5986;
    static final int TORRE_X1 = 6014;
    static final int ROJA_Z0 = 8;
    static final int ROJA_Z1 = 24;
    static final int AZUL_Z0 = 33;
    static final int AZUL_Z1 = 49;
    /** El palco (la entrada, con baranda): donde se llega y se escuchan las reglas. */
    private static final int PALCO_X0 = 5977;
    private static final int PALCO_X1 = 6023;
    private static final int PALCO_Z0 = -10;
    private static final int PALCO_Z1 = -1;
    static final Vec3 PODIO = new Vec3(6000.5, 102.0, -13.5);
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(5975.5, 100.0, -0.5), new Vec3(6025.5, 100.0, -0.5),
            new Vec3(5992.5, 100.0, -13.5), new Vec3(6008.5, 100.0, -13.5),
    };
    static final float[] GIROS_SARGENTOS = {0.0F, 0.0F, 0.0F, 0.0F};

    // ------------------------------------------------------------------ reglas
    /** Cuánto dura el juego: 4 minutos (antes, 5 segundos de cuenta regresiva). */
    static final int DURACION = 4 * 60 * 20;
    private static final int CUENTA = 5 * 20;
    /** La bola nueva llega a los 2 segundos de tirar (a los bots, un poco después). */
    static final int RECARGA = 40;
    /** Qué tan fuerte sale la bola, cuánto empuja al que le pega y cuánto lo quema (ticks de fuego). */
    static final float FUERZA = 1.45F;
    private static final double EMPUJON = 0.62;
    private static final int QUEMA = 30;

    private enum Estado { NINGUNO, CUENTA, JUEGO, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int pasaron;
    /** El equipo de cada uno: true los rojos. */
    private static final Map<UUID, Boolean> ROJO = new HashMap<>();
    /** Cuándo le llega a cada uno la próxima bola, y los bots que tienen una en la mano. */
    private static final Map<UUID, Integer> RECARGANDO = new HashMap<>();
    private static final Set<UUID> CON_BOLA = new HashSet<>();
    private static final Map<UUID, JugadorBot> BOTS = new HashMap<>();
    /** Las bolas que cada bot ya decidió si esquivaba o no (para no decidir cada tick). */
    private static final Set<Long> VISTAS = new HashSet<>();

    private Fuego() {
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean jugando() {
        return estado == Estado.JUEGO;
    }

    static int pasaron() {
        return pasaron;
    }

    static boolean juega(LivingEntity quien) {
        return estado != Estado.NINGUNO && ROJO.containsKey(quien.getUUID()) && quien.isAlive() && !Juego.eliminado(quien);
    }

    static boolean esRojo(LivingEntity quien) {
        return Boolean.TRUE.equals(ROJO.get(quien.getUUID()));
    }

    static boolean tieneBola(JugadorBot bot) {
        return CON_BOLA.contains(bot.getUUID());
    }

    /** ¿Esta bola puede pegarle a este? A los de su propio equipo (y a los que no juegan) los atraviesa. */
    static boolean puedePegar(@Nullable Entity duenio, Entity objetivo) {
        if (estado == Estado.NINGUNO) {
            return true;
        }
        if (!(objetivo instanceof LivingEntity vivo) || !juega(vivo)) {
            return false;
        }
        return !(duenio instanceof LivingEntity tirador) || !ROJO.containsKey(tirador.getUUID())
                || esRojo(tirador) != esRojo(vivo);
    }

    /** null si puede tirar; si no, la clave del mensaje que dice por qué. */
    @Nullable
    static String porQueNoTira(LivingEntity quien) {
        if (estado == Estado.NINGUNO || !ROJO.containsKey(quien.getUUID())) {
            return null;
        }
        return estado != Estado.JUEGO ? "fuego_todavia" : null;
    }

    static void tiro(LivingEntity quien) {
        if (ROJO.containsKey(quien.getUUID())) {
            RECARGANDO.put(quien.getUUID(), tiempo + RECARGA);
        }
    }

    // ------------------------------------------------------------------ empezar
    static void empezar(ServerLevel complejo, List<LivingEntity> gente) {
        olvidar();
        restaurarPiso(complejo);
        RandomSource azar = complejo.getRandom();
        List<List<LivingEntity>> equipos = Equipos.repartir(gente, azar);
        for (int e = 0; e < 2; e++) {
            boolean rojo = e == 0;
            for (LivingEntity quien : equipos.get(e)) {
                ROJO.put(quien.getUUID(), rojo);
                Equipos.ponerChaleco(quien, rojo);
                llevar(complejo, quien, lugarEnLaTorre(rojo, azar), rojo ? 0.0F : 180.0F);
                if (quien instanceof JugadorBot bot) {
                    BOTS.put(bot.getUUID(), bot);
                }
                if (quien instanceof ServerPlayer jugador) {
                    sacarBolas(jugador.getInventory());
                    Juego.titulo(jugador, Component.translatable(rojo ? "titulo.juegosdelpatio.equipo_rojo"
                                    : "titulo.juegosdelpatio.equipo_azul").withStyle(rojo ? ChatFormatting.RED : ChatFormatting.BLUE),
                            Component.translatable("titulo.juegosdelpatio.fuego_detalle").withStyle(ChatFormatting.GRAY),
                            5, 60, 15);
                    jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, rojo ? 0.8F : 1.2F);
                }
            }
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.fuego_equipos", equipos.get(0).size(),
                equipos.get(1).size()));
        estado = Estado.CUENTA;
        tiempo = 0;
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        switch (estado) {
            case CUENTA -> {
                int faltan = CUENTA - tiempo;
                if (faltan > 0 && faltan % 20 == 0) {
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 1.0F, 1.0F);
                        jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.cuenta_juego", faltan / 20)
                                .withStyle(ChatFormatting.YELLOW), true);
                    }
                }
                if (tiempo % 10 == 1) {
                    barra(complejo, Math.max(0, faltan) / (float) CUENTA);
                }
                if (faltan <= 0) {
                    estado = Estado.JUEGO;
                    tiempo = 0;
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.ya").withStyle(ChatFormatting.GOLD),
                                Component.empty(), 2, 20, 8);
                        jugador.playNotifySound(SoundEvents.BLAZE_SHOOT, SoundSource.MASTER, 0.8F, 0.8F);
                    }
                    recargar(complejo);
                }
            }
            case JUEGO -> {
                if (tiempo % 5 == 0) {
                    recargar(complejo);
                }
                if (tiempo % 10 == 0) {
                    caidos(complejo);
                }
                if (tiempo % 100 == 0) {
                    VISTAS.clear();
                }
                if (tiempo % 10 == 1) {
                    barra(complejo, Math.max(0, DURACION - tiempo) / (float) DURACION);
                }
                int rojos = vivos(complejo, true);
                int azules = vivos(complejo, false);
                if (tiempo >= DURACION || rojos == 0 || azules == 0) {
                    terminarJuego(complejo, rojos, azules);
                }
            }
            default -> {
            }
        }
        return estado == Estado.TERMINADO;
    }

    private static void barra(ServerLevel complejo, float progreso) {
        int queda = estado == Estado.CUENTA ? DURACION : Math.max(0, DURACION - tiempo);
        Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.fuego", Juego.reloj(queda),
                        vivos(complejo, true), vivos(complejo, false)),
                estado == Estado.CUENTA ? BossEvent.BossBarColor.YELLOW : BossEvent.BossBarColor.RED, progreso);
    }

    private static void terminarJuego(ServerLevel complejo, int rojos, int azules) {
        estado = Estado.TERMINADO;
        Juego.decir(complejo, Component.translatable(rojos == 0 && azules == 0 ? "juego.juegosdelpatio.fuego_nadie"
                : rojos == 0 ? "juego.juegosdelpatio.fuego_sin_rojos"
                : azules == 0 ? "juego.juegosdelpatio.fuego_sin_azules" : "juego.juegosdelpatio.fuego_tiempo"));
        CON_BOLA.clear();
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            sacarBolas(jugador.getInventory());
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.6F);
        }
        for (JugadorBot bot : BOTS.values()) {
            if (bot.isAlive() && bot.getMainHandItem().is(Registro.BOLA_DE_FUEGO_ITEM.get())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
        }
        pasaron = enJuego(complejo).size();
    }

    /** A los que no tienen bola y ya pasó la espera, les llega una (a los jugadores, al inventario). */
    private static void recargar(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            UUID id = quien.getUUID();
            if (RECARGANDO.getOrDefault(id, 0) > tiempo) {
                continue;
            }
            if (quien instanceof ServerPlayer jugador) {
                if (jugador.getInventory().countItem(Registro.BOLA_DE_FUEGO_ITEM.get()) < 1) {
                    ItemStack bola = new ItemStack(Registro.BOLA_DE_FUEGO_ITEM.get());
                    if (jugador.getMainHandItem().isEmpty()) {
                        jugador.setItemInHand(InteractionHand.MAIN_HAND, bola);
                    } else if (!jugador.getInventory().add(bola)) {
                        continue;
                    }
                    jugador.playNotifySound(SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.3F, 1.8F);
                }
            } else if (quien instanceof JugadorBot bot && CON_BOLA.add(id)) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Registro.BOLA_DE_FUEGO_ITEM.get()));
                bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
            }
        }
    }

    /** El que se cayó y no murió (aterrizó vivo allá abajo, por ejemplo con un tótem), queda eliminado igual. */
    private static void caidos(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getY() < PISO - 20 && quien.onGround()) {
                Juego.eliminar(complejo, quien, false, "te_caiste");
            }
        }
    }

    // ------------------------------------------------------------------ las bolas de fuego
    /** Una bola le pegó a alguien del otro equipo: lo empuja hacia donde iba la bola y lo quema un poco. */
    static void golpe(BolaDeFuego bola, @Nullable Entity duenio, Entity objetivo) {
        if (estado != Estado.JUEGO || !(objetivo instanceof LivingEntity victima)
                || !(victima.level() instanceof ServerLevel complejo) || !juega(victima)) {
            return;
        }
        Vec3 v = bola.getDeltaMovement();
        double largo = Math.sqrt(v.x * v.x + v.z * v.z);
        if (largo > 1.0E-4) {
            victima.knockback(EMPUJON, -v.x / largo, -v.z / largo);
            victima.hurtMarked = true;
        }
        victima.setRemainingFireTicks(Math.max(victima.getRemainingFireTicks(), QUEMA));
        complejo.playSound(null, victima.getX(), victima.getY(), victima.getZ(), SoundEvents.PLAYER_ATTACK_KNOCKBACK,
                SoundSource.PLAYERS, 1.0F, 0.9F);
        if (duenio instanceof ServerPlayer jugador && duenio != victima) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.le_diste", Juego.nombreDe(victima))
                    .withStyle(ChatFormatting.GOLD), true);
        }
    }

    /**
     * Una bola pegó en un bloque. Si es el piso de arriba de una torre, lo quema: se vuelve magma; y si ya era magma,
     * se rompe (queda un agujero).
     */
    static void alPegarPiso(ServerLevel complejo, BlockPos pos) {
        if (estado != Estado.JUEGO || !esPiso(pos)) {
            return;
        }
        BlockState antes = complejo.getBlockState(pos);
        if (antes.isAir()) {
            return;
        }
        double x = pos.getX() + 0.5;
        double z = pos.getZ() + 0.5;
        if (antes.is(Blocks.MAGMA_BLOCK)) {
            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
            complejo.sendParticles(ParticleTypes.LAVA, x, pos.getY() + 0.8, z, 6, 0.3, 0.1, 0.3, 0.0);
            complejo.sendParticles(ParticleTypes.LARGE_SMOKE, x, pos.getY() + 0.8, z, 6, 0.3, 0.2, 0.3, 0.02);
            complejo.playSound(null, x, pos.getY() + 0.5, z, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS,
                    0.6F, 1.4F);
        } else {
            complejo.setBlock(pos, Blocks.MAGMA_BLOCK.defaultBlockState(), Block.UPDATE_ALL);
            complejo.sendParticles(ParticleTypes.FLAME, x, pos.getY() + 1.0, z, 8, 0.3, 0.1, 0.3, 0.02);
            complejo.playSound(null, x, pos.getY() + 0.5, z, SoundEvents.FIRE_AMBIENT, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    /** ¿Es un bloque del piso de arriba de una de las dos torres? */
    static boolean esPiso(BlockPos pos) {
        return pos.getY() == PISO - 1 && pos.getX() >= TORRE_X0 && pos.getX() <= TORRE_X1
                && (pos.getZ() >= ROJA_Z0 && pos.getZ() <= ROJA_Z1 || pos.getZ() >= AZUL_Z0 && pos.getZ() <= AZUL_Z1);
    }

    /** El piso de las dos torres, como en gen_fuego.py: el borde del color del equipo y adentro, piedra negra. */
    private static void restaurarPiso(ServerLevel complejo) {
        if (EstadoComplejo.de(complejo.getServer()).versionFuego() != VERSION_ARENA) {
            return;
        }
        BlockState piedra = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        for (int e = 0; e < 2; e++) {
            int z0 = e == 0 ? ROJA_Z0 : AZUL_Z0;
            int z1 = e == 0 ? ROJA_Z1 : AZUL_Z1;
            BlockState borde = (e == 0 ? Blocks.RED_NETHER_BRICKS : Blocks.DARK_PRISMARINE).defaultBlockState();
            for (int x = TORRE_X0; x <= TORRE_X1; x++) {
                for (int z = z0; z <= z1; z++) {
                    BlockPos pos = new BlockPos(x, PISO - 1, z);
                    BlockState debe = x == TORRE_X0 || x == TORRE_X1 || z == z0 || z == z1 ? borde : piedra;
                    if (!complejo.getBlockState(pos).equals(debe)) {
                        complejo.setBlock(pos, debe, Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ para los bots
    /**
     * El bot tira su bola a {@code blanco}: casi siempre al cuerpo (un poco adelante de donde va y un poco más alto,
     * porque la bola cae); a veces al piso, a los pies, para quemarlo. Erra más cuanto más lejos. false si no podía.
     */
    static boolean botTira(JugadorBot bot, LivingEntity blanco) {
        if (estado != Estado.JUEGO || !CON_BOLA.contains(bot.getUUID())) {
            return false;
        }
        Vec3 desde = bot.getEyePosition();
        double distancia = Math.sqrt(desde.distanceToSqr(blanco.position()));
        double vuelo = distancia / FUERZA;
        boolean alPiso = bot.getRandom().nextInt(100) < 35;
        Vec3 hacia = blanco.position().add(0.0, alPiso ? -0.2 : blanco.getBbHeight() * 0.55, 0.0)
                .add(blanco.getDeltaMovement().multiply(1.0, 0.0, 1.0).scale(vuelo * 0.6));
        double dx = hacia.x - desde.x;
        double dz = hacia.z - desde.z;
        double dy = hacia.y - desde.y + 0.5 * 0.03 * vuelo * vuelo;
        BolaDeFuego bola = new BolaDeFuego(bot.level(), bot);
        float error = 3.0F + (float) distancia * 0.18F + punteria(bot);
        bola.shoot(dx, dy, dz, FUERZA, error);
        bot.level().addFreshEntity(bola);
        bot.swing(InteractionHand.MAIN_HAND);
        bot.level().playSound(null, bot.getX(), bot.getY(), bot.getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS,
                0.5F, 1.3F);
        CON_BOLA.remove(bot.getUUID());
        bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        RECARGANDO.put(bot.getUUID(), tiempo + RECARGA + 30 + bot.getRandom().nextInt(70));
        return true;
    }

    private static float punteria(JugadorBot bot) {
        return Math.floorMod(bot.getUUID().getLeastSignificantBits(), 100) * 0.03F;
    }

    /** A quién le tira el bot: a uno del otro equipo que vea (o null). */
    @Nullable
    static LivingEntity blanco(JugadorBot bot) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        List<LivingEntity> posibles = new ArrayList<>();
        for (LivingEntity otro : enJuego(complejo)) {
            if (esRojo(otro) != esRojo(bot) && otro.distanceToSqr(bot) <= 40.0 * 40.0 && bot.hasLineOfSight(otro)) {
                posibles.add(otro);
            }
        }
        return posibles.isEmpty() ? null : posibles.get(bot.getRandom().nextInt(posibles.size()));
    }

    /** Un lugar adonde caminar en su torre: lejos del borde, con piso firme y sin magma. */
    static Vec3 paraCaminar(JugadorBot bot) {
        RandomSource azar = bot.getRandom();
        for (int intento = 0; intento < 12; intento++) {
            Vec3 lugar = lugarEnLaTorre(esRojo(bot), azar);
            if (pisoSano(bot.level().getBlockState(BlockPos.containing(lugar.x, PISO - 1, lugar.z)))) {
                return lugar;
            }
        }
        return bot.position();
    }

    /** ¿Está parado en magma (o al lado de un agujero)? Entonces se tiene que mover. */
    static boolean pisoMalo(JugadorBot bot) {
        BlockState abajo = bot.level().getBlockState(BlockPos.containing(bot.getX(), PISO - 1, bot.getZ()));
        return bot.onGround() && !pisoSano(abajo);
    }

    private static boolean pisoSano(BlockState piso) {
        return !piso.isAir() && !piso.is(Blocks.MAGMA_BLOCK);
    }

    /**
     * Si viene una bola del otro equipo derecho al bot (y decide esquivarla: a veces no se da cuenta), adónde se
     * corre: dos bloques para el costado, sin acercarse al borde. null si no hay que esquivar nada.
     */
    @Nullable
    static Vec3 esquivar(JugadorBot bot) {
        if (estado != Estado.JUEGO) {
            return null;
        }
        Vec3 yo = bot.position().add(0.0, 1.0, 0.0);
        for (BolaDeFuego bola : bot.level().getEntitiesOfClass(BolaDeFuego.class, bot.getBoundingBox().inflate(9.0, 4.0, 9.0))) {
            if (!(bola.getOwner() instanceof LivingEntity tirador) || !ROJO.containsKey(tirador.getUUID())
                    || esRojo(tirador) == esRojo(bot)) {
                continue;
            }
            Vec3 v = bola.getDeltaMovement();
            double v2 = v.lengthSqr();
            if (v2 < 0.01) {
                continue;
            }
            Vec3 rel = yo.subtract(bola.position());
            double t = rel.dot(v) / v2;
            if (t < 0.0 || t > 12.0 || rel.subtract(v.scale(t)).lengthSqr() > 1.4) {
                continue;
            }
            long clave = bola.getId() * 31L + bot.getId();
            if (!VISTAS.add(clave) || bot.getRandom().nextInt(100) >= 45) {
                continue;
            }
            Vec3 costado = new Vec3(-v.z, 0.0, v.x).normalize().scale(2.2);
            for (Vec3 lado : new Vec3[] {costado, costado.scale(-1.0)}) {
                Vec3 destino = bot.position().add(lado);
                if (lejosDelBorde(bot, destino)
                        && pisoSano(bot.level().getBlockState(BlockPos.containing(destino.x, PISO - 1, destino.z)))) {
                    return destino;
                }
            }
        }
        return null;
    }

    private static boolean lejosDelBorde(JugadorBot bot, Vec3 punto) {
        if (punto.x < TORRE_X0 + 1.5 || punto.x > TORRE_X1 - 0.5) {
            return false;
        }
        return esRojo(bot) ? punto.z >= ROJA_Z0 + 1.5 && punto.z <= ROJA_Z1 - 0.5
                : punto.z >= AZUL_Z0 + 1.5 && punto.z <= AZUL_Z1 - 0.5;
    }

    // ------------------------------------------------------------------ muertes
    /** Murió uno que jugaba (se cayó, o se quemó): Juego lo anota como eliminado. Acá se avisa. */
    static void alMorir(ServerLevel complejo, LivingEntity muerto, DamageSource fuente) {
        if (!ROJO.containsKey(muerto.getUUID())) {
            return;
        }
        CON_BOLA.remove(muerto.getUUID());
        BOTS.remove(muerto.getUUID());
        Equipos.sacarChaleco(muerto);
        if (muerto instanceof ServerPlayer jugador) {
            sacarBolas(jugador.getInventory());
        }
        Component mensaje = Component.translatable(quemado(fuente) ? "mensaje.juegosdelpatio.se_quemo"
                : "mensaje.juegosdelpatio.se_cayo", Juego.nombreDe(muerto));
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (jugador != muerto) {
                jugador.sendSystemMessage(mensaje.copy().withStyle(ChatFormatting.DARK_RED));
            }
        }
    }

    /** ¿Murió quemado (fuego, o magma)? Si no, se cayó. */
    static boolean quemado(DamageSource fuente) {
        return fuente.is(DamageTypes.ON_FIRE) || fuente.is(DamageTypes.IN_FIRE) || fuente.is(DamageTypes.HOT_FLOOR)
                || fuente.is(DamageTypes.LAVA);
    }

    // ------------------------------------------------------------------ limpiar
    static void limpiar(ServerLevel complejo) {
        for (ServerPlayer jugador : complejo.players()) {
            if (ROJO.containsKey(jugador.getUUID())) {
                Equipos.sacarChaleco(jugador);
                jugador.clearFire();
            }
            sacarBolas(jugador.getInventory());
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> ROJO.containsKey(bot.getUUID()))) {
            Equipos.sacarChaleco(bot);
            bot.clearFire();
            if (bot.getMainHandItem().is(Registro.BOLA_DE_FUEGO_ITEM.get())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
        }
        AABB zona = new AABB(X0, SUELO - 2, Z0, X1 + 1, PISO + 12, Z1 + 1);
        for (ItemEntity tirada : complejo.getEntitiesOfClass(ItemEntity.class, zona,
                tirada -> tirada.getItem().is(Registro.BOLA_DE_FUEGO_ITEM.get()) || Equipos.esChaleco(tirada.getItem()))) {
            tirada.discard();
        }
        for (BolaDeFuego bola : complejo.getEntitiesOfClass(BolaDeFuego.class, zona)) {
            bola.discard();
        }
        restaurarPiso(complejo);
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ROJO.clear();
        RECARGANDO.clear();
        CON_BOLA.clear();
        BOTS.clear();
        VISTAS.clear();
        Equipos.olvidar();
    }

    private static void sacarBolas(Inventory inventario) {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            if (inventario.getItem(i).is(Registro.BOLA_DE_FUEGO_ITEM.get())) {
                inventario.setItem(i, ItemStack.EMPTY);
            }
        }
    }

    // ------------------------------------------------------------------ la arena
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(PALCO_X0 + azar.nextInt(PALCO_X1 - PALCO_X0 + 1) + 0.5, PISO,
                PALCO_Z0 + azar.nextInt(PALCO_Z1 - PALCO_Z0 + 1) + 0.5);
    }

    /** Un lugar arriba de la torre del equipo, a 2 bloques o más del borde. */
    static Vec3 lugarEnLaTorre(boolean rojo, RandomSource azar) {
        int z0 = (rojo ? ROJA_Z0 : AZUL_Z0) + 2;
        int z1 = (rojo ? ROJA_Z1 : AZUL_Z1) - 2;
        return new Vec3(TORRE_X0 + 2 + azar.nextInt(TORRE_X1 - TORRE_X0 - 3) + 0.5, PISO, z0 + azar.nextInt(z1 - z0 + 1) + 0.5);
    }

    private static void llevar(ServerLevel complejo, LivingEntity quien, Vec3 lugar, float giro) {
        quien.setDeltaMovement(Vec3.ZERO);
        quien.fallDistance = 0.0F;
        if (quien instanceof ServerPlayer jugador) {
            jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
        } else {
            quien.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
            quien.setYHeadRot(giro);
            if (quien instanceof JugadorBot bot) {
                bot.getNavigation().stop();
            }
        }
    }

    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionFuego() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        if (estadoComplejo.versionFuego() > 0) {
            BlockState aire = Blocks.AIR.defaultBlockState();
            for (BlockPos pos : BlockPos.betweenClosed(X0, SUELO - 1, Z0, X1, PISO + 17, Z1)) {
                if (!complejo.getBlockState(pos).isAir()) {
                    complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
                }
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionFuego(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Fuego cruzado colocada en {}", ORIGEN);
        return true;
    }

    // ------------------------------------------------------------------ ayudas
    private static List<LivingEntity> enJuego(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : Juego.participantes(complejo)) {
            if (ROJO.containsKey(quien.getUUID())) {
                lista.add(quien);
            }
        }
        return lista;
    }

    private static int vivos(ServerLevel complejo, boolean rojo) {
        int cuantos = 0;
        for (LivingEntity quien : enJuego(complejo)) {
            if (esRojo(quien) == rojo) {
                cuantos++;
            }
        }
        return cuantos;
    }
}
