package com.juegosdelpatio;

import net.minecraft.util.RandomSource;

/** Nombres de usuario inventados para los bots. */
public final class Nombres {
    private static final String[] BASES = {
            "Mati", "Lucia", "Santi", "Valen", "Juli", "Nico", "Cami", "Fran", "Tomi", "Agus",
            "Sofi", "Maxi", "Lola", "Benja", "Emi", "Joaco", "Male", "Feli", "Thiago", "Bruno",
            "Abril", "Martu", "Facu", "Lauti", "Mica", "Zoe", "Lucas", "Mia", "Dylan", "Uma",
            "Pili", "Gonza", "Rocio", "Ivan", "Sol", "Ale", "Dani", "Leo", "Nahue", "Paz",
            "Vicky", "Rama", "Guada", "Tobi", "Delfi", "Seba", "Flor", "Kevin", "Luna", "Bauti"
    };
    private static final String[] FINALES = {
            "", "", "", "_07", "123", "MC", "XD", "Pro", "2012", "_uy", "Gamer", "Craft", "_01", "99", "_ok", "Max"
    };

    private Nombres() {
    }

    public static String alAzar(RandomSource azar) {
        String nombre = BASES[azar.nextInt(BASES.length)] + FINALES[azar.nextInt(FINALES.length)];
        return nombre.length() > 16 ? nombre.substring(0, 16) : nombre;
    }
}
