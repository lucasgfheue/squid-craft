package com.juegosdelpatio;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Pistola, rifle o escopeta: clic derecho para disparar. Los jugadores gastan una bala por disparo
 * (en creativo no); los guardias no necesitan balas.
 */
public class ArmaDeFuego extends Item {
    private final float danio;
    private final int recarga;
    private final float velocidad;
    private final float imprecision;
    private final int perdigones;
    private final float tono;
    /** Cada cuántos ticks dispara un guardia con esta arma, y desde qué distancia. */
    public final int intervaloGuardia;
    public final float alcanceGuardia;

    public ArmaDeFuego(Properties propiedades, float danio, int recarga, float velocidad, float imprecision,
                       int perdigones, float tono, int intervaloGuardia, float alcanceGuardia) {
        super(propiedades);
        this.danio = danio;
        this.recarga = recarga;
        this.velocidad = velocidad;
        this.imprecision = imprecision;
        this.perdigones = perdigones;
        this.tono = tono;
        this.intervaloGuardia = intervaloGuardia;
        this.alcanceGuardia = alcanceGuardia;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level nivel, Player jugador, InteractionHand mano) {
        ItemStack arma = jugador.getItemInHand(mano);
        boolean infinitas = jugador.getAbilities().instabuild;
        ItemStack municion = infinitas ? ItemStack.EMPTY : buscarMunicion(jugador);
        if (!infinitas && municion.isEmpty()) {
            if (!nivel.isClientSide()) {
                nivel.playSound(null, jugador.getX(), jugador.getY(), jugador.getZ(),
                        SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.6F, 1.6F);
                jugador.displayClientMessage(
                        Component.translatable("mensaje.juegosdelpatio.sin_balas").withStyle(ChatFormatting.GRAY), true);
            }
            jugador.getCooldowns().addCooldown(this, 10);
            return InteractionResultHolder.fail(arma);
        }
        if (!nivel.isClientSide()) {
            Vec3 mira = jugador.getLookAngle();
            disparar(jugador, mira.x, mira.y, mira.z, imprecision);
            if (!infinitas) {
                municion.shrink(1);
            }
        }
        jugador.getCooldowns().addCooldown(this, recarga);
        return InteractionResultHolder.consume(arma);
    }

    /** Disparo de un guardia hacia su objetivo (un poco menos preciso que un jugador). */
    public void dispararHacia(LivingEntity tirador, LivingEntity objetivo) {
        double dx = objetivo.getX() - tirador.getX();
        double dy = objetivo.getY(0.5) - tirador.getEyeY();
        double dz = objetivo.getZ() - tirador.getZ();
        disparar(tirador, dx, dy, dz, imprecision + 3.0F);
    }

    private void disparar(LivingEntity tirador, double dx, double dy, double dz, float desvio) {
        Level nivel = tirador.level();
        for (int i = 0; i < perdigones; i++) {
            Bala bala = new Bala(nivel, tirador, danio);
            bala.shoot(dx, dy, dz, velocidad, desvio);
            nivel.addFreshEntity(bala);
        }
        nivel.playSound(null, tirador.getX(), tirador.getY(), tirador.getZ(),
                SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1.2F, tono);
        if (nivel instanceof ServerLevel servidor) {
            Vec3 boca = tirador.getEyePosition().add(tirador.getLookAngle().scale(0.8));
            servidor.sendParticles(ParticleTypes.SMOKE, boca.x, boca.y, boca.z, 3, 0.04, 0.04, 0.04, 0.01);
        }
    }

    private static ItemStack buscarMunicion(Player jugador) {
        if (jugador.getOffhandItem().is(Registro.BALA_ITEM.get())) {
            return jugador.getOffhandItem();
        }
        Inventory inventario = jugador.getInventory();
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack objeto = inventario.getItem(i);
            if (objeto.is(Registro.BALA_ITEM.get())) {
                return objeto;
            }
        }
        return ItemStack.EMPTY;
    }

    @Override
    public void appendHoverText(ItemStack objeto, TooltipContext contexto, List<Component> lineas, TooltipFlag opciones) {
        String texto = perdigones > 1 ? Math.round(danio) + " x " + perdigones : String.valueOf(Math.round(danio));
        lineas.add(Component.translatable("item.juegosdelpatio.arma.danio", texto).withStyle(ChatFormatting.GRAY));
        lineas.add(Component.translatable("item.juegosdelpatio.arma.municion").withStyle(ChatFormatting.DARK_GRAY));
    }
}
