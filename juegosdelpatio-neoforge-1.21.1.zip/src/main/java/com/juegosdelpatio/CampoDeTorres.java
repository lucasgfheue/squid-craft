package com.juegosdelpatio;

import java.util.Arrays;
import java.util.function.BiPredicate;
import javax.annotation.Nullable;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Un campo de torres: arriba de cada una, un rectángulo donde pararse (x0, x1, z0, z1, en bloques) y de cuál se puede
 * saltar a cuál. Lo usan los juegos en torres (Asientos al vacío, El tejo y Los estandartes) para saber en qué torre
 * está cada uno y, los bots, para ir de una torre a otra saltando (ver {@link SaltosBot}). En Los estandartes las
 * torres de los costados se caen: a una torre caída (o que se está por caer) ya no se va, pero el que está arriba
 * todavía puede saltar a otra.
 */
final class CampoDeTorres {
    /** A qué distancia del borde salta un bot, y cuánto adentro de la otra torre cae. */
    static final double BORDE = 0.55;
    static final double ADENTRO = 1.6;
    /** Donde se para la gente: arriba de las torres. */
    final int piso;
    final int[][] torres;
    final int[][] vecinos;
    /** Por dónde se sale de cada torre para saltar (x0, x1 del borde sur o norte), si no es todo el lado; o null. */
    private final int[][] salidas;
    /** Qué bloques de arriba de una torre son piso (para las que no son rectángulos enteros, como el cielo). */
    @Nullable
    private final BiPredicate<Integer, Integer> esPiso;
    private final int[][] saltos;
    private final int[][] siguiente;
    /** Las torres que se cayeron (o se están por caer): ahí no va nadie. */
    private final boolean[] caidas;

    CampoDeTorres(int piso, int[][] torres, int[][] vecinos, int[][] salidas, @Nullable BiPredicate<Integer, Integer> esPiso) {
        this.piso = piso;
        this.torres = torres;
        this.vecinos = vecinos;
        this.salidas = salidas;
        this.esPiso = esPiso;
        int n = torres.length;
        saltos = new int[n][n];
        siguiente = new int[n][n];
        caidas = new boolean[n];
        calcular();
    }

    /** Los caminos más cortos (Floyd-Warshall): sin pasar por las torres caídas ni llegar a ellas. */
    private void calcular() {
        int n = torres.length;
        int[][] costo = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                saltos[i][j] = i == j ? 0 : 1000;
                costo[i][j] = i == j ? 0 : 1000;
                siguiente[i][j] = i == j ? i : -1;
            }
            for (int j : vecinos[i]) {
                if (caidas[j]) {
                    continue;                                     // a una torre caída no se salta
                }
                saltos[i][j] = 1;
                costo[i][j] = hueco(i, j) >= 3 ? 3 : 1;          // los saltos largos, solo si no hay otra
                siguiente[i][j] = j;
            }
        }
        for (int k = 0; k < n; k++) {
            if (caidas[k]) {
                continue;                                         // ni se pasa por ella
            }
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    saltos[i][j] = Math.min(saltos[i][j], saltos[i][k] + saltos[k][j]);
                    if (costo[i][k] + costo[k][j] < costo[i][j]) {
                        costo[i][j] = costo[i][k] + costo[k][j];
                        siguiente[i][j] = siguiente[i][k];
                    }
                }
            }
        }
    }

    /** Esa torre se cae (o se está por caer): ya no se va para ahí (el que está arriba todavía puede salir). */
    void quitar(int torre) {
        if (!caidas[torre]) {
            caidas[torre] = true;
            calcular();
        }
    }

    boolean caida(int torre) {
        return torre >= 0 && caidas[torre];
    }

    /** Todas las torres de nuevo en pie. */
    void restaurar() {
        boolean habia = false;
        for (boolean c : caidas) {
            habia |= c;
        }
        if (habia) {
            Arrays.fill(caidas, false);
            calcular();
        }
    }

    int cuantas() {
        return torres.length;
    }

    /** Cuántos saltos hacen falta de una torre a otra (por el camino más corto). */
    int saltos(int desde, int hasta) {
        return saltos[desde][hasta];
    }

    /** La próxima torre en el camino de {@code desde} a {@code hasta} (evita los saltos largos si puede), o -1. */
    int proximo(int desde, int hasta) {
        return desde < 0 || hasta < 0 ? -1 : siguiente[desde][hasta];
    }

    /** Cuántos bloques de vacío hay entre dos torres vecinas. */
    int hueco(int a, int b) {
        int[] p = torres[a];
        int[] q = torres[b];
        if (q[2] > p[3]) {
            return q[2] - p[3] - 1;
        }
        if (q[3] < p[2]) {
            return p[2] - q[3] - 1;
        }
        return q[0] > p[1] ? q[0] - p[1] - 1 : p[0] - q[1] - 1;
    }

    /** En qué torre está ese bloque de arriba (o -1). */
    int torreEn(double x, double z) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        for (int i = 0; i < torres.length; i++) {
            int[] t = torres[i];
            if (bx >= t[0] && bx <= t[1] && bz >= t[2] && bz <= t[3] && (esPiso == null || esPiso.test(bx, bz))) {
                return i;
            }
        }
        return -1;
    }

    /** En qué torre está parado (arriba), mirando también las esquinas de los pies; o -1. */
    int torreDe(LivingEntity quien) {
        if (quien.getY() < piso - 0.5 || quien.getY() > piso + 0.75) {
            return -1;
        }
        int aca = torreEn(quien.getX(), quien.getZ());
        if (aca >= 0) {
            return aca;
        }
        double r = quien.getBbWidth() / 2.0 - 0.02;
        for (double[] esquina : new double[][] {{r, r}, {r, -r}, {-r, r}, {-r, -r}}) {
            aca = torreEn(quien.getX() + esquina[0], quien.getZ() + esquina[1]);
            if (aca >= 0) {
                return aca;
            }
        }
        return -1;
    }

    /** Un lugar al azar arriba de una torre, a {@code margen} bloques del borde (o más). */
    Vec3 lugarEn(int torre, RandomSource azar, int margen) {
        int[] t = torres[torre];
        int ancho = Math.max(1, t[1] - t[0] + 1 - 2 * margen);
        int largo = Math.max(1, t[3] - t[2] + 1 - 2 * margen);
        for (int intento = 0; intento < 30; intento++) {
            int x = t[0] + margen + azar.nextInt(ancho);
            int z = t[2] + margen + azar.nextInt(largo);
            if (esPiso == null || esPiso.test(x, z) && esPiso.test(x - margen, z) && esPiso.test(x + margen, z)
                    && esPiso.test(x, z + margen) && esPiso.test(x, z - margen)) {
                return new Vec3(x + 0.5, piso, z + 0.5);
            }
        }
        return new Vec3((t[0] + t[1]) / 2.0 + 0.5, piso, (t[2] + t[3]) / 2.0 + 0.5);
    }

    /**
     * Para un bot, el salto de una torre a la vecina: de dónde salta (cerca del borde) y dónde cae (adentro de la
     * otra), en una línea derecha por donde las dos torres se enfrentan.
     */
    Vec3[] salto(int desde, int hacia, RandomSource azar) {
        int[] a = torres[desde];
        int[] b = torres[hacia];
        int ax0 = salidas[desde] != null ? salidas[desde][0] : a[0];
        int ax1 = salidas[desde] != null ? salidas[desde][1] : a[1];
        int bx0 = salidas[hacia] != null ? salidas[hacia][0] : b[0];
        int bx1 = salidas[hacia] != null ? salidas[hacia][1] : b[1];
        if (b[2] > a[3]) {                                       // hacia el sur
            double x = elegir(Math.max(ax0, bx0), Math.min(ax1, bx1), azar);
            return new Vec3[] {new Vec3(x, piso, a[3] + 1 - BORDE), new Vec3(x, piso, b[2] + ADENTRO)};
        }
        if (b[3] < a[2]) {                                       // hacia el norte
            double x = elegir(Math.max(ax0, bx0), Math.min(ax1, bx1), azar);
            return new Vec3[] {new Vec3(x, piso, a[2] + BORDE), new Vec3(x, piso, b[3] + 1 - ADENTRO)};
        }
        double z = elegir(Math.max(a[2], b[2]), Math.min(a[3], b[3]), azar);
        if (b[0] > a[1]) {                                       // hacia el este
            return new Vec3[] {new Vec3(a[1] + 1 - BORDE, piso, z), new Vec3(b[0] + ADENTRO, piso, z)};
        }
        return new Vec3[] {new Vec3(a[0] + BORDE, piso, z), new Vec3(b[1] + 1 - ADENTRO, piso, z)};   // al oeste
    }

    private static double elegir(int desde, int hasta, RandomSource azar) {
        return desde + 0.5 + azar.nextDouble() * Math.max(0, hasta - desde);
    }
}
