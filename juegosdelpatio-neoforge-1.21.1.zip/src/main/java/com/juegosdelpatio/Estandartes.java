package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.joml.Vector3f;

/**
 * El juego 7, el último, "Los estandartes": un juego nuevo, con un guiño a capturar la bandera, en un campo largo de
 * noche, partido por una grieta enorme (ver gen_estandartes.py).
 *
 * <ol>
 *   <li>Se reparten dos equipos al azar, cada uno con su chaleco y una espada de hierro. Cada equipo empieza en su lado
 *       del campo (el rojo al oeste y el azul al este), junto a su fortín, donde está parado su estandarte.</li>
 *   <li>Después de 10 segundos de cuenta, a jugar: hay que tocar el estandarte del otro equipo (así se agarra) y
 *       llevarlo hasta el propio. La grieta del medio se cruza saltando por las torres de pasto (tres caminos: al norte,
 *       en el medio y al sur). El que lleva el estandarte lo tiene puesto en la cabeza, brilla y no puede pegar ni
 *       empujar. Si muere, el estandarte vuelve a su fortín.</li>
 *   <li>El que muere (por la espada, o porque se cayó a la grieta) queda eliminado. A los del propio equipo no se les
 *       puede pegar.</li>
 *   <li>El equipo que pierde su estandarte, pierde: les caen rayos y quedan todos eliminados. Si un equipo muere entero,
 *       también pierde. Si a los 8 minutos nadie ganó, pierde el que tenga menos gente en pie (si están parejos, pasan
 *       todos). Los que quedan ganan los juegos y se reparten el premio.</li>
 * </ol>
 */
public final class Estandartes {
    // ------------------------------------------------------------------ la arena (igual que gen_estandartes.py)
    public static final ResourceLocation ARENA = Complejo.id("estandartes");
    /** Esquina de la plantilla estandartes.nbt (211 x 96 x 111): abajo de todo, en el fondo de la grieta. */
    public static final BlockPos ORIGEN = new BlockPos(7895, 40, -20);
    /** La 1 era el patio de La batalla y la 2 un campo de torres, en el mismo lugar: se borran y se pone esta. */
    static final int VERSION_ARENA = 3;
    /** Toda la plantilla: lo que se mantiene cargado mientras se juega. */
    static final int X0 = 7895;
    static final int X1 = 8105;
    static final int Z0 = -20;
    static final int Z1 = 90;
    /** Lo que ocupaban las arenas de antes (x0, x1, z0, z1, y0, y1): se borra antes de poner esta. */
    private static final int[] VIEJAS = {7955, 8045, -17, 54, 38, 118};
    private static final int ABAJO = 38;
    private static final int ARRIBA = 135;
    /** Donde se para la gente en lo llano junto a la grieta, en los fortines y arriba de las torres de la grieta. */
    static final int PISO = 101;
    static final int FONDO = 41;
    static final int CX = 8000;
    /** La mitad del ancho de la grieta: va de x 7984 a 8016 (a veces un bloque más ancha, lejos de los caminos). */
    static final int GRIETA = 16;
    /**
     * Los tres caminos para cruzar la grieta, saltando (x0, x1, z0, z1 de donde se para la gente): en cada uno, el borde
     * oeste (en lo llano), las torres de la grieta y el borde este. El norte del 0 al 4, el medio del 5 al 10 y el sur
     * del 11 al 15. Entre uno y otro hay 2 o 3 bloques de vacío.
     */
    static final int[][] TORRES = {
            {7979, 7983, 18, 24}, {7986, 7992, 18, 24}, {7996, 8004, 18, 24}, {8008, 8014, 18, 24}, {8017, 8021, 18, 24},
            {7979, 7983, 44, 48}, {7986, 7990, 44, 48}, {7994, 7998, 44, 48}, {8002, 8006, 44, 48}, {8010, 8014, 44, 48},
            {8017, 8021, 44, 48},
            {7979, 7983, 68, 74}, {7986, 7992, 68, 74}, {7996, 8004, 68, 74}, {8008, 8014, 68, 74}, {8017, 8021, 68, 74},
    };
    static final int[][] VECINOS = {
            {1}, {0, 2}, {1, 3}, {2, 4}, {3},
            {6}, {5, 7}, {6, 8}, {7, 9}, {8, 10}, {9},
            {12}, {11, 13}, {12, 14}, {13, 15}, {14},
    };
    static final CampoDeTorres CAMPO = new CampoDeTorres(PISO, TORRES, VECINOS, new int[TORRES.length][], null);
    /** De cada camino (norte, medio y sur): el borde oeste y el borde este. */
    static final int[][] CAMINOS = {{0, 4}, {5, 10}, {11, 15}};
    /** Donde está parado cada estandarte, sobre oro, en el medio de su fortín (el rojo mira al este y el azul al oeste). */
    static final BlockPos ESTANDARTE_ROJO = new BlockPos(7912, PISO, 46);
    static final BlockPos ESTANDARTE_AZUL = new BlockPos(8088, PISO, 46);
    private static final int GIRO_ROJO = 12;
    private static final int GIRO_AZUL = 4;
    /** El palco del comandante, al norte, más alto y separado del campo: el piso en y = 111. */
    static final Vec3 PODIO = new Vec3(8000.5, 114.0, -13.5);
    /** Los sargentos, en el palco: dos adelante, en las esquinas, y dos junto al podio. */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(7980.5, 112.0, -4.5), new Vec3(8020.5, 112.0, -4.5),
            new Vec3(7992.5, 112.0, -13.5), new Vec3(8008.5, 112.0, -13.5),
    };
    static final float[] GIROS_SARGENTOS = {0.0F, 0.0F, 0.0F, 0.0F};

    // ------------------------------------------------------------------ reglas
    private static final int CUENTA = 10 * 20;
    /** La pelea dura 8 minutos (si nadie gana antes). */
    static final int DURACION = 8 * 60 * 20;
    /** Desde el minuto 5, la mitad de los bots que cuidaban salen a buscar el otro estandarte (si no, se trabaría). */
    private static final int DEFENSA_HASTA = 5 * 60 * 20;
    /** A cuántos bloques del estandarte hay que estar para agarrarlo, y para dejarlo junto al propio. */
    private static final double TOCAR = 1.2;
    private static final double LLEGAR = 1.5;
    /** Cuando un equipo pierde: durante 3 segundos les caen rayos (uno cada 3 ticks); después, quedan eliminados los que sigan. */
    private static final int FINAL = 60;
    private static final int CADA_RAYO = 3;

    /** Lo que hace cada bot: cuidar su estandarte, o ir a buscar el otro por el camino del medio, el del norte o el del sur. */
    static final int DEFENSOR = 0;
    static final int CENTRO = 1;
    static final int NORTE = 2;
    static final int SUR = 3;

    private enum Estado { NINGUNO, CUENTA, PELEA, FINAL, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int pasaron;
    /** De qué equipo es cada uno (true: rojo). */
    private static final Map<UUID, Boolean> ROJO = new HashMap<>();
    private static final Map<UUID, Integer> PAPELES = new HashMap<>();
    /** Quién lleva el estandarte rojo (un azul) y quién el azul (un rojo); null: está en su fortín. */
    @Nullable
    private static UUID llevaRojo;
    @Nullable
    private static UUID llevaAzul;
    /** Lo que los jugadores tenían en la cabeza antes del estandarte, para devolvérselo. */
    private static final Map<UUID, ItemStack> CABEZAS = new HashMap<>();
    /** Cómo estaba cada bloque que se cambió (el estandarte clavado al final), para dejar todo como antes. */
    private static final Map<BlockPos, BlockState> GUARDADOS = new LinkedHashMap<>();
    /** El equipo que perdió (en el final) y por qué. */
    private static boolean pierdenRojos;
    private static String motivoFinal = "perdio_tu_equipo";
    @Nullable
    private static List<LivingEntity> enJuegoCache;
    private static long enJuegoTick = -1;

    private Estandartes() {
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean peleando() {
        return estado == Estado.PELEA;
    }

    static int pasaron() {
        return pasaron;
    }

    static boolean juega(LivingEntity quien) {
        return estado != Estado.NINGUNO && ROJO.containsKey(quien.getUUID()) && quien.isAlive() && !Juego.eliminado(quien);
    }

    static boolean esRojo(LivingEntity quien) {
        return Boolean.TRUE.equals(ROJO.get(quien.getUUID()));
    }

    /** En el juego, los bots no se chocan con nadie (si no, en una torre llena se tirarían unos a otros a la grieta). */
    static boolean sinChoques(LivingEntity quien) {
        return estado != Estado.NINGUNO && ROJO.containsKey(quien.getUUID());
    }

    /** ¿Lleva un estandarte (el del otro equipo)? */
    static boolean lleva(LivingEntity quien) {
        UUID uuid = quien.getUUID();
        return uuid.equals(llevaRojo) || uuid.equals(llevaAzul);
    }

    /** Por qué quedó eliminado el que murió: lo mataron, se cayó a la grieta, o perdió su equipo. */
    static String motivo(LivingEntity muerto, DamageSource fuente) {
        if (estado == Estado.FINAL && ROJO.containsKey(muerto.getUUID()) && esRojo(muerto) == pierdenRojos) {
            return motivoFinal;
        }
        if (muerto.getY() < PISO - 4) {
            return "te_caiste_grieta";
        }
        return fuente.getEntity() instanceof LivingEntity asesino && asesino != muerto ? "te_mataron" : "moriste";
    }

    // ------------------------------------------------------------------ empezar
    static void empezar(ServerLevel complejo, List<LivingEntity> gente) {
        olvidar();
        for (boolean rojo : new boolean[] {true, false}) {
            BlockPos clavado = pedestal(rojo).offset(0, 0, 1);         // el trofeo de un juego que se cortó, afuera
            if (complejo.getBlockState(clavado).is(Blocks.RED_BANNER) || complejo.getBlockState(clavado).is(Blocks.BLUE_BANNER)) {
                complejo.setBlock(clavado, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
            ponerEstandarte(complejo, rojo);
        }
        RandomSource azar = complejo.getRandom();
        List<List<LivingEntity>> equipos = Equipos.repartir(gente, azar);
        for (int e = 0; e < 2; e++) {
            boolean rojo = e == 0;
            List<JugadorBot> bots = new ArrayList<>();
            for (LivingEntity quien : equipos.get(e)) {
                ROJO.put(quien.getUUID(), rojo);
                Equipos.ponerChaleco(quien, rojo);
                Vec3 lugar = lugarDeInicio(complejo, rojo, azar);
                float giro = rojo ? -90.0F : 90.0F;                   // mirando a la grieta
                quien.setDeltaMovement(Vec3.ZERO);
                quien.fallDistance = 0.0F;
                if (quien instanceof ServerPlayer jugador) {
                    jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
                    ItemStack espada = espada();
                    if (jugador.getMainHandItem().isEmpty()) {
                        jugador.setItemInHand(InteractionHand.MAIN_HAND, espada);
                    } else if (!jugador.getInventory().add(espada)) {
                        jugador.drop(espada, false);
                    }
                    Juego.titulo(jugador, Component.translatable(rojo ? "titulo.juegosdelpatio.equipo_rojo"
                                    : "titulo.juegosdelpatio.equipo_azul").withStyle(rojo ? ChatFormatting.RED : ChatFormatting.BLUE),
                            Component.translatable(rojo ? "titulo.juegosdelpatio.estandartes_detalle_rojo"
                                    : "titulo.juegosdelpatio.estandartes_detalle_azul").withStyle(ChatFormatting.GRAY),
                            5, 60, 15);
                    jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, rojo ? 0.8F : 1.2F);
                } else {
                    quien.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
                    quien.setYHeadRot(giro);
                }
                if (quien instanceof JugadorBot bot) {
                    bots.add(bot);
                    bot.getNavigation().stop();
                    bot.setItemSlot(EquipmentSlot.MAINHAND, espada());
                    bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
                }
            }
            repartirPapeles(bots, azar);
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.estandartes_equipos", equipos.get(0).size(),
                equipos.get(1).size(), CUENTA / 20));
        estado = Estado.CUENTA;
        tiempo = 0;
    }

    /**
     * Qué hace cada bot de un equipo: un tercio cuida el estandarte (uno por lo menos, si son dos o más) y los demás van
     * a buscar el otro: la mitad por el camino del medio y la otra mitad por los del norte y el sur.
     */
    private static void repartirPapeles(List<JugadorBot> bots, RandomSource azar) {
        for (int i = bots.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            JugadorBot cambio = bots.get(i);
            bots.set(i, bots.get(j));
            bots.set(j, cambio);
        }
        int defensores = bots.size() < 2 ? 0 : Math.max(1, Math.round(bots.size() / 3.0F));
        for (int i = 0; i < bots.size(); i++) {
            int papel = i < defensores ? DEFENSOR : (i - defensores) % 4 == 1 ? NORTE : (i - defensores) % 4 == 3 ? SUR : CENTRO;
            PAPELES.put(bots.get(i).getUUID(), papel);
        }
    }

    /** La espada de los estandartes: de hierro, que no se rompe (y marcada, para sacarla al final). */
    private static ItemStack espada() {
        ItemStack espada = new ItemStack(Items.IRON_SWORD);
        espada.set(DataComponents.UNBREAKABLE, new Unbreakable(true));
        espada.set(DataComponents.ITEM_NAME, Component.translatable("item.juegosdelpatio.espada_bastion"));
        CompoundTag marca = new CompoundTag();
        marca.putBoolean("EspadaBastion", true);
        espada.set(DataComponents.CUSTOM_DATA, CustomData.of(marca));
        return espada;
    }

    static boolean esEspada(ItemStack cosa) {
        CustomData datos = cosa.get(DataComponents.CUSTOM_DATA);
        return datos != null && cosa.is(Items.IRON_SWORD) && datos.copyTag().getBoolean("EspadaBastion");
    }

    /** El estandarte de un equipo, para llevar puesto (marcado, para sacarlo al final). */
    private static ItemStack estandarte(boolean rojo) {
        ItemStack cosa = new ItemStack(rojo ? Items.RED_BANNER : Items.BLUE_BANNER);
        cosa.set(DataComponents.ITEM_NAME, Component.translatable(rojo ? "item.juegosdelpatio.estandarte_rojo"
                : "item.juegosdelpatio.estandarte_azul"));
        CompoundTag marca = new CompoundTag();
        marca.putBoolean("Estandarte", true);
        cosa.set(DataComponents.CUSTOM_DATA, CustomData.of(marca));
        return cosa;
    }

    static boolean esEstandarte(ItemStack cosa) {
        CustomData datos = cosa.get(DataComponents.CUSTOM_DATA);
        return datos != null && (cosa.is(Items.RED_BANNER) || cosa.is(Items.BLUE_BANNER)) && datos.copyTag().getBoolean("Estandarte");
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        switch (estado) {
            case CUENTA -> {
                int faltan = CUENTA - tiempo;
                if (faltan > 0 && faltan <= 100 && faltan % 20 == 0) {
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 1.0F, 1.0F);
                        jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.cuenta_juego", faltan / 20)
                                .withStyle(ChatFormatting.YELLOW), true);
                    }
                }
                if (faltan <= 0) {
                    estado = Estado.PELEA;
                    tiempo = 0;
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.a_pelear").withStyle(ChatFormatting.RED),
                                Component.empty(), 2, 25, 8);
                        jugador.playNotifySound(SoundEvents.RAID_HORN.value(), SoundSource.MASTER, 0.7F, 1.0F);
                    }
                }
            }
            case PELEA -> pelea(complejo);
            case FINAL -> {
                if (tiempo % CADA_RAYO == 0) {
                    rayoAlQueSigue(complejo);
                }
                if (tiempo >= FINAL || perdedores(complejo).isEmpty()) {
                    eliminarPerdedores(complejo);
                }
            }
            default -> {
            }
        }
        if (tiempo % 10 == 1 && (estado == Estado.CUENTA || estado == Estado.PELEA)) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    private static void pelea(ServerLevel complejo) {
        cuidarEstandarte(complejo, true);
        if (estado == Estado.PELEA) {
            cuidarEstandarte(complejo, false);
        }
        if (estado != Estado.PELEA) {
            return;                                                // alguien llegó con el estandarte
        }
        for (LivingEntity quien : enJuego(complejo)) {             // ¿alguien tocó el estandarte del otro equipo?
            boolean rojo = esRojo(quien);
            boolean libre = rojo ? llevaAzul == null : llevaRojo == null;
            if (libre && !lleva(quien) && cerca(quien, pedestal(!rojo), TOCAR)) {
                agarrar(complejo, quien, !rojo);
            }
        }
        if (tiempo % 10 == 0) {
            avisar(complejo);
            caidos(complejo);
            for (ItemEntity tirado : complejo.getEntitiesOfClass(ItemEntity.class, caja(), tirado -> esEstandarte(tirado.getItem()))) {
                tirado.discard();                                  // el estandarte no se tira
            }
        }
        int rojos = vivos(complejo, true);
        int azules = vivos(complejo, false);
        if (rojos == 0 || azules == 0) {
            if (rojos == 0 && azules == 0) {
                Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.estandartes_nadie"));
                terminar(complejo);
            } else {
                Juego.decir(complejo, Component.translatable(rojos == 0 ? "juego.juegosdelpatio.estandartes_sin_rojos"
                        : "juego.juegosdelpatio.estandartes_sin_azules"));
                perder(complejo, rojos == 0, "perdio_tu_equipo", true);
            }
        } else if (tiempo >= DURACION) {
            porTiempo(complejo, true);
        }
    }

    private static void barra(ServerLevel complejo) {
        int quedan = estado == Estado.CUENTA ? DURACION : Math.max(0, DURACION - tiempo);
        Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.estandartes", Juego.reloj(quedan),
                        vivos(complejo, true), vivos(complejo, false)),
                estado == Estado.CUENTA ? BossEvent.BossBarColor.YELLOW : BossEvent.BossBarColor.PURPLE,
                quedan / (float) DURACION);
    }

    /** Al que lleva un estandarte, se le recuerda adónde ir. */
    private static void avisar(ServerLevel complejo) {
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (juega(jugador) && lleva(jugador)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.llevas_estandarte")
                        .withStyle(ChatFormatting.GOLD), true);
            }
        }
    }

    /** El que se cayó a la grieta y no murió (aterrizó vivo allá abajo), queda eliminado igual. */
    private static void caidos(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getY() < PISO - 20 && quien.onGround()) {
                quitarCosas(quien);
                Juego.eliminar(complejo, quien, false, "te_caiste_grieta");
            }
        }
    }

    // ------------------------------------------------------------------ los estandartes
    static BlockPos pedestal(boolean rojo) {
        return rojo ? ESTANDARTE_ROJO : ESTANDARTE_AZUL;
    }

    /** ¿Está a menos de {@code distancia} bloques (de costado) del estandarte, parado en el fortín? */
    private static boolean cerca(LivingEntity quien, BlockPos pos, double distancia) {
        double dx = quien.getX() - (pos.getX() + 0.5);
        double dz = quien.getZ() - (pos.getZ() + 0.5);
        return dx * dx + dz * dz <= distancia * distancia && Math.abs(quien.getY() - PISO) < 1.5;
    }

    /** El estandarte, parado en su pedestal de oro. */
    private static void ponerEstandarte(ServerLevel complejo, boolean rojo) {
        BlockPos pos = pedestal(rojo);
        if (complejo.getBlockState(pos.below()).isAir()) {
            return;
        }
        complejo.setBlock(pos, (rojo ? Blocks.RED_BANNER : Blocks.BLUE_BANNER).defaultBlockState()
                .setValue(BlockStateProperties.ROTATION_16, rojo ? GIRO_ROJO : GIRO_AZUL), Block.UPDATE_CLIENTS);
    }

    /** Lo tocó uno del otro equipo: se lo lleva puesto en la cabeza. */
    private static void agarrar(ServerLevel complejo, LivingEntity quien, boolean rojoEstandarte) {
        if (rojoEstandarte) {
            llevaRojo = quien.getUUID();
        } else {
            llevaAzul = quien.getUUID();
        }
        BlockPos pos = pedestal(rojoEstandarte);
        complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
        ponerEnLaCabeza(quien, rojoEstandarte);
        quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
        Component nombre = Juego.nombreDe(quien);
        Component aviso = Component.translatable(rojoEstandarte ? "mensaje.juegosdelpatio.robo_rojo"
                : "mensaje.juegosdelpatio.robo_azul", nombre).withStyle(rojoEstandarte ? ChatFormatting.BLUE : ChatFormatting.RED);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.sendSystemMessage(aviso);
            jugador.playNotifySound(SoundEvents.RAID_HORN.value(), SoundSource.MASTER, 0.6F, 1.3F);
            if (jugador == quien) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.tienes_estandarte").withStyle(ChatFormatting.GOLD),
                        Component.translatable("titulo.juegosdelpatio.tienes_estandarte_detalle").withStyle(ChatFormatting.GRAY),
                        0, 40, 10);
            } else if (juega(jugador) && esRojo(jugador) == rojoEstandarte) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.les_robaron").withStyle(ChatFormatting.RED),
                        Component.translatable("titulo.juegosdelpatio.les_robaron_detalle", nombre).withStyle(ChatFormatting.GRAY),
                        0, 40, 10);
            }
        }
    }

    private static void ponerEnLaCabeza(LivingEntity quien, boolean rojoEstandarte) {
        ItemStack antes = quien.getItemBySlot(EquipmentSlot.HEAD);
        if (quien instanceof ServerPlayer && !esEstandarte(antes) && !CABEZAS.containsKey(quien.getUUID())) {
            CABEZAS.put(quien.getUUID(), antes.copy());
        }
        quien.setItemSlot(EquipmentSlot.HEAD, estandarte(rojoEstandarte));
        if (quien instanceof JugadorBot bot) {
            bot.setDropChance(EquipmentSlot.HEAD, 0.0F);
        }
    }

    /** Se saca el estandarte de la cabeza (y el jugador vuelve a tener lo que tenía); también los que tenga guardados. */
    private static void sacarDeLaCabeza(LivingEntity quien) {
        ItemStack antes = CABEZAS.remove(quien.getUUID());
        if (esEstandarte(quien.getItemBySlot(EquipmentSlot.HEAD))) {
            quien.setItemSlot(EquipmentSlot.HEAD, antes != null ? antes : ItemStack.EMPTY);
        }
        if (quien instanceof ServerPlayer jugador) {
            sacar(jugador.getInventory(), true);
            if (esEstandarte(jugador.containerMenu.getCarried())) {
                jugador.containerMenu.setCarried(ItemStack.EMPTY);
            }
        }
    }

    /**
     * Cada tick, el que lleva un estandarte: si ya no juega (murió, se fue), el estandarte vuelve a su fortín. Si no,
     * lo sigue teniendo puesto (no se lo puede sacar), brilla, y si llegó a su propio estandarte, gana su equipo.
     */
    private static void cuidarEstandarte(ServerLevel complejo, boolean rojoEstandarte) {
        UUID uuid = rojoEstandarte ? llevaRojo : llevaAzul;
        if (uuid == null) {
            return;
        }
        LivingEntity quien = buscar(complejo, uuid);
        if (quien == null || !juega(quien)) {
            if (quien != null) {
                sacarDeLaCabeza(quien);
            }
            volver(complejo, rojoEstandarte);
            return;
        }
        if (quien instanceof ServerPlayer jugador) {
            int tiene = 0;
            Inventory inventario = jugador.getInventory();
            for (int i = 0; i < inventario.getContainerSize(); i++) {
                if (esEstandarte(inventario.getItem(i))) {
                    tiene++;
                }
            }
            if (tiene != 1 || !esEstandarte(jugador.getItemBySlot(EquipmentSlot.HEAD)) || esEstandarte(jugador.containerMenu.getCarried())) {
                sacar(inventario, true);                           // se lo quiso sacar: vuelve a la cabeza
                if (esEstandarte(jugador.containerMenu.getCarried())) {
                    jugador.containerMenu.setCarried(ItemStack.EMPTY);
                }
                ponerEnLaCabeza(jugador, rojoEstandarte);
            }
        } else if (!esEstandarte(quien.getItemBySlot(EquipmentSlot.HEAD))) {
            ponerEnLaCabeza(quien, rojoEstandarte);
        }
        if (tiempo % 20 == 0) {
            quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
        }
        if (tiempo % 4 == 0) {
            Vector3f color = rojoEstandarte ? new Vector3f(0.85F, 0.12F, 0.10F) : new Vector3f(0.20F, 0.30F, 0.95F);
            complejo.sendParticles(new DustParticleOptions(color, 1.0F), quien.getX(), quien.getY() + 2.5, quien.getZ(), 2,
                    0.2, 0.2, 0.2, 0.0);
        }
        if (cerca(quien, pedestal(!rojoEstandarte), LLEGAR)) {
            ganar(complejo, !rojoEstandarte, quien);               // ¡lo trajo a su fortín!
        }
    }

    /** El que lo llevaba murió (o se fue): el estandarte vuelve a su fortín. */
    private static void volver(ServerLevel complejo, boolean rojoEstandarte) {
        if (rojoEstandarte) {
            llevaRojo = null;
        } else {
            llevaAzul = null;
        }
        ponerEstandarte(complejo, rojoEstandarte);
        Component aviso = Component.translatable(rojoEstandarte ? "mensaje.juegosdelpatio.volvio_rojo"
                : "mensaje.juegosdelpatio.volvio_azul").withStyle(rojoEstandarte ? ChatFormatting.RED : ChatFormatting.BLUE);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.sendSystemMessage(aviso);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.MASTER, 0.8F, 0.7F);
        }
    }

    // ------------------------------------------------------------------ el final
    /** Llegó con el estandarte del otro equipo a su fortín: lo clava al lado del suyo, y el otro equipo pierde. */
    private static void ganar(ServerLevel complejo, boolean rojoGana, LivingEntity portador) {
        Juego.decir(complejo, Component.translatable(rojoGana ? "juego.juegosdelpatio.estandartes_ganan_rojos"
                : "juego.juegosdelpatio.estandartes_ganan_azules", Juego.nombreDe(portador)));
        sacarDeLaCabeza(portador);
        portador.removeEffect(MobEffects.GLOWING);
        if (rojoGana) {
            llevaAzul = null;
        } else {
            llevaRojo = null;
        }
        BlockPos clavado = pedestal(rojoGana).offset(0, 0, 1);
        GUARDADOS.putIfAbsent(clavado, complejo.getBlockState(clavado));
        complejo.setBlock(clavado, (rojoGana ? Blocks.BLUE_BANNER : Blocks.RED_BANNER).defaultBlockState()
                .setValue(BlockStateProperties.ROTATION_16, rojoGana ? GIRO_ROJO : GIRO_AZUL), Block.UPDATE_CLIENTS);
        perder(complejo, !rojoGana, "perdiste_el_estandarte", true);
    }

    /**
     * Un equipo perdió: durante 3 segundos les caen rayos, uno por uno, y quedan eliminados; después, los que sigan. Si
     * {@code conFinal} es false (Juego corta el juego), quedan eliminados ya, sin rayos.
     */
    private static void perder(ServerLevel complejo, boolean rojos, String motivo, boolean conFinal) {
        pierdenRojos = rojos;
        motivoFinal = motivo;
        for (boolean rojoEstandarte : new boolean[] {true, false}) {   // el estandarte que tenga alguien, vuelve
            UUID uuid = rojoEstandarte ? llevaRojo : llevaAzul;
            LivingEntity quien = uuid != null ? buscar(complejo, uuid) : null;
            if (quien != null) {
                sacarDeLaCabeza(quien);
                quien.removeEffect(MobEffects.GLOWING);
            }
            if (uuid != null) {
                if (rojoEstandarte) {
                    llevaRojo = null;
                } else {
                    llevaAzul = null;
                }
                ponerEstandarte(complejo, rojoEstandarte);
            }
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.5F);
            if (!juega(jugador)) {
                continue;
            }
            boolean pierde = esRojo(jugador) == rojos;
            Juego.titulo(jugador, Component.translatable(pierde ? "titulo.juegosdelpatio.perdieron" : "titulo.juegosdelpatio.ganaron")
                            .withStyle(pierde ? ChatFormatting.DARK_RED : ChatFormatting.GOLD),
                    Component.translatable(pierde ? "titulo.juegosdelpatio.perdieron_detalle" : "titulo.juegosdelpatio.ganaron_detalle")
                            .withStyle(ChatFormatting.GRAY), 5, 60, 15);
        }
        estado = Estado.FINAL;
        tiempo = 0;
        if (!conFinal) {
            eliminarPerdedores(complejo);
        }
    }

    /** Los del equipo que perdió que siguen en pie. */
    private static List<LivingEntity> perdedores(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : enJuego(complejo)) {
            if (esRojo(quien) == pierdenRojos) {
                lista.add(quien);
            }
        }
        return lista;
    }

    /** Le cae un rayo (que no prende fuego ni lastima a nadie más) a uno del equipo que perdió, y queda eliminado. */
    private static void rayoAlQueSigue(ServerLevel complejo) {
        List<LivingEntity> quedan = perdedores(complejo);
        if (quedan.isEmpty()) {
            return;
        }
        LivingEntity quien = quedan.get(complejo.getRandom().nextInt(quedan.size()));
        LightningBolt rayo = EntityType.LIGHTNING_BOLT.create(complejo);
        if (rayo != null) {
            rayo.moveTo(quien.getX(), quien.getY(), quien.getZ(), 0.0F, 0.0F);
            rayo.setVisualOnly(true);
            complejo.addFreshEntity(rayo);
        }
        quitarCosas(quien);
        Juego.eliminar(complejo, quien, false, motivoFinal);
    }

    private static void eliminarPerdedores(ServerLevel complejo) {
        for (LivingEntity quien : perdedores(complejo)) {
            quitarCosas(quien);
            Juego.eliminar(complejo, quien, false, motivoFinal);
        }
        terminar(complejo);
    }

    private static void terminar(ServerLevel complejo) {
        estado = Estado.TERMINADO;
        pasaron = enJuego(complejo).size();
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.6F);
        }
    }

    /** Se terminó el tiempo: pierde el equipo con menos gente en pie. Si están iguales, no pierde nadie. */
    private static void porTiempo(ServerLevel complejo, boolean conFinal) {
        int rojos = vivos(complejo, true);
        int azules = vivos(complejo, false);
        if (rojos != azules) {
            boolean pierden = rojos < azules;
            Juego.decir(complejo, Component.translatable(pierden ? "juego.juegosdelpatio.estandartes_tiempo_rojos"
                    : "juego.juegosdelpatio.estandartes_tiempo_azules"));
            perder(complejo, pierden, "perdio_tu_equipo", conFinal);
        } else {
            Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.estandartes_tiempo_empate"));
            terminar(complejo);
        }
    }

    /** Juego corta el juego (se trabó): se decide ya, por la gente que queda en pie. */
    static void alargue(ServerLevel complejo) {
        if (estado == Estado.TERMINADO || estado == Estado.NINGUNO) {
            return;
        }
        if (estado == Estado.FINAL) {
            eliminarPerdedores(complejo);
            return;
        }
        porTiempo(complejo, false);
    }

    // ------------------------------------------------------------------ golpes y muertes
    /**
     * Vale pegarle a los del otro equipo, una vez que empezó la pelea. A los del propio equipo no (ni antes de que
     * empiece, ni cuando ya terminó), y el que lleva un estandarte no puede pegarle a nadie: esos golpes no hacen nada,
     * y se le avisa al que pegó.
     */
    static void alRecibirGolpe(LivingIncomingDamageEvent evento) {
        LivingEntity victima = evento.getEntity();
        Entity fuente = evento.getSource().getEntity();
        if (!(fuente instanceof LivingEntity atacante) || atacante == victima
                || !(victima instanceof Player || victima instanceof JugadorBot)) {
            return;                                              // caídas y demás: lo de siempre
        }
        if (!juega(victima) || !juega(atacante)) {
            evento.setCanceled(true);                            // los que no juegan no se meten
            return;
        }
        String aviso = estado == Estado.CUENTA ? "estandartes_todavia" : estado != Estado.PELEA ? "ya_termino"
                : esRojo(victima) == esRojo(atacante) ? "no_pegar_companero" : lleva(atacante) ? "con_estandarte_no" : null;
        if (aviso == null) {
            return;                                              // ¡vale!
        }
        evento.setCanceled(true);
        if (atacante instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio." + aviso)
                    .withStyle(ChatFormatting.RED), true);
        }
    }

    /** Murió uno que jugaba: Juego lo anota como eliminado. Acá se le saca todo y se avisa (y quién fue). */
    static void alMorir(ServerLevel complejo, LivingEntity muerto, DamageSource fuente) {
        if (!ROJO.containsKey(muerto.getUUID())) {
            return;
        }
        boolean llevaba = lleva(muerto);
        boolean final_ = estado == Estado.FINAL;
        String clave = muerto.getY() < PISO - 4 ? "se_cayo_grieta"
                : fuente.getEntity() instanceof LivingEntity asesino && asesino != muerto ? "estandartes_mato" : "estandartes_murio";
        Component mensaje = clave.equals("estandartes_mato") && fuente.getEntity() instanceof LivingEntity asesino
                ? Component.translatable("mensaje.juegosdelpatio.estandartes_mato", Juego.nombreDe(asesino), Juego.nombreDe(muerto))
                : Component.translatable("mensaje.juegosdelpatio." + clave, Juego.nombreDe(muerto));
        quitarCosas(muerto);
        if (llevaba) {
            volver(complejo, Boolean.FALSE.equals(ROJO.get(muerto.getUUID())));   // el que llevaba el del otro equipo
        }
        if (final_) {
            return;                                              // ya se sabe quién perdió: sin un mensaje por cada uno
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (jugador != muerto) {
                jugador.sendSystemMessage(mensaje.copy().withStyle(esRojo(muerto) ? ChatFormatting.RED : ChatFormatting.BLUE));
            }
        }
    }

    /** Se le saca a alguien todo lo del juego (chaleco, espada y estandarte), para que no se le caiga al morir. */
    private static void quitarCosas(LivingEntity quien) {
        if (lleva(quien)) {
            if (quien.getUUID().equals(llevaRojo)) {
                llevaRojo = null;
            } else {
                llevaAzul = null;
            }
            if (quien.level() instanceof ServerLevel complejo) {
                ponerEstandarte(complejo, !esRojo(quien));
            }
        }
        sacarDeLaCabeza(quien);
        Equipos.sacarChaleco(quien);
        quien.removeEffect(MobEffects.GLOWING);
        if (quien instanceof ServerPlayer jugador) {
            sacar(jugador.getInventory(), false);
        } else if (esEspada(quien.getMainHandItem())) {
            quien.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
    }

    // ------------------------------------------------------------------ para los bots
    /** Qué hace el bot (ver DEFENSOR, CENTRO, NORTE y SUR). Desde el minuto 5, la mitad de los que cuidaban, salen. */
    static int papel(JugadorBot bot) {
        int papel = PAPELES.getOrDefault(bot.getUUID(), CENTRO);
        if (papel == DEFENSOR && estado == Estado.PELEA && tiempo > DEFENSA_HASTA
                && Math.floorMod(bot.getUUID().getLeastSignificantBits(), 2) == 0) {
            return CENTRO;
        }
        return papel;
    }

    /** Por cuál camino cruza un bot que va a buscar el otro estandarte (0 el del norte, 1 el del medio y 2 el del sur). */
    static int ruta(int papel) {
        return papel == NORTE ? 0 : papel == SUR ? 2 : 1;
    }

    /** El camino que pasa más cerca de ese z. */
    static int caminoCerca(double z) {
        int mejor = 1;
        double mejorD = Double.MAX_VALUE;
        for (int c = 0; c < CAMINOS.length; c++) {
            int[] borde = TORRES[CAMINOS[c][0]];
            double d = Math.abs(z - (borde[2] + borde[3] + 1) / 2.0);
            if (d < mejorD) {
                mejorD = d;
                mejor = c;
            }
        }
        return mejor;
    }

    /** De qué camino es una torre (o un borde). */
    static int caminoDe(int torre) {
        for (int c = 0; c < CAMINOS.length; c++) {
            if (torre >= CAMINOS[c][0] && torre <= CAMINOS[c][1]) {
                return c;
            }
        }
        return 1;
    }

    /** El medio de arriba de una torre (o de un borde). */
    static Vec3 centro(int torre) {
        int[] t = TORRES[torre];
        return new Vec3((t[0] + t[1] + 1) / 2.0, PISO, (t[2] + t[3] + 1) / 2.0);
    }

    /** El lado del campo de cada equipo: -1 el oeste (los rojos) y 1 el este (los azules). */
    static int ladoDe(boolean rojo) {
        return rojo ? -1 : 1;
    }

    /** De qué lado de la grieta está: -1 el oeste, 1 el este, y 0 si está en la grieta (en una torre, o cayéndose). */
    static int lado(LivingEntity quien) {
        if (quien.getY() < PISO - 3) {
            return 0;
        }
        double x = quien.getX();
        return x < CX - GRIETA ? -1 : x >= CX + GRIETA + 1 ? 1 : 0;
    }

    /** ¿Uno puede llegar caminando hasta el otro? Si están en la misma torre, o del mismo lado y a la misma altura. */
    static boolean juntos(LivingEntity a, LivingEntity b) {
        int ta = CAMPO.torreDe(a);
        int tb = CAMPO.torreDe(b);
        if (ta >= 0 && ta == tb) {
            return true;
        }
        int la = lado(a);
        return la != 0 && la == lado(b) && Math.abs(a.getY() - b.getY()) < 4.0;
    }

    /** Quién lleva el estandarte de ese color (o null: está en su fortín). */
    @Nullable
    static LivingEntity portador(ServerLevel complejo, boolean rojoEstandarte) {
        UUID uuid = rojoEstandarte ? llevaRojo : llevaAzul;
        return uuid == null ? null : buscar(complejo, uuid);
    }

    /** El del otro equipo más cerca del bot, al que puede llegar (ver {@link #juntos}) y a menos de {@code radio}; o null. */
    @Nullable
    static LivingEntity enemigoCerca(JugadorBot bot, double radio) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        LivingEntity mejor = null;
        double mejorD = radio * radio;
        for (LivingEntity otro : enJuego(complejo)) {
            if (esRojo(otro) == esRojo(bot)) {
                continue;
            }
            double d = otro.distanceToSqr(bot);
            if (d < mejorD && juntos(bot, otro)) {
                mejorD = d;
                mejor = otro;
            }
        }
        return mejor;
    }

    /** La probabilidad de que a un bot le salga mal un salto (casi nunca: más en los de 3 y en los más torpes). */
    static double riesgo(JugadorBot bot, int desde, int hacia) {
        double base = CAMPO.hueco(desde, hacia) >= 3 ? 0.015 : 0.004;
        return base * (0.5 + Math.floorMod(bot.getUUID().getMostSignificantBits(), 100) * 0.012);
    }

    /** Un lugar cerca del propio estandarte (a menos de 6 bloques), para cuidarlo. */
    static Vec3 lugarEnFortin(ServerLevel complejo, boolean rojo, RandomSource azar) {
        BlockPos pie = pedestal(rojo);
        for (int intento = 0; intento < 30; intento++) {
            int x = pie.getX() - 6 + azar.nextInt(13);
            int z = pie.getZ() - 6 + azar.nextInt(13);
            if (Math.abs(x - pie.getX()) <= 1 && Math.abs(z - pie.getZ()) <= 1) {
                continue;
            }
            int y = alturaDePie(complejo, x, z);
            if (y != Integer.MIN_VALUE) {
                return new Vec3(x + 0.5, y, z + 0.5);
            }
        }
        return new Vec3(pie.getX() + (rojo ? 3.5 : -2.5), PISO, pie.getZ() + 3.5);
    }

    /** Dónde empieza cada uno: en su lado, cerca de su fortín (y no encima del estandarte). */
    static Vec3 lugarDeInicio(ServerLevel complejo, boolean rojo, RandomSource azar) {
        BlockPos pie = pedestal(rojo);
        for (int intento = 0; intento < 60; intento++) {
            int adelante = 2 + azar.nextInt(22);                      // del fortín hacia la grieta
            int x = pie.getX() + (rojo ? adelante : -adelante);
            int z = pie.getZ() - 13 + azar.nextInt(27);
            int dx = x - pie.getX();
            int dz = z - pie.getZ();
            if (dx * dx + dz * dz < 9) {
                continue;
            }
            int y = alturaDePie(complejo, x, z);
            if (y != Integer.MIN_VALUE) {
                return new Vec3(x + 0.5, y, z + 0.5);
            }
        }
        return new Vec3(pie.getX() + (rojo ? 4.5 : -3.5), PISO, pie.getZ() + 4.5);
    }

    /**
     * A qué altura se para uno en (x, z) del campo: arriba del pasto o del piso del fortín. Integer.MIN_VALUE si ahí no
     * se puede (una ruina, una roca, la grieta, una columna).
     */
    static int alturaDePie(Level nivel, int x, int z) {
        for (int y = PISO + 10; y >= PISO - 3; y--) {
            BlockState abajo = nivel.getBlockState(new BlockPos(x, y - 1, z));
            if (abajo.isAir() || abajo.is(Blocks.LIGHT)) {
                continue;
            }
            boolean piso = abajo.is(Blocks.GRASS_BLOCK) || y == PISO && (abajo.is(Blocks.COBBLESTONE)
                    || abajo.is(Blocks.MOSSY_COBBLESTONE) || abajo.is(Blocks.STONE_BRICKS) || abajo.is(Blocks.CHISELED_STONE_BRICKS));
            boolean lugar = nivel.getBlockState(new BlockPos(x, y, z)).isAir() && nivel.getBlockState(new BlockPos(x, y + 1, z)).isAir();
            return piso && lugar ? y : Integer.MIN_VALUE;
        }
        return Integer.MIN_VALUE;
    }

    // ------------------------------------------------------------------ limpiar
    static void limpiar(ServerLevel complejo) {
        for (ServerPlayer jugador : complejo.players()) {
            if (ROJO.containsKey(jugador.getUUID())) {
                Equipos.sacarChaleco(jugador);
                sacarDeLaCabeza(jugador);
                jugador.removeEffect(MobEffects.GLOWING);
            }
            sacar(jugador.getInventory(), false);
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> ROJO.containsKey(bot.getUUID()))) {
            Equipos.sacarChaleco(bot);
            bot.removeEffect(MobEffects.GLOWING);
            if (esEspada(bot.getMainHandItem())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
            if (esEstandarte(bot.getItemBySlot(EquipmentSlot.HEAD))) {
                bot.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            }
        }
        for (ItemEntity tirada : complejo.getEntitiesOfClass(ItemEntity.class, caja(), tirada -> esEspada(tirada.getItem())
                || Equipos.esChaleco(tirada.getItem()) || tirada.getItem().is(Items.RED_BANNER) || tirada.getItem().is(Items.BLUE_BANNER))) {
            tirada.discard();
        }
        for (Map.Entry<BlockPos, BlockState> guardado : GUARDADOS.entrySet()) {      // todo como estaba
            complejo.setBlock(guardado.getKey(), guardado.getValue(), Block.UPDATE_CLIENTS);
        }
        GUARDADOS.clear();
        if (EstadoComplejo.de(complejo.getServer()).versionEstandartes() == VERSION_ARENA) {
            ponerEstandarte(complejo, true);
            ponerEstandarte(complejo, false);
        }
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ROJO.clear();
        PAPELES.clear();
        llevaRojo = null;
        llevaAzul = null;
        CABEZAS.clear();
        GUARDADOS.clear();
        pierdenRojos = false;
        motivoFinal = "perdio_tu_equipo";
        enJuegoCache = null;
        enJuegoTick = -1;
        Equipos.olvidar();
    }

    /** Saca las espadas (y, si se pide, los estandartes) de un inventario. */
    private static void sacar(Inventory inventario, boolean soloEstandartes) {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack cosa = inventario.getItem(i);
            if (esEstandarte(cosa) || !soloEstandartes && esEspada(cosa)) {
                inventario.setItem(i, ItemStack.EMPTY);
            }
        }
    }

    // ------------------------------------------------------------------ la arena
    /** Dónde aparece quien llega: en el palco, delante del podio. */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(7980.5 + azar.nextInt(41), 112.0, -11.5 + azar.nextInt(8));
    }

    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionEstandartes() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        if (estadoComplejo.versionEstandartes() > 0) {               // lo de antes (La batalla, o las torres), afuera
            BlockState aire = Blocks.AIR.defaultBlockState();
            for (BlockPos pos : BlockPos.betweenClosed(VIEJAS[0], VIEJAS[4], VIEJAS[2], VIEJAS[1], VIEJAS[5], VIEJAS[3])) {
                if (!complejo.getBlockState(pos).isAir()) {
                    complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
                }
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionEstandartes(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Los estandartes colocada en {}", ORIGEN);
        return true;
    }

    private static AABB caja() {
        return new AABB(X0, ABAJO, Z0, X1 + 1, ARRIBA + 1, Z1 + 1);
    }

    // ------------------------------------------------------------------ ayudas
    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID uuid) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getUUID().equals(uuid)) {
                return quien;
            }
        }
        return null;
    }

    /** Los que siguen jugando (vivos y sin eliminar). Se arma una vez por tick: los bots lo piden todo el tiempo. */
    private static List<LivingEntity> enJuego(ServerLevel complejo) {
        long ahora = complejo.getGameTime();
        if (ahora == enJuegoTick && enJuegoCache != null) {
            List<LivingEntity> vivos = new ArrayList<>();
            for (LivingEntity quien : enJuegoCache) {
                if (quien.isAlive() && !Juego.eliminado(quien)) {
                    vivos.add(quien);
                }
            }
            return vivos;
        }
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : Juego.participantes(complejo)) {
            if (ROJO.containsKey(quien.getUUID())) {
                lista.add(quien);
            }
        }
        enJuegoCache = lista;
        enJuegoTick = ahora;
        return new ArrayList<>(lista);
    }

    private static int vivos(ServerLevel complejo, boolean rojo) {
        int cuantos = 0;
        for (LivingEntity quien : enJuego(complejo)) {
            if (esRojo(quien) == rojo) {
                cuantos++;
            }
        }
        return cuantos;
    }
}
