package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.joml.Vector3f;

/**
 * El juego 7, el último, "Los estandartes": un juego nuevo, con un guiño a capturar la bandera, en un campo de torres
 * altísimas (ver gen_estandartes.py).
 *
 * <ol>
 *   <li>Se reparten dos equipos al azar, cada uno con su chaleco y una espada de hierro. Cada equipo empieza en su
 *       bastión, en una punta del campo (el rojo al oeste y el azul al este), donde está parado su estandarte.</li>
 *   <li>Después de 10 segundos de cuenta, a jugar: hay que tocar el estandarte del otro equipo (así se agarra) y
 *       llevarlo hasta el propio bastión. El que lo lleva lo tiene puesto en la cabeza, brilla y no puede pegar ni
 *       empujar. Si muere o se cae, el estandarte vuelve a su bastión.</li>
 *   <li>El que muere (por la espada o por una caída) queda eliminado. A los del propio equipo no se les puede pegar.</li>
 *   <li>Desde el minuto 3, cada 40 segundos se agrietan dos torres de los costados (una de cada lado, la misma): a los
 *       5 segundos se derrumban, con los que estén arriba. El camino del medio y la plaza no se caen.</li>
 *   <li>El equipo que pierde su estandarte, pierde: su bastión se derrumba y quedan todos eliminados. Si un equipo muere
 *       entero, también pierde. Si a los 8 minutos nadie ganó, pierde el que tenga menos gente en pie (si están parejos,
 *       pasan todos). Los que quedan ganan los juegos y se reparten el premio.</li>
 * </ol>
 */
public final class Estandartes {
    // ------------------------------------------------------------------ la arena (igual que gen_estandartes.py)
    public static final ResourceLocation ARENA = Complejo.id("estandartes");
    /** Esquina de la plantilla estandartes.nbt (91 x 78 x 58): abajo de todo, en el suelo. */
    public static final BlockPos ORIGEN = new BlockPos(7955, 40, -17);
    /** La 1 era el patio de La batalla (el juego 7 de antes), en el mismo lugar: se borra y se pone esta. */
    static final int VERSION_ARENA = 2;
    /** Lo que se borra y se mantiene cargado: la arena (x 7955..8045, z -17..40) y lo que ocupaba el patio de antes. */
    static final int X0 = 7955;
    static final int X1 = 8045;
    static final int Z0 = -17;
    static final int Z1 = 54;
    static final int PISO = 100;
    static final int SUELO = 41;
    /**
     * Arriba de cada torre, donde se puede estar (x0, x1, z0, z1): los dos bastiones (0 el rojo y 8 el azul), el
     * camino del medio (1 a 7, con la plaza en el 4), el costado norte (9 a 15) y el sur (16 a 22).
     */
    static final int BASTION_ROJO = 0;
    static final int PLAZA = 4;
    static final int BASTION_AZUL = 8;
    static final int[][] TORRES = {
            {7958, 7967, 11, 35},
            {7970, 7975, 21, 25}, {7979, 7984, 21, 25}, {7987, 7992, 21, 25},
            {7995, 8005, 18, 28},
            {8008, 8013, 21, 25}, {8016, 8021, 21, 25}, {8025, 8030, 21, 25},
            {8033, 8042, 11, 35},
            {7971, 7975, 10, 14}, {7979, 7983, 10, 14}, {7987, 7991, 10, 14}, {7995, 8005, 10, 14},
            {8009, 8013, 10, 14}, {8017, 8021, 10, 14}, {8025, 8029, 10, 14},
            {7971, 7975, 32, 36}, {7979, 7983, 32, 36}, {7987, 7991, 32, 36}, {7995, 8005, 32, 36},
            {8009, 8013, 32, 36}, {8017, 8021, 32, 36}, {8025, 8029, 32, 36},
    };
    static final int[][] VECINOS = {
            {1, 9, 16}, {0, 2}, {1, 3}, {2, 4}, {3, 5, 12, 19}, {4, 6}, {5, 7}, {6, 8}, {7, 15, 22},
            {0, 10}, {9, 11}, {10, 12}, {11, 13, 4}, {12, 14}, {13, 15}, {14, 8},
            {0, 17}, {16, 18}, {17, 19}, {18, 20, 4}, {19, 21}, {20, 22}, {21, 8},
    };
    /** De la plaza se salta al norte y al sur sin pasar por las esquinas (ahí están los faroles). */
    static final CampoDeTorres CAMPO = new CampoDeTorres(PISO, TORRES, VECINOS, salidas(), null);
    /** Arriba de los bastiones, de la muralla al frente (para el derrumbe del final). */
    private static final int[][] BASTIONES = {{7957, 7967, 10, 36}, {8033, 8043, 10, 36}};
    /** Donde está parado cada estandarte (y para dónde mira: el rojo al este y el azul al oeste). */
    static final BlockPos ESTANDARTE_ROJO = new BlockPos(7962, PISO, 23);
    static final BlockPos ESTANDARTE_AZUL = new BlockPos(8038, PISO, 23);
    private static final int GIRO_ROJO = 12;
    private static final int GIRO_AZUL = 4;
    /** Las torres de los costados se derrumban de a dos: una de cada lado, la misma (para que sea parejo). */
    static final int[][] PARES = {{9, 15}, {10, 14}, {11, 13}, {16, 22}, {17, 21}, {18, 20}, {12, 19}};
    static final Vec3 PODIO = new Vec3(8000.5, 102.0, -13.5);
    /** Los sargentos, en el palco: dos en las esquinas del fondo y dos junto al podio. */
    static final Vec3[] PUESTOS_SARGENTOS = {
            new Vec3(7978.5, 100.0, -13.5), new Vec3(8022.5, 100.0, -13.5),
            new Vec3(7992.5, 100.0, -13.5), new Vec3(8008.5, 100.0, -13.5),
    };
    static final float[] GIROS_SARGENTOS = {0.0F, 0.0F, 0.0F, 0.0F};

    // ------------------------------------------------------------------ reglas
    private static final int CUENTA = 10 * 20;
    /** La pelea dura 8 minutos (si nadie gana antes). */
    static final int DURACION = 8 * 60 * 20;
    /** Desde el minuto 3, cada 40 segundos se agrietan dos torres; a los 5 segundos se caen. */
    static final int DERRUMBE_DESDE = 3 * 60 * 20;
    static final int DERRUMBE_CADA = 40 * 20;
    static final int AVISO_DERRUMBE = 5 * 20;
    /** Desde el minuto 5, la mitad de los bots que cuidaban salen a buscar el otro estandarte (si no, se trabaría). */
    private static final int DEFENSA_HASTA = 5 * 60 * 20;
    /** A cuántos bloques del estandarte hay que estar para agarrarlo, y para dejarlo en el propio bastión. */
    private static final double TOCAR = 1.2;
    private static final double LLEGAR = 1.5;
    /** Cuando un equipo pierde: su bastión se derrumba y, 3 segundos después, quedan eliminados los que sigan. */
    private static final int FINAL = 60;
    /** Los bloques que caen se borran antes de llegar al suelo (2 segundos). */
    private static final int CAIDA = 40;

    /** Lo que hace cada bot: cuidar su estandarte, o ir a buscar el otro por el medio o por un costado. */
    static final int DEFENSOR = 0;
    static final int CENTRO = 1;
    static final int NORTE = 2;
    static final int SUR = 3;

    private enum Estado { NINGUNO, CUENTA, PELEA, FINAL, TERMINADO }

    private static Estado estado = Estado.NINGUNO;
    private static int tiempo;
    private static int pasaron;
    /** De qué equipo es cada uno (true: rojo). */
    private static final Map<UUID, Boolean> ROJO = new HashMap<>();
    private static final Map<UUID, Integer> PAPELES = new HashMap<>();
    /** Quién lleva el estandarte rojo (un azul) y quién el azul (un rojo); null: está en su bastión. */
    @Nullable
    private static UUID llevaRojo;
    @Nullable
    private static UUID llevaAzul;
    /** Lo que los jugadores tenían en la cabeza antes del estandarte, para devolvérselo. */
    private static final Map<UUID, ItemStack> CABEZAS = new HashMap<>();
    /** El orden en que se caen los pares de torres, cuál sigue, y las que se están agrietando (y cuándo caen). */
    private static final List<int[]> ORDEN = new ArrayList<>();
    private static int siguientePar;
    private static final Map<Integer, Integer> AGRIETADAS = new LinkedHashMap<>();
    /** Los que estaban arriba de una torre (o del bastión) cuando se derrumbó. */
    private static final java.util.Set<UUID> CON_LA_TORRE = new java.util.HashSet<>();
    /** Cómo estaba cada bloque que se agrietó o se cayó (para dejar todo como antes al final). */
    private static final Map<BlockPos, BlockState> GUARDADOS = new LinkedHashMap<>();
    private static final List<FallingBlockEntity> CAYENDO = new ArrayList<>();
    /** El equipo que perdió (en el final) y por qué. */
    private static boolean pierdenRojos;
    private static String motivoFinal = "perdio_tu_equipo";
    @Nullable
    private static List<LivingEntity> enJuegoCache;
    private static long enJuegoTick = -1;

    private Estandartes() {
    }

    private static int[][] salidas() {
        int[][] salidas = new int[TORRES.length][];
        salidas[PLAZA] = new int[] {7996, 8004};
        return salidas;
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return estado != Estado.NINGUNO;
    }

    static boolean peleando() {
        return estado == Estado.PELEA;
    }

    static int pasaron() {
        return pasaron;
    }

    static boolean juega(LivingEntity quien) {
        return estado != Estado.NINGUNO && ROJO.containsKey(quien.getUUID()) && quien.isAlive() && !Juego.eliminado(quien);
    }

    static boolean esRojo(LivingEntity quien) {
        return Boolean.TRUE.equals(ROJO.get(quien.getUUID()));
    }

    /** En las torres, los bots no se chocan con nadie (si no, en una torre llena se tirarían unos a otros). */
    static boolean sinChoques(LivingEntity quien) {
        return estado != Estado.NINGUNO && ROJO.containsKey(quien.getUUID());
    }

    /** ¿Lleva un estandarte (el del otro equipo)? */
    static boolean lleva(LivingEntity quien) {
        UUID uuid = quien.getUUID();
        return uuid.equals(llevaRojo) || uuid.equals(llevaAzul);
    }

    /** Por qué quedó eliminado el que murió: lo mataron, se cayó, se cayó con su torre, o perdió su equipo. */
    static String motivo(LivingEntity muerto, DamageSource fuente) {
        if (estado == Estado.FINAL && ROJO.containsKey(muerto.getUUID()) && esRojo(muerto) == pierdenRojos) {
            return motivoFinal;
        }
        if (CON_LA_TORRE.contains(muerto.getUUID())) {
            return "se_cayo_tu_torre";
        }
        return fuente.getEntity() instanceof LivingEntity asesino && asesino != muerto && muerto.getY() > PISO - 3
                ? "te_mataron" : "te_caiste";
    }

    // ------------------------------------------------------------------ empezar
    static void empezar(ServerLevel complejo, List<LivingEntity> gente) {
        olvidar();
        if (hayDerrumbes(complejo)) {                              // de un juego que se cortó: la arena, de nuevo
            EstadoComplejo.de(complejo.getServer()).setVersionEstandartes(0);
            prepararArena(complejo);
        }
        for (boolean rojo : new boolean[] {true, false}) {
            BlockPos clavado = pedestal(rojo).offset(0, 0, 1);         // el trofeo de un juego que se cortó, afuera
            if (complejo.getBlockState(clavado).is(Blocks.RED_BANNER) || complejo.getBlockState(clavado).is(Blocks.BLUE_BANNER)) {
                complejo.setBlock(clavado, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
            ponerEstandarte(complejo, rojo);
        }
        RandomSource azar = complejo.getRandom();
        List<List<LivingEntity>> equipos = Equipos.repartir(gente, azar);
        for (int e = 0; e < 2; e++) {
            boolean rojo = e == 0;
            List<JugadorBot> bots = new ArrayList<>();
            for (LivingEntity quien : equipos.get(e)) {
                ROJO.put(quien.getUUID(), rojo);
                Equipos.ponerChaleco(quien, rojo);
                Vec3 lugar = lugarEnBastion(complejo, rojo, azar, false);
                float giro = rojo ? -90.0F : 90.0F;                   // mirando al campo
                quien.setDeltaMovement(Vec3.ZERO);
                quien.fallDistance = 0.0F;
                if (quien instanceof ServerPlayer jugador) {
                    jugador.teleportTo(complejo, lugar.x, lugar.y, lugar.z, giro, 0.0F);
                    ItemStack espada = espada();
                    if (jugador.getMainHandItem().isEmpty()) {
                        jugador.setItemInHand(InteractionHand.MAIN_HAND, espada);
                    } else if (!jugador.getInventory().add(espada)) {
                        jugador.drop(espada, false);
                    }
                    Juego.titulo(jugador, Component.translatable(rojo ? "titulo.juegosdelpatio.equipo_rojo"
                                    : "titulo.juegosdelpatio.equipo_azul").withStyle(rojo ? ChatFormatting.RED : ChatFormatting.BLUE),
                            Component.translatable(rojo ? "titulo.juegosdelpatio.estandartes_detalle_rojo"
                                    : "titulo.juegosdelpatio.estandartes_detalle_azul").withStyle(ChatFormatting.GRAY),
                            5, 60, 15);
                    jugador.playNotifySound(SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 1.0F, rojo ? 0.8F : 1.2F);
                } else {
                    quien.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
                    quien.setYHeadRot(giro);
                }
                if (quien instanceof JugadorBot bot) {
                    bots.add(bot);
                    bot.getNavigation().stop();
                    bot.setItemSlot(EquipmentSlot.MAINHAND, espada());
                    bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
                }
            }
            repartirPapeles(bots, azar);
        }
        ORDEN.clear();
        for (int[] par : PARES) {
            ORDEN.add(par);
        }
        for (int i = ORDEN.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            int[] cambio = ORDEN.get(i);
            ORDEN.set(i, ORDEN.get(j));
            ORDEN.set(j, cambio);
        }
        Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.estandartes_equipos", equipos.get(0).size(),
                equipos.get(1).size(), CUENTA / 20));
        estado = Estado.CUENTA;
        tiempo = 0;
    }

    /**
     * Qué hace cada bot de un equipo: un tercio cuida el estandarte (uno por lo menos, si son dos o más) y los demás van
     * a buscar el otro: la mitad por el medio y la otra mitad por los costados.
     */
    private static void repartirPapeles(List<JugadorBot> bots, RandomSource azar) {
        for (int i = bots.size() - 1; i > 0; i--) {
            int j = azar.nextInt(i + 1);
            JugadorBot cambio = bots.get(i);
            bots.set(i, bots.get(j));
            bots.set(j, cambio);
        }
        int defensores = bots.size() < 2 ? 0 : Math.max(1, Math.round(bots.size() / 3.0F));
        for (int i = 0; i < bots.size(); i++) {
            int papel = i < defensores ? DEFENSOR : (i - defensores) % 4 == 1 ? NORTE : (i - defensores) % 4 == 3 ? SUR : CENTRO;
            PAPELES.put(bots.get(i).getUUID(), papel);
        }
    }

    /** La espada de los estandartes: de hierro, que no se rompe (y marcada, para sacarla al final). */
    private static ItemStack espada() {
        ItemStack espada = new ItemStack(Items.IRON_SWORD);
        espada.set(DataComponents.UNBREAKABLE, new Unbreakable(true));
        espada.set(DataComponents.ITEM_NAME, Component.translatable("item.juegosdelpatio.espada_bastion"));
        CompoundTag marca = new CompoundTag();
        marca.putBoolean("EspadaBastion", true);
        espada.set(DataComponents.CUSTOM_DATA, CustomData.of(marca));
        return espada;
    }

    static boolean esEspada(ItemStack cosa) {
        CustomData datos = cosa.get(DataComponents.CUSTOM_DATA);
        return datos != null && cosa.is(Items.IRON_SWORD) && datos.copyTag().getBoolean("EspadaBastion");
    }

    /** El estandarte de un equipo, para llevar puesto (marcado, para sacarlo al final). */
    private static ItemStack estandarte(boolean rojo) {
        ItemStack cosa = new ItemStack(rojo ? Items.RED_BANNER : Items.BLUE_BANNER);
        cosa.set(DataComponents.ITEM_NAME, Component.translatable(rojo ? "item.juegosdelpatio.estandarte_rojo"
                : "item.juegosdelpatio.estandarte_azul"));
        CompoundTag marca = new CompoundTag();
        marca.putBoolean("Estandarte", true);
        cosa.set(DataComponents.CUSTOM_DATA, CustomData.of(marca));
        return cosa;
    }

    static boolean esEstandarte(ItemStack cosa) {
        CustomData datos = cosa.get(DataComponents.CUSTOM_DATA);
        return datos != null && (cosa.is(Items.RED_BANNER) || cosa.is(Items.BLUE_BANNER)) && datos.copyTag().getBoolean("Estandarte");
    }

    // ------------------------------------------------------------------ cada tick (lo llama Juego)
    static boolean tick(ServerLevel complejo) {
        tiempo++;
        switch (estado) {
            case CUENTA -> {
                int faltan = CUENTA - tiempo;
                if (faltan > 0 && faltan <= 100 && faltan % 20 == 0) {
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        jugador.playNotifySound(SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.MASTER, 1.0F, 1.0F);
                        jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.cuenta_juego", faltan / 20)
                                .withStyle(ChatFormatting.YELLOW), true);
                    }
                }
                if (faltan <= 0) {
                    estado = Estado.PELEA;
                    tiempo = 0;
                    for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
                        Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.a_pelear").withStyle(ChatFormatting.RED),
                                Component.empty(), 2, 25, 8);
                        jugador.playNotifySound(SoundEvents.RAID_HORN.value(), SoundSource.MASTER, 0.7F, 1.0F);
                    }
                }
            }
            case PELEA -> pelea(complejo);
            case FINAL -> {
                if (tiempo >= FINAL) {
                    eliminarPerdedores(complejo);
                }
            }
            default -> {
            }
        }
        for (Iterator<FallingBlockEntity> it = CAYENDO.iterator(); it.hasNext(); ) {
            FallingBlockEntity cae = it.next();
            if (cae.isRemoved() || cae.tickCount > CAIDA) {
                cae.discard();                                     // se pierde en la oscuridad antes de llegar abajo
                it.remove();
            }
        }
        if (tiempo % 10 == 1 && (estado == Estado.CUENTA || estado == Estado.PELEA)) {
            barra(complejo);
        }
        return estado == Estado.TERMINADO;
    }

    private static void pelea(ServerLevel complejo) {
        cuidarEstandarte(complejo, true);
        if (estado == Estado.PELEA) {
            cuidarEstandarte(complejo, false);
        }
        if (estado != Estado.PELEA) {
            return;                                                // alguien llegó con el estandarte
        }
        for (LivingEntity quien : enJuego(complejo)) {             // ¿alguien tocó el estandarte del otro equipo?
            boolean rojo = esRojo(quien);
            boolean libre = rojo ? llevaAzul == null : llevaRojo == null;
            if (libre && !lleva(quien) && cerca(quien, pedestal(!rojo), TOCAR)) {
                agarrar(complejo, quien, !rojo);
            }
        }
        if (tiempo >= DERRUMBE_DESDE && (tiempo - DERRUMBE_DESDE) % DERRUMBE_CADA == 0 && siguientePar < ORDEN.size()) {
            for (int torre : ORDEN.get(siguientePar++)) {
                agrietar(complejo, torre);
            }
            Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.estandartes_se_agrietan", AVISO_DERRUMBE / 20));
        }
        for (Iterator<Map.Entry<Integer, Integer>> it = AGRIETADAS.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<Integer, Integer> torre = it.next();
            if (tiempo >= torre.getValue()) {
                derrumbarTorre(complejo, torre.getKey());
                it.remove();
            }
        }
        if (tiempo % 10 == 0) {
            avisar(complejo);
            caidos(complejo);
            for (ItemEntity tirado : complejo.getEntitiesOfClass(ItemEntity.class, caja(), tirado -> esEstandarte(tirado.getItem()))) {
                tirado.discard();                                  // el estandarte no se tira
            }
        }
        int rojos = vivos(complejo, true);
        int azules = vivos(complejo, false);
        if (rojos == 0 || azules == 0) {
            if (rojos == 0 && azules == 0) {
                Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.estandartes_nadie"));
                terminar(complejo);
            } else {
                Juego.decir(complejo, Component.translatable(rojos == 0 ? "juego.juegosdelpatio.estandartes_sin_rojos"
                        : "juego.juegosdelpatio.estandartes_sin_azules"));
                perder(complejo, rojos == 0, "perdio_tu_equipo", true);
            }
        } else if (tiempo >= DURACION) {
            porTiempo(complejo, true);
        }
    }

    private static void barra(ServerLevel complejo) {
        int quedan = estado == Estado.CUENTA ? DURACION : Math.max(0, DURACION - tiempo);
        Juego.barraJuego(complejo, Component.translatable("barra.juegosdelpatio.estandartes", Juego.reloj(quedan),
                        vivos(complejo, true), vivos(complejo, false)),
                estado == Estado.CUENTA ? BossEvent.BossBarColor.YELLOW : BossEvent.BossBarColor.PURPLE,
                quedan / (float) DURACION);
    }

    /** A los que están en una torre que se está por caer, se les avisa (y se ve el polvo que cae). */
    private static void avisar(ServerLevel complejo) {
        for (int torre : AGRIETADAS.keySet()) {
            int[] t = TORRES[torre];
            complejo.sendParticles(new BlockParticleOption(ParticleTypes.FALLING_DUST, Blocks.DEEPSLATE_TILES.defaultBlockState()),
                    (t[0] + t[1] + 1) / 2.0, PISO - 0.6, (t[2] + t[3] + 1) / 2.0, 10, (t[1] - t[0]) / 3.0, 0.1,
                    (t[3] - t[2]) / 3.0, 0.0);
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (!juega(jugador)) {
                continue;
            }
            int aca = CAMPO.torreDe(jugador);
            if (aca >= 0 && AGRIETADAS.containsKey(aca)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.torre_se_cae")
                        .withStyle(ChatFormatting.RED), true);
            } else if (lleva(jugador)) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.llevas_estandarte")
                        .withStyle(ChatFormatting.GOLD), true);
            }
        }
    }

    /** El que se cayó y no murió (aterrizó vivo allá abajo) queda eliminado igual. */
    private static void caidos(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getY() < PISO - 20 && quien.onGround()) {
                quitarCosas(quien);
                Juego.eliminar(complejo, quien, false, CON_LA_TORRE.contains(quien.getUUID()) ? "se_cayo_tu_torre" : "te_caiste");
            }
        }
    }

    // ------------------------------------------------------------------ los estandartes
    static BlockPos pedestal(boolean rojo) {
        return rojo ? ESTANDARTE_ROJO : ESTANDARTE_AZUL;
    }

    /** ¿Está a menos de {@code distancia} bloques (de costado) del estandarte, parado arriba del bastión? */
    private static boolean cerca(LivingEntity quien, BlockPos pos, double distancia) {
        double dx = quien.getX() - (pos.getX() + 0.5);
        double dz = quien.getZ() - (pos.getZ() + 0.5);
        return dx * dx + dz * dz <= distancia * distancia && Math.abs(quien.getY() - PISO) < 1.5;
    }

    /** El estandarte, parado en su pedestal (si el bastión sigue en pie). */
    private static void ponerEstandarte(ServerLevel complejo, boolean rojo) {
        BlockPos pos = pedestal(rojo);
        if (complejo.getBlockState(pos.below()).isAir()) {
            return;
        }
        complejo.setBlock(pos, (rojo ? Blocks.RED_BANNER : Blocks.BLUE_BANNER).defaultBlockState()
                .setValue(BlockStateProperties.ROTATION_16, rojo ? GIRO_ROJO : GIRO_AZUL), Block.UPDATE_CLIENTS);
    }

    /** Lo tocó uno del otro equipo: se lo lleva puesto en la cabeza. */
    private static void agarrar(ServerLevel complejo, LivingEntity quien, boolean rojoEstandarte) {
        if (rojoEstandarte) {
            llevaRojo = quien.getUUID();
        } else {
            llevaAzul = quien.getUUID();
        }
        BlockPos pos = pedestal(rojoEstandarte);
        complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
        ponerEnLaCabeza(quien, rojoEstandarte);
        quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
        Component nombre = Juego.nombreDe(quien);
        Component aviso = Component.translatable(rojoEstandarte ? "mensaje.juegosdelpatio.robo_rojo"
                : "mensaje.juegosdelpatio.robo_azul", nombre).withStyle(rojoEstandarte ? ChatFormatting.BLUE : ChatFormatting.RED);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.sendSystemMessage(aviso);
            jugador.playNotifySound(SoundEvents.RAID_HORN.value(), SoundSource.MASTER, 0.6F, 1.3F);
            if (jugador == quien) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.tienes_estandarte").withStyle(ChatFormatting.GOLD),
                        Component.translatable("titulo.juegosdelpatio.tienes_estandarte_detalle").withStyle(ChatFormatting.GRAY),
                        0, 40, 10);
            } else if (juega(jugador) && esRojo(jugador) == rojoEstandarte) {
                Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.les_robaron").withStyle(ChatFormatting.RED),
                        Component.translatable("titulo.juegosdelpatio.les_robaron_detalle", nombre).withStyle(ChatFormatting.GRAY),
                        0, 40, 10);
            }
        }
    }

    private static void ponerEnLaCabeza(LivingEntity quien, boolean rojoEstandarte) {
        ItemStack antes = quien.getItemBySlot(EquipmentSlot.HEAD);
        if (quien instanceof ServerPlayer && !esEstandarte(antes) && !CABEZAS.containsKey(quien.getUUID())) {
            CABEZAS.put(quien.getUUID(), antes.copy());
        }
        quien.setItemSlot(EquipmentSlot.HEAD, estandarte(rojoEstandarte));
        if (quien instanceof JugadorBot bot) {
            bot.setDropChance(EquipmentSlot.HEAD, 0.0F);
        }
    }

    /** Se saca el estandarte de la cabeza (y el jugador vuelve a tener lo que tenía); también los que tenga guardados. */
    private static void sacarDeLaCabeza(LivingEntity quien) {
        ItemStack antes = CABEZAS.remove(quien.getUUID());
        if (esEstandarte(quien.getItemBySlot(EquipmentSlot.HEAD))) {
            quien.setItemSlot(EquipmentSlot.HEAD, antes != null ? antes : ItemStack.EMPTY);
        }
        if (quien instanceof ServerPlayer jugador) {
            sacar(jugador.getInventory(), true);
            if (esEstandarte(jugador.containerMenu.getCarried())) {
                jugador.containerMenu.setCarried(ItemStack.EMPTY);
            }
        }
    }

    /**
     * Cada tick, el que lleva un estandarte: si ya no juega (murió, se fue), el estandarte vuelve a su bastión. Si no,
     * lo sigue teniendo puesto (no se lo puede sacar), brilla, y si llegó a su propio bastión, gana su equipo.
     */
    private static void cuidarEstandarte(ServerLevel complejo, boolean rojoEstandarte) {
        UUID uuid = rojoEstandarte ? llevaRojo : llevaAzul;
        if (uuid == null) {
            return;
        }
        LivingEntity quien = buscar(complejo, uuid);
        if (quien == null || !juega(quien)) {
            if (quien != null) {
                sacarDeLaCabeza(quien);
            }
            volver(complejo, rojoEstandarte);
            return;
        }
        if (quien instanceof ServerPlayer jugador) {
            int tiene = 0;
            Inventory inventario = jugador.getInventory();
            for (int i = 0; i < inventario.getContainerSize(); i++) {
                if (esEstandarte(inventario.getItem(i))) {
                    tiene++;
                }
            }
            if (tiene != 1 || !esEstandarte(jugador.getItemBySlot(EquipmentSlot.HEAD)) || esEstandarte(jugador.containerMenu.getCarried())) {
                sacar(inventario, true);                           // se lo quiso sacar: vuelve a la cabeza
                if (esEstandarte(jugador.containerMenu.getCarried())) {
                    jugador.containerMenu.setCarried(ItemStack.EMPTY);
                }
                ponerEnLaCabeza(jugador, rojoEstandarte);
            }
        } else if (!esEstandarte(quien.getItemBySlot(EquipmentSlot.HEAD))) {
            ponerEnLaCabeza(quien, rojoEstandarte);
        }
        if (tiempo % 20 == 0) {
            quien.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
        }
        if (tiempo % 4 == 0) {
            Vector3f color = rojoEstandarte ? new Vector3f(0.85F, 0.12F, 0.10F) : new Vector3f(0.20F, 0.30F, 0.95F);
            complejo.sendParticles(new DustParticleOptions(color, 1.0F), quien.getX(), quien.getY() + 2.5, quien.getZ(), 2,
                    0.2, 0.2, 0.2, 0.0);
        }
        if (cerca(quien, pedestal(!rojoEstandarte), LLEGAR)) {
            ganar(complejo, !rojoEstandarte, quien);               // ¡lo trajo a su bastión!
        }
    }

    /** El que lo llevaba murió (o se fue): el estandarte vuelve a su bastión. */
    private static void volver(ServerLevel complejo, boolean rojoEstandarte) {
        if (rojoEstandarte) {
            llevaRojo = null;
        } else {
            llevaAzul = null;
        }
        ponerEstandarte(complejo, rojoEstandarte);
        Component aviso = Component.translatable(rojoEstandarte ? "mensaje.juegosdelpatio.volvio_rojo"
                : "mensaje.juegosdelpatio.volvio_azul").withStyle(rojoEstandarte ? ChatFormatting.RED : ChatFormatting.BLUE);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.sendSystemMessage(aviso);
            jugador.playNotifySound(SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.MASTER, 0.8F, 0.7F);
        }
    }

    // ------------------------------------------------------------------ el final
    /** Llegó con el estandarte del otro equipo a su bastión: lo clava al lado del suyo, y el otro equipo pierde. */
    private static void ganar(ServerLevel complejo, boolean rojoGana, LivingEntity portador) {
        Juego.decir(complejo, Component.translatable(rojoGana ? "juego.juegosdelpatio.estandartes_ganan_rojos"
                : "juego.juegosdelpatio.estandartes_ganan_azules", Juego.nombreDe(portador)));
        sacarDeLaCabeza(portador);
        portador.removeEffect(MobEffects.GLOWING);
        if (rojoGana) {
            llevaAzul = null;
        } else {
            llevaRojo = null;
        }
        BlockPos clavado = pedestal(rojoGana).offset(0, 0, 1);
        GUARDADOS.putIfAbsent(clavado, complejo.getBlockState(clavado));
        complejo.setBlock(clavado, (rojoGana ? Blocks.BLUE_BANNER : Blocks.RED_BANNER).defaultBlockState()
                .setValue(BlockStateProperties.ROTATION_16, rojoGana ? GIRO_ROJO : GIRO_AZUL), Block.UPDATE_CLIENTS);
        perder(complejo, !rojoGana, "perdiste_el_estandarte", true);
    }

    /**
     * Un equipo perdió: su bastión se derrumba (con los que estén arriba) y, 3 segundos después, quedan eliminados
     * todos los que sigan. Si {@code conFinal} es false (Juego corta el juego), quedan eliminados ya.
     */
    private static void perder(ServerLevel complejo, boolean rojos, String motivo, boolean conFinal) {
        pierdenRojos = rojos;
        motivoFinal = motivo;
        for (boolean rojoEstandarte : new boolean[] {true, false}) {   // el estandarte que tengan los que pierden, vuelve
            UUID uuid = rojoEstandarte ? llevaRojo : llevaAzul;
            LivingEntity quien = uuid != null ? buscar(complejo, uuid) : null;
            if (quien != null) {
                sacarDeLaCabeza(quien);
                quien.removeEffect(MobEffects.GLOWING);
            }
            if (uuid != null) {
                if (rojoEstandarte) {
                    llevaRojo = null;
                } else {
                    llevaAzul = null;
                }
                ponerEstandarte(complejo, rojoEstandarte);
            }
        }
        derrumbarBastion(complejo, rojos, conFinal);
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.5F);
            if (!juega(jugador)) {
                continue;
            }
            boolean pierde = esRojo(jugador) == rojos;
            Juego.titulo(jugador, Component.translatable(pierde ? "titulo.juegosdelpatio.perdieron" : "titulo.juegosdelpatio.ganaron")
                            .withStyle(pierde ? ChatFormatting.DARK_RED : ChatFormatting.GOLD),
                    Component.translatable(pierde ? "titulo.juegosdelpatio.perdieron_detalle" : "titulo.juegosdelpatio.ganaron_detalle")
                            .withStyle(ChatFormatting.GRAY), 5, 60, 15);
        }
        estado = Estado.FINAL;
        tiempo = 0;
        if (!conFinal) {
            eliminarPerdedores(complejo);
        }
    }

    private static void eliminarPerdedores(ServerLevel complejo) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (esRojo(quien) == pierdenRojos) {
                quitarCosas(quien);
                Juego.eliminar(complejo, quien, false, motivoFinal);
            }
        }
        terminar(complejo);
    }

    private static void terminar(ServerLevel complejo) {
        estado = Estado.TERMINADO;
        pasaron = enJuego(complejo).size();
        for (FallingBlockEntity cae : CAYENDO) {
            cae.discard();                                         // ya no se llama a tick: que no lleguen abajo
        }
        CAYENDO.clear();
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1.0F, 0.6F);
        }
    }

    /** Se terminó el tiempo: pierde el equipo con menos gente en pie. Si están iguales, no pierde nadie. */
    private static void porTiempo(ServerLevel complejo, boolean conFinal) {
        int rojos = vivos(complejo, true);
        int azules = vivos(complejo, false);
        if (rojos != azules) {
            boolean pierden = rojos < azules;
            Juego.decir(complejo, Component.translatable(pierden ? "juego.juegosdelpatio.estandartes_tiempo_rojos"
                    : "juego.juegosdelpatio.estandartes_tiempo_azules"));
            perder(complejo, pierden, "perdio_tu_equipo", conFinal);
        } else {
            Juego.decir(complejo, Component.translatable("juego.juegosdelpatio.estandartes_tiempo_empate"));
            terminar(complejo);
        }
    }

    /** Juego corta el juego (se trabó): se decide ya, por la gente que queda en pie. */
    static void alargue(ServerLevel complejo) {
        if (estado == Estado.TERMINADO || estado == Estado.NINGUNO) {
            return;
        }
        if (estado == Estado.FINAL) {
            eliminarPerdedores(complejo);
            return;
        }
        porTiempo(complejo, false);
    }

    // ------------------------------------------------------------------ derrumbes
    /** Se agrieta el piso de una torre de los costados: en 5 segundos se cae. Ya nadie salta para ahí. */
    private static void agrietar(ServerLevel complejo, int torre) {
        CAMPO.quitar(torre);
        int[] t = TORRES[torre];
        for (int x = t[0]; x <= t[1]; x++) {
            for (int z = t[2]; z <= t[3]; z++) {
                BlockPos pos = new BlockPos(x, PISO - 1, z);
                BlockState antes = complejo.getBlockState(pos);
                if (antes.isAir()) {
                    continue;
                }
                GUARDADOS.putIfAbsent(pos, antes);
                complejo.setBlock(pos, (antes.is(Blocks.POLISHED_BLACKSTONE_BRICKS) ? Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS
                        : Blocks.CRACKED_DEEPSLATE_TILES).defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        double cx = (t[0] + t[1] + 1) / 2.0;
        double cz = (t[2] + t[3] + 1) / 2.0;
        complejo.playSound(null, cx, PISO, cz, SoundEvents.DEEPSLATE_BREAK, SoundSource.BLOCKS, 2.0F, 0.6F);
        complejo.playSound(null, cx, PISO, cz, SoundEvents.GRAVEL_BREAK, SoundSource.BLOCKS, 2.0F, 0.5F);
        AGRIETADAS.put(torre, tiempo + AVISO_DERRUMBE);
    }

    /** Se cae lo de arriba de una torre (el piso y un poco de las paredes), con los que estén ahí. */
    private static void derrumbarTorre(ServerLevel complejo, int torre) {
        int[] t = TORRES[torre];
        anotarArriba(complejo, t[0], t[1], t[2], t[3]);
        derrumbe(complejo, t[0], t[1], t[2], t[3], PISO + 2, 4, 3);
        double cx = (t[0] + t[1] + 1) / 2.0;
        double cz = (t[2] + t[3] + 1) / 2.0;
        complejo.playSound(null, cx, PISO, cz, SoundEvents.DEEPSLATE_BREAK, SoundSource.BLOCKS, 3.0F, 0.4F);
        complejo.playSound(null, cx, PISO, cz, SoundEvents.ANVIL_LAND, SoundSource.BLOCKS, 1.0F, 0.5F);
    }

    /** Se derrumba el bastión del equipo que perdió: el piso, la muralla, las banderas y su estandarte. */
    private static void derrumbarBastion(ServerLevel complejo, boolean rojo, boolean conBloquesCayendo) {
        int[] b = BASTIONES[rojo ? 0 : 1];
        anotarArriba(complejo, b[0], b[1], b[2], b[3]);
        derrumbe(complejo, b[0], b[1], b[2], b[3], PISO + 7, 5, conBloquesCayendo ? 4 : 0);
        double cx = (b[0] + b[1] + 1) / 2.0;
        double cz = (b[2] + b[3] + 1) / 2.0;
        complejo.playSound(null, cx, PISO, cz, SoundEvents.DEEPSLATE_BREAK, SoundSource.BLOCKS, 4.0F, 0.3F);
        complejo.playSound(null, cx, PISO, cz, SoundEvents.ANVIL_LAND, SoundSource.BLOCKS, 2.0F, 0.4F);
    }

    /**
     * Se cae todo lo de esa parte, desde {@code arriba} hasta el piso; las paredes de los bordes, rotas a distinta
     * altura (hasta {@code rotas} bloques más abajo). Primero lo que está colgado o apoyado (banderas, rejas, faroles y
     * luces, también lo de afuera, pegado a las paredes), así nada se suelta ni queda tirado; después lo demás: de eso,
     * uno de cada {@code seVe} se ve caer (0: ninguno).
     */
    private static void derrumbe(ServerLevel complejo, int x0, int x1, int z0, int z1, int arriba, int rotas, int seVe) {
        RandomSource azar = complejo.getRandom();
        for (int x = x0 - 1; x <= x1 + 1; x++) {
            for (int z = z0 - 1; z <= z1 + 1; z++) {
                for (int y = arriba; y >= PISO - 1 - rotas; y--) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (adorno(complejo.getBlockState(pos))) {
                        caer(complejo, pos, false);
                    }
                }
            }
        }
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean borde = x == x0 || x == x1 || z == z0 || z == z1;
                int hasta = borde ? PISO - 2 - azar.nextInt(rotas) : PISO - 1;
                for (int y = arriba; y >= hasta; y--) {
                    caer(complejo, new BlockPos(x, y, z), seVe > 0 && azar.nextInt(seVe) == 0);
                }
            }
        }
    }

    /** Lo que va colgado o apoyado en otro bloque (o no se ve): se saca sin que se suelte. */
    private static boolean adorno(BlockState estado) {
        return estado.is(Blocks.LIGHT) || estado.is(Blocks.IRON_BARS) || estado.is(Blocks.LANTERN) || estado.is(Blocks.SOUL_LANTERN)
                || estado.is(Blocks.RED_BANNER) || estado.is(Blocks.BLUE_BANNER) || estado.is(Blocks.RED_WALL_BANNER)
                || estado.is(Blocks.BLUE_WALL_BANNER);
    }

    /** Los que están arriba de esa parte cuando se derrumba: si mueren, es porque se cayeron con su torre. */
    private static void anotarArriba(ServerLevel complejo, int x0, int x1, int z0, int z1) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getX() >= x0 - 0.3 && quien.getX() < x1 + 1.3 && quien.getZ() >= z0 - 0.3 && quien.getZ() < z1 + 1.3
                    && quien.getY() > PISO - 2 && quien.getY() < PISO + 3) {
                CON_LA_TORRE.add(quien.getUUID());
            }
        }
    }

    /** Ese bloque se cae: a veces se lo ve caer (se borra antes de llegar abajo); si no, se rompe en pedazos. */
    private static void caer(ServerLevel complejo, BlockPos pos, boolean seVe) {
        BlockState antes = complejo.getBlockState(pos);
        if (antes.isAir()) {
            return;
        }
        GUARDADOS.putIfAbsent(pos, antes);
        if (seVe && !adorno(antes)) {
            CAYENDO.add(FallingBlockEntity.fall(complejo, pos, antes));
        } else {
            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            if (!antes.is(Blocks.LIGHT) && complejo.getRandom().nextInt(3) == 0) {
                complejo.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, antes), pos.getX() + 0.5, pos.getY() + 0.5,
                        pos.getZ() + 0.5, 4, 0.3, 0.3, 0.3, 0.05);
            }
        }
    }

    // ------------------------------------------------------------------ golpes y muertes
    /**
     * Vale pegarle a los del otro equipo, una vez que empezó la pelea. A los del propio equipo no (ni antes de que
     * empiece, ni cuando ya terminó), y el que lleva un estandarte no puede pegarle a nadie: esos golpes no hacen nada,
     * y se le avisa al que pegó.
     */
    static void alRecibirGolpe(LivingIncomingDamageEvent evento) {
        LivingEntity victima = evento.getEntity();
        Entity fuente = evento.getSource().getEntity();
        if (!(fuente instanceof LivingEntity atacante) || atacante == victima
                || !(victima instanceof Player || victima instanceof JugadorBot)) {
            return;                                              // caídas y demás: lo de siempre
        }
        if (!juega(victima) || !juega(atacante)) {
            evento.setCanceled(true);                            // los que no juegan no se meten
            return;
        }
        String aviso = estado == Estado.CUENTA ? "estandartes_todavia" : estado != Estado.PELEA ? "ya_termino"
                : esRojo(victima) == esRojo(atacante) ? "no_pegar_companero" : lleva(atacante) ? "con_estandarte_no" : null;
        if (aviso == null) {
            return;                                              // ¡vale!
        }
        evento.setCanceled(true);
        if (atacante instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio." + aviso)
                    .withStyle(ChatFormatting.RED), true);
        }
    }

    /** Murió uno que jugaba: Juego lo anota como eliminado. Acá se le saca todo y se avisa (y quién fue). */
    static void alMorir(ServerLevel complejo, LivingEntity muerto, DamageSource fuente) {
        if (!ROJO.containsKey(muerto.getUUID())) {
            return;
        }
        boolean llevaba = lleva(muerto);
        boolean final_ = estado == Estado.FINAL;
        String clave = CON_LA_TORRE.contains(muerto.getUUID()) ? "cayo_con_su_torre"
                : fuente.getEntity() instanceof LivingEntity asesino && asesino != muerto && muerto.getY() > PISO - 3
                ? "estandartes_mato" : muerto.getY() < PISO - 1 ? "se_cayo" : "estandartes_murio";
        Component mensaje = clave.equals("estandartes_mato") && fuente.getEntity() instanceof LivingEntity asesino
                ? Component.translatable("mensaje.juegosdelpatio.estandartes_mato", Juego.nombreDe(asesino), Juego.nombreDe(muerto))
                : Component.translatable("mensaje.juegosdelpatio." + clave, Juego.nombreDe(muerto));
        quitarCosas(muerto);
        if (llevaba) {
            volver(complejo, Boolean.FALSE.equals(ROJO.get(muerto.getUUID())));   // el que llevaba el del otro equipo
        }
        if (final_) {
            return;                                              // ya se sabe quién perdió: sin un mensaje por cada uno
        }
        for (ServerPlayer jugador : Juego.jugadoresEnArena(complejo)) {
            if (jugador != muerto) {
                jugador.sendSystemMessage(mensaje.copy().withStyle(esRojo(muerto) ? ChatFormatting.RED : ChatFormatting.BLUE));
            }
        }
    }

    /** Se le saca a alguien todo lo del juego (chaleco, espada y estandarte), para que no se le caiga al morir. */
    private static void quitarCosas(LivingEntity quien) {
        if (lleva(quien)) {
            if (quien.getUUID().equals(llevaRojo)) {
                llevaRojo = null;
            } else {
                llevaAzul = null;
            }
            if (quien.level() instanceof ServerLevel complejo) {
                ponerEstandarte(complejo, !esRojo(quien));
            }
        }
        sacarDeLaCabeza(quien);
        Equipos.sacarChaleco(quien);
        quien.removeEffect(MobEffects.GLOWING);
        if (quien instanceof ServerPlayer jugador) {
            sacar(jugador.getInventory(), false);
        } else if (esEspada(quien.getMainHandItem())) {
            quien.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
    }

    // ------------------------------------------------------------------ para los bots
    /** Qué hace el bot (ver DEFENSOR, CENTRO, NORTE y SUR). Desde el minuto 5, la mitad de los que cuidaban, salen. */
    static int papel(JugadorBot bot) {
        int papel = PAPELES.getOrDefault(bot.getUUID(), CENTRO);
        if (papel == DEFENSOR && estado == Estado.PELEA && tiempo > DEFENSA_HASTA
                && Math.floorMod(bot.getUUID().getLeastSignificantBits(), 2) == 0) {
            return CENTRO;
        }
        return papel;
    }

    /** El bastión de un equipo (en el campo de torres). */
    static int bastion(boolean rojo) {
        return rojo ? BASTION_ROJO : BASTION_AZUL;
    }

    /** Por dónde va al otro bastión un bot que va por un costado: dos torres del camino (de su lado y del otro). */
    static int[] ruta(boolean rojo, int papel) {
        if (papel == NORTE) {
            return rojo ? new int[] {11, 14} : new int[] {13, 10};
        }
        if (papel == SUR) {
            return rojo ? new int[] {18, 21} : new int[] {20, 17};
        }
        return new int[0];
    }

    /** Quién lleva el estandarte de ese color (o null: está en su bastión). */
    @Nullable
    static LivingEntity portador(ServerLevel complejo, boolean rojoEstandarte) {
        UUID uuid = rojoEstandarte ? llevaRojo : llevaAzul;
        return uuid == null ? null : buscar(complejo, uuid);
    }

    /** El del otro equipo más cerca del bot, en su misma torre y a menos de {@code radio} bloques (o null). */
    @Nullable
    static LivingEntity enemigoCerca(JugadorBot bot, double radio) {
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return null;
        }
        int aca = CAMPO.torreDe(bot);
        if (aca < 0) {
            return null;
        }
        LivingEntity mejor = null;
        double mejorD = radio * radio;
        for (LivingEntity otro : enJuego(complejo)) {
            if (esRojo(otro) == esRojo(bot) || CAMPO.torreDe(otro) != aca) {
                continue;
            }
            double d = otro.distanceToSqr(bot);
            if (d < mejorD) {
                mejorD = d;
                mejor = otro;
            }
        }
        return mejor;
    }

    /** ¿Esa torre se está por caer (o ya se cayó)? */
    static boolean seCae(int torre) {
        return torre >= 0 && (AGRIETADAS.containsKey(torre) || CAMPO.caida(torre));
    }

    /** Adónde salta un bot que está en una torre que se cae: la de al lado que siga en pie, la del salto más corto. */
    static int refugio(int torre, JugadorBot bot) {
        int mejor = -1;
        double mejorPuntaje = Double.MAX_VALUE;
        for (int v : CAMPO.vecinos[torre]) {
            if (seCae(v)) {
                continue;
            }
            int[] t = TORRES[v];
            double dx = (t[0] + t[1] + 1) / 2.0 - bot.getX();
            double dz = (t[2] + t[3] + 1) / 2.0 - bot.getZ();
            double puntaje = CAMPO.hueco(torre, v) * 10.0 + Math.sqrt(dx * dx + dz * dz);
            if (puntaje < mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = v;
            }
        }
        return mejor;
    }

    /** La probabilidad de que a un bot le salga mal un salto (casi nunca: más en los de 3 y en los más torpes). */
    static double riesgo(JugadorBot bot, int desde, int hacia) {
        double base = CAMPO.hueco(desde, hacia) >= 3 ? 0.015 : 0.004;
        return base * (0.5 + Math.floorMod(bot.getUUID().getMostSignificantBits(), 100) * 0.012);
    }

    /** Un lugar en el bastión de un equipo: para empezar (lejos del estandarte) o, cerca del estandarte, para cuidarlo. */
    static Vec3 lugarEnBastion(ServerLevel complejo, boolean rojo, RandomSource azar, boolean cuidar) {
        BlockPos pie = pedestal(rojo);
        int[] t = TORRES[bastion(rojo)];
        for (int intento = 0; intento < 40; intento++) {
            int x;
            int z;
            if (cuidar) {
                x = pie.getX() - 4 + azar.nextInt(9);
                z = pie.getZ() - 4 + azar.nextInt(9);
            } else {
                x = (rojo ? t[0] : t[0] + 2) + azar.nextInt(t[1] - t[0] - 1);   // sin la fila del frente
                z = t[2] + 1 + azar.nextInt(t[3] - t[2] - 1);
            }
            int dx = x - pie.getX();
            int dz = z - pie.getZ();
            if (x < t[0] || x > t[1] || z < t[2] || z > t[3] || Math.abs(dx) <= 1 && Math.abs(dz) <= 1
                    || !cuidar && dx * dx + dz * dz < 9) {
                continue;
            }
            BlockPos pos = new BlockPos(x, PISO, z);
            if (complejo.getBlockState(pos).isAir() && complejo.getBlockState(pos.above()).isAir()
                    && !complejo.getBlockState(pos.below()).isAir()) {
                return new Vec3(x + 0.5, PISO, z + 0.5);
            }
        }
        return new Vec3(pie.getX() + (rojo ? -2.5 : 3.5), PISO, pie.getZ() + 3.5);
    }

    // ------------------------------------------------------------------ limpiar
    static void limpiar(ServerLevel complejo) {
        for (ServerPlayer jugador : complejo.players()) {
            if (ROJO.containsKey(jugador.getUUID())) {
                Equipos.sacarChaleco(jugador);
                sacarDeLaCabeza(jugador);
                jugador.removeEffect(MobEffects.GLOWING);
            }
            sacar(jugador.getInventory(), false);
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> ROJO.containsKey(bot.getUUID()))) {
            Equipos.sacarChaleco(bot);
            bot.removeEffect(MobEffects.GLOWING);
            if (esEspada(bot.getMainHandItem())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
            if (esEstandarte(bot.getItemBySlot(EquipmentSlot.HEAD))) {
                bot.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            }
        }
        for (ItemEntity tirada : complejo.getEntitiesOfClass(ItemEntity.class, caja(), tirada -> esEspada(tirada.getItem())
                || Equipos.esChaleco(tirada.getItem()) || tirada.getItem().is(Items.RED_BANNER) || tirada.getItem().is(Items.BLUE_BANNER))) {
            tirada.discard();
        }
        for (FallingBlockEntity cae : CAYENDO) {
            cae.discard();
        }
        for (Map.Entry<BlockPos, BlockState> guardado : GUARDADOS.entrySet()) {      // todo como estaba
            complejo.setBlock(guardado.getKey(), guardado.getValue(), Block.UPDATE_CLIENTS);
        }
        GUARDADOS.clear();
        if (EstadoComplejo.de(complejo.getServer()).versionEstandartes() == VERSION_ARENA) {
            ponerEstandarte(complejo, true);
            ponerEstandarte(complejo, false);
        }
        olvidar();
    }

    static void olvidar() {
        estado = Estado.NINGUNO;
        tiempo = 0;
        ROJO.clear();
        PAPELES.clear();
        llevaRojo = null;
        llevaAzul = null;
        CABEZAS.clear();
        ORDEN.clear();
        siguientePar = 0;
        AGRIETADAS.clear();
        CON_LA_TORRE.clear();
        GUARDADOS.clear();
        CAYENDO.clear();
        pierdenRojos = false;
        motivoFinal = "perdio_tu_equipo";
        enJuegoCache = null;
        enJuegoTick = -1;
        CAMPO.restaurar();
        Equipos.olvidar();
    }

    /** Saca las espadas (y, si se pide, los estandartes) de un inventario. */
    private static void sacar(Inventory inventario, boolean soloEstandartes) {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack cosa = inventario.getItem(i);
            if (esEstandarte(cosa) || !soloEstandartes && esEspada(cosa)) {
                inventario.setItem(i, ItemStack.EMPTY);
            }
        }
    }

    // ------------------------------------------------------------------ la arena
    /** Dónde aparece quien llega: en el palco, delante del podio. */
    static Vec3 lugarDeSalida(RandomSource azar) {
        return new Vec3(7980.5 + azar.nextInt(41), PISO, -10.5 + azar.nextInt(10));
    }

    /** ¿Quedó algo roto (de un juego que se cortó sin arreglarlo)? */
    private static boolean hayDerrumbes(ServerLevel complejo) {
        if (EstadoComplejo.de(complejo.getServer()).versionEstandartes() != VERSION_ARENA) {
            return false;
        }
        for (int[] t : TORRES) {
            for (int x = t[0]; x <= t[1]; x++) {
                for (int z = t[2]; z <= t[3]; z++) {
                    BlockState piso = complejo.getBlockState(new BlockPos(x, PISO - 1, z));
                    if (piso.isAir() || piso.is(Blocks.CRACKED_DEEPSLATE_TILES) || piso.is(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    static boolean prepararArena(ServerLevel complejo) {
        EstadoComplejo estadoComplejo = EstadoComplejo.de(complejo.getServer());
        if (estadoComplejo.versionEstandartes() == VERSION_ARENA) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(ARENA);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", ARENA);
            return false;
        }
        if (estadoComplejo.versionEstandartes() > 0) {               // lo de antes (el patio de La batalla), afuera
            BlockState aire = Blocks.AIR.defaultBlockState();
            for (BlockPos pos : BlockPos.betweenClosed(X0, SUELO - 2, Z0, X1, PISO + 18, Z1)) {
                if (!complejo.getBlockState(pos).isAir()) {
                    complejo.setBlock(pos, aire, Block.UPDATE_CLIENTS);
                }
            }
        }
        plantilla.get().placeInWorld(complejo, ORIGEN, ORIGEN, new StructurePlaceSettings(), complejo.getRandom(),
                Block.UPDATE_CLIENTS);
        estadoComplejo.setVersionEstandartes(VERSION_ARENA);
        JuegosDelPatio.LOGGER.info("Arena de Los estandartes colocada en {}", ORIGEN);
        return true;
    }

    private static AABB caja() {
        return new AABB(X0, SUELO - 2, Z0, X1 + 1, PISO + 16, Z1 + 1);
    }

    // ------------------------------------------------------------------ ayudas
    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID uuid) {
        for (LivingEntity quien : enJuego(complejo)) {
            if (quien.getUUID().equals(uuid)) {
                return quien;
            }
        }
        return null;
    }

    /** Los que siguen jugando (vivos y sin eliminar). Se arma una vez por tick: los bots lo piden todo el tiempo. */
    private static List<LivingEntity> enJuego(ServerLevel complejo) {
        long ahora = complejo.getGameTime();
        if (ahora == enJuegoTick && enJuegoCache != null) {
            List<LivingEntity> vivos = new ArrayList<>();
            for (LivingEntity quien : enJuegoCache) {
                if (quien.isAlive() && !Juego.eliminado(quien)) {
                    vivos.add(quien);
                }
            }
            return vivos;
        }
        List<LivingEntity> lista = new ArrayList<>();
        for (LivingEntity quien : Juego.participantes(complejo)) {
            if (ROJO.containsKey(quien.getUUID())) {
                lista.add(quien);
            }
        }
        enJuegoCache = lista;
        enJuegoTick = ahora;
        return new ArrayList<>(lista);
    }

    private static int vivos(ServerLevel complejo, boolean rojo) {
        int cuantos = 0;
        for (LivingEntity quien : enJuego(complejo)) {
            if (esRojo(quien) == rojo) {
                cuantos++;
            }
        }
        return cuantos;
    }
}
