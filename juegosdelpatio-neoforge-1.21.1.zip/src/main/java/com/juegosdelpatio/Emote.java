package com.juegosdelpatio;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.RandomSource;

/** Emoticones que los bots muestran al lado de su nombre. */
public enum Emote {
    HOLA("¡Hola!", ChatFormatting.WHITE, true),
    FELIZ(":D", ChatFormatting.YELLOW, false),
    RISA("jaja", ChatFormatting.YELLOW, false),
    CARITA("☺", ChatFormatting.GOLD, false),
    CORAZON("♥", ChatFormatting.RED, false),
    MUSICA("♪", ChatFormatting.AQUA, false),
    TRISTE("☹", ChatFormatting.BLUE, false),
    ENOJO(">:(", ChatFormatting.RED, false),
    GG("gg", ChatFormatting.GREEN, false),
    DUDA("?", ChatFormatting.WHITE, false),
    PAZ("✌", ChatFormatting.GOLD, false),
    XD("xD", ChatFormatting.LIGHT_PURPLE, false),
    DORMIDO("zzz", ChatFormatting.GRAY, false);

    private static final Emote[] CHARLA = {FELIZ, RISA, CARITA, CORAZON, MUSICA, TRISTE, ENOJO, GG, DUDA, PAZ, XD, HOLA};

    public final String texto;
    public final ChatFormatting color;
    public final boolean saludo;

    Emote(String texto, ChatFormatting color, boolean saludo) {
        this.texto = texto;
        this.color = color;
        this.saludo = saludo;
    }

    /** Partículas que acompañan al emoticón (o null). */
    public SimpleParticleType particula() {
        return switch (this) {
            case CORAZON -> ParticleTypes.HEART;
            case MUSICA -> ParticleTypes.NOTE;
            case FELIZ, RISA, CARITA, XD, GG -> ParticleTypes.HAPPY_VILLAGER;
            case ENOJO -> ParticleTypes.ANGRY_VILLAGER;
            default -> null;
        };
    }

    /** Emoticones contentos, que a veces vienen con saltitos. */
    public boolean alegre() {
        return this == FELIZ || this == RISA || this == CARITA || this == GG || this == XD;
    }

    public static Emote alAzar(RandomSource azar) {
        return CHARLA[azar.nextInt(CHARLA.length)];
    }
}
