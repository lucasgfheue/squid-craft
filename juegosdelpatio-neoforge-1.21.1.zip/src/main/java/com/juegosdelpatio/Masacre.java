package com.juegosdelpatio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * La noche después del tercer juego (la noche del pastel). En la cena les dan a todos un pastel y una espada para
 * cortarlo; cuando terminan de comer:
 *
 * <ol>
 *   <li><b>La pelea.</b> Dos bots se pelean a las piñas frente al escenario y todos los demás se juntan alrededor a
 *       mirar. Uno de los dos muere.</li>
 *   <li><b>El apagón.</b> Se apagan las luces y todos se van a dormir (el que ganó la pelea también).</li>
 *   <li><b>El acecho.</b> El que ganó se levanta, va agachado con su espada hasta uno que está durmiendo y lo mata de
 *       un golpe.</li>
 *   <li><b>La masacre (2 minutos).</b> Las luces se prenden y parpadean todo el rato; todos se despiertan: unos
 *       huyen y otros atacan con la espada a cualquiera que vean (jugadores también). Los guardias de la sala no se
 *       meten.</li>
 *   <li><b>Los guardias.</b> Se terminan los dos minutos: las luces quedan prendidas, entran los guardias corriendo
 *       con las armas en alto, les quitan las espadas a todos y desde ahí está prohibido pelear (hasta la mañana).
 *       El comandante dice cuántos murieron, cuánto es el premio y que el cuarto juego está por empezar, y se va
 *       (ver {@link Ceremonia#empezarMasacre}). Al minuto, a dormir como siempre.</li>
 * </ol>
 *
 * El que muere esa noche queda tirado en el piso (un {@link Cuerpo}) y eliminado: el premio sube como siempre.
 */
final class Masacre {
    enum Fase { NINGUNA, PELEA, APAGON, ACECHO, MASACRE, GUARDIAS }

    /** El medio de la ronda de la pelea: en el lugar del público, frente al escenario. */
    static final Vec3 RING = new Vec3(0.5, 65.0, 21.5);
    /** Cada peleador, a este costado del medio (uno de cada lado). */
    private static final double LADO = 1.1;
    /** Antes de la primera piña: los dos se ponen frente a frente y los demás se juntan alrededor. */
    static final int JUNTARSE = 6 * 20;
    /** Si la pelea dura más que esto, el que pierde cae igual. */
    private static final int PELEA_MAX = 45 * 20;
    /** Cuánto duermen antes de que el que ganó la pelea se levante (antes, si ya están casi todos dormidos). */
    static final int APAGON = 30 * 20;
    private static final int APAGON_MIN = 20 * 20;
    /** Si en este tiempo no llegó hasta el que duerme, igual empieza la masacre. */
    private static final int ACECHO_MAX = 50 * 20;
    /** La masacre: 2 minutos. */
    static final int DURACION = 2 * 60 * 20;
    /** Lo que saca la espada del pastel cuando pega un bot (5 golpes matan). */
    static final float DANO_BOT = 4.0F;
    /** De todos los bots que había, en la masacre muere como mucho esta parte: después ya nadie ataca. */
    private static final double MUERTOS_MAX = 0.45;
    /** Al empezar la masacre, uno de cada tantos bots ataca (el que mató al que dormía, siempre). */
    private static final float ATACAN = 0.35F;
    /** Al que huye y le pegan, a veces se defiende (y desde ahí ataca él también). */
    private static final float SE_DEFIENDEN = 0.4F;
    /** El que ataca ve hasta acá; el que huye se escapa del que ataca si lo tiene a menos de esto. */
    private static final double VISTA = 18.0;
    private static final double PELIGRO = 10.0;
    /** Desde dónde pega el que ataca. */
    private static final double ALCANCE = 2.6;
    /** La sala (salón, baños y comedor), sin el pasillo de los guardias. */
    private static final AABB SALA = new AABB(-32, 60, -33, 33, 90, 69);
    /** Lo que hace el público mientras mira la pelea. */
    private static final Emote[] PUBLICO = {Emote.DUDA, Emote.TRISTE, Emote.ENOJO, Emote.RISA, Emote.XD};

    private static Fase fase = Fase.NINGUNA;
    private static int tiempo;
    /** Los dos que se pelean: el que gana (después mata al que duerme y empieza la masacre) y el que pierde. */
    @Nullable
    private static JugadorBot ganador;
    @Nullable
    private static JugadorBot perdedor;
    private static int esperaGolpe;
    /** Al que va a matar mientras duerme. */
    @Nullable
    private static UUID victima;
    /** Los muertos de esta noche (todos, y los de la masacre), y cuántos bots había al empezar. */
    private static int muertos;
    private static int muertosMasacre;
    private static int botsAlEmpezar;
    /** Después de la masacre está prohibido pelear en la sala (hasta la mañana). */
    private static boolean prohibido;
    /** En la masacre: quién ataca (los demás huyen), a quién va cada uno y cuánto le falta para el próximo golpe. */
    private static final Map<UUID, Boolean> ATACA = new HashMap<>();
    private static final Map<UUID, UUID> OBJETIVO = new HashMap<>();
    private static final Map<UUID, Integer> ESPERA = new HashMap<>();

    private Masacre() {
    }

    // ------------------------------------------------------------------ consultas
    static boolean enCurso() {
        return fase != Fase.NINGUNA;
    }

    /** Las luces apagadas antes de la masacre: los bots se acuestan y los jugadores pueden dormir. */
    static boolean horaDeDormir() {
        return fase == Fase.APAGON || fase == Fase.ACECHO;
    }

    /** El que ganó la pelea, que se levanta en el medio del apagón (no vuelve a la cama). */
    static boolean despierto(LivingEntity bot) {
        return fase == Fase.ACECHO && bot == ganador;
    }

    /** Ya pasó la masacre: está prohibido pelear (hasta la mañana). */
    static boolean prohibido() {
        return prohibido;
    }

    /** ¿Esta noche este bot hace lo que dice la masacre? (la pelea y su público, el que acecha, y en la masacre todos) */
    static boolean controla(JugadorBot bot) {
        if (!bot.isAlive() || !enLaSala(bot)) {
            return false;
        }
        return switch (fase) {
            case PELEA, MASACRE -> true;
            case ACECHO -> bot == ganador;
            default -> false;
        };
    }

    // ------------------------------------------------------------------ el pastel y la espada
    /** La espada para cortar el pastel (una de hierro con su nombre; los guardias la reconocen y se la llevan). */
    static ItemStack espadaPastel() {
        ItemStack espada = new ItemStack(Items.IRON_SWORD);
        espada.set(DataComponents.ITEM_NAME, Component.translatable("item.juegosdelpatio.espada_pastel"));
        CompoundTag marca = new CompoundTag();
        marca.putBoolean("EspadaPastel", true);
        espada.set(DataComponents.CUSTOM_DATA, CustomData.of(marca));
        return espada;
    }

    static boolean esEspadaPastel(ItemStack cosa) {
        CustomData datos = cosa.get(DataComponents.CUSTOM_DATA);
        return datos != null && cosa.is(Items.IRON_SWORD) && datos.copyTag().getBoolean("EspadaPastel");
    }

    /** El pastel de la cena: se puede comer así como viene (clic derecho al aire) o ponerlo en el piso. */
    static ItemStack pastel() {
        ItemStack pastel = new ItemStack(Items.CAKE);
        pastel.set(DataComponents.FOOD, new FoodProperties.Builder().nutrition(8).saturationModifier(0.6F).build());
        return pastel;
    }

    // ------------------------------------------------------------------ empieza: la pelea
    /**
     * Terminó la cena del tercer juego: dos bots empiezan a pelearse. false si no se puede (hacen falta por lo menos 3
     * bots en la sala): entonces la noche es como siempre.
     */
    static boolean empezar(ServerLevel complejo) {
        if (fase != Fase.NINGUNA) {
            return false;
        }
        List<JugadorBot> bots = botsEnLaSala(complejo);
        if (bots.size() < 3) {
            return false;
        }
        olvidar();
        RandomSource azar = complejo.getRandom();
        bots.sort(Comparator.comparingDouble(bot -> bot.distanceToSqr(RING.x, RING.y, RING.z)));
        int cerca = Math.min(10, bots.size());
        JugadorBot uno = bots.get(azar.nextInt(cerca));                // dos de los que están cerca de la ronda
        JugadorBot otro = uno;
        while (otro == uno) {
            otro = bots.get(azar.nextInt(cerca));
        }
        ganador = uno;
        perdedor = otro;
        botsAlEmpezar = bots.size();
        fase = Fase.PELEA;
        tiempo = 0;
        esperaGolpe = JUNTARSE;
        for (JugadorBot peleador : List.of(uno, otro)) {
            peleador.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);   // a las piñas
            peleador.mostrarEmote(Emote.ENOJO);
        }
        decir(complejo, Component.translatable("mensaje.juegosdelpatio.masacre_pelea", uno.nombre(), otro.nombre())
                .withStyle(ChatFormatting.GOLD), null);
        return true;
    }

    // ------------------------------------------------------------------ cada tick
    static void alTick(ServerTickEvent.Post evento) {
        if (fase == Fase.NINGUNA) {
            return;
        }
        ServerLevel complejo = evento.getServer().getLevel(Complejo.DIMENSION);
        if (complejo == null) {
            return;
        }
        tiempo++;
        switch (fase) {
            case PELEA -> pelea(complejo);
            case APAGON -> {
                if (tiempo >= APAGON || tiempo >= APAGON_MIN && casiTodosDuermen(complejo)) {
                    empezarAcecho(complejo);
                }
            }
            case ACECHO -> acecho(complejo);
            case MASACRE -> masacre(complejo);
            default -> {
            }
        }
    }

    /** Los dos se dan piñas por turnos (un poco más el que va a ganar) hasta que uno cae. */
    private static void pelea(ServerLevel complejo) {
        if (ganador == null || !ganador.isAlive()) {
            ganador = perdedor != null && perdedor.isAlive() ? perdedor : null;   // (alguien lo mató): gana el otro
            perdedor = null;
            apagar(complejo);
            return;
        }
        if (perdedor == null || !perdedor.isAlive()) {
            apagar(complejo);                                          // uno cayó: se apagan las luces
            return;
        }
        if (tiempo > PELEA_MAX) {
            perdedor.hurt(ganador.damageSources().mobAttack(ganador), 1000.0F);
            return;
        }
        if (tiempo < JUNTARSE || --esperaGolpe > 0) {
            return;
        }
        RandomSource azar = complejo.getRandom();
        esperaGolpe = 12 + azar.nextInt(14);
        boolean pegaElQueGana = azar.nextFloat() < 0.6F;
        JugadorBot atacante = pegaElQueGana ? ganador : perdedor;
        JugadorBot golpeado = pegaElQueGana ? perdedor : ganador;
        if (atacante.distanceToSqr(golpeado) > 3.2 * 3.2) {
            return;                                                    // todavía no están frente a frente
        }
        float dano = 2.0F + azar.nextFloat() * 2.0F;
        if (golpeado == ganador) {
            dano = Math.min(dano, Math.max(0.0F, ganador.getHealth() - 8.0F));   // el que gana no cae
        }
        atacante.getLookControl().setLookAt(golpeado, 30.0F, 30.0F);
        atacante.swing(InteractionHand.MAIN_HAND);
        if (dano > 0.0F) {
            golpeado.hurt(atacante.damageSources().mobAttack(atacante), dano);
        } else {
            complejo.playSound(null, golpeado.getX(), golpeado.getY(), golpeado.getZ(), SoundEvents.PLAYER_ATTACK_WEAK,
                    SoundSource.PLAYERS, 0.8F, 0.9F);
        }
    }

    /** Se apagan las luces: todos a dormir (el que ganó la pelea también). */
    private static void apagar(ServerLevel complejo) {
        fase = Fase.APAGON;
        tiempo = 0;
        Noche.luces(complejo, false);
        for (ServerPlayer jugador : jugadoresEnLaSala(complejo)) {
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.luces").withStyle(ChatFormatting.DARK_AQUA),
                    Component.translatable("titulo.juegosdelpatio.a_dormir").withStyle(ChatFormatting.GRAY), 10, 70, 20);
            jugador.playNotifySound(SoundEvents.BEACON_DEACTIVATE, SoundSource.AMBIENT, 1.0F, 0.8F);
        }
    }

    private static boolean casiTodosDuermen(ServerLevel complejo) {
        List<JugadorBot> bots = botsEnLaSala(complejo);
        int duermen = 0;
        for (JugadorBot bot : bots) {
            if (bot.isSleeping()) {
                duermen++;
            }
        }
        return !bots.isEmpty() && duermen >= bots.size() * 0.7;
    }

    // ------------------------------------------------------------------ el acecho
    /** El que ganó la pelea se levanta y va agachado, con la espada, hasta uno que duerme. */
    private static void empezarAcecho(ServerLevel complejo) {
        if (ganador == null || !ganador.isAlive()) {
            ganador = null;
            for (JugadorBot bot : botsEnLaSala(complejo)) {
                if (ganador == null || bot.isSleeping() && !ganador.isSleeping()) {
                    ganador = bot;                                     // (el de la pelea ya no está): otro cualquiera
                }
            }
        }
        LivingEntity presa = ganador == null ? null : elegirVictima(complejo, ganador);
        if (ganador == null || presa == null) {
            empezarMasacre(complejo, ganador, null);
            return;
        }
        victima = presa.getUUID();
        fase = Fase.ACECHO;
        tiempo = 0;
        if (ganador.isSleeping()) {
            ganador.stopSleeping();
        }
        ganador.setItemSlot(EquipmentSlot.MAINHAND, espadaPastel());
        ganador.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    /** Uno que duerme (mejor un bot, y no muy lejos); si no hay nadie durmiendo, cualquiera. */
    @Nullable
    private static LivingEntity elegirVictima(ServerLevel complejo, JugadorBot asesino) {
        List<LivingEntity> duermen = new ArrayList<>();
        for (JugadorBot bot : botsEnLaSala(complejo)) {
            if (bot != asesino && bot.isSleeping() && bot.distanceToSqr(asesino) < 40.0 * 40.0) {
                duermen.add(bot);
            }
        }
        if (duermen.isEmpty()) {
            for (ServerPlayer jugador : jugadoresEnLaSala(complejo)) {
                if (jugador.isSleeping()) {
                    duermen.add(jugador);
                }
            }
        }
        if (duermen.isEmpty()) {
            for (JugadorBot bot : botsEnLaSala(complejo)) {
                if (bot != asesino) {
                    duermen.add(bot);
                }
            }
        }
        return duermen.isEmpty() ? null : duermen.get(complejo.getRandom().nextInt(duermen.size()));
    }

    private static void acecho(ServerLevel complejo) {
        LivingEntity presa = victima == null ? null : buscar(complejo, victima);
        if (ganador == null || !ganador.isAlive() || presa == null || !presa.isAlive()) {
            empezarMasacre(complejo, ganador, null);
            return;
        }
        double d2 = ganador.distanceToSqr(presa);
        if (d2 < 2.3 * 2.3 || tiempo > ACECHO_MAX && d2 < 8.0 * 8.0) {
            ganador.getLookControl().setLookAt(presa, 30.0F, 30.0F);
            ganador.swing(InteractionHand.MAIN_HAND);
            presa.hurt(ganador.damageSources().mobAttack(ganador), 1000.0F);   // de un golpe
            empezarMasacre(complejo, ganador, presa);
        } else if (tiempo > ACECHO_MAX) {
            empezarMasacre(complejo, ganador, null);
        }
    }

    // ------------------------------------------------------------------ la masacre
    /** Las luces se prenden y parpadean; todos se despiertan: unos atacan y otros huyen. */
    private static void empezarMasacre(ServerLevel complejo, @Nullable JugadorBot asesino, @Nullable LivingEntity muerto) {
        fase = Fase.MASACRE;
        tiempo = 0;
        muertosMasacre = 0;
        Noche.luces(complejo, true);
        Parpadeo aviso = new Parpadeo(DURACION, Parpadeo.MASACRE);
        MutableComponent detalle = asesino != null && muerto != null
                ? Component.translatable("titulo.juegosdelpatio.masacre_detalle", asesino.nombre(), nombreDe(muerto))
                : Component.translatable("titulo.juegosdelpatio.masacre_detalle_sin");
        for (ServerPlayer jugador : jugadoresEnLaSala(complejo)) {
            if (jugador.isSleeping()) {
                jugador.stopSleepInBed(true, true);                    // ¡todos despiertos!
            }
            PacketDistributor.sendToPlayer(jugador, aviso);
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.masacre").withStyle(ChatFormatting.DARK_RED),
                    detalle.withStyle(ChatFormatting.GRAY), 5, 60, 15);
            jugador.playNotifySound(SoundEvents.RAID_HORN.value(), SoundSource.MASTER, 0.9F, 1.2F);
        }
        RandomSource azar = complejo.getRandom();
        ATACA.clear();
        OBJETIVO.clear();
        ESPERA.clear();
        for (JugadorBot bot : botsEnLaSala(complejo)) {
            if (bot.isSleeping()) {
                bot.stopSleeping();
            }
            boolean ataca = bot == asesino || azar.nextFloat() < ATACAN;
            ATACA.put(bot.getUUID(), ataca);
            if (ataca) {
                armar(bot);
            }
        }
    }

    private static void masacre(ServerLevel complejo) {
        boolean apagadas = Parpadeo.apagadas(tiempo, Parpadeo.MASACRE);
        if (apagadas != Parpadeo.apagadas(tiempo - 1, Parpadeo.MASACRE)) {
            for (ServerPlayer jugador : jugadoresEnLaSala(complejo)) {
                jugador.playNotifySound(apagadas ? SoundEvents.COPPER_BULB_TURN_OFF : SoundEvents.COPPER_BULB_TURN_ON,
                        SoundSource.BLOCKS, 0.8F, apagadas ? 0.8F : 1.0F);
            }
        }
        if (tiempo % 40 == 0 && muertosMasacre < tope()) {
            List<JugadorBot> huyen = new ArrayList<>();
            int atacan = 0;
            for (JugadorBot bot : botsEnLaSala(complejo)) {
                if (ATACA.getOrDefault(bot.getUUID(), false)) {
                    atacan++;
                } else {
                    huyen.add(bot);
                }
            }
            RandomSource azar = complejo.getRandom();
            while (atacan < 3 && !huyen.isEmpty()) {                   // siempre hay alguno atacando
                JugadorBot nuevo = huyen.remove(azar.nextInt(huyen.size()));
                ATACA.put(nuevo.getUUID(), true);
                armar(nuevo);
                atacan++;
            }
        }
        if (tiempo >= DURACION) {
            llegarGuardias(complejo);
        }
    }

    /** Cuántos pueden morir en la masacre como mucho (después ya nadie ataca). */
    private static int tope() {
        return Math.max(3, (int) Math.ceil(botsAlEmpezar * MUERTOS_MAX));
    }

    private static void armar(JugadorBot bot) {
        if (!esEspadaPastel(bot.getMainHandItem())) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, espadaPastel());
            bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        }
    }

    // ------------------------------------------------------------------ los guardias
    /** Pasaron los 2 minutos: las luces quedan prendidas, entran los guardias y se terminan las peleas. */
    private static void llegarGuardias(ServerLevel complejo) {
        fase = Fase.GUARDIAS;
        tiempo = 0;
        prohibido = true;
        Parpadeo corte = new Parpadeo(0, Parpadeo.MASACRE);
        for (ServerPlayer jugador : jugadoresEnLaSala(complejo)) {
            PacketDistributor.sendToPlayer(jugador, corte);
            Juego.titulo(jugador, Component.translatable("titulo.juegosdelpatio.quietos").withStyle(ChatFormatting.RED),
                    Component.translatable("titulo.juegosdelpatio.quietos_detalle").withStyle(ChatFormatting.GRAY), 5, 60, 15);
        }
        Noche.luces(complejo, true);
        quitarEspadas(complejo);
        ATACA.clear();
        OBJETIVO.clear();
        ESPERA.clear();
        if (!Ceremonia.empezarMasacre(complejo, muertos)) {
            ceremoniaTerminada(complejo);                              // (no pudieron entrar): sigue la noche
        }
    }

    /** Los guardias les quitan las espadas del pastel a todos (jugadores y bots). */
    private static void quitarEspadas(ServerLevel complejo) {
        for (ServerPlayer jugador : complejo.players()) {
            Inventory inventario = jugador.getInventory();
            boolean tenia = false;
            for (int i = 0; i < inventario.getContainerSize(); i++) {
                if (esEspadaPastel(inventario.getItem(i))) {
                    inventario.setItem(i, ItemStack.EMPTY);
                    tenia = true;
                }
            }
            if (esEspadaPastel(jugador.containerMenu.getCarried())) {
                jugador.containerMenu.setCarried(ItemStack.EMPTY);
                tenia = true;
            }
            if (tenia) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.masacre_sin_espada")
                        .withStyle(ChatFormatting.RED), true);
            }
        }
        for (ItemEntity tirada : complejo.getEntitiesOfClass(ItemEntity.class, SALA, tirada -> esEspadaPastel(tirada.getItem()))) {
            tirada.discard();                                          // las que quedaron tiradas en el piso
        }
        for (JugadorBot bot : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> true)) {
            if (esEspadaPastel(bot.getMainHandItem())) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
            bot.setTarget(null);
            bot.getNavigation().stop();
            bot.dejarDeCorrer();
            pararse(bot);
        }
        decir(complejo, Component.translatable("mensaje.juegosdelpatio.masacre_espadas").withStyle(ChatFormatting.RED), null);
    }

    /** Se fue el comandante y se cerró el portón: la noche sigue como siempre (al minuto, a dormir). */
    static void ceremoniaTerminada(ServerLevel complejo) {
        fase = Fase.NINGUNA;
        tiempo = 0;
        ganador = null;
        perdedor = null;
        victima = null;
        Noche.ceremoniaTerminada(complejo.getServer());
    }

    /** Empezó el día siguiente: se termina la prohibición de pelear de esa noche. */
    static void amanecio() {
        prohibido = false;
    }

    // ------------------------------------------------------------------ los bots
    /** Cada tick, a cada bot que esta noche hace lo que dice la masacre (ver {@link #controla}). */
    static void guiar(JugadorBot bot) {
        switch (fase) {
            case PELEA -> guiarPelea(bot);
            case ACECHO -> guiarAcecho(bot);
            case MASACRE -> guiarMasacre(bot);
            default -> {
            }
        }
    }

    /** Termina lo que le hacía hacer la masacre: se para derecho y deja de correr. */
    static void soltar(JugadorBot bot) {
        bot.dejarDeCorrer();
        bot.getNavigation().stop();
        pararse(bot);
    }

    private static void guiarPelea(JugadorBot bot) {
        bot.dejarDeCorrer();
        if (bot == ganador || bot == perdedor) {
            JugadorBot rival = bot == ganador ? perdedor : ganador;
            irA(bot, RING.add(bot == ganador ? -LADO : LADO, 0.0, 0.0), 1.0, 0.5);   // frente a frente
            if (rival != null) {
                bot.getLookControl().setLookAt(rival, 30.0F, 30.0F);
            }
            return;
        }
        double angulo = Math.toRadians(Math.floorMod(bot.getId() * 137, 360));
        double radio = 4.5 + Math.floorMod(bot.getId(), 3) * 0.9;
        irA(bot, RING.add(Math.cos(angulo) * radio, 0.0, Math.sin(angulo) * radio), 1.0, 1.2);   // en ronda, alrededor
        bot.getLookControl().setLookAt(RING.x, RING.y + 1.5, RING.z);
        if (bot.getRandom().nextInt(240) == 0) {
            bot.mostrarEmote(PUBLICO[bot.getRandom().nextInt(PUBLICO.length)]);
        }
    }

    private static void guiarAcecho(JugadorBot bot) {
        bot.dejarDeCorrer();
        bot.setShiftKeyDown(true);                                     // agachado, sin hacer ruido
        bot.setPose(Pose.CROUCHING);
        LivingEntity presa = victima == null || !(bot.level() instanceof ServerLevel complejo) ? null : buscar(complejo, victima);
        if (presa == null) {
            bot.getNavigation().stop();
            return;
        }
        bot.getLookControl().setLookAt(presa, 30.0F, 30.0F);
        if (bot.distanceToSqr(presa) > 2.0 * 2.0 && (bot.getNavigation().isDone() || bot.tickCount % 20 == 0)) {
            bot.getNavigation().moveTo(presa.getX(), presa.getY(), presa.getZ(), 0.6);
        }
    }

    private static void guiarMasacre(JugadorBot bot) {
        if (bot.isSleeping()) {
            bot.stopSleeping();
        }
        ESPERA.put(bot.getUUID(), Math.max(0, ESPERA.getOrDefault(bot.getUUID(), 0) - 1));
        if (ATACA.getOrDefault(bot.getUUID(), false) && muertosMasacre < tope()) {
            atacar(bot);
        } else {
            huir(bot);
        }
    }

    /** El que ataca va por el más cercano que ve (jugador o bot) y le pega con la espada. */
    private static void atacar(JugadorBot bot) {
        pararse(bot);
        armar(bot);
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return;
        }
        UUID id = OBJETIVO.get(bot.getUUID());
        LivingEntity objetivo = id == null ? null : buscar(complejo, id);
        if (objetivo != null && (!objetivo.isAlive() || !enLaSala(objetivo) || bot.distanceToSqr(objetivo) > 24.0 * 24.0)) {
            objetivo = null;
        }
        if (objetivo == null || bot.tickCount % 20 == 0 && !bot.hasLineOfSight(objetivo)) {
            objetivo = masCercanoQueVe(complejo, bot);
        }
        if (objetivo == null) {
            OBJETIVO.remove(bot.getUUID());
            bot.dejarDeCorrer();
            if (bot.getNavigation().isDone() && bot.getRandom().nextInt(30) == 0) {
                Vec3 lugar = DefaultRandomPos.getPos(bot, 10, 4);       // busca a quién
                if (lugar != null) {
                    bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, 1.0);
                }
            }
            return;
        }
        OBJETIVO.put(bot.getUUID(), objetivo.getUUID());
        bot.getLookControl().setLookAt(objetivo, 30.0F, 30.0F);
        if (bot.distanceToSqr(objetivo) > ALCANCE * ALCANCE) {
            bot.empezarACorrer();
            if (bot.getNavigation().isDone() || bot.tickCount % 8 == 0) {
                bot.getNavigation().moveTo(objetivo, 1.25);
            }
            return;
        }
        bot.getNavigation().stop();
        if (ESPERA.getOrDefault(bot.getUUID(), 0) <= 0) {
            bot.swing(InteractionHand.MAIN_HAND);
            objetivo.hurt(bot.damageSources().mobAttack(bot), DANO_BOT);
            ESPERA.put(bot.getUUID(), 14 + bot.getRandom().nextInt(10));
        }
    }

    /** El que no ataca se escapa del que tiene cerca con una espada; si no hay peligro, se agacha y espera. */
    private static void huir(JugadorBot bot) {
        if (esEspadaPastel(bot.getMainHandItem()) && muertosMasacre >= tope()) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);   // ya no ataca nadie
        }
        if (!(bot.level() instanceof ServerLevel complejo)) {
            return;
        }
        LivingEntity peligro = peligroCerca(complejo, bot);
        if (peligro == null) {
            bot.dejarDeCorrer();
            if (!bot.getNavigation().isDone() && bot.getRandom().nextInt(20) == 0) {
                bot.getNavigation().stop();
            }
            bot.setShiftKeyDown(true);                                 // se esconde como puede
            bot.setPose(Pose.CROUCHING);
            return;
        }
        pararse(bot);
        bot.empezarACorrer();
        if (bot.getNavigation().isDone() || bot.tickCount % 10 == 0) {
            Vec3 lejos = DefaultRandomPos.getPosAway(bot, 14, 6, peligro.position());
            if (lejos != null) {
                bot.getNavigation().moveTo(lejos.x, lejos.y, lejos.z, 1.25);
            }
        }
    }

    /** El más cercano que el bot ve (jugador o bot, de la sala), a menos de {@link #VISTA}. */
    @Nullable
    private static LivingEntity masCercanoQueVe(ServerLevel complejo, JugadorBot bot) {
        LivingEntity mejor = null;
        double menor = VISTA * VISTA;
        for (LivingEntity otro : participantes(complejo)) {
            if (otro == bot) {
                continue;
            }
            double d2 = bot.distanceToSqr(otro);
            if (d2 < menor && bot.hasLineOfSight(otro)) {
                menor = d2;
                mejor = otro;
            }
        }
        return mejor;
    }

    /** Uno con una espada que viene atacando y está cerca (un bot que ataca, o un jugador armado). */
    @Nullable
    private static LivingEntity peligroCerca(ServerLevel complejo, JugadorBot bot) {
        LivingEntity mejor = null;
        double menor = PELIGRO * PELIGRO;
        for (LivingEntity otro : participantes(complejo)) {
            if (otro == bot) {
                continue;
            }
            boolean peligroso = otro instanceof JugadorBot otroBot ? ATACA.getOrDefault(otroBot.getUUID(), false)
                    : esEspadaPastel(otro.getMainHandItem()) && bot.distanceToSqr(otro) < 6.0 * 6.0;
            double d2 = bot.distanceToSqr(otro);
            if (peligroso && d2 < menor && bot.hasLineOfSight(otro)) {
                menor = d2;
                mejor = otro;
            }
        }
        return mejor;
    }

    // ------------------------------------------------------------------ muertes y golpes
    /** El que muere esta noche queda tirado en el piso y eliminado (el premio sube, como siempre). */
    static void alMorir(LivingDeathEvent evento) {
        if (fase != Fase.PELEA && fase != Fase.APAGON && fase != Fase.ACECHO && fase != Fase.MASACRE) {
            return;
        }
        LivingEntity muerto = evento.getEntity();
        if (muerto.level().isClientSide() || !(muerto.level() instanceof ServerLevel complejo)
                || !complejo.dimension().equals(Complejo.DIMENSION) || !(muerto instanceof JugadorBot || muerto instanceof Player)
                || !enLaSala(muerto)) {
            return;
        }
        muertos++;
        if (fase == Fase.MASACRE) {
            muertosMasacre++;
        }
        Entity fuente = evento.getSource().getEntity();
        Component quien = nombreDe(muerto);
        MutableComponent texto = fase == Fase.PELEA && fuente instanceof LivingEntity asesino
                ? Component.translatable("mensaje.juegosdelpatio.masacre_pelea_muerto", nombreDe(asesino), quien)
                : fase == Fase.ACECHO && fuente instanceof LivingEntity asesino
                ? Component.translatable("mensaje.juegosdelpatio.masacre_dormido", nombreDe(asesino), quien)
                : fuente instanceof LivingEntity asesino && asesino != muerto
                ? Component.translatable("mensaje.juegosdelpatio.masacre_mato", nombreDe(asesino), quien)
                : Component.translatable("mensaje.juegosdelpatio.masacre_murio", quien);
        Cuerpo.dejar(complejo, muerto, 0);                             // queda tirado en el piso...
        muerto.setInvisible(true);                                     // ...y el que muere ya no se ve
        ATACA.remove(muerto.getUUID());
        OBJETIVO.remove(muerto.getUUID());
        ESPERA.remove(muerto.getUUID());
        Juego.anotarEliminado(complejo, muerto, "masacre_te_mataron");
        decir(complejo, texto.withStyle(ChatFormatting.DARK_RED), muerto);
    }

    /**
     * En la masacre, al que huye y le pegan a veces se defiende (y ataca él también). Después de la masacre, en la
     * sala está prohibido pelear: el golpe no hace nada.
     */
    static void alRecibirGolpe(LivingIncomingDamageEvent evento) {
        LivingEntity victimaGolpe = evento.getEntity();
        if (victimaGolpe.level().isClientSide() || !(victimaGolpe instanceof JugadorBot || victimaGolpe instanceof Player)
                || !(evento.getSource().getEntity() instanceof LivingEntity atacante) || atacante == victimaGolpe
                || !(atacante instanceof JugadorBot || atacante instanceof Player)
                || !victimaGolpe.level().dimension().equals(Complejo.DIMENSION) || !enLaSala(victimaGolpe)) {
            return;
        }
        if (prohibido) {
            evento.setCanceled(true);
            if (atacante instanceof ServerPlayer jugador) {
                jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.masacre_prohibido")
                        .withStyle(ChatFormatting.RED), true);
            }
            return;
        }
        if (fase == Fase.MASACRE && victimaGolpe instanceof JugadorBot bot && !ATACA.getOrDefault(bot.getUUID(), false)
                && muertosMasacre < tope() && bot.getRandom().nextFloat() < SE_DEFIENDEN) {
            ATACA.put(bot.getUUID(), true);                            // se defiende: ahora ataca él
            OBJETIVO.put(bot.getUUID(), atacante.getUUID());
            armar(bot);
        }
    }

    static void alParar(ServerStoppedEvent evento) {
        olvidar();
        fase = Fase.NINGUNA;
        prohibido = false;
    }

    private static void olvidar() {
        tiempo = 0;
        ganador = null;
        perdedor = null;
        victima = null;
        esperaGolpe = 0;
        muertos = 0;
        muertosMasacre = 0;
        botsAlEmpezar = 0;
        ATACA.clear();
        OBJETIVO.clear();
        ESPERA.clear();
    }

    // ------------------------------------------------------------------ ayudas
    static boolean enLaSala(Entity quien) {
        double x = quien.getX();
        double z = quien.getZ();
        return SALA.contains(quien.position()) && !(Math.abs(x) <= 5.5 && z <= -5.0);   // (sin el pasillo de los guardias)
    }

    private static List<JugadorBot> botsEnLaSala(ServerLevel complejo) {
        return new ArrayList<>(complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> bot.isAlive() && enLaSala(bot)));
    }

    private static List<ServerPlayer> jugadoresEnLaSala(ServerLevel complejo) {
        List<ServerPlayer> lista = new ArrayList<>();
        for (ServerPlayer jugador : complejo.players()) {
            if (enLaSala(jugador)) {
                lista.add(jugador);
            }
        }
        return lista;
    }

    /** Los que pueden pelear en la sala esta noche: bots y jugadores vivos (sin los que miran o están en creativo). */
    private static List<LivingEntity> participantes(ServerLevel complejo) {
        List<LivingEntity> lista = new ArrayList<>(botsEnLaSala(complejo));
        for (ServerPlayer jugador : jugadoresEnLaSala(complejo)) {
            if (jugador.isAlive() && !jugador.isSpectator() && !jugador.isCreative()) {
                lista.add(jugador);
            }
        }
        return lista;
    }

    @Nullable
    private static LivingEntity buscar(ServerLevel complejo, UUID id) {
        ServerPlayer jugador = complejo.getServer().getPlayerList().getPlayer(id);
        if (jugador != null) {
            return jugador.level() == complejo && jugador.isAlive() ? jugador : null;
        }
        return complejo.getEntity(id) instanceof LivingEntity otro && otro.isAlive() ? otro : null;
    }

    private static void irA(JugadorBot bot, Vec3 lugar, double velocidad, double cerca) {
        if (bot.distanceToSqr(lugar.x, lugar.y, lugar.z) > cerca * cerca) {
            if (bot.getNavigation().isDone() || bot.tickCount % 20 == 0) {
                bot.getNavigation().moveTo(lugar.x, lugar.y, lugar.z, velocidad);
            }
        } else if (!bot.getNavigation().isDone()) {
            bot.getNavigation().stop();
        }
    }

    private static void pararse(JugadorBot bot) {
        if (bot.isShiftKeyDown() || bot.getPose() == Pose.CROUCHING) {
            bot.setShiftKeyDown(false);
            bot.setPose(Pose.STANDING);
        }
    }

    private static Component nombreDe(LivingEntity quien) {
        return quien instanceof JugadorBot bot ? Component.literal(bot.nombre()) : quien.getName();
    }

    /** Un mensaje en el chat para todos los del complejo (menos {@code salvo}). */
    private static void decir(ServerLevel complejo, Component texto, @Nullable LivingEntity salvo) {
        for (ServerPlayer jugador : complejo.players()) {
            if (jugador != salvo) {
                jugador.sendSystemMessage(texto);
            }
        }
    }
}
