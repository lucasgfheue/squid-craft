package com.juegosdelpatio;

import java.util.Optional;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec3;

/** La dimensión del complejo: entrar, salir, colocar el dormitorio y poblarlo de bots. */
public final class Complejo {
    public static final ResourceKey<Level> DIMENSION = ResourceKey.create(Registries.DIMENSION, id("complejo"));
    public static final ResourceLocation DORMITORIO = id("dormitorio");

    /** Subir este número cada vez que cambia dormitorio.nbt: la sala se rehace sola en los mundos viejos. */
    public static final int VERSION_SALA = 7;
    /** Subir este número cuando cambian los bots: en los mundos viejos se reemplazan solos. */
    public static final int VERSION_BOTS = 2;
    public static final int MAX_BOTS = 150;

    /** Esquina de la plantilla (65 x 21 x 102 bloques: baños y comedor delante, salón detrás). */
    public static final BlockPos ORIGEN_DORMITORIO = new BlockPos(-32, 64, -33);

    /** Punto de llegada: frente al portón, mirando hacia las literas. */
    private static final double LLEGADA_X = 0.5;
    private static final double LLEGADA_Y = 65.0;
    private static final double LLEGADA_Z = 0.5;

    /** Lugares a los que van a pasear los bots (coordenadas del complejo). */
    private static final Vec3[] LUGARES = {
            new Vec3(0.5, 65, 32.5),     // centro de la plaza
            new Vec3(0.5, 65, 20.5),     // rayuela
            new Vec3(0.5, 65, 4.5),      // frente al portón
            new Vec3(20.5, 65, -12.5),   // comedor
            new Vec3(-24.5, 65, -15.5),  // baños
            new Vec3(-27.5, 65, 40.5),   // pasillo de literas (izquierda)
            new Vec3(28.5, 65, 40.5),    // pasillo de literas (derecha)
            new Vec3(-20.5, 65, 52.5),   // literas del fondo (izquierda)
            new Vec3(21.5, 65, 52.5),    // literas del fondo (derecha)
            new Vec3(0.5, 65, 62.5),     // bajo el barrilete
    };

    private Complejo() {
    }

    static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID, ruta);
    }

    public static boolean estaDentro(ServerPlayer jugador) {
        return jugador.level().dimension().equals(DIMENSION);
    }

    public static void usarInvitacion(ServerPlayer jugador) {
        if (estaDentro(jugador)) {
            salir(jugador);
        } else {
            entrar(jugador);
        }
    }

    public static void entrar(ServerPlayer jugador) {
        if (estaDentro(jugador)) {
            aviso(jugador, "mensaje.juegosdelpatio.ya_dentro");
            return;
        }
        ServerLevel complejo = jugador.server.getLevel(DIMENSION);
        if (complejo == null) {
            error(jugador, "mensaje.juegosdelpatio.sin_dimension");
            return;
        }
        if (!prepararComplejo(complejo, false)) {
            error(jugador, "mensaje.juegosdelpatio.sin_sala");
            return;
        }

        jugador.setData(Registro.RETORNO, new PosicionRetorno(Optional.of(jugador.level().dimension()),
                jugador.getX(), jugador.getY(), jugador.getZ(), jugador.getYRot(), jugador.getXRot()));
        jugador.teleportTo(complejo, LLEGADA_X, LLEGADA_Y, LLEGADA_Z, 0.0F, 0.0F);
        darUniforme(jugador);

        // "Despertar" en el dormitorio
        jugador.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
        jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
        jugador.connection.send(new ClientboundSetSubtitleTextPacket(
                Component.translatable("titulo.juegosdelpatio.dormitorio").withStyle(ChatFormatting.GRAY)));
        jugador.connection.send(new ClientboundSetTitleTextPacket(
                Component.translatable("titulo.juegosdelpatio.bienvenido")));
        jugador.playNotifySound(SoundEvents.BELL_RESONATE, SoundSource.PLAYERS, 1.0F, 0.7F);
    }

    public static void salir(ServerPlayer jugador) {
        if (!estaDentro(jugador)) {
            aviso(jugador, "mensaje.juegosdelpatio.no_dentro");
            return;
        }
        MinecraftServer servidor = jugador.server;
        PosicionRetorno retorno = jugador.getData(Registro.RETORNO);
        ServerLevel destino = retorno.dimension().map(servidor::getLevel).orElse(null);
        double x = retorno.x();
        double y = retorno.y();
        double z = retorno.z();
        float yRot = retorno.yRot();
        float xRot = retorno.xRot();

        if (destino == null || destino.dimension().equals(DIMENSION)) {
            // No sabemos de dónde vino: lo mandamos al punto de aparición del mundo
            destino = servidor.overworld();
            BlockPos aparicion = destino.getSharedSpawnPos();
            destino.getChunk(aparicion);
            BlockPos suelo = destino.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, aparicion);
            x = suelo.getX() + 0.5;
            y = suelo.getY();
            z = suelo.getZ() + 0.5;
            yRot = jugador.getYRot();
            xRot = jugador.getXRot();
        }

        jugador.setData(Registro.RETORNO, PosicionRetorno.NINGUNA);
        jugador.teleportTo(destino, x, y, z, yRot, xRot);
        jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 1.0F, 1.3F);
    }

    // ------------------------------------------------------------------ sala y bots

    /**
     * Deja el complejo listo: si la sala no existe o es de una versión anterior, la vuelve a colocar
     * y crea los bots. Con {@code forzar} la rehace siempre.
     */
    public static boolean prepararComplejo(ServerLevel complejo, boolean forzar) {
        EstadoComplejo estado = EstadoComplejo.de(complejo.getServer());
        if (forzar || estado.versionSala() != VERSION_SALA) {
            if (!colocarSala(complejo)) {
                return false;
            }
            estado.setVersionSala(VERSION_SALA);
            estado.setVersionBots(-1);
        }
        if (estado.versionBots() != VERSION_BOTS) {
            generarBots(complejo, MAX_BOTS);
            estado.setVersionBots(VERSION_BOTS);
        }
        return true;
    }

    private static boolean colocarSala(ServerLevel complejo) {
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(DORMITORIO);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", DORMITORIO);
            return false;
        }
        // Vacía el espacio primero, así no quedan restos de una versión anterior de la sala
        Vec3i tamano = plantilla.get().getSize();
        BlockPos fin = ORIGEN_DORMITORIO.offset(tamano.getX() - 1, tamano.getY() - 1, tamano.getZ() - 1);
        for (BlockPos pos : BlockPos.betweenClosed(ORIGEN_DORMITORIO, fin)) {
            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
        }
        plantilla.get().placeInWorld(complejo, ORIGEN_DORMITORIO, ORIGEN_DORMITORIO,
                new StructurePlaceSettings(), complejo.getRandom(), Block.UPDATE_CLIENTS);
        JuegosDelPatio.LOGGER.info("Dormitorio colocado en {} {}", DIMENSION.location(), ORIGEN_DORMITORIO);
        return true;
    }

    /** Reemplaza a todos los bots por una tanda nueva de {@code cantidad} (máximo 150). */
    public static int generarBots(ServerLevel complejo, int cantidad) {
        EstadoComplejo.de(complejo.getServer()).nuevaGeneracion();
        for (JugadorBot viejo : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> true)) {
            viejo.discard();
        }
        int total = Math.max(0, Math.min(cantidad, MAX_BOTS));
        RandomSource azar = complejo.getRandom();
        for (int i = 0; i < total; i++) {
            JugadorBot bot = Registro.JUGADOR_BOT.get().create(complejo);
            if (bot == null) {
                continue;
            }
            double x = -16.5 + azar.nextInt(34);
            double z = 3.5 + azar.nextInt(58);
            BlockPos pos = BlockPos.containing(x, 65, z);
            complejo.getChunkAt(pos);
            bot.moveTo(x, 65.0, z, azar.nextFloat() * 360.0F, 0.0F);
            bot.finalizeSpawn(complejo, complejo.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null);
            complejo.addFreshEntity(bot);
        }
        return total;
    }

    public static Vec3 lugarAlAzar(RandomSource azar) {
        Vec3 lugar = LUGARES[azar.nextInt(LUGARES.length)];
        return lugar.add(azar.nextInt(5) - 2, 0, azar.nextInt(5) - 2);
    }

    // ------------------------------------------------------------------ uniforme

    /** Le pone el uniforme al jugador si todavía no tiene ninguna prenda. */
    public static void darUniforme(ServerPlayer jugador) {
        Set<Item> prendas = Set.of(Registro.UNIFORME_CAMISA.get(), Registro.UNIFORME_PANTALON.get(),
                Registro.UNIFORME_ZAPATILLAS.get());
        if (jugador.getInventory().hasAnyOf(prendas)) {
            return;
        }
        ponerPrenda(jugador, EquipmentSlot.CHEST, Registro.UNIFORME_CAMISA.get());
        ponerPrenda(jugador, EquipmentSlot.LEGS, Registro.UNIFORME_PANTALON.get());
        ponerPrenda(jugador, EquipmentSlot.FEET, Registro.UNIFORME_ZAPATILLAS.get());
    }

    private static void ponerPrenda(ServerPlayer jugador, EquipmentSlot lugar, Item prenda) {
        ItemStack objeto = new ItemStack(prenda);
        if (jugador.getItemBySlot(lugar).isEmpty()) {
            jugador.setItemSlot(lugar, objeto);
        } else if (!jugador.getInventory().add(objeto)) {
            jugador.drop(objeto, false);
        }
    }

    private static void aviso(ServerPlayer jugador, String clave) {
        jugador.displayClientMessage(Component.translatable(clave).withStyle(ChatFormatting.GRAY), true);
    }

    private static void error(ServerPlayer jugador, String clave) {
        jugador.sendSystemMessage(Component.translatable(clave).withStyle(ChatFormatting.RED));
    }
}
