package com.juegosdelpatio;

import java.util.Optional;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec3;

/** La dimensión del complejo: entrar, salir, colocar el dormitorio y poblarlo de bots y guardias. */
public final class Complejo {
    public static final ResourceKey<Level> DIMENSION = ResourceKey.create(Registries.DIMENSION, id("complejo"));
    public static final ResourceLocation DORMITORIO = id("dormitorio");

    /** Subir este número cada vez que cambia dormitorio.nbt: la sala se rehace sola en los mundos viejos. */
    public static final int VERSION_SALA = 8;
    /** Subir este número cuando cambian los bots: en los mundos viejos se reemplazan solos. */
    public static final int VERSION_BOTS = 2;
    public static final int MAX_BOTS = 150;
    /** Subir este número cuando cambian los guardias: en los mundos viejos se reemplazan solos. */
    public static final int VERSION_GUARDIAS = 1;
    public static final int GUARDIAS_POR_DEFECTO = 16;
    public static final int MAX_GUARDIAS = 40;

    // ------------------------------------------------------------------ calendario (días del mundo normal)
    /** Las puertas abren un día de cada {@code CICLO_DIAS}: el día 0, el 6, el 12... Los otros días no se puede entrar. */
    public static final int CICLO_DIAS = 6;
    /** Atardecer (como /time set 12500): a esta hora del día de entrada empieza la ceremonia de bienvenida. */
    public static final long HORA_CEREMONIA = 12500L;
    /** Si a medianoche todavía no hubo ceremonia (no había nadie adentro), ese día ya no se hace. */
    public static final long FIN_CEREMONIA = 18000L;
    /** Lo que anuncia el comandante. */
    public static final int JUEGOS = 5;
    public static final int PREMIO_DIAMANTES = 1000;

    // ------------------------------------------------------------------ portón (puerta que sube como un rastrillo)
    public static final int PORTON_X0 = -4;
    public static final int PORTON_X1 = 4;
    public static final int PORTON_Y = 65;
    public static final int PORTON_Z = -5;
    public static final int PORTON_ALTO = 9;

    /** Esquina de la plantilla (65 x 21 x 102 bloques: baños y comedor delante, salón detrás). */
    public static final BlockPos ORIGEN_DORMITORIO = new BlockPos(-32, 64, -33);

    /** Punto de llegada: frente al portón, mirando hacia las literas. */
    private static final double LLEGADA_X = 0.5;
    private static final double LLEGADA_Y = 65.0;
    private static final double LLEGADA_Z = 0.5;

    /** Lugares a los que van a pasear los bots (coordenadas del complejo). */
    private static final Vec3[] LUGARES = {
            new Vec3(0.5, 65, 32.5),     // centro de la plaza
            new Vec3(0.5, 65, 20.5),     // rayuela
            new Vec3(0.5, 65, 4.5),      // frente al portón
            new Vec3(20.5, 65, -12.5),   // comedor
            new Vec3(-24.5, 65, -15.5),  // baños
            new Vec3(-27.5, 65, 40.5),   // pasillo de literas (izquierda)
            new Vec3(28.5, 65, 40.5),    // pasillo de literas (derecha)
            new Vec3(-20.5, 65, 52.5),   // literas del fondo (izquierda)
            new Vec3(21.5, 65, 52.5),    // literas del fondo (derecha)
            new Vec3(0.5, 65, 62.5),     // bajo el barrilete
    };

    /** Puestos de guardia (coordenadas del complejo). */
    private static final Vec3[] PUESTOS = {
            new Vec3(0.5, 65, 32.5),     // centro de la plaza
            new Vec3(-19.5, 65, -1.5),   // puerta de los baños
            new Vec3(20.5, 65, -1.5),    // puerta del comedor
            new Vec3(-6.5, 65, -1.5),    // portón, lado izquierdo
            new Vec3(7.5, 65, -1.5),     // portón, lado derecho
            new Vec3(20.5, 65, -20.5),   // dentro del comedor
            new Vec3(-24.5, 65, -15.5),  // dentro de los baños
            new Vec3(-27.5, 65, 32.5),   // pasillo de literas (izquierda)
            new Vec3(28.5, 65, 32.5),    // pasillo de literas (derecha)
            new Vec3(-27.5, 65, 50.5),   // pasillo del fondo (izquierda)
            new Vec3(28.5, 65, 50.5),    // pasillo del fondo (derecha)
            new Vec3(-17.5, 65, 24.5),   // plaza, adelante a la izquierda
            new Vec3(18.5, 65, 24.5),    // plaza, adelante a la derecha
            new Vec3(0.5, 65, 62.5),     // bajo el barrilete
            new Vec3(-17.5, 65, 58.5),   // plaza, al fondo a la izquierda
            new Vec3(18.5, 65, 58.5),    // plaza, al fondo a la derecha
    };

    /** Rangos de la tanda: muchos vigilantes y guardias, algunos sargentos (el comandante solo viene a las ceremonias). */
    private static final Rango[] TANDA = {Rango.GUARDIA, Rango.VIGILANTE, Rango.SARGENTO, Rango.VIGILANTE, Rango.GUARDIA};

    private Complejo() {
    }

    static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID, ruta);
    }

    public static boolean estaDentro(ServerPlayer jugador) {
        return jugador.level().dimension().equals(DIMENSION);
    }

    public static void usarInvitacion(ServerPlayer jugador) {
        if (estaDentro(jugador)) {
            salir(jugador);
        } else {
            entrar(jugador, false);
        }
    }

    /** Día del mundo normal (el mismo número que muestra F3). */
    public static long diaActual(MinecraftServer servidor) {
        return servidor.overworld().getDayTime() / 24000L;
    }

    public static boolean esDiaDeEntrada(long dia) {
        return dia % CICLO_DIAS == 0;
    }

    /**
     * Lleva al jugador al dormitorio. Con la invitación solo se puede los días de entrada (0, 6, 12...);
     * el comando de operador ({@code ignorarHorario}) entra cualquier día.
     */
    public static void entrar(ServerPlayer jugador, boolean ignorarHorario) {
        if (estaDentro(jugador)) {
            aviso(jugador, "mensaje.juegosdelpatio.ya_dentro");
            return;
        }
        long hoy = diaActual(jugador.server);
        if (!ignorarHorario && !esDiaDeEntrada(hoy)) {
            long proximo = (hoy / CICLO_DIAS + 1) * CICLO_DIAS;
            jugador.displayClientMessage(Component.translatable("mensaje.juegosdelpatio.cerrado", proximo, hoy)
                    .withStyle(ChatFormatting.RED), true);
            jugador.playNotifySound(SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.0F, 0.7F);
            return;
        }
        ServerLevel complejo = jugador.server.getLevel(DIMENSION);
        if (complejo == null) {
            error(jugador, "mensaje.juegosdelpatio.sin_dimension");
            return;
        }
        if (!prepararComplejo(complejo, false)) {
            error(jugador, "mensaje.juegosdelpatio.sin_sala");
            return;
        }

        jugador.setData(Registro.RETORNO, new PosicionRetorno(Optional.of(jugador.level().dimension()),
                jugador.getX(), jugador.getY(), jugador.getZ(), jugador.getYRot(), jugador.getXRot()));
        jugador.teleportTo(complejo, LLEGADA_X, LLEGADA_Y, LLEGADA_Z, 0.0F, 0.0F);
        darUniforme(jugador);

        // "Despertar" en el dormitorio
        jugador.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
        jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
        jugador.connection.send(new ClientboundSetSubtitleTextPacket(
                Component.translatable("titulo.juegosdelpatio.dormitorio").withStyle(ChatFormatting.GRAY)));
        jugador.connection.send(new ClientboundSetTitleTextPacket(
                Component.translatable("titulo.juegosdelpatio.bienvenido")));
        jugador.playNotifySound(SoundEvents.BELL_RESONATE, SoundSource.PLAYERS, 1.0F, 0.7F);
    }

    public static void salir(ServerPlayer jugador) {
        if (!estaDentro(jugador)) {
            aviso(jugador, "mensaje.juegosdelpatio.no_dentro");
            return;
        }
        MinecraftServer servidor = jugador.server;
        PosicionRetorno retorno = jugador.getData(Registro.RETORNO);
        ServerLevel destino = retorno.dimension().map(servidor::getLevel).orElse(null);
        double x = retorno.x();
        double y = retorno.y();
        double z = retorno.z();
        float yRot = retorno.yRot();
        float xRot = retorno.xRot();

        if (destino == null || destino.dimension().equals(DIMENSION)) {
            // No sabemos de dónde vino: lo mandamos al punto de aparición del mundo
            destino = servidor.overworld();
            BlockPos aparicion = destino.getSharedSpawnPos();
            destino.getChunk(aparicion);
            BlockPos suelo = destino.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, aparicion);
            x = suelo.getX() + 0.5;
            y = suelo.getY();
            z = suelo.getZ() + 0.5;
            yRot = jugador.getYRot();
            xRot = jugador.getXRot();
        }

        jugador.setData(Registro.RETORNO, PosicionRetorno.NINGUNA);
        jugador.teleportTo(destino, x, y, z, yRot, xRot);
        jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 1.0F, 1.3F);
    }

    // ------------------------------------------------------------------ sala y bots

    /**
     * Deja el complejo listo: si la sala no existe o es de una versión anterior, la vuelve a colocar
     * y crea los bots. Con {@code forzar} la rehace siempre.
     */
    public static boolean prepararComplejo(ServerLevel complejo, boolean forzar) {
        EstadoComplejo estado = EstadoComplejo.de(complejo.getServer());
        if (forzar || estado.versionSala() != VERSION_SALA) {
            if (!colocarSala(complejo)) {
                return false;
            }
            estado.setVersionSala(VERSION_SALA);
            estado.setVersionBots(-1);
            estado.setVersionGuardias(-1);
        }
        if (estado.versionBots() != VERSION_BOTS) {
            generarBots(complejo, MAX_BOTS);
            estado.setVersionBots(VERSION_BOTS);
        }
        if (estado.versionGuardias() != VERSION_GUARDIAS) {
            generarGuardias(complejo, GUARDIAS_POR_DEFECTO);
            estado.setVersionGuardias(VERSION_GUARDIAS);
        }
        return true;
    }

    private static boolean colocarSala(ServerLevel complejo) {
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(DORMITORIO);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", DORMITORIO);
            return false;
        }
        // Vacía el espacio primero, así no quedan restos de una versión anterior de la sala
        Vec3i tamano = plantilla.get().getSize();
        BlockPos fin = ORIGEN_DORMITORIO.offset(tamano.getX() - 1, tamano.getY() - 1, tamano.getZ() - 1);
        for (BlockPos pos : BlockPos.betweenClosed(ORIGEN_DORMITORIO, fin)) {
            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
        }
        plantilla.get().placeInWorld(complejo, ORIGEN_DORMITORIO, ORIGEN_DORMITORIO,
                new StructurePlaceSettings(), complejo.getRandom(), Block.UPDATE_CLIENTS);
        JuegosDelPatio.LOGGER.info("Dormitorio colocado en {} {}", DIMENSION.location(), ORIGEN_DORMITORIO);
        return true;
    }

    /** Reemplaza a todos los bots por una tanda nueva de {@code cantidad} (máximo 150). */
    public static int generarBots(ServerLevel complejo, int cantidad) {
        EstadoComplejo.de(complejo.getServer()).nuevaGeneracion();
        for (JugadorBot viejo : complejo.getEntities(Registro.JUGADOR_BOT.get(), bot -> true)) {
            viejo.discard();
        }
        int total = Math.max(0, Math.min(cantidad, MAX_BOTS));
        RandomSource azar = complejo.getRandom();
        for (int i = 0; i < total; i++) {
            JugadorBot bot = Registro.JUGADOR_BOT.get().create(complejo);
            if (bot == null) {
                continue;
            }
            double x = -16.5 + azar.nextInt(34);
            double z = 3.5 + azar.nextInt(58);
            BlockPos pos = BlockPos.containing(x, 65, z);
            complejo.getChunkAt(pos);
            bot.moveTo(x, 65.0, z, azar.nextFloat() * 360.0F, 0.0F);
            bot.finalizeSpawn(complejo, complejo.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null);
            complejo.addFreshEntity(bot);
        }
        return total;
    }

    /**
     * Reemplaza a los guardias del complejo por una tanda nueva de {@code cantidad} (máximo 40), repartidos en los
     * puestos. Los guardias puestos a mano (huevo o comando) y los de la ceremonia no se tocan.
     */
    public static int generarGuardias(ServerLevel complejo, int cantidad) {
        int tanda = EstadoComplejo.de(complejo.getServer()).nuevaGeneracionGuardias();
        for (Guardia viejo : complejo.getEntities(Registro.GUARDIA.get(), Guardia::esDeLaTanda)) {
            viejo.discard();
        }
        int total = Math.max(0, Math.min(cantidad, MAX_GUARDIAS));
        RandomSource azar = complejo.getRandom();
        for (int i = 0; i < total; i++) {
            Rango rango = TANDA[i % TANDA.length];
            Vec3 puesto = PUESTOS[i % PUESTOS.length];
            int vuelta = i / PUESTOS.length;                // si hay más guardias que puestos, se ponen al lado
            puesto = puesto.add(vuelta == 1 ? 1.0 : vuelta == 2 ? -1.0 : 0.0, 0.0, 0.0);
            invocarGuardia(complejo, puesto, azar.nextFloat() * 360.0F, rango, tanda);
        }
        return total;
    }

    /** Crea un guardia de un rango en un lugar. Con {@code tanda} -1 queda fijo (no se borra al regenerar). */
    @Nullable
    public static Guardia invocarGuardia(ServerLevel nivel, Vec3 lugar, float giro, Rango rango, int tanda) {
        Guardia guardia = Registro.GUARDIA.get().create(nivel);
        if (guardia == null) {
            return null;
        }
        BlockPos pos = BlockPos.containing(lugar.x, lugar.y, lugar.z);
        nivel.getChunkAt(pos);
        guardia.moveTo(lugar.x, lugar.y, lugar.z, giro, 0.0F);
        guardia.finalizeSpawn(nivel, nivel.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null);
        guardia.configurar(rango, lugar, tanda);
        nivel.addFreshEntity(guardia);
        return guardia;
    }

    // ------------------------------------------------------------------ portón

    /**
     * Pone la puerta del portón a una altura: 0 = cerrada, {@link #PORTON_ALTO} = abierta del todo
     * (escondida dentro del muro). Mismo dibujo que en dormitorio.nbt.
     */
    public static void ponerPorton(ServerLevel nivel, int subida) {
        for (int fila = 0; fila < 2 * PORTON_ALTO; fila++) {
            int filaPuerta = fila - subida;
            for (int x = PORTON_X0; x <= PORTON_X1; x++) {
                BlockState estado = filaPuerta >= 0 && filaPuerta < PORTON_ALTO
                        ? bloquePuerta(x, filaPuerta) : Blocks.AIR.defaultBlockState();
                BlockPos pos = new BlockPos(x, PORTON_Y + fila, PORTON_Z);
                if (nivel.getBlockState(pos) != estado) {
                    nivel.setBlock(pos, estado, Block.UPDATE_CLIENTS);
                }
            }
        }
    }

    private static BlockState bloquePuerta(int x, int fila) {
        return x == PORTON_X0 || x == PORTON_X1 || fila % 4 == 0
                ? Blocks.POLISHED_BLACKSTONE.defaultBlockState()
                : Blocks.IRON_BLOCK.defaultBlockState();
    }

    /** true si el portón está bien cerrado (o si esa parte del mundo no está cargada). */
    public static boolean portonCerrado(ServerLevel nivel) {
        BlockPos abajo = new BlockPos(0, PORTON_Y, PORTON_Z);
        BlockPos arriba = new BlockPos(0, PORTON_Y + PORTON_ALTO, PORTON_Z);
        if (!nivel.isLoaded(abajo) || !nivel.isLoaded(arriba)) {
            return true;
        }
        return !nivel.getBlockState(abajo).isAir() && nivel.getBlockState(arriba).isAir();
    }

    public static Vec3 puestoAlAzar(RandomSource azar) {
        return PUESTOS[azar.nextInt(PUESTOS.length)];
    }

    public static Vec3 lugarAlAzar(RandomSource azar) {
        Vec3 lugar = LUGARES[azar.nextInt(LUGARES.length)];
        return lugar.add(azar.nextInt(5) - 2, 0, azar.nextInt(5) - 2);
    }

    // ------------------------------------------------------------------ uniforme

    /** Le pone el uniforme al jugador si todavía no tiene ninguna prenda. */
    public static void darUniforme(ServerPlayer jugador) {
        Set<Item> prendas = Set.of(Registro.UNIFORME_CAMISA.get(), Registro.UNIFORME_PANTALON.get(),
                Registro.UNIFORME_ZAPATILLAS.get());
        if (jugador.getInventory().hasAnyOf(prendas)) {
            return;
        }
        ponerPrenda(jugador, EquipmentSlot.CHEST, Registro.UNIFORME_CAMISA.get());
        ponerPrenda(jugador, EquipmentSlot.LEGS, Registro.UNIFORME_PANTALON.get());
        ponerPrenda(jugador, EquipmentSlot.FEET, Registro.UNIFORME_ZAPATILLAS.get());
    }

    private static void ponerPrenda(ServerPlayer jugador, EquipmentSlot lugar, Item prenda) {
        ItemStack objeto = new ItemStack(prenda);
        if (jugador.getItemBySlot(lugar).isEmpty()) {
            jugador.setItemSlot(lugar, objeto);
        } else if (!jugador.getInventory().add(objeto)) {
            jugador.drop(objeto, false);
        }
    }

    private static void aviso(ServerPlayer jugador, String clave) {
        jugador.displayClientMessage(Component.translatable(clave).withStyle(ChatFormatting.GRAY), true);
    }

    private static void error(ServerPlayer jugador, String clave) {
        jugador.sendSystemMessage(Component.translatable(clave).withStyle(ChatFormatting.RED));
    }
}
