package com.juegosdelpatio;

import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

/** La dimensión del complejo: entrar, salir y colocar el dormitorio. */
public final class Complejo {
    public static final ResourceKey<Level> DIMENSION = ResourceKey.create(Registries.DIMENSION, id("complejo"));
    public static final ResourceLocation DORMITORIO = id("dormitorio");

    /** Esquina de la plantilla (65 x 21 x 102 bloques: baños y comedor delante, salón detrás). */
    public static final BlockPos ORIGEN_DORMITORIO = new BlockPos(-32, 64, -33);

    /** Punto de llegada: frente al portón, mirando hacia las literas. */
    private static final double LLEGADA_X = 0.5;
    private static final double LLEGADA_Y = 65.0;
    private static final double LLEGADA_Z = 0.5;

    private Complejo() {
    }

    static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(JuegosDelPatio.MODID, ruta);
    }

    public static boolean estaDentro(ServerPlayer jugador) {
        return jugador.level().dimension().equals(DIMENSION);
    }

    public static void usarInvitacion(ServerPlayer jugador) {
        if (estaDentro(jugador)) {
            salir(jugador);
        } else {
            entrar(jugador);
        }
    }

    public static void entrar(ServerPlayer jugador) {
        if (estaDentro(jugador)) {
            aviso(jugador, "mensaje.juegosdelpatio.ya_dentro");
            return;
        }
        ServerLevel complejo = jugador.server.getLevel(DIMENSION);
        if (complejo == null) {
            error(jugador, "mensaje.juegosdelpatio.sin_dimension");
            return;
        }
        if (!construirSiFalta(complejo, false)) {
            error(jugador, "mensaje.juegosdelpatio.sin_sala");
            return;
        }

        jugador.setData(Registro.RETORNO, new PosicionRetorno(Optional.of(jugador.level().dimension()),
                jugador.getX(), jugador.getY(), jugador.getZ(), jugador.getYRot(), jugador.getXRot()));
        jugador.teleportTo(complejo, LLEGADA_X, LLEGADA_Y, LLEGADA_Z, 0.0F, 0.0F);

        // "Despertar" en el dormitorio
        jugador.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
        jugador.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
        jugador.connection.send(new ClientboundSetSubtitleTextPacket(
                Component.translatable("titulo.juegosdelpatio.dormitorio").withStyle(ChatFormatting.GRAY)));
        jugador.connection.send(new ClientboundSetTitleTextPacket(
                Component.translatable("titulo.juegosdelpatio.bienvenido")));
        jugador.playNotifySound(SoundEvents.BELL_RESONATE, SoundSource.PLAYERS, 1.0F, 0.7F);
    }

    public static void salir(ServerPlayer jugador) {
        if (!estaDentro(jugador)) {
            aviso(jugador, "mensaje.juegosdelpatio.no_dentro");
            return;
        }
        MinecraftServer servidor = jugador.server;
        PosicionRetorno retorno = jugador.getData(Registro.RETORNO);
        ServerLevel destino = retorno.dimension().map(servidor::getLevel).orElse(null);
        double x = retorno.x();
        double y = retorno.y();
        double z = retorno.z();
        float yRot = retorno.yRot();
        float xRot = retorno.xRot();

        if (destino == null || destino.dimension().equals(DIMENSION)) {
            // No sabemos de dónde vino: lo mandamos al punto de aparición del mundo
            destino = servidor.overworld();
            BlockPos aparicion = destino.getSharedSpawnPos();
            destino.getChunk(aparicion);
            BlockPos suelo = destino.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, aparicion);
            x = suelo.getX() + 0.5;
            y = suelo.getY();
            z = suelo.getZ() + 0.5;
            yRot = jugador.getYRot();
            xRot = jugador.getXRot();
        }

        jugador.setData(Registro.RETORNO, PosicionRetorno.NINGUNA);
        jugador.teleportTo(destino, x, y, z, yRot, xRot);
        jugador.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 1.0F, 1.3F);
    }

    /**
     * Coloca el dormitorio si todavía no existe. Con {@code forzar} lo vuelve a colocar
     * encima del que haya (sirve después de actualizar el mod).
     */
    public static boolean construirSiFalta(ServerLevel complejo, boolean forzar) {
        if (!forzar && !complejo.getBlockState(ORIGEN_DORMITORIO).isAir()) {
            return true;
        }
        Optional<StructureTemplate> plantilla = complejo.getStructureManager().get(DORMITORIO);
        if (plantilla.isEmpty()) {
            JuegosDelPatio.LOGGER.error("No se encontró la estructura {}", DORMITORIO);
            return false;
        }
        // Vacía el espacio primero, así no quedan restos de una versión anterior de la sala
        Vec3i tamano = plantilla.get().getSize();
        BlockPos fin = ORIGEN_DORMITORIO.offset(tamano.getX() - 1, tamano.getY() - 1, tamano.getZ() - 1);
        for (BlockPos pos : BlockPos.betweenClosed(ORIGEN_DORMITORIO, fin)) {
            complejo.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
        }
        plantilla.get().placeInWorld(complejo, ORIGEN_DORMITORIO, ORIGEN_DORMITORIO,
                new StructurePlaceSettings(), complejo.getRandom(), Block.UPDATE_CLIENTS);
        JuegosDelPatio.LOGGER.info("Dormitorio colocado en {} {}", DIMENSION.location(), ORIGEN_DORMITORIO);
        return true;
    }

    private static void aviso(ServerPlayer jugador, String clave) {
        jugador.displayClientMessage(Component.translatable(clave).withStyle(ChatFormatting.GRAY), true);
    }

    private static void error(ServerPlayer jugador, String clave) {
        jugador.sendSystemMessage(Component.translatable(clave).withStyle(ChatFormatting.RED));
    }
}
